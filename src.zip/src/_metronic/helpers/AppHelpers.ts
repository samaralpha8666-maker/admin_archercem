export const getInstitutionType = () => {
    // We can get it directly from localStorage if stored separately,
    // or parse the kt-auth-react-v object.
    const lsValue = localStorage.getItem('kt-auth-react-v');
    if (lsValue) {
        try {
            const auth = JSON.parse(lsValue);
            return auth?.user?.institution_type || 'SCHOOL';
        } catch (error) {
            return 'SCHOOL';
        }
    }
    return 'SCHOOL';
}

export const getAcademicLabel = () => {
    const type = getInstitutionType();
    if (type === 'COACHING') return 'Batch';
    return type === 'COLLEGE' ? 'Course' : 'Class';
}

export const getPluralAcademicLabel = () => {
    const type = getInstitutionType();
    if (type === 'COACHING') return 'Batches';
    return getAcademicLabel() === 'Course' ? 'Courses' : 'Classes';
}

export const getDepartmentLabel = () => {
    const type = getInstitutionType();
    return type === 'COLLEGE' ? 'Department' : null;
}
