import { FC } from 'react'
import { Link } from 'react-router-dom'
import { KTIcon, toAbsoluteUrl } from '../../../helpers'
import { useAuth } from '../../../../app/modules/auth'

const QuickLinks: FC = () => {
  const { currentUser } = useAuth()
  const isTeacher = currentUser?.role === 'teacher'

  return (
    <div
      className='menu menu-sub menu-sub-dropdown menu-column w-250px w-lg-325px'
      data-kt-menu='true'
    >
      <div
        className='d-flex flex-column flex-center bgi-no-repeat rounded-top px-9 py-10'
        style={{ backgroundImage: `url('${toAbsoluteUrl('media/misc/pattern-1.jpg')}')` }}
      >
        <h3 className='text-white fw-bold mb-3'>Quick Links</h3>
      </div>

      <div className='row g-0'>
        <div className='col-6'>
          <Link
            to='/students/admission'
            className='d-flex flex-column flex-center h-100 p-6 bg-hover-light border-end border-bottom text-decoration-none'
          >
            <KTIcon iconName='profile-user' className='fs-3x text-primary mb-2' />
            <span className='fs-5 fw-bold text-gray-800 mb-0'>Admission</span>
            <span className='fs-7 text-gray-500'>Student Entry</span>
          </Link>
        </div>

        <div className='col-6'>
          <Link
            to={isTeacher ? '/teacher/attendance' : '/staff/attendance'}
            className='d-flex flex-column flex-center h-100 p-6 bg-hover-light border-bottom text-decoration-none'
          >
            <KTIcon iconName='calendar-tick' className='fs-3x text-primary mb-2' />
            <span className='fs-5 fw-bold text-gray-800 mb-0'>{isTeacher ? 'Mark Attendance' : 'Staff Attend.'}</span>
            <span className='fs-7 text-gray-500'>{isTeacher ? 'Students' : 'Teachers'}</span>
          </Link>
        </div>

        <div className='col-6'>
          <Link to='/timetable/grid' className='d-flex flex-column flex-center h-100 p-6 bg-hover-light border-end text-decoration-none'>
            <KTIcon iconName='calendar-8' className='fs-3x text-primary mb-2' />
            <span className='fs-5 fw-bold text-gray-800 mb-0'>Timetable</span>
            <span className='fs-7 text-gray-500'>Schedule</span>
          </Link>
        </div>

        <div className='col-6'>
          <Link to='/fees/monthly' className='d-flex flex-column flex-center h-100 p-6 bg-hover-light text-decoration-none'>
            <KTIcon iconName='dollar' className='fs-3x text-primary mb-2' />
            <span className='fs-5 fw-bold text-gray-800 mb-0'>Fees</span>
            <span className='fs-7 text-gray-500'>Collection</span>
          </Link>
        </div>
      </div>

      <div className='py-2 text-center border-top'>
        <Link to='/dashboard' className='btn btn-color-gray-600 btn-active-color-primary'>
          To Dashboard <KTIcon iconName='arrow-right' className='fs-5' />
        </Link>
      </div>
    </div>
  )
}

export { QuickLinks }
