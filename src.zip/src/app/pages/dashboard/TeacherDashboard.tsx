import { FC, useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { Content } from '../../../_metronic/layout/components/content'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { useAuth } from '../../modules/auth'
import axios from 'axios'
import { KTIcon } from '../../../_metronic/helpers'

const API_URL = import.meta.env.VITE_APP_API_URL

interface TeacherDashboardData {
  context: {
    session_name: string
    assigned_sections: any[]
  }
  today_overview: {
    day: string
    classes_today: number
    total_students: number
    present_today: number
    absent_today: number
    attendance_percentage: number
  }
  banner_items: any[]
  upcoming_exams: any[]
  recent_notices: any[]
}

const KpiCard: FC<{ title: string; value: string | number; subtitle: string; icon: string; color: string }> = ({ title, value, subtitle, icon, color }) => (
  <div className={`card card-xl-stretch bg-light-${color} border-0`}>
    <div className='card-body py-7 px-8'>
      <div className='d-flex align-items-center justify-content-between mb-4'>
        <div className={`symbol symbol-50px`}>
          <div className={`symbol-label bg-${color}`}>
            <KTIcon iconName={icon} className='fs-2x text-white' />
          </div>
        </div>
      </div>
      <div className={`text-${color} fw-bolder fs-2hx lh-1 mb-1`}>{value}</div>
      <div className={`text-${color} fw-semibold fs-6 opacity-75`}>{title}</div>
      <div className={`text-${color} fw-bold fs-8 opacity-50 mt-1`}>{subtitle}</div>
    </div>
  </div>
)

const TeacherDashboard: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')
  const [data, setData] = useState<TeacherDashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchDashboard = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    setError(null)
    try {
      const res = await axios.get(`${API_URL}/school/${schoolId}/teacher-app/dashboard/stats`)
      if (res.data.success) setData(res.data.data)
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load dashboard data')
    } finally {
      setLoading(false)
    }
  }, [schoolId])

  useEffect(() => { fetchDashboard() }, [fetchDashboard])

  if (loading) {
    return (
      <Content>
        <div className='d-flex align-items-center justify-content-center' style={{ minHeight: 400 }}>
          <div className='text-center'>
            <div className='spinner-border text-primary mb-3' style={{ width: 48, height: 48 }}></div>
            <div className='text-muted fw-semibold'>Loading My Workspace...</div>
          </div>
        </div>
      </Content>
    )
  }

  if (error || !data) {
    return (
      <Content>
        <div className='alert alert-danger d-flex align-items-center'>
          <KTIcon iconName='information-5' className='fs-2x text-danger me-3' />
          <div>{error || 'No dashboard data available.'}</div>
          <button className='btn btn-sm btn-danger ms-auto' onClick={fetchDashboard}>Retry</button>
        </div>
      </Content>
    )
  }

  const { today_overview, recent_notices, upcoming_exams } = data

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* ── Welcome Banner ── */}
        <div className='card bg-primary mb-5 border-0'>
          <div className='card-body py-8 px-8 d-flex justify-content-between align-items-center'>
            <div>
              <h2 className='text-white fw-bolder fs-1 mb-2'>Welcome back, {currentUser?.first_name || 'Teacher'}! 👋</h2>
              <div className='text-white opacity-75 fs-6'>Here is your overview for {today_overview.day}. You have {today_overview.classes_today} periods scheduled for today.</div>
            </div>
            <div className='d-none d-md-block'>
              <KTIcon iconName='book' className='fs-4x text-white opacity-50' />
            </div>
          </div>
        </div>

        {/* ── KPI Cards ── */}
        <div className='row g-5 mb-5'>
          <div className='col-md-3'>
            <KpiCard
              title='Classes Today' value={today_overview.classes_today}
              subtitle='Scheduled periods' icon='time' color='info'
            />
          </div>
          <div className='col-md-3'>
            <KpiCard
              title='My Students' value={today_overview.total_students}
              subtitle='Across all assigned sections' icon='people' color='primary'
            />
          </div>
          <div className='col-md-3'>
            <KpiCard
              title="Today's Present" value={today_overview.present_today}
              subtitle={`${today_overview.attendance_percentage}% Attendance`} icon='check-circle' color='success'
            />
          </div>
          <div className='col-md-3'>
            <KpiCard
              title="Today's Absent" value={today_overview.absent_today}
              subtitle='Requires follow-up' icon='cross-circle' color='danger'
            />
          </div>
        </div>

        <div className='row g-5'>
          {/* ── Notice Board ── */}
          <div className='col-xl-6'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Notice Board</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Recent announcements & events</span>
                </h3>
              </div>
              <div className='card-body pt-3'>
                {recent_notices.length === 0 ? (
                  <div className='text-center text-muted py-10'>No recent notices.</div>
                ) : (
                  recent_notices.map((notice, idx) => (
                    <div key={notice.id} className={`d-flex align-items-start py-4 ${idx < recent_notices.length - 1 ? 'border-bottom border-gray-200' : ''}`}>
                      <div className='me-4'>
                        <span className={`badge badge-light-${notice.priority === 'HIGH' ? 'danger' : 'primary'} fs-8 px-2 py-1`}>
                          {notice.category}
                        </span>
                      </div>
                      <div className='flex-grow-1'>
                        <a href='#' className='text-gray-800 fw-bold fs-6 text-hover-primary mb-1'>{notice.title}</a>
                        <div className='text-muted fs-8'>{new Date(notice.posted_at).toLocaleDateString()}</div>
                      </div>
                      {notice.is_pinned && <KTIcon iconName='pin' className='fs-2 text-warning' />}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* ── Upcoming Exams ── */}
          <div className='col-xl-6'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Upcoming Exams</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Exams scheduled for your sections</span>
                </h3>
                <div className='card-toolbar'>
                  <Link to='/teacher/exams' className='btn btn-sm btn-light-primary'>Marks Entry</Link>
                </div>
              </div>
              <div className='card-body pt-3'>
                {upcoming_exams.length === 0 ? (
                  <div className='text-center text-muted py-10'>No upcoming exams.</div>
                ) : (
                  upcoming_exams.map((exam, idx) => (
                    <div key={idx} className={`d-flex align-items-center py-4 ${idx < upcoming_exams.length - 1 ? 'border-bottom border-gray-200' : ''}`}>
                      <div className='symbol symbol-40px bg-light-primary me-4'>
                        <span className='symbol-label fs-5 fw-bold text-primary'>
                          {new Date(exam.date).getDate()}
                        </span>
                      </div>
                      <div className='flex-grow-1'>
                        <div className='fw-bold text-gray-800 fs-6'>{exam.subject_name || 'General Exam'} ({exam.exam_type})</div>
                        <div className='text-muted fs-8'>{exam.exam_group_name} — Sec: {exam.section_name}</div>
                      </div>
                      <div className='text-end'>
                        <span className='text-gray-600 fw-semibold fs-7'>{exam.start_time.slice(0, 5)} - {exam.end_time.slice(0, 5)}</span>
                        {exam.room_no && <div className='text-muted fs-8'>Room {exam.room_no}</div>}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

      </Content>
    </>
  )
}

export { TeacherDashboard }
