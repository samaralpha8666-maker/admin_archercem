import { FC, useEffect, useState, useCallback } from 'react'
import { useIntl } from 'react-intl'
import { Link } from 'react-router-dom'
import ReactApexChart from 'react-apexcharts'
import { ApexOptions } from 'apexcharts'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../../modules/auth'
import axios from 'axios'
import { TeacherDashboard } from './TeacherDashboard'

const API_URL = import.meta.env.VITE_APP_API_URL

// ─── Types ────────────────────────────────────────────────────────────────────
interface DashboardData {
  kpis: {
    total_students: number
    active_students: number
    total_teachers: number
    today_attendance_percent: number
    today_absent_teachers: number
    pending_fee_count: number
    total_fee_expected: number
    total_fee_collected: number
    total_fee_pending_amount: number
    today_collection: number
  }
  charts: {
    attendance_trend: { date: string; present: number; absent: number }[]
    teacher_attendance_trend: { date: string; present: number; absent: number }[]
    demographics: { boys: number; girls: number }
    class_strength: { class: string; count: number }[]
    fee_monthly_trend: { month: string; collected: number }[]
    fee_status_dropdown: { PAID: number; PARTIAL: number; UNPAID: number }
    fee_payment_methods: { method: string; count: number }[]
  }
  recent_admissions: { id: number; name: string; date: string }[]
  today_absent_students: { id: number; name: string; class: string }[]
  active_notices: { id: number; title: string }[]
  today_timetable?: {
    day: string
    total_periods: number
    free_periods: number
    entries: {
      id: number
      period: { name: string; start_time: string; end_time: string; is_break: boolean; sort_order: number }
      subject: { name: string; code: string } | null
      is_free: boolean
      teacher: { id: number; name: string } | null
      room_no: string | null
      class_name: string
      section_name: string
    }[]
  }
}

// ─── KPI Card ─────────────────────────────────────────────────────────────────
const KpiCard: FC<{
  title: string; value: string | number; subtitle: string
  icon: string; color: string; trend?: string
}> = ({ title, value, subtitle, icon, color, trend }) => (
  <div className={`card card-xl-stretch bg-light-${color} border-0`}>
    <div className='card-body py-7 px-8'>
      <div className='d-flex align-items-center justify-content-between mb-4'>
        <div className={`symbol symbol-50px`}>
          <div className={`symbol-label bg-${color}`}>
            <i className={`ki-duotone ${icon} fs-2x text-white`}>
              <span className='path1'></span><span className='path2'></span><span className='path3'></span>
            </i>
          </div>
        </div>
        {trend !== undefined && (
          <span className={`badge badge-${color} fw-semibold fs-8`}>{trend}</span>
        )}
      </div>
      <div className={`text-${color} fw-bolder fs-2hx lh-1 mb-1`}>{value}</div>
      <div className={`text-${color} fw-semibold fs-6 opacity-75`}>{title}</div>
      <div className={`text-${color} fw-bold fs-8 opacity-50 mt-1`}>{subtitle}</div>
    </div>
  </div>
)

// ─── Quick Link ───────────────────────────────────────────────────────────────
const QuickLink: FC<{ to: string; icon: string; label: string; color: string }> = ({ to, icon, label, color }) => (
  <Link to={to} className={`card card-flush bg-hover-light-${color} border-0 text-center p-5 text-decoration-none`}
    style={{ transition: 'all 0.2s' }}>
    <div className={`symbol symbol-50px symbol-circle mx-auto mb-3`}>
      <div className={`symbol-label bg-light-${color}`}>
        <i className={`ki-duotone ${icon} fs-2 text-${color}`}>
          <span className='path1'></span><span className='path2'></span><span className='path3'></span>
        </i>
      </div>
    </div>
    <div className={`fw-bold fs-7 text-gray-700`}>{label}</div>
  </Link>
)

// ─── Dashboard Page ───────────────────────────────────────────────────────────
const DashboardPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchDashboard = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    setError(null)
    try {
      const res = await axios.get(`${API_URL}/school/${schoolId}/dashboard/admin`)
      if (res.data.success) setData(res.data.data)
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to load dashboard data')
    } finally {
      setLoading(false)
    }
  }, [schoolId])

  useEffect(() => { fetchDashboard() }, [fetchDashboard])

  // ─── Attendance Line Chart Options ──────────────────────────────────────────
  const attendanceTrendOptions: ApexOptions = {
    chart: { type: 'area', height: 220, toolbar: { show: false }, sparkline: { enabled: false } },
    dataLabels: { enabled: false },
    stroke: { curve: 'smooth', width: 2 },
    xaxis: {
      categories: data?.charts.attendance_trend.map(d => {
        const dt = new Date(d.date)
        return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })
      }) || [],
      labels: { style: { fontSize: '11px', colors: '#a1a5b7' } },
    },
    yaxis: { labels: { style: { fontSize: '11px', colors: '#a1a5b7' } } },
    colors: ['#009ef7', '#f1416c'],
    fill: { type: 'gradient', gradient: { opacityFrom: 0.45, opacityTo: 0.05 } },
    legend: { position: 'top', horizontalAlign: 'right', fontSize: '12px' },
    tooltip: { shared: true, intersect: false },
    grid: { borderColor: '#f1f1f4', strokeDashArray: 4 },
  }

  const attendanceTrendSeries = [
    { name: 'Present', data: data?.charts.attendance_trend.map(d => d.present) || [] },
    { name: 'Absent', data: data?.charts.attendance_trend.map(d => d.absent) || [] },
  ]

  // ─── Teacher Attendance Line Chart ──────────────────────────────────────────
  const teacherTrendOptions: ApexOptions = {
    ...attendanceTrendOptions,
    xaxis: {
      ...attendanceTrendOptions.xaxis,
      categories: data?.charts.teacher_attendance_trend.map(d => {
        const dt = new Date(d.date)
        return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })
      }) || [],
    },
    colors: ['#50cd89', '#ffc700'],
  }

  const teacherTrendSeries = [
    { name: 'Present', data: data?.charts.teacher_attendance_trend.map(d => d.present) || [] },
    { name: 'Absent', data: data?.charts.teacher_attendance_trend.map(d => d.absent) || [] },
  ]

  // ─── Demographics Donut ──────────────────────────────────────────────────────
  const demoOptions: ApexOptions = {
    chart: { type: 'donut', height: 200 },
    labels: ['Boys', 'Girls'],
    colors: ['#009ef7', '#f1416c'],
    legend: { position: 'bottom', fontSize: '12px' },
    dataLabels: { enabled: true, style: { fontSize: '12px' } },
    plotOptions: { pie: { donut: { size: '65%', labels: { show: true, total: { show: true, label: 'Total', fontSize: '14px', fontWeight: 700 } } } } },
  }

  const demoSeries = [data?.charts.demographics.boys || 0, data?.charts.demographics.girls || 0]

  // ─── Class Strength Bar ───────────────────────────────────────────────────────
  const classStrengthOptions: ApexOptions = {
    chart: { type: 'bar', height: 200, toolbar: { show: false } },
    plotOptions: { bar: { horizontal: true, borderRadius: 4, distributed: true } },
    dataLabels: { enabled: true, style: { fontSize: '11px' } },
    xaxis: { categories: data?.charts.class_strength.map(c => c.class) || [], labels: { style: { fontSize: '11px', colors: '#a1a5b7' } } },
    yaxis: { labels: { style: { fontSize: '11px', colors: '#a1a5b7' } } },
    colors: ['#009ef7', '#50cd89', '#ffc700', '#f1416c', '#7239ea'],
    legend: { show: false },
    grid: { borderColor: '#f1f1f4', strokeDashArray: 4 },
  }

  const classStrengthSeries = [{ name: 'Students', data: data?.charts.class_strength.map(c => c.count) || [] }]

  // ─── Fee Metrics Formatting ──────────────────────────────────────────────────
  const fmtINR = (val: number | undefined) => `₹${Number(val || 0).toLocaleString('en-IN')}`

  // ─── Fee Monthly Trend Bar Chart ──────────────────────────────────────────────
  const feeMonthlyOptions: ApexOptions = {
    chart: { type: 'bar', height: 250, toolbar: { show: false } },
    plotOptions: { bar: { columnWidth: '40%', borderRadius: 4 } },
    dataLabels: { enabled: false },
    xaxis: { categories: data?.charts.fee_monthly_trend?.map(d => d.month) || [], labels: { style: { fontSize: '12px', colors: '#a1a5b7' } } },
    yaxis: { labels: { style: { fontSize: '11px', colors: '#a1a5b7' }, formatter: (v) => v >= 1000 ? `₹${(v / 1000).toFixed(1)}k` : `₹${v}` } },
    colors: ['#009ef7'],
    grid: { borderColor: '#f1f1f4', strokeDashArray: 4 },
  }
  const feeMonthlySeries = [{ name: 'Collection', data: data?.charts.fee_monthly_trend?.map(d => d.collected) || [] }]

  // ─── Fee Status Donut ────────────────────────────────────────────────────────
  const feeStatusOptions: ApexOptions = {
    chart: { type: 'donut', height: 220 },
    labels: ['Paid', 'Partial', 'Unpaid'],
    colors: ['#50cd89', '#ffc700', '#f1416c'],
    legend: { position: 'bottom' },
    plotOptions: { pie: { donut: { size: '65%', labels: { show: true, total: { show: true, label: 'Invoices' } } } } },
  }
  const feeStatusSeries = [
    data?.charts.fee_status_dropdown?.PAID || 0,
    data?.charts.fee_status_dropdown?.PARTIAL || 0,
    data?.charts.fee_status_dropdown?.UNPAID || 0
  ]

  // ─── Payment Methods Donut ───────────────────────────────────────────────────
  const feeMethodsOptions: ApexOptions = {
    ...feeStatusOptions,
    labels: data?.charts.fee_payment_methods?.map(m => m.method) || [],
    colors: ['#7239ea', '#009ef7', '#50cd89', '#ffc700'],
  }
  const feeMethodsSeries = data?.charts.fee_payment_methods?.map(m => m.count) || []

  if (loading) {
    return (
      <Content>
        <div className='d-flex align-items-center justify-content-center' style={{ minHeight: 400 }}>
          <div className='text-center'>
            <div className='spinner-border text-primary mb-3' style={{ width: 48, height: 48 }}></div>
            <div className='text-muted fw-semibold'>Loading Dashboard...</div>
          </div>
        </div>
      </Content>
    )
  }

  if (error || !data) {
    return (
      <Content>
        <div className='alert alert-danger d-flex align-items-center'>
          <i className='ki-duotone ki-information-5 fs-2x text-danger me-3'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
          <div>{error || 'No dashboard data available.'}</div>
          <button className='btn btn-sm btn-danger ms-auto' onClick={fetchDashboard}>Retry</button>
        </div>
      </Content>
    )
  }

  const kpi = data.kpis

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* ── Row 1: KPI Cards ── */}
        <div className='row g-5 mb-5'>
          <div className='col-sm-6 col-xl-2'>
            <KpiCard
              title='Total Students' value={kpi.total_students}
              subtitle={`${kpi.active_students} Active`} icon='ki-people' color='primary'
            />
          </div>
          <div className='col-sm-6 col-xl-2'>
            <KpiCard
              title='Staff / Teachers' value={kpi.total_teachers}
              subtitle='Teaching Staff' icon='ki-teacher' color='info'
            />
          </div>
          <div className='col-sm-6 col-xl-2'>
            <KpiCard
              title="Today's Attendance" value={`${kpi.today_attendance_percent.toFixed(1)}%`}
              subtitle='Student Presence' icon='ki-calendar-tick' color='success'
            />
          </div>
          <div className='col-sm-6 col-xl-2'>
            <KpiCard
              title='Absentees' value={kpi.today_absent_teachers}
              subtitle='Staff on leave' icon='ki-user-cross' color='warning'
            />
          </div>
          <div className='col-sm-6 col-xl-2'>
            <KpiCard
              title='Dues' value={kpi.pending_fee_count}
              subtitle='Unpaid Invoices' icon='ki-finance-calculator' color='danger'
            />
          </div>
          <div className='col-sm-6 col-xl-2'>
            <div className='card bg-light-dark border-0 h-100'>
              <div className='card-body py-7 px-8 d-flex flex-column justify-content-between'>
                <div className='d-flex align-items-center gap-3 mb-3'>
                  <div className='symbol symbol-45px'>
                    <div className='symbol-label bg-dark'>
                      <i className='ki-duotone ki-calendar fs-2 text-white'><span className='path1'></span><span className='path2'></span></i>
                    </div>
                  </div>
                  <div>
                    <div className='fw-bolder text-dark fs-5'>{data.today_timetable?.day || '—'}</div>
                    <div className='text-muted fs-8'>Today</div>
                  </div>
                </div>
                <div className='d-flex gap-4'>
                  <div>
                    <div className='fs-2 fw-bolder text-dark'>{data.today_timetable?.total_periods || 0}</div>
                    <div className='text-muted fs-9'>Periods</div>
                  </div>
                  <div>
                    <div className='fs-2 fw-bolder text-warning'>{data.today_timetable?.free_periods || 0}</div>
                    <div className='text-muted fs-9'>Free</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Row 1B: Financial KPIs ── */}
        <div className='row g-5 mb-5'>
          <div className='col-md-3'>
            <div className='card bg-primary card-xl-stretch border-0'>
              <div className='card-body px-8 py-6 d-flex justify-content-between align-items-center'>
                <div>
                  <div className='text-white fw-bolder fs-2'>{fmtINR(kpi.total_fee_expected)}</div>
                  <div className='text-white opacity-75 fw-semibold fs-7'>Total Expected Fee</div>
                </div>
                <i className='ki-duotone ki-wallet fs-3x text-white opacity-50'><span className='path1' /><span className='path2' /><span className='path3' /><span className='path4' /></i>
              </div>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='card bg-success card-xl-stretch border-0'>
              <div className='card-body px-8 py-6 d-flex justify-content-between align-items-center'>
                <div>
                  <div className='text-white fw-bolder fs-2'>{fmtINR(kpi.total_fee_collected)}</div>
                  <div className='text-white opacity-75 fw-semibold fs-7'>Total Collected</div>
                </div>
                <i className='ki-duotone ki-check-circle fs-3x text-white opacity-50'><span className='path1' /><span className='path2' /></i>
              </div>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='card bg-danger card-xl-stretch border-0'>
              <div className='card-body px-8 py-6 d-flex justify-content-between align-items-center'>
                <div>
                  <div className='text-white fw-bolder fs-2'>{fmtINR(kpi.total_fee_pending_amount)}</div>
                  <div className='text-white opacity-75 fw-semibold fs-7'>Total Dues Pending</div>
                </div>
                <i className='ki-duotone ki-cross-circle fs-3x text-white opacity-50'><span className='path1' /><span className='path2' /></i>
              </div>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='card bg-info card-xl-stretch border-0'>
              <div className='card-body px-8 py-6 d-flex justify-content-between align-items-center'>
                <div>
                  <div className='text-white fw-bolder fs-2'>{fmtINR(kpi.today_collection)}</div>
                  <div className='text-white opacity-75 fw-semibold fs-7'>Today's Collection</div>
                </div>
                <i className='ki-duotone ki-chart-line-up-2 fs-3x text-white opacity-50'><span className='path1' /><span className='path2' /></i>
              </div>
            </div>
          </div>
        </div>

        {/* ── Row 2: Quick Links ── */}
        <div className='card card-flush mb-5'>
          <div className='card-header py-5'>
            <h3 className='card-title fw-bold text-gray-800 fs-4'>Quick Actions</h3>
          </div>
          <div className='card-body pt-2 pb-6'>
            <div className='row g-4'>
              <div className='col-6 col-sm-4 col-md-3 col-lg'>
                <QuickLink to='/students/admission' icon='ki-profile-user' label='Admit Student' color='primary' />
              </div>
              <div className='col-6 col-sm-4 col-md-3 col-lg'>
                <QuickLink to={currentUser?.role === 'teacher' ? '/teacher/attendance' : '/staff/attendance'} icon='ki-calendar-tick' label={currentUser?.role === 'teacher' ? 'Mark Attendance' : 'Staff Attendance'} color='success' />
              </div>
              <div className='col-6 col-sm-4 col-md-3 col-lg'>
                <QuickLink to='/staff/teachers' icon='ki-people' label='Add Teacher' color='info' />
              </div>
              <div className='col-6 col-sm-4 col-md-3 col-lg'>
                <QuickLink to='/timetable/grid' icon='ki-time' label='View Timetable' color='warning' />
              </div>
              <div className='col-6 col-sm-4 col-md-3 col-lg'>
                <QuickLink to='/students/enrollment' icon='ki-book-open' label='Enrollment' color='primary' />
              </div>
              <div className='col-6 col-sm-4 col-md-3 col-lg'>
                <QuickLink to='/reports/attendance' icon='ki-chart-line-up-2' label='Reports' color='dark' />
              </div>
              <div className='col-6 col-sm-4 col-md-3 col-lg'>
                <QuickLink to='/fees/monthly' icon='ki-wallet' label='Collect Fee' color='danger' />
              </div>
              <div className='col-6 col-sm-4 col-md-3 col-lg'>
                <QuickLink to='/students/documents' icon='ki-document' label='Documents' color='warning' />
              </div>
            </div>
          </div>
        </div>

        {/* ── Row 3: Charts ── */}
        <div className='row g-5 mb-5'>
          {/* Student Attendance Trend */}
          <div className='col-xl-6'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Student Attendance Trend</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Last 7 days — Present vs Absent</span>
                </h3>
              </div>
              <div className='card-body pt-3'>
                {data.charts.attendance_trend.length > 0 ? (
                  <ReactApexChart options={attendanceTrendOptions} series={attendanceTrendSeries} type='area' height={220} />
                ) : (
                  <div className='text-center text-muted py-10 fs-7'>No attendance trend data available</div>
                )}
              </div>
            </div>
          </div>

          {/* Teacher Attendance Trend */}
          <div className='col-xl-6'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Teacher Attendance Trend</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Last 7 days — Present vs Absent</span>
                </h3>
              </div>
              <div className='card-body pt-3'>
                {data.charts.teacher_attendance_trend.length > 0 ? (
                  <ReactApexChart options={teacherTrendOptions} series={teacherTrendSeries} type='area' height={220} />
                ) : (
                  <div className='text-center text-muted py-10 fs-7'>No teacher trend data available</div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className='row g-5 mb-5'>
          {/* Demographics Donut */}
          <div className='col-xl-4'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Gender Demographics</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Boys vs Girls ratio</span>
                </h3>
              </div>
              <div className='card-body pt-3 d-flex flex-column justify-content-center'>
                <ReactApexChart options={demoOptions} series={demoSeries} type='donut' height={220} />
                <div className='d-flex justify-content-center gap-8 mt-3'>
                  <div className='text-center'>
                    <div className='fs-2 fw-bolder text-primary'>{data.charts.demographics.boys}</div>
                    <div className='text-muted fs-8 fw-semibold'>Boys</div>
                  </div>
                  <div className='text-center'>
                    <div className='fs-2 fw-bolder text-danger'>{data.charts.demographics.girls}</div>
                    <div className='text-muted fs-8 fw-semibold'>Girls</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Class Strength Bar */}
          <div className='col-xl-8'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Students per Class</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Class strength distribution</span>
                </h3>
              </div>
              <div className='card-body pt-3'>
                {data.charts.class_strength.length > 0 ? (
                  <ReactApexChart options={classStrengthOptions} series={classStrengthSeries} type='bar' height={220} />
                ) : (
                  <div className='text-center text-muted py-10 fs-7'>No class strength data available</div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* ── Finance Charts ── */}
        <div className='row g-5 mb-5'>
          {/* Monthly Collection Trend */}
          <div className='col-xl-6'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Fee Collection Trend</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Month-wise revenue stream</span>
                </h3>
              </div>
              <div className='card-body pt-3'>
                {data.charts.fee_monthly_trend && data.charts.fee_monthly_trend.length > 0 ? (
                  <ReactApexChart options={feeMonthlyOptions} series={feeMonthlySeries} type='bar' height={250} />
                ) : (
                  <div className='text-center text-muted py-10 fs-7'>No fee collection data yet</div>
                )}
              </div>
            </div>
          </div>

          <div className='col-xl-6'>
            <div className='row g-5 h-100'>
              {/* Fee Status Break down */}
              <div className='col-md-6'>
                <div className='card card-flush h-100'>
                  <div className='card-header pt-5'>
                    <h3 className='card-title flex-column'>
                      <span className='card-label fw-bold text-dark fs-5'>Invoice Status</span>
                    </h3>
                  </div>
                  <div className='card-body d-flex align-items-center justify-content-center pt-0'>
                    <ReactApexChart options={feeStatusOptions} series={feeStatusSeries} type='donut' height={220} width='100%' />
                  </div>
                </div>
              </div>
              {/* Payment Methods */}
              <div className='col-md-6'>
                <div className='card card-flush h-100'>
                  <div className='card-header pt-5'>
                    <h3 className='card-title flex-column'>
                      <span className='card-label fw-bold text-dark fs-5'>Payment Modes</span>
                    </h3>
                  </div>
                  <div className='card-body d-flex align-items-center justify-content-center pt-0'>
                    {data.charts.fee_payment_methods && data.charts.fee_payment_methods.length > 0 ? (
                      <ReactApexChart options={feeMethodsOptions} series={feeMethodsSeries} type='donut' height={220} width='100%' />
                    ) : (
                      <span className='text-muted fs-8'>No payment data</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Row 4: Activity Widgets ── */}
        <div className='row g-5 mb-5'>
          {/* Recent Admissions */}
          <div className='col-xl-4'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5 pb-0'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Recent Admissions</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Latest students admitted</span>
                </h3>
                <div className='card-toolbar'>
                  <Link to='/students/admission' className='btn btn-sm btn-light-primary btn-active-primary'>
                    View All
                  </Link>
                </div>
              </div>
              <div className='card-body pt-4'>
                {data.recent_admissions.length === 0 ? (
                  <div className='text-center text-muted py-8 fs-7'>No recent admissions</div>
                ) : data.recent_admissions.map((s, idx) => (
                  <div key={s.id} className={`d-flex align-items-center py-3 ${idx < data.recent_admissions.length - 1 ? 'border-bottom border-gray-200' : ''}`}>
                    <div className='symbol symbol-40px symbol-circle me-3'>
                      <div className='symbol-label bg-light-primary fw-bolder text-primary fs-5'>
                        {s.name.charAt(0).toUpperCase()}
                      </div>
                    </div>
                    <div className='flex-grow-1'>
                      <div className='fw-bold text-gray-800 fs-6'>{s.name}</div>
                      <div className='text-muted fs-8'>Admitted: {new Date(s.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
                    </div>
                    <span className='badge badge-light-success fw-semibold'>New</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Today Absent Students */}
          <div className='col-xl-4'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5 pb-0'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Today Absent Students</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>Students not present today</span>
                </h3>
              </div>
              <div className='card-body pt-4'>
                {data.today_absent_students.length === 0 ? (
                  <div className='text-center py-8'>
                    <i className='ki-duotone ki-shield-tick fs-3x text-success mb-3'><span className='path1'></span><span className='path2'></span></i>
                    <div className='text-muted fs-7'>All students are present today!</div>
                  </div>
                ) : data.today_absent_students.map((s, idx) => (
                  <div key={s.id} className={`d-flex align-items-center py-3 ${idx < data.today_absent_students.length - 1 ? 'border-bottom border-gray-200' : ''}`}>
                    <div className='symbol symbol-40px symbol-circle me-3'>
                      <div className='symbol-label bg-light-danger fw-bolder text-danger fs-5'>
                        {s.name.charAt(0).toUpperCase()}
                      </div>
                    </div>
                    <div className='flex-grow-1'>
                      <div className='fw-bold text-gray-800 fs-6'>{s.name}</div>
                      <div className='text-muted fs-8'>{s.class}</div>
                    </div>
                    <span className='badge badge-light-danger fw-semibold'>Absent</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Today Timetable Snapshot */}
          <div className='col-xl-4'>
            <div className='card card-flush h-100'>
              <div className='card-header pt-5 pb-0'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-dark'>Today's Timetable</span>
                  <span className='text-muted mt-1 fw-semibold fs-7'>
                    {data.today_timetable?.day} — {data.today_timetable?.total_periods} periods
                  </span>
                </h3>
                <div className='card-toolbar'>
                  <Link to='/timetable' className='btn btn-sm btn-light-info btn-active-info'>View Full</Link>
                </div>
              </div>
              <div className='card-body pt-3' style={{ maxHeight: 320, overflowY: 'auto' }}>
                {!data.today_timetable || data.today_timetable.entries.length === 0 ? (
                  <div className='text-center text-muted py-8 fs-7'>No timetable entries for today</div>
                ) : data.today_timetable.entries.slice(0, 6).map(e => (
                  <div key={e.id} className={`d-flex align-items-start py-2 border-bottom border-gray-100`}>
                    <div className='me-3 text-center' style={{ minWidth: 55 }}>
                      <div className='badge badge-light-primary fw-bold fs-9 mb-1'>{e.period.start_time.slice(0, 5)}</div>
                      {e.period.is_break && <div className='badge badge-light-warning fs-9'>Break</div>}
                    </div>
                    <div className='flex-grow-1'>
                      <div className='fw-bold text-gray-800 fs-7'>
                        {e.subject?.name || (e.is_free ? 'Free Period' : e.period.name)}
                        {e.room_no && <span className='text-muted ms-2 fs-9'>Room {e.room_no}</span>}
                      </div>
                      <div className='text-muted fs-9'>
                        {e.teacher?.name || '—'}
                        {e.class_name && <span className='ms-2 text-info'>· {e.class_name} {e.section_name}</span>}
                      </div>
                    </div>
                    <span className={`badge badge-light-${e.is_free ? 'warning' : 'success'} fs-9 ms-2`}>
                      {e.is_free ? 'Free' : 'Active'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── Active Notices ── */}
        {data.active_notices.length > 0 && (
          <div className='card card-flush mb-5'>
            <div className='card-header pt-5'>
              <h3 className='card-title align-items-start flex-column'>
                <span className='card-label fw-bold text-dark'>Active Notices / Events</span>
              </h3>
            </div>
            <div className='card-body pt-3'>
              <div className='d-flex flex-wrap gap-3'>
                {data.active_notices.map(n => (
                  <div key={n.id} className='badge badge-light-primary fs-7 py-3 px-5 fw-semibold'>
                    <i className='ki-duotone ki-notification fs-5 me-1 text-primary'><span className='path1'></span><span className='path2'></span></i>
                    {n.title}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Refresh button */}
        <div className='text-end'>
          <button className='btn btn-sm btn-light-primary' onClick={fetchDashboard}>
            <i className='ki-duotone ki-arrows-loop fs-4 me-1'><span className='path1'></span><span className='path2'></span></i>
            Refresh Dashboard
          </button>
        </div>

      </Content>
    </>
  )
}

const DashboardWrapper: FC = () => {
  const intl = useIntl()
  const { currentUser } = useAuth()

  if (currentUser?.role === 'teacher') {
    return (
      <>
        <PageTitle breadcrumbs={[]}>{intl.formatMessage({ id: 'MENU.DASHBOARD' })}</PageTitle>
        <TeacherDashboard />
      </>
    )
  }

  return (
    <>
      <PageTitle breadcrumbs={[]}>{intl.formatMessage({ id: 'MENU.DASHBOARD' })}</PageTitle>
      <DashboardPage />
    </>
  )
}

export { DashboardWrapper }
