import React, { useState, useEffect } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { useAuth } from '../auth'
import { getAppSettings, updateAppSettings } from './core/_requests'
import { UpdateAppSettingsPayload } from './core/_models'
import toast, { Toaster } from 'react-hot-toast'
import { KTIcon } from '../../../_metronic/helpers'

// ─── Default Templates Constants ──────────────────────────────────────────
const DEFAULT_ADMIT_CARD_EJS = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admit Card - <%= student.name %></title>
    <style>
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            color: #1e293b;
            background-color: #fff;
            line-height: 1.4;
        }
        .admit-card-container {
            border: 3px double #1e3a8a;
            border-radius: 12px;
            padding: 25px;
            position: relative;
            background: #fff;
        }
        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-30deg);
            font-size: 80px;
            font-weight: 900;
            color: rgba(226, 232, 240, 0.35);
            text-transform: uppercase;
            letter-spacing: 6px;
            pointer-events: none;
            z-index: 0;
            white-space: nowrap;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px solid #1e3a8a;
            padding-bottom: 15px;
            margin-bottom: 20px;
            position: relative;
            z-index: 1;
        }
        .header-left {
            display: flex;
            align-items: center;
        }
        .header-left img {
            width: 80px;
            height: 80px;
            object-fit: contain;
            margin-right: 18px;
            border-radius: 8px;
        }
        .header-title h1 {
            margin: 0;
            font-size: 26px;
            font-weight: 800;
            color: #1e3a8a;
            letter-spacing: -0.5px;
        }
        .header-right {
            text-align: right;
            font-size: 12px;
            color: #475569;
            line-height: 1.5;
        }
        .doc-title-bar {
            text-align: center;
            background: #1e3a8a;
            color: #fff;
            padding: 8px 0;
            border-radius: 6px;
            margin-bottom: 20px;
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-size: 15px;
            position: relative;
            z-index: 1;
        }
        .exam-meta-info {
            text-align: center;
            margin-top: -15px;
            margin-bottom: 20px;
            font-weight: 600;
            font-size: 14px;
            color: #475569;
        }
        .profile-section {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 25px;
            position: relative;
            z-index: 1;
        }
        .student-details-grid {
            flex: 1;
            display: grid;
            grid-template-columns: max-content 1fr;
            gap: 8px 15px;
            font-size: 12px;
        }
        .student-details-grid .label {
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .student-details-grid .value {
            color: #0f172a;
            font-weight: 700;
            text-transform: uppercase;
        }
        .photo-box {
            width: 105px;
            height: 125px;
            border: 2px solid #cbd5e1;
            border-radius: 8px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8fafc;
        }
        .photo-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
            font-size: 11px;
            position: relative;
            z-index: 1;
        }
        th, td {
            border: 1px solid #cbd5e1;
            padding: 8px 10px;
            text-align: center;
        }
        th {
            background-color: #f1f5f9;
            color: #1e293b;
            font-weight: 800;
            text-transform: uppercase;
        }
        .instructions-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px 18px;
            margin-bottom: 30px;
            font-size: 10px;
            color: #475569;
            position: relative;
            z-index: 1;
        }
        .instructions-box h4 {
            margin: 0 0 6px 0;
            color: #0f172a;
            font-weight: 700;
            text-transform: uppercase;
        }
        .signatures-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            padding: 0 10px;
            position: relative;
            z-index: 1;
        }
        .sig-box {
            text-align: center;
            width: 160px;
            border-top: 1px dashed #94a3b8;
            padding-top: 8px;
            font-size: 11px;
            font-weight: 700;
            color: #334155;
        }
    </style>
</head>
<body>
    <div class="admit-card-container">
        <div class="watermark">ADMIT CARD</div>
        <div class="header">
            <div class="header-left">
                <img src="<%= school.logoPath %>" alt="School Logo" onerror="this.src='https://via.placeholder.com/80?text=LOGO'">
                <div class="header-title">
                    <h1><%= school.name %></h1>
                    <% if (isCollege) { %>
                    <span style="display: inline-block; background: #3b82f6; color: #fff; font-size: 9px; font-weight: 700; padding: 2px 8px; border-radius: 4px; margin-top: 5px; text-transform: uppercase;">College / University</span>
                    <% } %>
                </div>
            </div>
            <div class="header-right">
                <div><strong>Address:</strong> <%= school.address %></div>
                <div><strong>Phone:</strong> <%= school.phone %></div>
                <div><strong>Email:</strong> <%= school.email %></div>
            </div>
        </div>
        <div class="doc-title-bar">Admit Card / Hall Ticket</div>
        <div class="exam-meta-info"><%= exam.name %> — <%= exam.year %></div>
        <div class="profile-section">
            <div class="student-details-grid">
                <div class="label">Admission No:</div>
                <div class="value"><%= student.admission_no %></div>
                <div class="label">Roll Number:</div>
                <div class="value"><%= student.roll_number %></div>
                <div class="label">Student Name:</div>
                <div class="value"><%= student.name %></div>
                <div class="label">Father Name:</div>
                <div class="value"><%= student.father_name %></div>
                <div class="label">Mother Name:</div>
                <div class="value"><%= student.mother_name %></div>
                <div class="label">Date of Birth:</div>
                <div class="value"><%= student.dob %></div>
                <div class="label"><%= labels.classLabel %>:</div>
                <div class="value"><%= student.class %></div>
            </div>
            <div class="photo-box">
                <img src="<%= student.profile_image %>" alt="Student Photo" onerror="this.src='https://via.placeholder.com/100?text=PHOTO'">
            </div>
        </div>
        <div style="font-size: 13px; font-weight: 800; color: #1e3a8a; margin-bottom: 8px; text-transform: uppercase; border-left: 4px solid #1e3a8a; padding-left: 8px;">Examination Timetable</div>
        <table>
            <thead>
                <tr>
                    <th style="width: 25%;">Subject</th>
                    <th style="width: 15%;">Type</th>
                    <th style="width: 15%;">Date</th>
                    <th style="width: 15%;">Day</th>
                    <th style="width: 20%;">Time</th>
                    <th style="width: 10%;">Room</th>
                </tr>
            </thead>
            <tbody>
                <% if (schedules && schedules.length > 0) { %>
                    <% schedules.forEach(function(item) { %>
                    <tr>
                        <td style="text-align: left; font-weight: 700;"><%= item.subject %></td>
                        <td><%= item.examType %></td>
                        <td><%= item.date %></td>
                        <td><%= item.day %></td>
                        <td><%= item.timeStr %></td>
                        <td><%= item.room %></td>
                    </tr>
                    <% }); %>
                <% } else { %>
                    <tr>
                        <td colspan="6" style="text-align: center; color: #94a3b8; font-style: italic; padding: 15px;">No exam schedules found.</td>
                    </tr>
                <% } %>
            </tbody>
        </table>
        <div class="instructions-box">
            <h4>Important Guidelines for Candidates</h4>
            <ul>
                <li>Candidates must bring a printed copy of this Admit Card along with their School/College ID to the exam hall.</li>
                <li>Please report to the examination room at least 15 minutes before the commencement of the exam.</li>
                <li>No electronic devices, calculators (unless specified), mobile phones, or smartwatches are permitted inside the hall.</li>
                <li>Any candidate found using unfair means will be summarily disqualified from the examination.</li>
            </ul>
        </div>
        <div class="signatures-section">
            <div class="sig-box">Candidate's Signature</div>
            <div class="sig-box">Invigilator's Signature</div>
            <div class="sig-box"><%= isCollege ? 'Controller of Exams' : 'Principal\\'s Signature' %></div>
        </div>
    </div>
</body>
</html>`

const DEFAULT_REPORT_CARD_EJS = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report Card</title>
    <style>
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .header {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #0f766e;
            padding-bottom: 15px;
            margin-bottom: 20px;
            padding: 0 0 15px 0;
        }
        .header-left {
            display: flex;
            flex-direction: row;
            align-items: center;
        }
        .header-left img {
            width: 80px;
            height: 80px;
            object-fit: contain;
            margin: 0 15px 0 0;
        }
        .header-title h1 {
            margin: 0;
            font-size: 28px;
            color: #0f766e;
        }
        .header-right {
            text-align: right;
            font-size: 13px;
            line-height: 1.6;
        }
        .exam-title {
            text-align: center;
            margin-bottom: 20px;
        }
        .exam-title h2 {
            margin: 0;
            font-size: 18px;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: #0f766e;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 13px;
        }
        th, td {
            border: 1px solid #999;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f8fafc;
            color: #0f172a;
            font-weight: bold;
            text-transform: uppercase;
        }
        .student-details {
            display: grid;
            grid-template-columns: max-content 1fr;
            gap: 5px 20px;
            margin-bottom: 20px;
            font-size: 12px;
            text-transform: uppercase;
        }
        .student-details div:nth-child(even) {
            font-weight: bold;
        }
        .marks-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .signatures {
            display: flex;
            justify-content: space-between;
            margin-top: 50px;
            padding: 0 20px;
        }
        .signature-box {
            text-align: center;
            min-width: 150px;
            border-top: 1px solid #000;
            padding-top: 10px;
            font-size: 12px;
            font-weight: bold;
        }
        .footer-note {
            text-align: center;
            font-size: 10px;
            color: #777;
            margin-top: 30px;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <img src="<%= school.logoPath %>" alt="Institution Logo" onerror="this.src='https://via.placeholder.com/80?text=LOGO'">
            <div class="header-title">
                <h1><%= school.name %></h1>
                <span style="display:inline-block; font-size:10px; font-weight:700; letter-spacing:1px; background:#0f766e; color:#fff; padding:2px 8px; border-radius:3px; margin-top:4px; text-transform:uppercase;">ACADEMIC ACHIEVEMENT REPORT CARD</span>
            </div>
        </div>
        <div class="header-right">
            <div><strong>Address:</strong> <%= school.address %></div>
            <div><strong>Phone No.:</strong> <%= school.phone %></div>
        </div>
    </div>
    <div class="exam-title">
        <h2><%= exam.name %></h2>
        <p><%= exam.year %></p>
    </div>
    <table>
        <tr>
            <th>ADMISSION NO</th>
            <th>ROLL NUMBER</th>
        </tr>
        <tr>
            <td><%= student.admission_no %></td>
            <td><%= student.roll_number %></td>
        </tr>
    </table>
    <div style="text-align: center; font-size: 12px; font-weight: bold; margin-bottom: 10px;">CERTIFIED THAT</div>
    <div class="student-details">
        <div>MR/MS</div>
        <div><%= student.name %></div>
        <div>FATHER / HUSBAND NAME</div><div><%= student.father_name %></div>
        <div>MOTHER NAME</div><div><%= student.mother_name %></div>
        <div>DATE OF BIRTH</div><div><%= student.dob %></div>
        <div><%= labels.classLabel %></div>
        <div><%= student.class %></div>
        <div><%= labels.schoolLabel %></div>
        <div><%= school.name %></div>
    </div>
    <table class="marks-table">
        <tr>
            <th>SUBJECTS</th>
            <th>MAX MARKS</th>
            <th>MIN MARKS</th>
            <th>MARKS OBTAINED</th>
            <th>REMARKS</th>
        </tr>
        <% marks.forEach(function(item) { %>
        <tr>
            <td style="text-align: left; font-weight: bold;"><%= item.subject %></td>
            <td><%= item.maxMarks %></td>
            <td><%= item.minMarks %></td>
            <td><%= item.marksObtained %></td>
            <td><%= item.remarks %></td>
        </tr>
        <% }); %>
        <tr style="font-weight: bold; background: #f8fafc;">
            <td colspan="3" style="text-align: right; padding-right: 20px;">GRAND TOTAL</td>
            <td><%= grandTotalObtained %> / <%= grandTotalMax %></td>
            <td><%= percentage %>%</td>
        </tr>
    </table>
    <table style="margin-top: -21px; border-top: none;">
        <tr>
            <th style="width: 200px; border-top: none;">RESULT</th>
            <td style="font-weight:bold; border-top: none; text-align: center;"><%= result %></td>
        </tr>
    </table>
    <div class="signatures">
        <div class="signature-box">Class Teacher</div>
        <div class="signature-box">Examiner</div>
        <div class="signature-box">Principal</div>
    </div>
    <div class="footer-note">This is a computer-generated document. No manual signature is required.</div>
</body>
</html>`

// ─── Preset Color Configurations ──────────────────────────────────────────
const PRESETS = {
    navy: { primary: '#1e3a8a', secondary: '#3b82f6', border: 'double' },
    teal: { primary: '#0f766e', secondary: '#14b8a6', border: 'solid' },
    emerald: { primary: '#065f46', secondary: '#10b981', border: 'solid' },
    maroon: { primary: '#7f1d1d', secondary: '#f87171', border: 'double' },
}

const CustomTemplatesPage: React.FC = () => {
    const { currentUser } = useAuth()
    const tenantId = currentUser?.schoolId || '30'

    const [activeSection, setActiveSection] = useState<'admit' | 'report'>('admit')
    const [isLoading, setIsLoading] = useState(false)
    const [isSaving, setIsSaving] = useState(false)

    // Visual Builder States - Admit Card
    const [admitMode, setAdmitMode] = useState<'visual' | 'code'>('visual')
    const [admitPreset, setAdmitPreset] = useState<keyof typeof PRESETS | 'custom'>('navy')
    const [admitConfig, setAdmitConfig] = useState({
        primaryColor: '#1e3a8a',
        secondaryColor: '#3b82f6',
        fontFamily: 'Inter',
        logoPosition: 'left' as 'left' | 'center',
        showPhoto: true,
        showWatermark: true,
        watermarkText: 'ADMIT CARD',
        showFatherName: true,
        showMotherName: true,
        showDob: true,
        showAdmissionNo: true,
        showRollNo: true,
        tableHeaderBg: '#f1f5f9',
        tableHeaderColor: '#1e293b',
        borderStyle: 'double' as 'double' | 'solid' | 'dashed',
        guidelines: [
            'Candidates must bring a printed copy of this Admit Card along with their School/College ID.',
            'Please report to the examination room at least 15 minutes before the exam starts.',
            'No electronic devices, calculators, or smartwatches are permitted inside.',
            'Any candidate using unfair means will be disqualified.'
        ],
        sig1: "Candidate's Signature",
        sig2: "Invigilator's Signature",
        sig3: "Principal's Signature"
    })

    // Visual Builder States - Report Card (Advanced)
    const [reportMode, setReportMode] = useState<'visual' | 'code'>('visual')
    const [reportPreset, setReportPreset] = useState<'classic' | 'university' | 'minimalist'>('classic')
    const [reportConfig, setReportConfig] = useState({
        primaryColor: '#0f766e',
        secondaryColor: '#14b8a6',
        fontFamily: 'Inter',
        headerStyle: 'classic' as 'classic' | 'centered' | 'boxed',
        schoolNameOverride: '',
        schoolSubtitleOverride: 'ACADEMIC ACHIEVEMENT REPORT CARD',
        footerNote: 'This is a computer-generated document. No manual signature is required.',
        showFooterNote: true,
        showWatermark: false,
        watermarkText: 'ANNUAL RESULT',
        showFatherName: true,
        showMotherName: true,
        showDob: true,
        showAdmissionNo: true,
        showRollNo: true,
        tableHeaderBg: '#f8fafc',
        tableHeaderColor: '#0f172a',
        borderStyle: 'solid' as 'solid' | 'dashed',
        showGrades: true,
        showCreditHours: true,
        tableStriped: true,
        sig1: 'Class Teacher',
        sig2: 'Examiner',
        sig3: 'Principal'
    })

    // Raw Code States
    const [admitCardTemplate, setAdmitCardTemplate] = useState('')
    const [reportCardTemplate, setReportCardTemplate] = useState('')

    // Apply Presets to Admit Card
    const applyAdmitPreset = (presetKey: keyof typeof PRESETS) => {
        setAdmitPreset(presetKey)
        const p = PRESETS[presetKey]
        setAdmitConfig(prev => ({
            ...prev,
            primaryColor: p.primary,
            secondaryColor: p.secondary,
            borderStyle: p.border as any
        }))
    }

    // Apply Canva-presets to Report Card
    const applyReportPreset = (preset: 'classic' | 'university' | 'minimalist') => {
        setReportPreset(preset)
        if (preset === 'classic') {
            setReportConfig(prev => ({
                ...prev,
                primaryColor: '#0f766e',
                secondaryColor: '#14b8a6',
                headerStyle: 'classic',
                tableHeaderBg: '#f8fafc',
                borderStyle: 'solid',
                tableStriped: true,
                sig1: 'Class Teacher',
                sig2: 'Examiner',
                sig3: 'Principal',
                schoolSubtitleOverride: 'ACADEMIC ACHIEVEMENT REPORT CARD'
            }))
        } else if (preset === 'university') {
            setReportConfig(prev => ({
                ...prev,
                primaryColor: '#1e3a8a',
                secondaryColor: '#3b82f6',
                headerStyle: 'boxed',
                tableHeaderBg: '#1e3a8a0d',
                borderStyle: 'solid',
                tableStriped: false,
                sig1: 'Course Coordinator',
                sig2: 'Examiner',
                sig3: 'Controller of Examinations',
                schoolSubtitleOverride: 'OFFICIAL ACADEMIC TRANSCRIPT'
            }))
        } else if (preset === 'minimalist') {
            setReportConfig(prev => ({
                ...prev,
                primaryColor: '#334155',
                secondaryColor: '#64748b',
                headerStyle: 'centered',
                tableHeaderBg: '#f1f5f9',
                borderStyle: 'dashed',
                tableStriped: true,
                sig1: 'Tutor',
                sig2: 'Invigilator',
                sig3: 'Dean',
                schoolSubtitleOverride: 'GRADE CARD'
            }))
        }
    }

    // EJS Compiler - Generates raw EJS template from visual configurations for Admit Cards
    const generateAdmitCardHtml = (config: typeof admitConfig) => {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admit Card - <%= student.name %></title>
    <style>
        body {
            font-family: '${config.fontFamily}', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            color: #1e293b;
            background-color: #fff;
            line-height: 1.4;
        }
        .admit-card-container {
            border: 3px ${config.borderStyle} ${config.primaryColor};
            border-radius: 12px;
            padding: 25px;
            position: relative;
            background: #fff;
        }
        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-30deg);
            font-size: 80px;
            font-weight: 900;
            color: rgba(226, 232, 240, 0.35);
            text-transform: uppercase;
            letter-spacing: 6px;
            pointer-events: none;
            z-index: 0;
            white-space: nowrap;
            display: ${config.showWatermark ? 'block' : 'none'};
        }
        .header {
            display: flex;
            flex-direction: ${config.logoPosition === 'center' ? 'column' : 'row'};
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px solid ${config.primaryColor};
            padding-bottom: 15px;
            margin-bottom: 20px;
            position: relative;
            z-index: 1;
            text-align: ${config.logoPosition === 'center' ? 'center' : 'left'};
        }
        .header-left {
            display: flex;
            flex-direction: ${config.logoPosition === 'center' ? 'column' : 'row'};
            align-items: center;
        }
        .header-left img {
            width: 80px;
            height: 80px;
            object-fit: contain;
            margin: ${config.logoPosition === 'center' ? '0 0 10px 0' : '0 18px 0 0'};
            border-radius: 8px;
        }
        .header-title h1 {
            margin: 0;
            font-size: 26px;
            font-weight: 800;
            color: ${config.primaryColor};
            letter-spacing: -0.5px;
        }
        .header-right {
            text-align: ${config.logoPosition === 'center' ? 'center' : 'right'};
            font-size: 12px;
            color: #475569;
            line-height: 1.5;
            margin-top: ${config.logoPosition === 'center' ? '12px' : '0'};
        }
        .doc-title-bar {
            text-align: center;
            background: ${config.primaryColor};
            color: #fff;
            padding: 8px 0;
            border-radius: 6px;
            margin-bottom: 20px;
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-size: 15px;
            position: relative;
            z-index: 1;
        }
        .exam-meta-info {
            text-align: center;
            margin-top: -15px;
            margin-bottom: 20px;
            font-weight: 600;
            font-size: 14px;
            color: #475569;
        }
        .profile-section {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 25px;
            position: relative;
            z-index: 1;
        }
        .student-details-grid {
            flex: 1;
            display: grid;
            grid-template-columns: max-content 1fr;
            gap: 8px 15px;
            font-size: 12px;
        }
        .student-details-grid .label {
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .student-details-grid .value {
            color: #0f172a;
            font-weight: 700;
            text-transform: uppercase;
        }
        .photo-box {
            width: 105px;
            height: 125px;
            border: 2px solid #cbd5e1;
            border-radius: 8px;
            overflow: hidden;
            display: ${config.showPhoto ? 'flex' : 'none'};
            align-items: center;
            justify-content: center;
            background: #f8fafc;
        }
        .photo-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
            font-size: 11px;
            position: relative;
            z-index: 1;
        }
        th, td {
            border: 1px solid #cbd5e1;
            padding: 8px 10px;
            text-align: center;
        }
        th {
            background-color: ${config.tableHeaderBg};
            color: ${config.tableHeaderColor};
            font-weight: 800;
            text-transform: uppercase;
        }
        .instructions-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px 18px;
            margin-bottom: 30px;
            font-size: 10px;
            color: #475569;
            position: relative;
            z-index: 1;
        }
        .instructions-box h4 {
            margin: 0 0 6px 0;
            color: #0f172a;
            font-weight: 700;
            text-transform: uppercase;
        }
        .signatures-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            padding: 0 10px;
            position: relative;
            z-index: 1;
        }
        .sig-box {
            text-align: center;
            width: 160px;
            border-top: 1px dashed #94a3b8;
            padding-top: 8px;
            font-size: 11px;
            font-weight: 700;
            color: #334155;
        }
    </style>
</head>
<body>
    <div class="admit-card-container">
        <div class="watermark">${config.watermarkText || 'ADMIT CARD'}</div>
        <div class="header">
            <div class="header-left">
                <img src="<%= school.logoPath %>" alt="School Logo" onerror="this.src='https://via.placeholder.com/80?text=LOGO'">
                <div class="header-title">
                    <h1><%= school.name %></h1>
                    <% if (isCollege) { %>
                    <span style="display: inline-block; background: ${config.secondaryColor}; color: #fff; font-size: 9px; font-weight: 700; padding: 2px 8px; border-radius: 4px; margin-top: 5px; text-transform: uppercase;">College / University</span>
                    <% } %>
                </div>
            </div>
            <div class="header-right">
                <div><strong>Address:</strong> <%= school.address %></div>
                <div><strong>Phone:</strong> <%= school.phone %></div>
                <div><strong>Email:</strong> <%= school.email %></div>
            </div>
        </div>
        <div class="doc-title-bar">Admit Card / Hall Ticket</div>
        <div class="exam-meta-info"><%= exam.name %> — <%= exam.year %></div>
        <div class="profile-section">
            <div class="student-details-grid">
                ${config.showAdmissionNo ? `<div class="label">Admission No:</div><div class="value"><%= student.admission_no %></div>` : ''}
                ${config.showRollNo ? `<div class="label">Roll Number:</div><div class="value"><%= student.roll_number %></div>` : ''}
                <div class="label">Student Name:</div><div class="value"><%= student.name %></div>
                ${config.showFatherName ? `<div class="label">Father Name:</div><div class="value"><%= student.father_name %></div>` : ''}
                ${config.showMotherName ? `<div class="label">Mother Name:</div><div class="value"><%= student.mother_name %></div>` : ''}
                ${config.showDob ? `<div class="label">Date of Birth:</div><div class="value"><%= student.dob %></div>` : ''}
                <div class="label"><%= labels.classLabel %>:</div><div class="value"><%= student.class %></div>
            </div>
            <div class="photo-box">
                <img src="<%= student.profile_image %>" alt="Student Photo" onerror="this.src='https://via.placeholder.com/100?text=PHOTO'">
            </div>
        </div>
        <div style="font-size: 13px; font-weight: 800; color: ${config.primaryColor}; margin-bottom: 8px; text-transform: uppercase; border-left: 4px solid ${config.primaryColor}; padding-left: 8px;">Examination Timetable</div>
        <table>
            <thead>
                <tr>
                    <th style="width: 25%;">Subject</th>
                    <th style="width: 15%;">Type</th>
                    <th style="width: 15%;">Date</th>
                    <th style="width: 15%;">Day</th>
                    <th style="width: 20%;">Time</th>
                    <th style="width: 10%;">Room</th>
                </tr>
            </thead>
            <tbody>
                <% if (schedules && schedules.length > 0) { %>
                    <% schedules.forEach(function(item) { %>
                    <tr>
                        <td style="text-align: left; font-weight: 700;"><%= item.subject %></td>
                        <td><%= item.examType %></td>
                        <td><%= item.date %></td>
                        <td><%= item.day %></td>
                        <td><%= item.timeStr %></td>
                        <td><%= item.room %></td>
                    </tr>
                    <% }); %>
                <% } else { %>
                    <tr>
                        <td colspan="6" style="text-align: center; color: #94a3b8; font-style: italic; padding: 15px;">No exam schedules found.</td>
                    </tr>
                <% } %>
            </tbody>
        </table>
        <div class="instructions-box">
            <h4>Important Guidelines for Candidates</h4>
            <ul>
                ${config.guidelines.map(g => `<li>${g}</li>`).join('\n                ')}
            </ul>
        </div>
        <div class="signatures-section">
            <div class="sig-box">${config.sig1}</div>
            <div class="sig-box">${config.sig2}</div>
            <div class="sig-box">${config.sig3}</div>
        </div>
    </div>
</body>
</html>`
    }

    // EJS Compiler - Generates raw EJS template from visual configurations for Report Cards (3 styles support)
    const generateReportCardHtml = (config: typeof reportConfig) => {
        if (reportPreset === 'university') {
            return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Transcript</title>
    <style>
        body {
            font-family: '${config.fontFamily}', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            color: #1e293b;
        }
        .header {
            display: flex;
            flex-direction: ${config.headerStyle === 'centered' ? 'column' : 'row'};
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px double ${config.primaryColor};
            padding-bottom: 15px;
            margin-bottom: 20px;
            background: ${config.headerStyle === 'boxed' ? config.primaryColor + '0a' : 'transparent'};
            padding: ${config.headerStyle === 'boxed' ? '18px' : '0 0 15px 0'};
            border-radius: 8px;
            text-align: ${config.headerStyle === 'centered' ? 'center' : 'left'};
        }
        .header-left {
            display: flex;
            flex-direction: ${config.headerStyle === 'centered' ? 'column' : 'row'};
            align-items: center;
        }
        .header-left img {
            width: 85px;
            height: 85px;
            object-fit: contain;
            margin: ${config.headerStyle === 'centered' ? '0 0 12px 0' : '0 18px 0 0'};
        }
        .header-title h1 {
            margin: 0;
            font-size: 26px;
            font-weight: 800;
            color: ${config.primaryColor};
        }
        .header-right {
            text-align: ${config.headerStyle === 'centered' ? 'center' : 'right'};
            font-size: 12px;
            color: #475569;
            line-height: 1.5;
            margin-top: ${config.headerStyle === 'centered' ? '12px' : '0'};
        }
        .exam-title {
            text-align: center;
            margin-bottom: 25px;
            border-left: 5px solid ${config.primaryColor};
            border-right: 5px solid ${config.primaryColor};
            padding: 8px 0;
            background: #f8fafc;
        }
        .exam-title h2 {
            margin: 0;
            font-size: 16px;
            font-weight: 800;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: ${config.primaryColor};
        }
        .exam-title p {
            margin: 4px 0 0 0;
            font-size: 12px;
            color: #64748b;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
            font-size: 12px;
        }
        th, td {
            border: 1px solid #cbd5e1;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: ${config.tableHeaderBg};
            color: ${config.tableHeaderColor};
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        td {
            color: #334155;
        }
        .student-details {
            display: grid;
            grid-template-columns: max-content 1fr max-content 1fr;
            gap: 10px 20px;
            margin-bottom: 25px;
            font-size: 12px;
            padding: 15px;
            background: #f8fafc;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }
        .student-details .label {
            color: #64748b;
            font-weight: 600;
        }
        .student-details .value {
            color: #0f172a;
            font-weight: 700;
        }
        .marks-table tr:nth-child(even) {
            background-color: ${config.tableStriped ? '#f8fafc' : 'transparent'};
        }
        .summary-row {
            font-weight: 800;
            background-color: ${config.tableHeaderBg};
            color: ${config.primaryColor};
        }
        .gpa-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }
        .gpa-card {
            width: 100%;
            max-width: 450px;
            padding: 15px;
            background: ${config.primaryColor}0d;
            border-radius: 8px;
            border-left: 5px solid ${config.primaryColor};
            text-align: center;
        }
        .gpa-value {
            font-size: 32px;
            font-weight: 900;
            color: ${config.primaryColor};
            margin: 5px 0;
        }
        .signatures {
            display: flex;
            justify-content: space-between;
            margin-top: 50px;
            padding: 0 10px;
        }
        .signature-box {
            text-align: center;
            min-width: 160px;
            border-top: 2px solid #334155;
            padding-top: 8px;
            font-size: 11px;
            font-weight: 700;
            color: #0f172a;
        }
        .footer-note {
            text-align: center;
            font-size: 10px;
            color: #64748b;
            margin-top: 30px;
            border-top: 1px solid #e2e8f0;
            padding-top: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <img src="<%= school.logoPath %>" alt="Institution Logo" onerror="this.src='https://via.placeholder.com/80?text=LOGO'">
            <div class="header-title">
                <h1>${config.schoolNameOverride || '<%= school.name %>'}</h1>
                <span style="display:inline-block; font-size:10px; font-weight:700; letter-spacing:1px; background:${config.primaryColor}; color:#fff; padding:2px 8px; border-radius:3px; margin-top:5px; text-transform:uppercase;">${config.schoolSubtitleOverride}</span>
            </div>
        </div>
        <div class="header-right">
            <div><strong>Address:</strong> <%= school.address %></div>
            <div><strong>Phone:</strong> <%= school.phone %></div>
            <div><strong>Email:</strong> <%= school.email %></div>
        </div>
    </div>
    <div class="exam-title">
        <h2><%= exam.name %></h2>
        <p>ACADEMIC SESSION: <%= exam.year %></p>
    </div>
    <div class="student-details">
        <div class="label">STUDENT NAME</div>
        <div class="value"><%= student.name %></div>
        <div class="label">ADMISSION NO</div>
        <div class="value"><%= student.admission_no %></div>
        ${config.showFatherName ? `<div class="label">FATHER NAME</div><div class="value"><%= student.father_name %></div>` : ''}
        ${config.showRollNo ? `<div class="label">ROLL NUMBER</div><div class="value"><%= student.roll_number %></div>` : ''}
        ${config.showDob ? `<div class="label">DATE OF BIRTH</div><div class="value"><%= student.dob %></div>` : ''}
        <div class="label">PROGRAM / COURSE</div>
        <div class="value"><%= student.class %></div>
    </div>
    <table class="marks-table">
        <thead>
            <tr>
                <th style="text-align: left;">COURSE / SUBJECT</th>
                <th>TYPE</th>
                <th>CREDITS</th>
                <th>MAX MARKS</th>
                <th>MIN MARKS</th>
                <th>OBTAINED</th>
                <th>GRADE</th>
                <th>GRADE POINT</th>
            </tr>
        </thead>
        <tbody>
            <% marks.forEach(function(item) { %>
            <tr>
                <td style="text-align: left; font-weight: 700; color: #0f172a;"><%= item.subject %></td>
                <td><span style="display:inline-block; font-size:9px; padding:2px 6px; border-radius:4px; background:#e2e8f0; color:#334155; font-weight:700;"><%= item.examType %></span></td>
                <td><%= item.creditHours %></td>
                <td><%= item.maxMarks %></td>
                <td><%= item.minMarks %></td>
                <td style="font-weight: 700;"><%= item.marksObtained %></td>
                <td style="font-weight: 800; color: ${config.primaryColor};"><%= item.grade %></td>
                <td><%= item.gradePoint %></td>
            </tr>
            <% }); %>
            <tr class="summary-row">
                <td colspan="2" style="text-align: right; font-weight: 800;">CUMULATIVE TOTAL</td>
                <td><%= totalCredits %></td>
                <td><%= grandTotalMax %></td>
                <td></td>
                <td style="font-weight: 800;"><%= grandTotalObtained %></td>
                <td></td>
                <td><%= totalCreditPoints %></td>
            </tr>
        </tbody>
    </table>
    <div class="gpa-container">
        <div class="gpa-card">
            <div style="font-size: 11px; font-weight: 700; color: #64748b; letter-spacing: 1px;">SEMESTER GRADE POINT AVERAGE (SGPA)</div>
            <div class="gpa-value"><%= sgpa %></div>
            <div style="font-size: 11px; color: #64748b;">Total Credits: <%= totalCredits %> &nbsp;|&nbsp; Earned Points: <%= totalCreditPoints %></div>
        </div>
    </div>
    <div class="signatures">
        <div class="signature-box">${config.sig1}</div>
        <div class="signature-box">${config.sig2}</div>
        <div class="signature-box">${config.sig3}</div>
    </div>
    ${config.showFooterNote ? `<div class="footer-note">${config.footerNote}</div>` : ''}
</body>
</html>`
        }

        if (reportPreset === 'minimalist') {
            return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report Card</title>
    <style>
        body {
            font-family: '${config.fontFamily}', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 15px;
            color: #334155;
            background-color: #fff;
            font-size: 11px;
        }
        .card-container {
            border: 1px solid #e2e8f0;
            padding: 20px;
            border-radius: 8px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid ${config.primaryColor};
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        .header-title h1 {
            margin: 0;
            font-size: 20px;
            font-weight: 800;
            color: ${config.primaryColor};
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        th, td {
            border: 1px solid #cbd5e1;
            padding: 6px 8px;
            text-align: center;
        }
        th {
            background-color: ${config.tableHeaderBg};
            color: ${config.tableHeaderColor};
            font-weight: 700;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px 15px;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px dashed #e2e8f0;
        }
        .details-grid div:nth-child(odd) {
            color: #64748b;
            font-weight: 600;
        }
        .details-grid div:nth-child(even) {
            color: #0f172a;
            font-weight: 700;
        }
        .signatures {
            display: flex;
            justify-content: space-between;
            margin-top: 35px;
        }
        .signature-box {
            text-align: center;
            width: 120px;
            border-top: 1px solid #94a3b8;
            padding-top: 4px;
            font-weight: 600;
            color: #475569;
        }
    </style>
</head>
<body>
    <div class="card-container">
        <div class="header">
            <div>
                <h1 class="header-title">${config.schoolNameOverride || '<%= school.name %>'}</h1>
                <div style="color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px;">${config.schoolSubtitleOverride}</div>
            </div>
            <div style="text-align: right; color: #64748b; font-size: 9px;">
                <div><%= school.phone %> | <%= school.email %></div>
            </div>
        </div>
        <div style="text-align: center; font-weight: 800; font-size: 12px; margin-bottom: 15px; color: ${config.primaryColor}; text-transform: uppercase;"><%= exam.name %> (<%= exam.year %>)</div>
        <div class="details-grid">
            <div>Student Name:</div>
            <div style="grid-column: span 3;"><%= student.name %></div>
            ${config.showAdmissionNo ? `<div>Admission No:</div><div><%= student.admission_no %></div>` : ''}
            ${config.showRollNo ? `<div>Roll Number:</div><div><%= student.roll_number %></div>` : ''}
            ${config.showFatherName ? `<div>Father Name:</div><div><%= student.father_name %></div>` : ''}
            ${config.showDob ? `<div>Date of Birth:</div><div><%= student.dob %></div>` : ''}
            <div>Class:</div>
            <div><%= student.class %></div>
            <div>Session:</div>
            <div><%= exam.year %></div>
        </div>
        <table class="marks-table">
            <thead>
                <tr style="background: ${config.tableHeaderBg}; color: ${config.tableHeaderColor};">
                    <th style="text-align: left;">Subject</th>
                    <th>Max Marks</th>
                    <th>Min Marks</th>
                    <th>Obtained</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <% marks.forEach(function(item) { %>
                <tr>
                    <td style="text-align: left; font-weight: 700; color: #0f172a;"><%= item.subject %></td>
                    <td><%= item.maxMarks %></td>
                    <td><%= item.minMarks %></td>
                    <td style="font-weight: 700;"><%= item.marksObtained %></td>
                    <td><%= item.remarks %></td>
                </tr>
                <% }); %>
                <tr style="font-weight: bold; background: ${config.tableHeaderBg};">
                    <td colspan="3" style="text-align: right;">GRAND TOTAL</td>
                    <td style="color: ${config.primaryColor};"><%= grandTotalObtained %> / <%= grandTotalMax %></td>
                    <td><%= percentage %>%</td>
                </tr>
            </tbody>
        </table>
        <div style="margin-top: 10px; padding: 6px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; text-align: center; font-weight: 700; text-transform: uppercase;">
            Result Status: <span style="color: ${config.primaryColor};"><%= result %></span>
        </div>
        <div class="signatures">
            <div class="signature-box">${config.sig1}</div>
            <div class="signature-box">${config.sig2}</div>
            <div class="signature-box">${config.sig3}</div>
        </div>
        ${config.showFooterNote ? `<div style="text-align: center; font-size: 8px; color: #94a3b8; margin-top: 20px; border-top: 1px solid #f1f5f9; padding-top: 6px;">${config.footerNote}</div>` : ''}
    </div>
</body>
</html>`
        }

        // Preset === 'classic' (Default)
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report Card</title>
    <style>
        body {
            font-family: '${config.fontFamily}', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .header {
            display: flex;
            flex-direction: ${config.headerStyle === 'centered' ? 'column' : 'row'};
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid ${config.primaryColor};
            padding-bottom: 15px;
            margin-bottom: 20px;
            background: ${config.headerStyle === 'boxed' ? config.primaryColor + '0d' : 'transparent'};
            padding: ${config.headerStyle === 'boxed' ? '15px' : '0 0 15px 0'};
            border-radius: ${config.headerStyle === 'boxed' ? '8px' : '0'};
            text-align: ${config.headerStyle === 'centered' ? 'center' : 'left'};
        }
        .header-left {
            display: flex;
            flex-direction: ${config.headerStyle === 'centered' ? 'column' : 'row'};
            align-items: center;
        }
        .header-left img {
            width: 80px;
            height: 80px;
            object-fit: contain;
            margin: ${config.headerStyle === 'centered' ? '0 0 10px 0' : '0 15px 0 0'};
        }
        .header-title h1 {
            margin: 0;
            font-size: 28px;
            color: ${config.primaryColor};
        }
        .header-right {
            text-align: ${config.headerStyle === 'centered' ? 'center' : 'right'};
            font-size: 13px;
            line-height: 1.6;
            margin-top: ${config.headerStyle === 'centered' ? '12px' : '0'};
        }
        .exam-title {
            text-align: center;
            margin-bottom: 20px;
        }
        .exam-title h2 {
            margin: 0;
            font-size: 18px;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: ${config.primaryColor};
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 13px;
        }
        th, td {
            border: 1px solid #999;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: ${config.tableHeaderBg};
            color: ${config.tableHeaderColor};
            font-weight: bold;
            text-transform: uppercase;
        }
        .student-details {
            display: grid;
            grid-template-columns: max-content 1fr;
            gap: 5px 20px;
            margin-bottom: 20px;
            font-size: 12px;
            text-transform: uppercase;
        }
        .student-details div:nth-child(even) {
            font-weight: bold;
        }
        .marks-table tr:nth-child(even) {
            background-color: ${config.tableStriped ? '#f9f9f9' : 'transparent'};
        }
        .signatures {
            display: flex;
            justify-content: space-between;
            margin-top: 50px;
            padding: 0 20px;
        }
        .signature-box {
            text-align: center;
            min-width: 150px;
            border-top: 1px solid #000;
            padding-top: 10px;
            font-size: 12px;
            font-weight: bold;
        }
        .footer-note {
            text-align: center;
            font-size: 10px;
            color: #777;
            margin-top: 30px;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <img src="<%= school.logoPath %>" alt="Institution Logo" onerror="this.src='https://via.placeholder.com/80?text=LOGO'">
            <div class="header-title">
                <h1>${config.schoolNameOverride || '<%= school.name %>'}</h1>
                <span style="display:inline-block; font-size:10px; font-weight:700; letter-spacing:1px; background:${config.primaryColor}; color:#fff; padding:2px 8px; border-radius:3px; margin-top:4px; text-transform:uppercase;">${config.schoolSubtitleOverride}</span>
            </div>
        </div>
        <div class="header-right">
            <div><strong>Address:</strong> <%= school.address %></div>
            <div><strong>Phone No.:</strong> <%= school.phone %></div>
        </div>
    </div>
    <div class="exam-title">
        <h2><%= exam.name %></h2>
        <p><%= exam.year %></p>
    </div>
    <table>
        <tr>
            <th>ADMISSION NO</th>
            <th>ROLL NUMBER</th>
        </tr>
        <tr>
            <td><%= student.admission_no %></td>
            <td><%= student.roll_number %></td>
        </tr>
    </table>
    <div style="text-align: center; font-size: 12px; font-weight: bold; margin-bottom: 10px;">CERTIFIED THAT</div>
    <div class="student-details">
        <div>MR/MS</div>
        <div><%= student.name %></div>
        ${config.showFatherName ? `<div>FATHER / HUSBAND NAME</div><div><%= student.father_name %></div>` : ''}
        ${config.showMotherName ? `<div>MOTHER NAME</div><div><%= student.mother_name %></div>` : ''}
        ${config.showDob ? `<div>DATE OF BIRTH</div><div><%= student.dob %></div>` : ''}
        <div><%= labels.classLabel %></div>
        <div><%= student.class %></div>
        <div><%= labels.schoolLabel %></div>
        <div><%= school.name %></div>
    </div>
    <table class="marks-table">
        <tr>
            <th>SUBJECTS</th>
            <th>MAX MARKS</th>
            <th>MIN MARKS</th>
            <th>MARKS OBTAINED</th>
            <th>REMARKS</th>
        </tr>
        <% marks.forEach(function(item) { %>
        <tr>
            <td style="text-align: left; font-weight: bold;"><%= item.subject %></td>
            <td><%= item.maxMarks %></td>
            <td><%= item.minMarks %></td>
            <td><%= item.marksObtained %></td>
            <td><%= item.remarks %></td>
        </tr>
        <% }); %>
        <tr style="font-weight: bold; background: ${config.tableHeaderBg};">
            <td colspan="3" style="text-align: right; padding-right: 20px;">GRAND TOTAL</td>
            <td><%= grandTotalObtained %> / <%= grandTotalMax %></td>
            <td><%= percentage %>%</td>
        </tr>
    </table>
    <table style="margin-top: -21px; border-top: none;">
        <tr>
            <th style="width: 200px; border-top: none;">RESULT</th>
            <td style="font-weight:bold; border-top: none; text-align: center;"><%= result %></td>
        </tr>
    </table>
    <div class="signatures">
        <div class="signature-box">${config.sig1}</div>
        <div class="signature-box">${config.sig2}</div>
        <div class="signature-box">${config.sig3}</div>
    </div>
    ${config.showFooterNote ? `<div class="footer-note">${config.footerNote}</div>` : ''}
</body>
</html>`
    }

    // Sync visual config changes to code states automatically
    useEffect(() => {
        if (admitMode === 'visual') {
            const html = generateAdmitCardHtml(admitConfig)
            setAdmitCardTemplate(html)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [admitConfig, admitMode])

    useEffect(() => {
        if (reportMode === 'visual') {
            const html = generateReportCardHtml(reportConfig)
            setReportCardTemplate(html)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [reportConfig, reportPreset, reportMode])

    // Load configurations from EJS Database Columns
    const fetchSettings = async () => {
        try {
            setIsLoading(true)
            const response = await getAppSettings(tenantId)
            if (response.data?.success && response.data?.data) {
                const fetchedData = response.data.data
                setAdmitCardTemplate(fetchedData.admit_card_template || '')
                setReportCardTemplate(fetchedData.report_card_template || '')

                // If template exists, toggle to code mode by default to ensure custom designs aren't overwritten
                if (fetchedData.admit_card_template) {
                    setAdmitMode('code')
                }
                if (fetchedData.report_card_template) {
                    setReportMode('code')
                }
            }
        } catch (error) {
            console.error('Error fetching templates settings:', error)
            toast.error('Failed to load saved templates')
        } finally {
            setIsLoading(false)
        }
    }

    useEffect(() => {
        if (tenantId) {
            fetchSettings()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [tenantId])

    const handleSave = async () => {
        try {
            setIsSaving(true)
            const payload: UpdateAppSettingsPayload = {
                primary_color: '#4c662b', // standard fallback primary
                secondary_color: '#586249', // standard fallback secondary
                enabled_modules: {
                    exams: true,
                    fees: true,
                    notices: true,
                    assignments: true,
                    timetable: true,
                    attendance: true,
                },
                admit_card_template: admitCardTemplate || null,
                report_card_template: reportCardTemplate || null
            }
            const response = await updateAppSettings(tenantId, payload)
            if (response.data?.success) {
                toast.success('Custom PDF templates saved successfully!')
            } else {
                toast.error(response.data?.message || 'Failed to save templates')
            }
        } catch (error) {
            console.error('Error saving app settings:', error)
            toast.error('An error occurred while saving templates')
        } finally {
            setIsSaving(false)
        }
    }

    // Reset editor content with EJS Defaults
    const loadDefaultAdmitCard = () => {
        setAdmitMode('code')
        setAdmitCardTemplate(DEFAULT_ADMIT_CARD_EJS)
        toast.success('Loaded Premium Default Admit Card Template')
    }

    const loadDefaultReportCard = () => {
        setReportMode('code')
        setReportCardTemplate(DEFAULT_REPORT_CARD_EJS)
        toast.success('Loaded Premium Default Report Card Template')
    }

    // Handle Guideline addition/editing
    const handleAddGuideline = () => {
        setAdmitConfig(prev => ({
            ...prev,
            guidelines: [...prev.guidelines, 'New guideline point...']
        }))
    }

    const handleEditGuideline = (index: number, val: string) => {
        const updated = [...admitConfig.guidelines]
        updated[index] = val
        setAdmitConfig(prev => ({ ...prev, guidelines: updated }))
    }

    const handleRemoveGuideline = (index: number) => {
        const updated = admitConfig.guidelines.filter((_, i) => i !== index)
        setAdmitConfig(prev => ({ ...prev, guidelines: updated }))
    }

    return (
        <>
            <PageTitle breadcrumbs={[]}>Custom PDF Templates</PageTitle>
            <Toaster position="top-right" />

            <div className='card mb-6 shadow-sm border-0'>
                {/* Visual Canva Header tabs */}
                <div className='card-header border-0 pt-5 bg-white d-flex align-items-center justify-content-between flex-wrap gap-4'>
                    <div className='d-flex align-items-center gap-3'>
                        <div className='symbol symbol-40px bg-light-primary rounded-circle p-2 d-flex align-items-center justify-content-center' style={{ width: 44, height: 44 }}>
                            <KTIcon iconName='notepad' className='fs-2 text-primary' />
                        </div>
                        <div>
                            <h3 className='fw-bold m-0 text-gray-900'>Canva-style PDF Template Workspace</h3>
                            <p className='text-muted fs-7 m-0'>Visual designer and code editor to personalize student admit and result layouts.</p>
                        </div>
                    </div>

                    <div className='d-flex align-items-center gap-2 bg-light rounded p-1'>
                        <button
                            className={`btn btn-sm px-4 fw-bold border-0 ${activeSection === 'admit' ? 'bg-primary text-white shadow-sm' : 'text-gray-600'}`}
                            onClick={() => setActiveSection('admit')}
                        >
                            <i className='bi bi-card-heading me-2'></i>
                            Student Admit Cards
                        </button>
                        <button
                            className={`btn btn-sm px-4 fw-bold border-0 ${activeSection === 'report' ? 'bg-success text-white shadow-sm' : 'text-gray-600'}`}
                            onClick={() => setActiveSection('report')}
                        >
                            <i className='bi bi-journal-text me-2'></i>
                            Report Cards (Results)
                        </button>
                    </div>
                </div>
            </div>

            {isLoading ? (
                <div className='card p-10 text-center shadow-sm border-0 bg-white'>
                    <span className='spinner-border spinner-border text-primary my-5' />
                    <h5 className='text-gray-600 fw-semibold'>Loading template database...</h5>
                </div>
            ) : (
                <div className='row g-6'>
                    {/* ADMIT CARD WORKSPACE */}
                    {activeSection === 'admit' && (
                        <>
                            {/* Left Settings Sidebar (35%) */}
                            <div className='col-xl-4'>
                                <div className='card shadow-sm border-0 h-100 d-flex flex-column bg-white'>
                                    <div className='card-header border-0 bg-light-primary py-4 d-flex align-items-center justify-content-between'>
                                        <h4 className='card-title fw-bold text-primary m-0'>
                                            <i className='bi bi-sliders me-2 text-primary fs-4'></i> Visual Designer
                                        </h4>
                                        <div className='btn-group'>
                                            <button
                                                className={`btn btn-xs fw-bold ${admitMode === 'visual' ? 'btn-primary' : 'btn-light'}`}
                                                onClick={() => setAdmitMode('visual')}
                                            >
                                                Visual
                                            </button>
                                            <button
                                                className={`btn btn-xs fw-bold ${admitMode === 'code' ? 'btn-primary' : 'btn-light'}`}
                                                onClick={() => setAdmitMode('code')}
                                            >
                                                Code EJS
                                            </button>
                                        </div>
                                    </div>

                                    {admitMode === 'visual' ? (
                                        <div className='card-body flex-grow-1 overflow-auto p-6' style={{ maxHeight: '72vh' }}>
                                            {/* Section 1: Themes & Palettes */}
                                            <div className='mb-6'>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>1. Theme Style Preset</label>
                                                <div className='row g-2 mb-4'>
                                                    {Object.keys(PRESETS).map((key) => (
                                                        <div key={key} className='col-6'>
                                                            <button
                                                                type='button'
                                                                className={`btn btn-sm w-100 text-capitalize d-flex align-items-center justify-content-between px-3 ${admitPreset === key ? 'btn-outline-primary border-2 fw-bold bg-light-primary' : 'btn-light'}`}
                                                                onClick={() => applyAdmitPreset(key as any)}
                                                            >
                                                                {key}
                                                                <span className='d-inline-block rounded-circle' style={{ width: 12, height: 12, background: PRESETS[key as keyof typeof PRESETS].primary }}></span>
                                                            </button>
                                                        </div>
                                                    ))}
                                                </div>
                                                <div className='d-flex align-items-center gap-3 mt-4'>
                                                    <div className='flex-grow-1'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Primary Theme Color</label>
                                                        <div className='d-flex align-items-center gap-2'>
                                                            <input
                                                                type='color'
                                                                className='form-control form-control-solid p-1 border rounded'
                                                                style={{ width: 44, height: 32 }}
                                                                value={admitConfig.primaryColor}
                                                                onChange={(e) => {
                                                                    setAdmitPreset('custom')
                                                                    setAdmitConfig(prev => ({ ...prev, primaryColor: e.target.value }))
                                                                }}
                                                            />
                                                            <span className='fs-8 font-monospace text-gray-600'>{admitConfig.primaryColor}</span>
                                                        </div>
                                                    </div>
                                                    <div className='flex-grow-1'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Secondary Color</label>
                                                        <div className='d-flex align-items-center gap-2'>
                                                            <input
                                                                type='color'
                                                                className='form-control form-control-solid p-1 border rounded'
                                                                style={{ width: 44, height: 32 }}
                                                                value={admitConfig.secondaryColor}
                                                                onChange={(e) => {
                                                                    setAdmitPreset('custom')
                                                                    setAdmitConfig(prev => ({ ...prev, secondaryColor: e.target.value }))
                                                                }}
                                                            />
                                                            <span className='fs-8 font-monospace text-gray-600'>{admitConfig.secondaryColor}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <hr className='text-gray-200 my-5' />

                                            {/* Section 2: Header & Typography */}
                                            <div className='mb-6'>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>2. Layout & Typography</label>
                                                <div className='mb-4'>
                                                    <label className='form-label text-muted fs-8 mb-1'>Font Family</label>
                                                    <select
                                                        className='form-select form-select-sm form-select-solid'
                                                        value={admitConfig.fontFamily}
                                                        onChange={(e) => setAdmitConfig(prev => ({ ...prev, fontFamily: e.target.value }))}
                                                    >
                                                        <option value='Inter'>Inter (Sleek Clean)</option>
                                                        <option value='Outfit'>Outfit (Modern Rounded)</option>
                                                        <option value='Montserrat'>Montserrat (Geometric Bold)</option>
                                                        <option value='Georgia'>Georgia (Classic Editorial)</option>
                                                    </select>
                                                </div>
                                                <div className='row g-3'>
                                                    <div className='col-6'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Logo Position</label>
                                                        <select
                                                            className='form-select form-select-sm form-select-solid'
                                                            value={admitConfig.logoPosition}
                                                            onChange={(e) => setAdmitConfig(prev => ({ ...prev, logoPosition: e.target.value as any }))}
                                                        >
                                                            <option value='left'>Left Align</option>
                                                            <option value='center'>Centered Header</option>
                                                        </select>
                                                    </div>
                                                    <div className='col-6'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Outline Border</label>
                                                        <select
                                                            className='form-select form-select-sm form-select-solid'
                                                            value={admitConfig.borderStyle}
                                                            onChange={(e) => setAdmitConfig(prev => ({ ...prev, borderStyle: e.target.value as any }))}
                                                        >
                                                            <option value='double'>Double (Elegant)</option>
                                                            <option value='solid'>Solid (Clean)</option>
                                                            <option value='dashed'>Dashed (Retro)</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <hr className='text-gray-200 my-5' />

                                            {/* Section 3: Element Toggles */}
                                            <div className='mb-6'>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>3. Toggle Card Elements</label>
                                                <div className='row g-4'>
                                                    <div className='col-6 d-flex align-items-center justify-content-between'>
                                                        <span className='fs-8 fw-semibold text-gray-700'>Student Photo</span>
                                                        <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                            <input className='form-check-input' type='checkbox' checked={admitConfig.showPhoto} onChange={() => setAdmitConfig(prev => ({ ...prev, showPhoto: !prev.showPhoto }))} />
                                                        </div>
                                                    </div>
                                                    <div className='col-6 d-flex align-items-center justify-content-between'>
                                                        <span className='fs-8 fw-semibold text-gray-700'>Watermark</span>
                                                        <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                            <input className='form-check-input' type='checkbox' checked={admitConfig.showWatermark} onChange={() => setAdmitConfig(prev => ({ ...prev, showWatermark: !prev.showWatermark }))} />
                                                        </div>
                                                    </div>
                                                    <div className='col-6 d-flex align-items-center justify-content-between'>
                                                        <span className='fs-8 fw-semibold text-gray-700'>Admission No.</span>
                                                        <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                            <input className='form-check-input' type='checkbox' checked={admitConfig.showAdmissionNo} onChange={() => setAdmitConfig(prev => ({ ...prev, showAdmissionNo: !prev.showAdmissionNo }))} />
                                                        </div>
                                                    </div>
                                                    <div className='col-6 d-flex align-items-center justify-content-between'>
                                                        <span className='fs-8 fw-semibold text-gray-700'>Exam Roll No.</span>
                                                        <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                            <input className='form-check-input' type='checkbox' checked={admitConfig.showRollNo} onChange={() => setAdmitConfig(prev => ({ ...prev, showRollNo: !prev.showRollNo }))} />
                                                        </div>
                                                    </div>
                                                    <div className='col-6 d-flex align-items-center justify-content-between'>
                                                        <span className='fs-8 fw-semibold text-gray-700'>Father's Name</span>
                                                        <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                            <input className='form-check-input' type='checkbox' checked={admitConfig.showFatherName} onChange={() => setAdmitConfig(prev => ({ ...prev, showFatherName: !prev.showFatherName }))} />
                                                        </div>
                                                    </div>
                                                    <div className='col-6 d-flex align-items-center justify-content-between'>
                                                        <span className='fs-8 fw-semibold text-gray-700'>Mother's Name</span>
                                                        <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                            <input className='form-check-input' type='checkbox' checked={admitConfig.showMotherName} onChange={() => setAdmitConfig(prev => ({ ...prev, showMotherName: !prev.showMotherName }))} />
                                                        </div>
                                                    </div>
                                                </div>
                                                {admitConfig.showWatermark && (
                                                    <div className='mt-4'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Watermark Text</label>
                                                        <input
                                                            type='text'
                                                            className='form-control form-control-sm form-control-solid fw-bold'
                                                            value={admitConfig.watermarkText}
                                                            onChange={(e) => setAdmitConfig(prev => ({ ...prev, watermarkText: e.target.value }))}
                                                        />
                                                    </div>
                                                )}
                                            </div>

                                            <hr className='text-gray-200 my-5' />

                                            {/* Section 4: Guidelines list */}
                                            <div className='mb-6'>
                                                <div className='d-flex align-items-center justify-content-between mb-3'>
                                                    <label className='form-label fw-bold text-gray-800 fs-7 m-0'>4. Guidelines for Candidates</label>
                                                    <button type='button' className='btn btn-xs btn-light-primary fw-bold border-0' onClick={handleAddGuideline}>
                                                        + Add Point
                                                    </button>
                                                </div>
                                                <div className='d-flex flex-column gap-2'>
                                                    {admitConfig.guidelines.map((point, index) => (
                                                        <div key={index} className='d-flex align-items-center gap-2'>
                                                            <span className='badge bg-light-primary text-primary fw-bold font-monospace'>{index + 1}</span>
                                                            <input
                                                                type='text'
                                                                className='form-control form-control-sm form-control-solid flex-grow-1'
                                                                value={point}
                                                                onChange={(e) => handleEditGuideline(index, e.target.value)}
                                                            />
                                                            <button
                                                                type='button'
                                                                className='btn btn-icon btn-sm btn-light-danger border-0 rounded-circle'
                                                                style={{ width: 26, height: 26 }}
                                                                onClick={() => handleRemoveGuideline(index)}
                                                            >
                                                                <i className='bi bi-trash fs-8'></i>
                                                            </button>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>

                                            <hr className='text-gray-200 my-5' />

                                            {/* Section 5: Signature labels */}
                                            <div>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>5. Sign-off Authorities</label>
                                                <div className='row g-3'>
                                                    <div className='col-4'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Sig 1 Label</label>
                                                        <input type='text' className='form-control form-control-sm form-control-solid' value={admitConfig.sig1} onChange={(e) => setAdmitConfig(prev => ({ ...prev, sig1: e.target.value }))} />
                                                    </div>
                                                    <div className='col-4'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Sig 2 Label</label>
                                                        <input type='text' className='form-control form-control-sm form-control-solid' value={admitConfig.sig2} onChange={(e) => setAdmitConfig(prev => ({ ...prev, sig2: e.target.value }))} />
                                                    </div>
                                                    <div className='col-4'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Sig 3 Label</label>
                                                        <input type='text' className='form-control form-control-sm form-control-solid' value={admitConfig.sig3} onChange={(e) => setAdmitConfig(prev => ({ ...prev, sig3: e.target.value }))} />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className='card-body flex-grow-1 p-6 d-flex flex-column h-100'>
                                            <div className='alert alert-light-warning border border-dashed border-warning rounded p-4 mb-4 fs-7 text-gray-700'>
                                                <KTIcon iconName='information-5' className='fs-3 text-warning me-2' />
                                                <strong>Caution:</strong> Writing custom EJS code directly will ignore any adjustments made in the "Visual Designer" sidebar. Click below to load the starting premium EJS template.
                                            </div>
                                            <textarea
                                                className='form-control form-control-solid font-monospace fs-8 flex-grow-1 bg-dark text-white rounded p-4 mb-4'
                                                rows={22}
                                                style={{ fontFamily: 'Courier, monospace', fontSize: '11px', lineHeight: '1.4' }}
                                                value={admitCardTemplate}
                                                onChange={(e) => setAdmitCardTemplate(e.target.value)}
                                            />
                                            <button
                                                type='button'
                                                className='btn btn-sm btn-light-primary fw-bold w-100 border border-dashed border-primary mt-auto'
                                                onClick={loadDefaultAdmitCard}
                                            >
                                                Load EJS Premium Default
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Right Live Preview Canvas (65%) */}
                            <div className='col-xl-8'>
                                <div className='card shadow-sm border-0 h-100 bg-light p-6 d-flex align-items-center justify-content-center' style={{ minHeight: '65vh' }}>
                                    <div className='w-100 mb-4 d-flex justify-content-between align-items-center px-4'>
                                        <h5 className='fw-bold text-gray-800 m-0 d-flex align-items-center'>
                                            <i className='bi bi-eye me-2 text-primary fs-4'></i> Dynamic Preview Simulation (A4 Page)
                                        </h5>
                                        <span className='badge bg-light-success text-success fw-bold px-3 py-2 fs-8 rounded'>
                                            Auto-generating EJS markup...
                                        </span>
                                    </div>

                                    {/* Mock Card Preview Container */}
                                    <div
                                        className='bg-white shadow-lg p-9 w-100 rounded-3 border border-gray-200'
                                        style={{
                                            maxWidth: '750px',
                                            minHeight: '800px',
                                            fontFamily: `${admitConfig.fontFamily}, sans-serif`,
                                            position: 'relative',
                                            overflow: 'hidden',
                                            transition: 'all 0.3s ease'
                                        }}
                                    >
                                        {/* Watermark */}
                                        {admitConfig.showWatermark && (
                                            <div
                                                style={{
                                                    position: 'absolute',
                                                    top: '50%',
                                                    left: '50%',
                                                    transform: 'translate(-50%, -50%) rotate(-30deg)',
                                                    fontSize: '70px',
                                                    fontWeight: 900,
                                                    color: 'rgba(226, 232, 240, 0.45)',
                                                    letterSpacing: '5px',
                                                    pointerEvents: 'none',
                                                    zIndex: 0,
                                                    whiteSpace: 'nowrap',
                                                    textTransform: 'uppercase'
                                                }}
                                            >
                                                {admitConfig.watermarkText}
                                            </div>
                                        )}

                                        {/* Card container box */}
                                        <div
                                            style={{
                                                border: `3px ${admitConfig.borderStyle} ${admitConfig.primaryColor}`,
                                                borderRadius: '12px',
                                                padding: '24px',
                                                position: 'relative',
                                                zIndex: 1,
                                                background: '#ffffffef'
                                            }}
                                        >
                                            {/* School Header */}
                                            <div className={`d-flex align-items-center justify-content-between pb-4 mb-4 border-bottom`} style={{ borderBottomWidth: '3px', borderBottomColor: admitConfig.primaryColor, flexDirection: admitConfig.logoPosition === 'center' ? 'column' : 'row', textAlign: admitConfig.logoPosition === 'center' ? 'center' : 'left' }}>
                                                <div className='d-flex align-items-center' style={{ flexDirection: admitConfig.logoPosition === 'center' ? 'column' : 'row' }}>
                                                    <img
                                                        src='https://via.placeholder.com/80?text=LOGO'
                                                        alt='School Logo'
                                                        className='rounded-3 mb-2'
                                                        style={{ width: '80px', height: '80px', marginRight: admitConfig.logoPosition === 'center' ? 0 : '18px' }}
                                                    />
                                                    <div>
                                                        <h1 className='fw-bold m-0' style={{ fontSize: '24px', color: admitConfig.primaryColor }}>ALPHA INTERNATIONAL SCHOOL</h1>
                                                        <span className='badge text-white font-weight-bold uppercase fs-9 mt-2' style={{ background: admitConfig.secondaryColor }}>College / University</span>
                                                    </div>
                                                </div>
                                                <div className='fs-8 text-muted text-right' style={{ textAlign: admitConfig.logoPosition === 'center' ? 'center' : 'right', marginTop: admitConfig.logoPosition === 'center' ? '10px' : 0 }}>
                                                    <div><strong>Address:</strong> Sector 4, Salt Lake, Kolkata</div>
                                                    <div><strong>Phone:</strong> +91 9876543210</div>
                                                    <div><strong>Email:</strong> admin@alphaschool.edu</div>
                                                </div>
                                            </div>

                                            {/* Document Title Banner */}
                                            <div className='text-center text-white fw-bold py-2 rounded-3 mb-4' style={{ background: admitConfig.primaryColor, fontSize: '14px', letterSpacing: '1px', textTransform: 'uppercase' }}>
                                                Admit Card / Hall Ticket
                                            </div>

                                            <div className='text-center text-muted fw-bold fs-7 mb-4' style={{ marginTop: '-12px' }}>
                                                ANNUAL BOARD EXAMINATION — 2026
                                            </div>

                                            {/* Profile Row */}
                                            <div className='d-flex justify-content-between align-items-start gap-4 mb-5'>
                                                <div className='student-details-grid flex-grow-1' style={{ display: 'grid', gridTemplateColumns: 'max-content 1fr', gap: '8px 15px', fontSize: '12px' }}>
                                                    {admitConfig.showAdmissionNo && (
                                                        <>
                                                            <div className='text-muted fw-bold uppercase' style={{ letterSpacing: '0.5px' }}>Admission No:</div>
                                                            <div className='fw-bold text-dark'>ADM/2026/4011</div>
                                                        </>
                                                    )}
                                                    {admitConfig.showRollNo && (
                                                        <>
                                                            <div className='text-muted fw-bold uppercase' style={{ letterSpacing: '0.5px' }}>Roll Number:</div>
                                                            <div className='fw-bold text-dark'>RL-992140</div>
                                                        </>
                                                    )}
                                                    <div className='text-muted fw-bold uppercase' style={{ letterSpacing: '0.5px' }}>Student Name:</div>
                                                    <div className='fw-bold text-dark uppercase'>Rohan Kumar Sharma</div>
                                                    {admitConfig.showFatherName && (
                                                        <>
                                                            <div className='text-muted fw-bold uppercase' style={{ letterSpacing: '0.5px' }}>Father Name:</div>
                                                            <div className='fw-bold text-dark'>Mr. Alok Sharma</div>
                                                        </>
                                                    )}
                                                    {admitConfig.showMotherName && (
                                                        <>
                                                            <div className='text-muted fw-bold uppercase' style={{ letterSpacing: '0.5px' }}>Mother Name:</div>
                                                            <div className='fw-bold text-dark'>Mrs. Suman Sharma</div>
                                                        </>
                                                    )}
                                                    {admitConfig.showDob && (
                                                        <>
                                                            <div className='text-muted fw-bold uppercase' style={{ letterSpacing: '0.5px' }}>Date of Birth:</div>
                                                            <div className='fw-bold text-dark'>14-08-2010</div>
                                                        </>
                                                    )}
                                                    <div className='text-muted fw-bold uppercase' style={{ letterSpacing: '0.5px' }}>Class / Section:</div>
                                                    <div className='fw-bold text-dark'>Class X - Section B</div>
                                                </div>

                                                {/* Student photo */}
                                                {admitConfig.showPhoto && (
                                                    <div className='border border-gray-300 rounded bg-light d-flex align-items-center justify-content-center' style={{ width: '95px', height: '115px' }}>
                                                        <i className='bi bi-person text-gray-400 fs-1'></i>
                                                    </div>
                                                )}
                                            </div>

                                            {/* Schedules Grid Mock */}
                                            <div className='fw-bold mb-2 uppercase fs-7' style={{ borderLeft: `4px solid ${admitConfig.primaryColor}`, paddingLeft: '8px', color: admitConfig.primaryColor, letterSpacing: '0.5px' }}>
                                                Examination Timetable
                                            </div>
                                            <table className='table table-bordered border-gray-300 text-center fs-8 mb-4' style={{ width: '100%', borderCollapse: 'collapse' }}>
                                                <thead>
                                                    <tr style={{ background: admitConfig.tableHeaderBg, color: admitConfig.tableHeaderColor }}>
                                                        <th className='py-2 px-3 fw-bold border border-gray-300'>Subject</th>
                                                        <th className='py-2 px-3 fw-bold border border-gray-300'>Type</th>
                                                        <th className='py-2 px-3 fw-bold border border-gray-300'>Date</th>
                                                        <th className='py-2 px-3 fw-bold border border-gray-300'>Day</th>
                                                        <th className='py-2 px-3 fw-bold border border-gray-300'>Time</th>
                                                    </tr>
                                                </thead>
                                                <tbody className='text-dark fw-semibold'>
                                                    <tr>
                                                        <td className='py-2 px-3 border border-gray-300 text-left fw-bold text-dark'>Mathematics (Core)</td>
                                                        <td className='py-2 px-3 border border-gray-300'><span className='badge bg-light-primary text-primary fs-9 px-2'>THEORY</span></td>
                                                        <td className='py-2 px-3 border border-gray-300'>02-06-2026</td>
                                                        <td className='py-2 px-3 border border-gray-300'>Tuesday</td>
                                                        <td className='py-2 px-3 border border-gray-300'>09:30 AM - 12:30 PM</td>
                                                    </tr>
                                                    <tr>
                                                        <td className='py-2 px-3 border border-gray-300 text-left fw-bold text-dark'>Science & Tech</td>
                                                        <td className='py-2 px-3 border border-gray-300'><span className='badge bg-light-danger text-danger fs-9 px-2'>PRACTICAL</span></td>
                                                        <td className='py-2 px-3 border border-gray-300'>04-06-2026</td>
                                                        <td className='py-2 px-3 border border-gray-300'>Thursday</td>
                                                        <td className='py-2 px-3 border border-gray-300'>10:00 AM - 01:00 PM</td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                            {/* Guidelines List Mock */}
                                            <div className='p-4 border border-gray-200 rounded mb-4' style={{ background: '#f8fafc', fontSize: '9px', lineHeight: '1.5' }}>
                                                <h6 className='fw-bold text-dark m-0 mb-2 uppercase' style={{ letterSpacing: '0.5px' }}>Guidelines for Candidates</h6>
                                                <ul className='m-0 ps-3 text-muted'>
                                                    {admitConfig.guidelines.map((g, idx) => (
                                                        <li key={idx} className='mb-1'>{g}</li>
                                                    ))}
                                                </ul>
                                            </div>

                                            {/* Signatures Mock */}
                                            <div className='d-flex justify-content-between pt-5 mt-4 border-top border-gray-300' style={{ borderTopStyle: 'dashed' }}>
                                                <div className='text-center text-muted fw-bold fs-9' style={{ width: '130px', borderTop: '1px dashed #94a3b8', paddingTop: '6px' }}>{admitConfig.sig1}</div>
                                                <div className='text-center text-muted fw-bold fs-9' style={{ width: '130px', borderTop: '1px dashed #94a3b8', paddingTop: '6px' }}>{admitConfig.sig2}</div>
                                                <div className='text-center text-muted fw-bold fs-9' style={{ width: '130px', borderTop: '1px dashed #94a3b8', paddingTop: '6px' }}>{admitConfig.sig3}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}

                    {/* REPORT CARD WORKSPACE (CANVA STYLE CHOSEN PRESETS) */}
                    {activeSection === 'report' && (
                        <>
                            {/* Left Settings Sidebar (35%) */}
                            <div className='col-xl-4'>
                                <div className='card shadow-sm border-0 h-100 d-flex flex-column bg-white'>
                                    <div className='card-header border-0 bg-light-success py-4 d-flex align-items-center justify-content-between'>
                                        <h4 className='card-title fw-bold text-success m-0'>
                                            <i className='bi bi-sliders me-2 text-success fs-4'></i> Visual Designer
                                        </h4>
                                        <div className='btn-group'>
                                            <button
                                                className={`btn btn-xs fw-bold ${reportMode === 'visual' ? 'btn-success' : 'btn-light'}`}
                                                onClick={() => setReportMode('visual')}
                                            >
                                                Visual
                                            </button>
                                            <button
                                                className={`btn btn-xs fw-bold ${reportMode === 'code' ? 'btn-success' : 'btn-light'}`}
                                                onClick={() => setReportMode('code')}
                                            >
                                                Code EJS
                                            </button>
                                        </div>
                                    </div>

                                    {reportMode === 'visual' ? (
                                        <div className='card-body flex-grow-1 overflow-auto p-6' style={{ maxHeight: '72vh' }}>
                                            {/* Section 1: Canva Presets Selector */}
                                            <div className='mb-6'>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>1. Canva Template Preset</label>
                                                <div className='d-flex flex-column gap-2'>
                                                    <div
                                                        className={`border rounded-3 p-3 cursor-pointer d-flex align-items-center justify-content-between ${reportPreset === 'classic' ? 'border-primary bg-light-primary shadow-sm' : 'border-gray-300'}`}
                                                        onClick={() => applyReportPreset('classic')}
                                                    >
                                                        <div className='d-flex align-items-center gap-3'>
                                                            <div className='p-2 bg-light rounded text-center' style={{ width: 34, height: 34 }}>
                                                                <i className='bi bi-journal-check text-primary fs-5'></i>
                                                            </div>
                                                            <div>
                                                                <h6 className='fw-bold m-0 fs-7'>Classic School Marksheet</h6>
                                                                <span className='text-muted fs-9'>Certified text, striped marks grid</span>
                                                            </div>
                                                        </div>
                                                        {reportPreset === 'classic' && <i className='bi bi-check-circle-fill text-primary fs-5'></i>}
                                                    </div>

                                                    <div
                                                        className={`border rounded-3 p-3 cursor-pointer d-flex align-items-center justify-content-between ${reportPreset === 'university' ? 'border-success bg-light-success shadow-sm' : 'border-gray-300'}`}
                                                        onClick={() => applyReportPreset('university')}
                                                    >
                                                        <div className='d-flex align-items-center gap-3'>
                                                            <div className='p-2 bg-light rounded text-center' style={{ width: 34, height: 34 }}>
                                                                <i className='bi bi-mortarboard text-success fs-5'></i>
                                                            </div>
                                                            <div>
                                                                <h6 className='fw-bold m-0 fs-7'>Modern University Grade Card</h6>
                                                                <span className='text-muted fs-9'>CGPA cards, credit hours, grade points</span>
                                                            </div>
                                                        </div>
                                                        {reportPreset === 'university' && <i className='bi bi-check-circle-fill text-success fs-5'></i>}
                                                    </div>

                                                    <div
                                                        className={`border rounded-3 p-3 cursor-pointer d-flex align-items-center justify-content-between ${reportPreset === 'minimalist' ? 'border-dark bg-light-dark shadow-sm' : 'border-gray-300'}`}
                                                        onClick={() => applyReportPreset('minimalist')}
                                                    >
                                                        <div className='d-flex align-items-center gap-3'>
                                                            <div className='p-2 bg-light rounded text-center' style={{ width: 34, height: 34 }}>
                                                                <i className='bi bi-grid-3x3-gap text-dark fs-5'></i>
                                                            </div>
                                                            <div>
                                                                <h6 className='fw-bold m-0 fs-7'>Compact Minimalist Grade Sheet</h6>
                                                                <span className='text-muted fs-9'>Spacing-optimized, space-saving layout</span>
                                                            </div>
                                                        </div>
                                                        {reportPreset === 'minimalist' && <i className='bi bi-check-circle-fill text-dark fs-5'></i>}
                                                    </div>
                                                </div>
                                            </div>

                                            <hr className='text-gray-200 my-5' />

                                            {/* Section 2: Colors & Theme */}
                                            <div className='mb-6'>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>2. Colors & Styling</label>
                                                <div className='d-flex align-items-center gap-3'>
                                                    <div className='flex-grow-1'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Primary Theme Color</label>
                                                        <div className='d-flex align-items-center gap-2'>
                                                            <input
                                                                type='color'
                                                                className='form-control form-control-solid p-1 border rounded'
                                                                style={{ width: 44, height: 32 }}
                                                                value={reportConfig.primaryColor}
                                                                onChange={(e) => {
                                                                    setReportConfig(prev => ({ ...prev, primaryColor: e.target.value }))
                                                                }}
                                                            />
                                                            <span className='fs-8 font-monospace text-gray-600'>{reportConfig.primaryColor}</span>
                                                        </div>
                                                    </div>
                                                    <div className='flex-grow-1'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Font Family</label>
                                                        <select
                                                            className='form-select form-select-sm form-select-solid'
                                                            value={reportConfig.fontFamily}
                                                            onChange={(e) => setReportConfig(prev => ({ ...prev, fontFamily: e.target.value }))}
                                                        >
                                                            <option value='Inter'>Inter (Modern Sans)</option>
                                                            <option value='Outfit'>Outfit (Rounded Elegant)</option>
                                                            <option value='Montserrat'>Montserrat (Bold Geometric)</option>
                                                            <option value='Georgia'>Georgia (Classic Serif)</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <hr className='text-gray-200 my-5' />

                                            {/* Section 3: Header Configuration */}
                                            <div className='mb-6'>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>3. Header Style & Custom Text</label>
                                                <div className='mb-4'>
                                                    <label className='form-label text-muted fs-8 mb-1'>Header Alignment</label>
                                                    <select
                                                        className='form-select form-select-sm form-select-solid'
                                                        value={reportConfig.headerStyle}
                                                        onChange={(e) => setReportConfig(prev => ({ ...prev, headerStyle: e.target.value as any }))}
                                                    >
                                                        <option value='classic'>Inline Left Logo</option>
                                                        <option value='centered'>Centered Stacked</option>
                                                        <option value='boxed'>Boxed (Light background)</option>
                                                    </select>
                                                </div>
                                                <div className='mb-3'>
                                                    <label className='form-label text-muted fs-8 mb-1'>Institution Name Override</label>
                                                    <input
                                                        type='text'
                                                        className='form-control form-control-sm form-control-solid fw-bold'
                                                        placeholder='Leave empty to use school database name'
                                                        value={reportConfig.schoolNameOverride}
                                                        onChange={(e) => setReportConfig(prev => ({ ...prev, schoolNameOverride: e.target.value }))}
                                                    />
                                                </div>
                                                <div>
                                                    <label className='form-label text-muted fs-8 mb-1'>Report Subtitle Override</label>
                                                    <input
                                                        type='text'
                                                        className='form-control form-control-sm form-control-solid fw-bold'
                                                        placeholder='Subtitle'
                                                        value={reportConfig.schoolSubtitleOverride}
                                                        onChange={(e) => setReportConfig(prev => ({ ...prev, schoolSubtitleOverride: e.target.value }))}
                                                    />
                                                </div>
                                            </div>

                                            <hr className='text-gray-200 my-5' />

                                            {/* Section 4: Table Grid Styles */}
                                            <div className='mb-6'>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>4. Data Table Configuration</label>
                                                <div className='row g-3 mb-3'>
                                                    <div className='col-6 d-flex align-items-center justify-content-between'>
                                                        <span className='fs-8 fw-semibold text-gray-700'>Striped Table Rows</span>
                                                        <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                            <input className='form-check-input' type='checkbox' checked={reportConfig.tableStriped} onChange={() => setReportConfig(prev => ({ ...prev, tableStriped: !prev.tableStriped }))} />
                                                        </div>
                                                    </div>
                                                    <div className='col-6 d-flex align-items-center justify-content-between'>
                                                        <span className='fs-8 fw-semibold text-gray-700'>Show GPA / Grades</span>
                                                        <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                            <input className='form-check-input' type='checkbox' checked={reportConfig.showGrades} onChange={() => setReportConfig(prev => ({ ...prev, showGrades: !prev.showGrades }))} />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='row g-3'>
                                                    <div className='col-6'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Grid Header BG Color</label>
                                                        <input
                                                            type='color'
                                                            className='form-control form-control-solid p-1 border rounded'
                                                            style={{ width: '100%', height: 32 }}
                                                            value={reportConfig.tableHeaderBg}
                                                            onChange={(e) => setReportConfig(prev => ({ ...prev, tableHeaderBg: e.target.value }))}
                                                        />
                                                    </div>
                                                    <div className='col-6'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Border Line Style</label>
                                                        <select
                                                            className='form-select form-select-sm form-select-solid'
                                                            value={reportConfig.borderStyle}
                                                            onChange={(e) => setReportConfig(prev => ({ ...prev, borderStyle: e.target.value as any }))}
                                                        >
                                                            <option value='solid'>Solid Border</option>
                                                            <option value='dashed'>Dashed Border</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <hr className='text-gray-200 my-5' />

                                            {/* Section 5: Footer & Signatures */}
                                            <div className='mb-6'>
                                                <label className='form-label fw-bold text-gray-800 fs-7 mb-3'>5. Custom Footer & Signs</label>
                                                <div className='mb-4 d-flex align-items-center justify-content-between'>
                                                    <span className='fs-8 fw-semibold text-gray-700'>Display Custom Footer Note</span>
                                                    <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                                        <input className='form-check-input' type='checkbox' checked={reportConfig.showFooterNote} onChange={() => setReportConfig(prev => ({ ...prev, showFooterNote: !prev.showFooterNote }))} />
                                                    </div>
                                                </div>
                                                {reportConfig.showFooterNote && (
                                                    <div className='mb-4'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Footer Note Details</label>
                                                        <textarea
                                                            className='form-control form-control-sm form-control-solid'
                                                            rows={3}
                                                            value={reportConfig.footerNote}
                                                            onChange={(e) => setReportConfig(prev => ({ ...prev, footerNote: e.target.value }))}
                                                        />
                                                    </div>
                                                )}
                                                <div className='row g-3'>
                                                    <div className='col-4'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Signature 1</label>
                                                        <input type='text' className='form-control form-control-sm form-control-solid' value={reportConfig.sig1} onChange={(e) => setReportConfig(prev => ({ ...prev, sig1: e.target.value }))} />
                                                    </div>
                                                    <div className='col-4'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Signature 2</label>
                                                        <input type='text' className='form-control form-control-sm form-control-solid' value={reportConfig.sig2} onChange={(e) => setReportConfig(prev => ({ ...prev, sig2: e.target.value }))} />
                                                    </div>
                                                    <div className='col-4'>
                                                        <label className='form-label text-muted fs-8 mb-1'>Signature 3</label>
                                                        <input type='text' className='form-control form-control-sm form-control-solid' value={reportConfig.sig3} onChange={(e) => setReportConfig(prev => ({ ...prev, sig3: e.target.value }))} />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className='card-body flex-grow-1 p-6 d-flex flex-column h-100'>
                                            <div className='alert alert-light-warning border border-dashed border-warning rounded p-4 mb-4 fs-7 text-gray-700'>
                                                <KTIcon iconName='information-5' className='fs-3 text-warning me-2' />
                                                <strong>Caution:</strong> Writing custom EJS code directly will ignore any adjustments made in the "Visual Designer" sidebar. Click below to load the starting premium EJS template.
                                            </div>
                                            <textarea
                                                className='form-control form-control-solid font-monospace fs-8 flex-grow-1 bg-dark text-white rounded p-4 mb-4'
                                                rows={22}
                                                style={{ fontFamily: 'Courier, monospace', fontSize: '11px', lineHeight: '1.4' }}
                                                value={reportCardTemplate}
                                                onChange={(e) => setReportCardTemplate(e.target.value)}
                                            />
                                            <button
                                                type='button'
                                                className='btn btn-sm btn-light-success fw-bold w-100 border border-dashed border-success mt-auto'
                                                onClick={loadDefaultReportCard}
                                            >
                                                Load EJS Premium Default
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Right Live Preview Canvas (65%) */}
                            <div className='col-xl-8'>
                                <div className='card shadow-sm border-0 h-100 bg-light p-6 d-flex align-items-center justify-content-center' style={{ minHeight: '65vh' }}>
                                    <div className='w-100 mb-4 d-flex justify-content-between align-items-center px-4'>
                                        <h5 className='fw-bold text-gray-800 m-0 d-flex align-items-center'>
                                            <i className='bi bi-eye me-2 text-success fs-4'></i> Dynamic Preview Simulation (A4 Page)
                                        </h5>
                                        <span className='badge bg-light-success text-success fw-bold px-3 py-2 fs-8 rounded'>
                                            Active Preset: {reportPreset.toUpperCase()}
                                        </span>
                                    </div>

                                    {/* Mock Card Preview Container */}
                                    <div
                                        className='bg-white shadow-lg p-9 w-100 rounded-3 border border-gray-200'
                                        style={{
                                            maxWidth: '750px',
                                            minHeight: '800px',
                                            fontFamily: `${reportConfig.fontFamily}, sans-serif`,
                                            position: 'relative',
                                            overflow: 'hidden',
                                            transition: 'all 0.3s ease'
                                        }}
                                    >
                                        {/* School Header */}
                                        <div
                                            className={`d-flex pb-4 mb-4 border-bottom`}
                                            style={{
                                                borderBottomWidth: reportPreset === 'university' ? '3px' : '2px',
                                                borderBottomStyle: reportPreset === 'university' ? 'double' : 'solid',
                                                borderBottomColor: reportConfig.primaryColor,
                                                flexDirection: reportConfig.headerStyle === 'centered' ? 'column' : 'row',
                                                textAlign: reportConfig.headerStyle === 'centered' ? 'center' : 'left',
                                                alignItems: 'center',
                                                justifyContent: 'space-between',
                                                background: reportConfig.headerStyle === 'boxed' ? `${reportConfig.primaryColor}0d` : 'transparent',
                                                padding: reportConfig.headerStyle === 'boxed' ? '15px' : '0 0 15px 0',
                                                borderRadius: reportConfig.headerStyle === 'boxed' ? '8px' : '0',
                                            }}
                                        >
                                            <div className='d-flex align-items-center' style={{ flexDirection: reportConfig.headerStyle === 'centered' ? 'column' : 'row' }}>
                                                <img
                                                    src='https://via.placeholder.com/80?text=LOGO'
                                                    alt='School Logo'
                                                    className='rounded-3 mb-2'
                                                    style={{ width: '80px', height: '80px', marginRight: reportConfig.headerStyle === 'centered' ? 0 : '15px' }}
                                                />
                                                <div>
                                                    <h1 className='fw-bold m-0' style={{ fontSize: '24px', color: reportConfig.primaryColor }}>
                                                        {reportConfig.schoolNameOverride || 'ALPHA INTERNATIONAL SCHOOL'}
                                                    </h1>
                                                    <span className='badge text-white font-weight-bold uppercase fs-9 mt-2' style={{ background: reportConfig.primaryColor }}>
                                                        {reportConfig.schoolSubtitleOverride}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className='fs-8 text-muted text-right' style={{ textAlign: reportConfig.headerStyle === 'centered' ? 'center' : 'right', marginTop: reportConfig.headerStyle === 'centered' ? '10px' : 0 }}>
                                                <div><strong>Address:</strong> Sector 4, Salt Lake, Kolkata</div>
                                                <div><strong>Phone:</strong> +91 9876543210</div>
                                            </div>
                                        </div>

                                        {/* Layout Preset A: CLASSIC SCHOOL MARKSHEET */}
                                        {reportPreset === 'classic' && (
                                            <>
                                                {/* Exam Title Banner */}
                                                <div className='text-center mb-4'>
                                                    <h2 className='fw-bold m-0 fs-5 uppercase' style={{ color: reportConfig.primaryColor, letterSpacing: '1px' }}>ANNUAL EVALUATION REPORT CARD</h2>
                                                    <p className='text-muted fs-8 m-0 mt-1'>ACADEMIC SESSION: 2025-2026</p>
                                                </div>

                                                <table className='table table-bordered border-gray-400 text-center fs-8 mb-4' style={{ width: '100%', borderCollapse: 'collapse' }}>
                                                    <thead>
                                                        <tr style={{ background: '#f5f5f5' }}>
                                                            <th className='py-2 px-3 fw-bold border border-gray-400'>ADMISSION NO</th>
                                                            <th className='py-2 px-3 fw-bold border border-gray-400'>ROLL NUMBER</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className='text-dark fw-bold'>
                                                        <tr>
                                                            <td className='py-2 border border-gray-400'>ADM/2026/4011</td>
                                                            <td className='py-2 border border-gray-400'>RL-992140</td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                <div className='text-center text-muted fw-bold fs-9 mb-3'>CERTIFIED THAT</div>

                                                {/* Student Details Grid */}
                                                <div className='student-details mb-4' style={{ display: 'grid', gridTemplateColumns: 'max-content 1fr', gap: '6px 20px', fontSize: '11px', textTransform: 'uppercase' }}>
                                                    <div className='text-muted'>MR/MS</div>
                                                    <div className='fw-bold text-dark'>Rohan Kumar Sharma</div>
                                                    {reportConfig.showFatherName && (
                                                        <>
                                                            <div className='text-muted'>FATHER / HUSBAND NAME</div>
                                                            <div className='fw-bold text-dark'>Mr. Alok Sharma</div>
                                                        </>
                                                    )}
                                                    {reportConfig.showMotherName && (
                                                        <>
                                                            <div className='text-muted'>MOTHER NAME</div>
                                                            <div className='fw-bold text-dark'>Mrs. Suman Sharma</div>
                                                        </>
                                                    )}
                                                    {reportConfig.showDob && (
                                                        <>
                                                            <div className='text-muted'>DATE OF BIRTH</div>
                                                            <div className='fw-bold text-dark'>14-08-2010</div>
                                                        </>
                                                    )}
                                                    <div className='text-muted'>CLASS</div>
                                                    <div className='fw-bold text-dark'>CLASS X - SECTION B</div>
                                                </div>

                                                {/* Marks Grid Mock */}
                                                <table className='table text-center fs-8 mb-4' style={{ width: '100%', borderCollapse: 'collapse' }}>
                                                    <thead>
                                                        <tr style={{ background: reportConfig.tableHeaderBg, color: reportConfig.tableHeaderColor }}>
                                                            <th className='py-2 px-3 fw-bold border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1', textAlign: 'left' }}>SUBJECTS</th>
                                                            <th className='py-2 px-3 fw-bold border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>MAX MARKS</th>
                                                            <th className='py-2 px-3 fw-bold border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>MIN MARKS</th>
                                                            <th className='py-2 px-3 fw-bold border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>MARKS OBTAINED</th>
                                                            <th className='py-2 px-3 fw-bold border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>REMARKS</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className='text-dark fw-semibold'>
                                                        <tr style={{ background: reportConfig.tableStriped ? '#f9f9f9' : 'transparent' }}>
                                                            <td className='py-2 px-3 border text-left fw-bold text-dark' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>Mathematics</td>
                                                            <td className='py-2 border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>100</td>
                                                            <td className='py-2 border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>33</td>
                                                            <td className='py-2 border fw-bold text-dark' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>87</td>
                                                            <td className='py-2 border text-success fw-bold' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>Excellent</td>
                                                        </tr>
                                                        <tr style={{ background: 'transparent' }}>
                                                            <td className='py-2 px-3 border text-left fw-bold text-dark' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>Science & Tech</td>
                                                            <td className='py-2 border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>100</td>
                                                            <td className='py-2 border' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>33</td>
                                                            <td className='py-2 border fw-bold text-dark' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>91</td>
                                                            <td className='py-2 border text-success fw-bold' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>Outstanding</td>
                                                        </tr>
                                                        <tr className='fw-bold' style={{ background: '#f5f5f5' }}>
                                                            <td colSpan={3} className='py-2 px-3 border text-right' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>GRAND TOTAL</td>
                                                            <td className='py-2 border text-dark' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>178 / 200</td>
                                                            <td className='py-2 border text-primary' style={{ borderStyle: reportConfig.borderStyle, borderColor: '#cbd5e1' }}>89.00%</td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                <table className='table border-gray-400 fs-8 mb-4' style={{ width: '100%', borderCollapse: 'collapse', marginTop: '-21px' }}>
                                                    <tbody>
                                                        <tr>
                                                            <th className='py-2 px-3 border text-center fw-bold' style={{ width: '200px', background: '#f5f5f5' }}>RESULT</th>
                                                            <td className='py-2 px-3 border fw-bold text-success uppercase text-center fs-7'>PASSED (FIRST DIVISION)</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </>
                                        )}

                                        {/* Layout Preset B: MODERN UNIVERSITY TRANSCRIPT */}
                                        {reportPreset === 'university' && (
                                            <>
                                                {/* Exam Title Block */}
                                                <div className='text-center py-2 mb-4 rounded-3 border-start border-end' style={{ background: '#f8fafc', borderLeftWidth: '5px', borderRightWidth: '5px', borderLeftColor: reportConfig.primaryColor, borderRightColor: reportConfig.primaryColor }}>
                                                    <h2 className='fw-bold m-0 fs-6 uppercase' style={{ color: reportConfig.primaryColor, letterSpacing: '0.5px' }}>SEMESTER ACADEMIC RECORD SHEET</h2>
                                                    <p className='text-muted fs-9 m-0 mt-1'>FALL END SEMESTER EVALUATION — 2026</p>
                                                </div>

                                                {/* University Details Panel */}
                                                <div className='p-4 rounded-3 border border-gray-200 mb-4 bg-light d-grid' style={{ gridTemplateColumns: 'max-content 1fr max-content 1fr', gap: '8px 20px', fontSize: '11px' }}>
                                                    <span className='text-muted fw-bold'>STUDENT NAME:</span>
                                                    <span className='fw-bold text-dark'>Rohan Kumar Sharma</span>
                                                    <span className='text-muted fw-bold'>ADMISSION NO:</span>
                                                    <span className='fw-bold text-dark'>ADM/2026/4011</span>
                                                    ${reportConfig.showFatherName ? `<span class='text-muted fw-bold'>FATHER NAME:</span><span class='fw-bold text-dark'>Mr. Alok Sharma</span>` : ''}
                                                    ${reportConfig.showRollNo ? `<span class='text-muted fw-bold'>ROLL NUMBER:</span><span class='fw-bold text-dark'>RL-992140</span>` : ''}
                                                    <span className='text-muted fw-bold'>PROGRAM:</span>
                                                    <span className='fw-bold text-dark' style={{ gridColumn: 'span 3' }}>Class X - Section B</span>
                                                </div>

                                                {/* Marks Grid with Credits */}
                                                <table className='table text-center fs-8 mb-4' style={{ width: '100%', borderCollapse: 'collapse' }}>
                                                    <thead>
                                                        <tr style={{ background: reportConfig.primaryColor, color: '#ffffff' }}>
                                                            <th className='py-2 px-3 fw-bold border border-gray-300 text-left'>COURSE / SUBJECT</th>
                                                            <th className='py-2 px-3 fw-bold border border-gray-300'>TYPE</th>
                                                            <th className='py-2 px-3 fw-bold border border-gray-300'>CREDITS</th>
                                                            <th className='py-2 px-3 fw-bold border border-gray-300'>MAX</th>
                                                            <th className='py-2 px-3 fw-bold border border-gray-300'>OBTAINED</th>
                                                            <th className='py-2 px-3 fw-bold border border-gray-300'>GRADE</th>
                                                            <th className='py-2 px-3 fw-bold border border-gray-300'>GP</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className='text-dark fw-semibold'>
                                                        <tr style={{ background: 'transparent' }}>
                                                            <td className='py-2 px-3 border border-gray-300 text-left fw-bold text-dark'>Mathematics (Core)</td>
                                                            <td className='py-2 border border-gray-300'><span className='badge bg-light-primary text-primary fs-9'>CORE</span></td>
                                                            <td className='py-2 border border-gray-300'>4.0</td>
                                                            <td className='py-2 border border-gray-300'>100</td>
                                                            <td className='py-2 border fw-bold text-dark'>87</td>
                                                            <td className='py-2 border fw-bold text-primary'>A+</td>
                                                            <td className='py-2 border border-gray-300'>9.0</td>
                                                        </tr>
                                                        <tr style={{ background: 'transparent' }}>
                                                            <td className='py-2 px-3 border border-gray-300 text-left fw-bold text-dark'>Science & Tech</td>
                                                            <td className='py-2 border border-gray-300'><span className='badge bg-light-success text-success fs-9'>LAB</span></td>
                                                            <td className='py-2 border border-gray-300'>3.0</td>
                                                            <td className='py-2 border border-gray-300'>100</td>
                                                            <td className='py-2 border fw-bold text-dark'>91</td>
                                                            <td className='py-2 border fw-bold text-success'>O</td>
                                                            <td className='py-2 border border-gray-300'>10.0</td>
                                                        </tr>
                                                        <tr className='fw-bold bg-light' style={{ color: reportConfig.primaryColor }}>
                                                            <td colSpan={2} className='py-2 px-3 border border-gray-300 text-right'>TOTAL CREDIT POINTS</td>
                                                            <td className='py-2 border border-gray-300'>7.0</td>
                                                            <td className='py-2 border border-gray-300'>200</td>
                                                            <td className='py-2 border text-dark'>178</td>
                                                            <td className='py-2 border border-gray-300'></td>
                                                            <td className='py-2 border border-gray-300'>66.0</td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                {/* GPA block */}
                                                <div className='d-flex justify-content-center my-4'>
                                                    <div className='text-center p-3 rounded border-start' style={{ width: '100%', maxWidth: '400px', background: `${reportConfig.primaryColor}0d`, borderLeftWidth: '5px', borderLeftColor: reportConfig.primaryColor }}>
                                                        <div className='fs-9 text-muted fw-bold uppercase' style={{ letterSpacing: '0.5px' }}>Semester Grade Point Average (SGPA)</div>
                                                        <div className='fw-bold my-1' style={{ fontSize: '28px', color: reportConfig.primaryColor }}>9.43</div>
                                                        <div className='fs-9 text-muted'>Total Credits: 7.0 &nbsp;|&nbsp; Points Earned: 66.0</div>
                                                    </div>
                                                </div>
                                            </>
                                        )}

                                        {/* Layout Preset C: COMPACT MINIMALIST */}
                                        {reportPreset === 'minimalist' && (
                                            <>
                                                {/* Compact Meta Title */}
                                                <div className='text-center fw-bold text-dark uppercase fs-7 mb-3' style={{ letterSpacing: '0.5px' }}>
                                                    GRADE CARD (SESSION: 2025-2026)
                                                </div>

                                                {/* Grid for details */}
                                                <div className='d-grid pb-3 mb-3 border-bottom border-gray-300' style={{ gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px 12px', fontSize: '10px', borderBottomStyle: 'dashed' }}>
                                                    <span className='text-muted fw-bold'>Student Name:</span>
                                                    <span className='fw-bold text-dark' style={{ gridColumn: 'span 3' }}>Rohan Kumar Sharma</span>
                                                    ${reportConfig.showAdmissionNo ? `<span class='text-muted fw-bold'>Admission No:</span><span class='fw-bold text-dark'>ADM/2026/4011</span>` : ''}
                                                    ${reportConfig.showRollNo ? `<span class='text-muted fw-bold'>Roll Number:</span><span class='fw-bold text-dark'>RL-992140</span>` : ''}
                                                    <span className='text-muted fw-bold'>Class:</span>
                                                    <span className='fw-bold text-dark'>Class X - Section B</span>
                                                    <span className='text-muted fw-bold'>Term:</span>
                                                    <span className='fw-bold text-dark'>Annual Exam</span>
                                                </div>

                                                {/* Minimal table */}
                                                <table className='table text-center fs-8 mb-3' style={{ width: '100%', borderCollapse: 'collapse' }}>
                                                    <thead>
                                                        <tr style={{ background: reportConfig.tableHeaderBg, color: reportConfig.tableHeaderColor }}>
                                                            <th className='py-1.5 px-3 border text-left' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Subject</th>
                                                            <th className='py-1.5 px-3 border' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Max</th>
                                                            <th className='py-1.5 px-3 border' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Min</th>
                                                            <th className='py-1.5 px-3 border' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Obtained</th>
                                                            <th className='py-1.5 px-3 border' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Remarks</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className='text-dark'>
                                                        <tr style={{ background: '#f9f9f9' }}>
                                                            <td className='py-1.5 px-3 border text-left fw-bold text-dark' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Mathematics</td>
                                                            <td className='py-1.5 border' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>100</td>
                                                            <td className='py-1.5 border' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>33</td>
                                                            <td className='py-1.5 border fw-bold text-dark' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>87</td>
                                                            <td className='py-1.5 border fw-bold text-success' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Excellent</td>
                                                        </tr>
                                                        <tr>
                                                            <td className='py-1.5 px-3 border text-left fw-bold text-dark' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Science & Tech</td>
                                                            <td className='py-1.5 border' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>100</td>
                                                            <td className='py-1.5 border' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>33</td>
                                                            <td className='py-1.5 border fw-bold text-dark' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>91</td>
                                                            <td className='py-1.5 border fw-bold text-success' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>Outstanding</td>
                                                        </tr>
                                                        <tr className='fw-bold' style={{ background: '#f1f5f9' }}>
                                                            <td colSpan={3} className='py-1.5 px-3 border text-right' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>GRAND TOTAL</td>
                                                            <td className='py-1.5 border text-dark' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>178 / 200</td>
                                                            <td className='py-1.5 border text-primary' style={{ borderStyle: 'dashed', borderColor: '#cbd5e1' }}>89.00%</td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                {/* Compact status row */}
                                                <div className='py-2 px-3 border rounded text-center fw-bold text-dark uppercase fs-9 mb-4' style={{ background: '#f8fafc', borderColor: '#e2e8f0' }}>
                                                    Final Result Status: <span style={{ color: reportConfig.primaryColor }}>PASSED</span>
                                                </div>
                                            </>
                                        )}

                                        {/* Mock Signatures block */}
                                        <div className='d-flex justify-content-between pt-5 mt-4 border-top border-gray-300' style={{ borderTopStyle: reportPreset === 'university' ? 'solid' : 'dashed' }}>
                                            <div className='text-center text-muted fw-bold fs-9' style={{ width: '130px', borderTop: '1px solid #000', paddingTop: '6px' }}>{reportConfig.sig1}</div>
                                            <div className='text-center text-muted fw-bold fs-9' style={{ width: '130px', borderTop: '1px solid #000', paddingTop: '6px' }}>{reportConfig.sig2}</div>
                                            <div className='text-center text-muted fw-bold fs-9' style={{ width: '130px', borderTop: '1px solid #000', paddingTop: '6px' }}>{reportConfig.sig3}</div>
                                        </div>

                                        {/* Mock Footer Note */}
                                        {reportConfig.showFooterNote && (
                                            <div className='text-center fs-10 text-muted mt-5 pt-3 border-top border-gray-200' style={{ fontSize: '8px' }}>
                                                {reportConfig.footerNote}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            )}

            {/* Bottom Floating Save Button Bar */}
            <div className='card mt-6 shadow-sm border-0 bg-white'>
                <div className='card-footer d-flex align-items-center justify-content-between py-5 px-9'>
                    <div className='d-flex align-items-center gap-2 text-muted fs-7'>
                        <KTIcon iconName='information-5' className='fs-4 text-primary' />
                        All configurations generated compile into production-ready EJS templates.
                    </div>
                    <button
                        type='button'
                        className='btn btn-primary px-8 shadow-sm fw-bold'
                        onClick={handleSave}
                        disabled={isSaving || isLoading}
                    >
                        {!isSaving && (
                            <>
                                <i className='bi bi-save me-2'></i> Save Template Configuration
                            </>
                        )}
                        {isSaving && (
                            <span className='indicator-progress' style={{ display: 'block' }}>
                                Saving changes...{' '}
                                <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                            </span>
                        )}
                    </button>
                </div>
            </div>
        </>
    )
}

export const CustomTemplatesWrapper: React.FC = () => {
    return (
        <>
            
            <CustomTemplatesPage />
        </>
    )
}

export default CustomTemplatesPage
