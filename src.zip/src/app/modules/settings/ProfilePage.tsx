import { FC, useState, useEffect, useCallback, FormEvent, ChangeEvent } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../../modules/auth'
import { TeacherProfilePage } from './TeacherProfilePage'
import { getSchoolById, updateSchool } from '../auth/core/_requests'
import { toAbsoluteUrl } from '../../../_metronic/helpers'

const SchoolProfile: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const [code, setCode] = useState('')
  const [subdomain, setSubdomain] = useState('')
  const [name, setName] = useState('')
  const [address, setAddress] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [principalName, setPrincipalName] = useState('')
  const [establishedYear, setEstablishedYear] = useState('')
  const [institutionType, setInstitutionType] = useState('SCHOOL')

  const [logoFile, setLogoFile] = useState<File | null>(null)
  const [bannerFile, setBannerFile] = useState<File | null>(null)
  const [logoPreview, setLogoPreview] = useState<string | null>(null)
  const [bannerPreview, setBannerPreview] = useState<string | null>(null)

  const fetchSchoolDetails = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    setError(null)
    try {
      const res = await getSchoolById(schoolId)
      if (res.data?.success && res.data?.data?.school) {
        const s = res.data.data.school
        setCode(s.code || '')
        setSubdomain(s.subdomain || '')
        setName(s.name || '')
        setAddress(s.address || '')
        setPhone(s.phone || '')
        setEmail(s.email || '')
        setPrincipalName(s.principalName || '')
        setEstablishedYear(s.establishedYear ? String(s.establishedYear) : '')
        setInstitutionType(s.institution_type || 'SCHOOL')
        setLogoPreview(s.logoPath || null)
        setBannerPreview(s.bannerPath || null)
      } else {
        setError('Failed to fetch school details.')
      }
    } catch (err: any) {
      setError(err.response?.data?.error || err.response?.data?.message || 'Error fetching school details.')
    } finally {
      setLoading(false)
    }
  }, [schoolId])

  useEffect(() => {
    fetchSchoolDetails()
  }, [fetchSchoolDetails])

  const handleLogoChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setLogoFile(file)
      const reader = new FileReader()
      reader.onloadend = () => setLogoPreview(reader.result as string)
      reader.readAsDataURL(file)
    }
  }

  const handleBannerChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setBannerFile(file)
      const reader = new FileReader()
      reader.onloadend = () => setBannerPreview(reader.result as string)
      reader.readAsDataURL(file)
    }
  }

  const handleSave = async (e: FormEvent) => {
    e.preventDefault()
    if (!schoolId) return
    setSaving(true)
    setError(null)
    setSuccess(null)
    try {
      const formData = new FormData()
      formData.append('name', name)
      formData.append('address', address)
      formData.append('phone', phone)
      formData.append('email', email)
      formData.append('principalName', principalName)
      formData.append('establishedYear', establishedYear)
      formData.append('institution_type', institutionType)
      if (logoFile) formData.append('logo', logoFile)
      if (bannerFile) formData.append('banner', bannerFile)

      const res = await updateSchool(schoolId, formData)
      if (res.data?.success) {
        setSuccess('School profile updated successfully!')
        fetchSchoolDetails()
      } else {
        setError(res.data?.message || 'Failed to update school profile.')
      }
    } catch (err: any) {
      setError(err.response?.data?.error || err.response?.data?.message || 'Error updating school profile.')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <Content>
        <div className='d-flex align-items-center justify-content-center py-20'>
          <div className='spinner-border text-primary' role='status'>
            <span className='visually-hidden'>Loading...</span>
          </div>
        </div>
      </Content>
    )
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>
        <form onSubmit={handleSave} className='form'>

          {/* ── Banner + Logo identity card ── */}
          <div className='card mb-6'>
            {/* Banner */}
            <div
              className='rounded-top-3 overflow-hidden position-relative'
              style={{ height: 200, background: 'var(--kt-gray-100)' }}
            >
              {bannerPreview ? (
                <img
                  src={bannerPreview}
                  alt='School Banner'
                  className='w-100 h-100'
                  style={{ objectFit: 'cover' }}
                />
              ) : (
                <div className='d-flex flex-column align-items-center justify-content-center h-100 text-muted gap-2'>
                  <i className='ki-duotone ki-picture fs-2tx text-gray-400'>
                    <span className='path1' /><span className='path2' /><span className='path3' />
                  </i>
                  <span className='fs-6 fw-semibold text-gray-500'>No banner uploaded</span>
                  <span className='fs-7 text-gray-400'>Recommended 1200×400px · Aspect ratio 3:1</span>
                </div>
              )}
              {/* Banner edit button */}
              <label
                htmlFor='school-banner-upload'
                className='btn btn-sm btn-light btn-active-light-primary position-absolute bottom-0 end-0 m-4 shadow-sm'
                title='Change Banner'
              >
                <i className='ki-duotone ki-pencil fs-6 me-1'>
                  <span className='path1' /><span className='path2' />
                </i>
                Change Banner
              </label>
              <input id='school-banner-upload' type='file' accept='image/*' className='d-none' onChange={handleBannerChange} />
            </div>

            {/* Logo + Identity row */}
            <div className='d-flex align-items-flex-end gap-5 px-9 pb-6' style={{ marginTop: -36 }}>
              {/* Logo */}
              <div className='position-relative' style={{ flexShrink: 0 }}>
                <div
                  className='symbol symbol-75px symbol-circle border border-4 border-body bg-body shadow-sm overflow-hidden'
                >
                  {logoPreview ? (
                    <img
                      src={logoPreview}
                      alt='School Logo'
                      className='w-100 h-100'
                      style={{ objectFit: 'contain' }}
                    />
                  ) : (
                    <div className='symbol-label bg-light-primary'>
                      <i className='ki-duotone ki-teacher fs-2x text-primary'>
                        <span className='path1' /><span className='path2' />
                      </i>
                    </div>
                  )}
                </div>
                <label
                  htmlFor='school-logo-upload'
                  className='btn btn-icon btn-circle btn-sm btn-light btn-active-color-primary shadow-sm position-absolute bottom-0 end-0'
                  title='Change Logo'
                >
                  <i className='ki-duotone ki-pencil fs-8'>
                    <span className='path1' /><span className='path2' />
                  </i>
                </label>
                <input id='school-logo-upload' type='file' accept='image/*' className='d-none' onChange={handleLogoChange} />
              </div>

              {/* Name + meta */}
              <div className='pt-10'>
                <div className='d-flex align-items-center gap-3 flex-wrap'>
                  <h4 className='fw-bold text-gray-900 mb-0 fs-4'>{name || 'School Name'}</h4>
                  <span className={`badge badge-light-${institutionType === 'COLLEGE' ? 'info' : 'primary'} fs-8`}>
                    {institutionType === 'COLLEGE' ? 'College / University' : 'School'}
                  </span>
                </div>
                <div className='d-flex align-items-center gap-4 mt-1 flex-wrap'>
                  {subdomain && (
                    <span className='text-muted fs-7'>
                      <i className='ki-duotone ki-globe fs-7 me-1'>
                        <span className='path1' /><span className='path2' />
                      </i>
                      {subdomain}.schoole.app
                    </span>
                  )}
                  {establishedYear && (
                    <span className='text-muted fs-7'>
                      <i className='ki-duotone ki-calendar fs-7 me-1'>
                        <span className='path1' /><span className='path2' />
                      </i>
                      Est. {establishedYear}
                    </span>
                  )}
                  {principalName && (
                    <span className='text-muted fs-7'>
                      <i className='ki-duotone ki-profile-user fs-7 me-1'>
                        <span className='path1' /><span className='path2' /><span className='path3' /><span className='path4' />
                      </i>
                      {principalName}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* ── Alerts ── */}
          {error && (
            <div className='alert alert-danger d-flex align-items-center mb-6 p-5'>
              <i className='ki-duotone ki-information-5 fs-2hx text-danger me-4'>
                <span className='path1' /><span className='path2' /><span className='path3' />
              </i>
              <div className='d-flex flex-column'>
                <span className='fw-semibold'>{error}</span>
              </div>
            </div>
          )}
          {success && (
            <div className='alert alert-success d-flex align-items-center mb-6 p-5'>
              <i className='ki-duotone ki-shield-tick fs-2hx text-success me-4'>
                <span className='path1' /><span className='path2' />
              </i>
              <div className='d-flex flex-column'>
                <span className='fw-semibold'>{success}</span>
              </div>
            </div>
          )}

          {/* ── Basic Info ── */}
          <div className='card mb-6'>
            <div className='card-header border-0 pt-6 pb-0'>
              <div className='card-title'>
                <h3 className='fw-bold fs-5 text-gray-800 mb-0'>
                  <i className='ki-duotone ki-information fs-4 text-primary me-2'>
                    <span className='path1' /><span className='path2' /><span className='path3' />
                  </i>
                  Basic Information
                </h3>
              </div>
            </div>
            <div className='card-body pt-5'>
              <div className='row g-6'>
                <div className='col-md-8'>
                  <label className='form-label required fw-semibold fs-6'>School Name</label>
                  <input
                    type='text'
                    className='form-control form-control-solid'
                    placeholder='Enter school name'
                    value={name}
                    onChange={e => setName(e.target.value)}
                    required
                  />
                </div>
                <div className='col-md-4'>
                  <label className='form-label required fw-semibold fs-6'>Institution Type</label>
                  <select
                    className='form-select form-select-solid'
                    value={institutionType}
                    onChange={e => setInstitutionType(e.target.value)}
                    required
                  >
                    <option value='SCHOOL'>School</option>
                    <option value='COLLEGE'>College / University</option>
                  </select>
                </div>
                <div className='col-md-6'>
                  <label className='form-label fw-semibold fs-6'>Principal Name</label>
                  <input
                    type='text'
                    className='form-control form-control-solid'
                    placeholder='Enter principal name'
                    value={principalName}
                    onChange={e => setPrincipalName(e.target.value)}
                  />
                </div>
                <div className='col-md-6'>
                  <label className='form-label fw-semibold fs-6'>Established Year</label>
                  <input
                    type='number'
                    className='form-control form-control-solid'
                    placeholder='e.g. 2005'
                    value={establishedYear}
                    onChange={e => setEstablishedYear(e.target.value)}
                    min={1800}
                    max={2100}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* ── Contact Info ── */}
          <div className='card mb-6'>
            <div className='card-header border-0 pt-6 pb-0'>
              <div className='card-title'>
                <h3 className='fw-bold fs-5 text-gray-800 mb-0'>
                  <i className='ki-duotone ki-sms fs-4 text-primary me-2'>
                    <span className='path1' /><span className='path2' />
                  </i>
                  Contact Information
                </h3>
              </div>
            </div>
            <div className='card-body pt-5'>
              <div className='row g-6'>
                <div className='col-md-6'>
                  <label className='form-label fw-semibold fs-6'>Email Address</label>
                  <input
                    type='email'
                    className='form-control form-control-solid'
                    placeholder='school@example.com'
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                  />
                </div>
                <div className='col-md-6'>
                  <label className='form-label fw-semibold fs-6'>Phone Number</label>
                  <input
                    type='text'
                    className='form-control form-control-solid'
                    placeholder='+91 98765 43210'
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                  />
                </div>
                <div className='col-12'>
                  <label className='form-label fw-semibold fs-6'>Address</label>
                  <textarea
                    className='form-control form-control-solid'
                    placeholder='Full school address'
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                    rows={3}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* ── System Info (read-only) ── */}
          <div className='card mb-6'>
            <div className='card-header border-0 pt-6 pb-0'>
              <div className='card-title'>
                <h3 className='fw-bold fs-5 text-gray-800 mb-0'>
                  <i className='ki-duotone ki-lock-3 fs-4 text-warning me-2'>
                    <span className='path1' /><span className='path2' /><span className='path3' />
                  </i>
                  System Information
                </h3>
              </div>
              <div className='card-toolbar'>
                <span className='badge badge-light-warning fs-8 fw-semibold'>
                  <i className='ki-duotone ki-shield-cross fs-8 me-1'>
                    <span className='path1' /><span className='path2' /><span className='path3' />
                  </i>
                  Managed by Super Admin
                </span>
              </div>
            </div>
            <div className='card-body pt-5'>
              <div className='notice d-flex bg-light-warning rounded border-warning border border-dashed mb-6 p-4'>
                <i className='ki-duotone ki-information-5 fs-2tx text-warning me-4'>
                  <span className='path1' /><span className='path2' /><span className='path3' />
                </i>
                <div className='d-flex flex-stack flex-grow-1'>
                  <div className='fw-semibold'>
                    <div className='text-gray-700 fs-7'>
                      School code and subdomain can only be changed by a Super Admin.
                    </div>
                  </div>
                </div>
              </div>
              <div className='row g-6'>
                <div className='col-md-6'>
                  <label className='form-label fw-semibold fs-6 text-muted'>School Code</label>
                  <div className='input-group'>
                    <span className='input-group-text bg-light border-0'>
                      <i className='ki-duotone ki-barcode fs-5 text-muted'>
                        <span className='path1' /><span className='path2' /><span className='path3' /><span className='path4' /><span className='path5' /><span className='path6' /><span className='path7' /><span className='path8' />
                      </i>
                    </span>
                    <input
                      type='text'
                      className='form-control form-control-solid'
                      value={code}
                      readOnly
                      disabled
                    />
                  </div>
                </div>
                <div className='col-md-6'>
                  <label className='form-label fw-semibold fs-6 text-muted'>Subdomain</label>
                  <div className='input-group'>
                    <span className='input-group-text bg-light border-0'>
                      <i className='ki-duotone ki-globe fs-5 text-muted'>
                        <span className='path1' /><span className='path2' />
                      </i>
                    </span>
                    <input
                      type='text'
                      className='form-control form-control-solid'
                      value={subdomain}
                      readOnly
                      disabled
                    />
                    <span className='input-group-text bg-light border-0 text-muted fs-7'>.schoole.app</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ── Footer Actions ── */}
          <div className='d-flex justify-content-end gap-3'>
            <button
              type='button'
              className='btn btn-light btn-active-light-primary'
              onClick={fetchSchoolDetails}
              disabled={saving}
            >
              Discard Changes
            </button>
            <button type='submit' className='btn btn-primary' disabled={saving}>
              {saving ? (
                <>
                  <span className='spinner-border spinner-border-sm align-middle me-2' />
                  Saving...
                </>
              ) : (
                <>
                  <i className='ki-duotone ki-check fs-4 me-1'>
                    <span className='path1' /><span className='path2' />
                  </i>
                  Save Changes
                </>
              )}
            </button>
          </div>

        </form>
      </Content>
    </>
  )
}

const SchoolProfileWrapper: FC = () => {
  const { currentUser } = useAuth()
  if (currentUser?.role === 'teacher') {
    return (
      <>
        <PageTitle breadcrumbs={[]}>My Profile</PageTitle>
        <TeacherProfilePage />
      </>
    )
  }
  return (
    <>
      <PageTitle breadcrumbs={[]}>School Profile</PageTitle>
      <ToolbarWrapper />
      <SchoolProfile />
    </>
  )
}

export { SchoolProfileWrapper }