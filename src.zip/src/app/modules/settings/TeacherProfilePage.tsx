import { FC, useState, useEffect } from 'react'
import { useAuth } from '../../modules/auth'
import axios from 'axios'
import { toAbsoluteUrl } from '../../../_metronic/helpers'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'

const API_URL = import.meta.env.VITE_APP_API_URL
const GENDERS = ['male', 'female', 'other']
const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
const MARITAL_STATUSES = ['single', 'married', 'widowed', 'divorced']
const CATEGORIES = ['General', 'OBC', 'SC', 'ST', 'Other']

type Tab = 'profile' | 'bank' | 'experience' | 'documents'

const TeacherProfilePage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [activeTab, setActiveTab] = useState<Tab>('profile')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [successMsg, setSuccessMsg] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const [teacher, setTeacher] = useState<any>(null)

  // Forms
  const [profileForm, setProfileForm] = useState<any>({})
  const [profileImageFile, setProfileImageFile] = useState<File | null>(null)

  const [bankForm, setBankForm] = useState<any>({})

  const [experiences, setExperiences] = useState<any[]>([])
  const [expForm, setExpForm] = useState<any>({ is_current: false })
  const [editExpId, setEditExpId] = useState<number | null>(null)
  const [editExpForm, setEditExpForm] = useState<any>({})

  const [documents, setDocuments] = useState<any[]>([])
  const [docFile, setDocFile] = useState<File | null>(null)
  const [docType, setDocType] = useState('')

  useEffect(() => {
    fetchProfile()
  }, [])

  const fetchProfile = async () => {
    setLoading(true)
    try {
      const res = await axios.get(`${API_URL}/school/${schoolId}/teacher-app/profile`)
      if (res.data.success) {
        const t = res.data.data.teacher
        setTeacher(t)
        
        // Populate profile form
        setProfileForm({
          dob: t.profile?.dob ? t.profile.dob.split('T')[0] : '',
          gender: t.profile?.gender || '',
          blood_group: t.profile?.blood_group || '',
          marital_status: t.profile?.marital_status || '',
          religion: t.profile?.religion || '',
          category: t.profile?.category || '',
          father_name: t.profile?.father_name || '',
          mother_name: t.profile?.mother_name || '',
          spouse_name: t.profile?.spouse_name || '',
          highest_qualification: t.profile?.highest_qualification || '',
          present_address: t.profile?.present_address || '',
          permanent_address: t.profile?.permanent_address || '',
          emergency_contact_name: t.profile?.emergency_contact_name || '',
          emergency_contact_phone: t.profile?.emergency_contact_phone || ''
        })

        // Populate Bank
        setBankForm({
          bank_name: t.bank_details?.bank_name || '',
          account_holder_name: t.bank_details?.account_holder_name || '',
          account_number: t.bank_details?.account_number || '',
          ifsc_code: t.bank_details?.ifsc_code || '',
          branch_name: t.bank_details?.branch_name || ''
        })

        // Populate Experiences & Docs
        setExperiences(t.experiences || [])
        setDocuments(t.documents || [])
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch profile')
    } finally {
      setLoading(false)
    }
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true); setError(null); setSuccessMsg(null)
    try {
      const formData = new FormData()
      Object.entries(profileForm).forEach(([key, val]) => {
        if (val) formData.append(key, val as string)
      })
      if (profileImageFile) formData.append('profile_image', profileImageFile)
      
      await axios.put(`${API_URL}/school/${schoolId}/teacher-app/profile`, formData)
      setSuccessMsg('Profile updated successfully!')
      fetchProfile()
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to update profile')
    } finally { setSaving(false) }
  }

  const handleSaveBank = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true); setError(null); setSuccessMsg(null)
    try {
      await axios.put(`${API_URL}/school/${schoolId}/teacher-app/bank`, bankForm)
      setSuccessMsg('Bank details updated successfully!')
      fetchProfile()
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to update bank details')
    } finally { setSaving(false) }
  }

  const handleSaveExperience = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true); setError(null); setSuccessMsg(null)
    try {
      if (editExpId) {
        await axios.put(`${API_URL}/school/${schoolId}/teacher-app/experience/${editExpId}`, expForm)
        setSuccessMsg('Experience updated successfully!')
      } else {
        await axios.post(`${API_URL}/school/${schoolId}/teacher-app/experience`, expForm)
        setSuccessMsg('Experience added successfully!')
      }
      setExpForm({ is_current: false })
      setEditExpId(null)
      fetchProfile()
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to save experience')
    } finally { setSaving(false) }
  }

  const handleUpdateExperience = async (expId: number) => {
    setSaving(true); setError(null); setSuccessMsg(null)
    try {
      await axios.put(`${API_URL}/school/${schoolId}/teacher-app/experience/${expId}`, editExpForm)
      setSuccessMsg('Experience updated successfully!')
      setEditExpId(null); setEditExpForm({})
      fetchProfile()
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to update experience')
    } finally { setSaving(false) }
  }

  const handleDeleteExperience = async (expId: number) => {
    if (!window.confirm('Delete this experience?')) return
    try {
      await axios.delete(`${API_URL}/school/${schoolId}/teacher-app/experience/${expId}`)
      setSuccessMsg('Experience deleted!')
      fetchProfile()
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to delete experience')
    }
  }

  const handleAddDocument = async () => {
    if (!docFile || !docType) return
    setSaving(true); setError(null); setSuccessMsg(null)
    try {
      const formData = new FormData()
      formData.append('document_file', docFile)
      formData.append('document_type', docType)
      
      await axios.post(`${API_URL}/school/${schoolId}/teacher-app/documents`, formData)
      setSuccessMsg('Document uploaded successfully!')
      setDocFile(null); setDocType('')
      fetchProfile()
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to upload document')
    } finally { setSaving(false) }
  }

  const handleDeleteDocument = async (docId: number) => {
    if (!window.confirm('Delete this document?')) return
    try {
      await axios.delete(`${API_URL}/school/${schoolId}/teacher-app/documents/${docId}`)
      setSuccessMsg('Document deleted!')
      fetchProfile()
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to delete document')
    }
  }

  if (loading) return (
    <Content><div className='text-center py-10'><span className='spinner-border text-primary'></span></div></Content>
  )

  if (!teacher) return (
    <Content><div className='alert alert-danger'>{error || 'Could not load profile.'}</div></Content>
  )

  const cs = teacher.completion_status || {}
  const pct = teacher.completion_percentage || 0

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* Header Section */}
        <div className='card mb-5 mb-xl-10'>
          <div className='card-body pt-9 pb-0'>
            <div className='d-flex flex-wrap flex-sm-nowrap'>
              <div className='me-7 mb-4'>
                <div className='symbol symbol-100px symbol-lg-160px symbol-fixed position-relative'>
                  {teacher.profile?.profile_image ? (
                    <img src={teacher.profile.profile_image} alt='avatar' style={{ objectFit: 'cover' }} />
                  ) : (
                    <img src={toAbsoluteUrl('media/svg/avatars/blank.svg')} alt='avatar' />
                  )}
                  <div className='position-absolute translate-middle bottom-0 start-100 mb-6 bg-success rounded-circle border border-4 border-body h-20px w-20px'></div>
                </div>
              </div>
              <div className='flex-grow-1'>
                <div className='d-flex justify-content-between align-items-start flex-wrap mb-2'>
                  <div className='d-flex flex-column'>
                    <div className='d-flex align-items-center mb-2'>
                      <span className='text-gray-900 fs-2 fw-bold me-1'>{teacher.name}</span>
                      <i className='ki-duotone ki-verify fs-1 text-primary'><span className='path1'></span><span className='path2'></span></i>
                    </div>
                    <div className='d-flex flex-wrap fw-semibold fs-6 mb-4 pe-2'>
                      <span className='d-flex align-items-center text-gray-500 me-5 mb-2'>
                        <i className='ki-duotone ki-profile-circle fs-4 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                        {teacher.employment_type || 'Teacher'}
                      </span>
                      <span className='d-flex align-items-center text-gray-500 mb-2'>
                        <i className='ki-duotone ki-sms fs-4 me-1'><span className='path1'></span><span className='path2'></span></i>
                        {teacher.email}
                      </span>
                    </div>
                  </div>
                </div>
                <div className='d-flex flex-wrap flex-stack'>
                  <div className='d-flex flex-column flex-grow-1 pe-8'>
                    <div className='d-flex flex-wrap'>
                      <div className='border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3'>
                        <div className='d-flex align-items-center'><div className='fs-2 fw-bold'>{pct}%</div></div>
                        <div className='fw-semibold fs-6 text-gray-500'>Profile Completion</div>
                      </div>
                    </div>
                  </div>
                  <div className='d-flex align-items-center w-200px w-sm-300px flex-column mt-3'>
                    <div className='d-flex justify-content-between w-100 mt-auto mb-2'>
                      <span className='fw-semibold fs-6 text-gray-500'>Profile Completeness</span>
                      <span className='fw-bold fs-6'>{pct}%</span>
                    </div>
                    <div className='h-5px mx-3 w-100 bg-light mb-3'>
                      <div className='bg-success rounded h-5px' role='progressbar' style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Menu Nav */}
            <ul className='nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bold'>
              <li className='nav-item mt-2'>
                <a className={`nav-link text-active-primary ms-0 me-10 py-5 cursor-pointer ${activeTab === 'profile' ? 'active' : ''}`} onClick={() => setActiveTab('profile')}>
                  Personal Details {cs.profile && <i className='ki-duotone ki-check-circle text-success ms-1 fs-4'><span className='path1'></span><span className='path2'></span></i>}
                </a>
              </li>
              <li className='nav-item mt-2'>
                <a className={`nav-link text-active-primary ms-0 me-10 py-5 cursor-pointer ${activeTab === 'bank' ? 'active' : ''}`} onClick={() => setActiveTab('bank')}>
                  Bank Info {cs.bank_details && <i className='ki-duotone ki-check-circle text-success ms-1 fs-4'><span className='path1'></span><span className='path2'></span></i>}
                </a>
              </li>
              <li className='nav-item mt-2'>
                <a className={`nav-link text-active-primary ms-0 me-10 py-5 cursor-pointer ${activeTab === 'experience' ? 'active' : ''}`} onClick={() => setActiveTab('experience')}>
                  Experience {cs.experience && <i className='ki-duotone ki-check-circle text-success ms-1 fs-4'><span className='path1'></span><span className='path2'></span></i>}
                </a>
              </li>
              <li className='nav-item mt-2'>
                <a className={`nav-link text-active-primary ms-0 me-10 py-5 cursor-pointer ${activeTab === 'documents' ? 'active' : ''}`} onClick={() => setActiveTab('documents')}>
                  Documents {cs.documents && <i className='ki-duotone ki-check-circle text-success ms-1 fs-4'><span className='path1'></span><span className='path2'></span></i>}
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Tab Content */}
        <div className='card mb-5 mb-xl-10'>
          <div className='card-body p-9'>
            {error && <div className='alert alert-danger'>{error}</div>}
            {successMsg && <div className='alert alert-success'>{successMsg}</div>}

            {/* PROFILE TAB */}
            {activeTab === 'profile' && (
              <form onSubmit={handleSaveProfile}>
                <div className='row g-5'>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Date of Birth</label><input type='date' className='form-control form-control-solid' value={profileForm.dob} onChange={e => setProfileForm((s: any) => ({ ...s, dob: e.target.value }))} /></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Gender</label><select className='form-select form-select-solid' value={profileForm.gender} onChange={e => setProfileForm((s: any) => ({ ...s, gender: e.target.value }))}><option value=''>Select...</option>{GENDERS.map(g => <option key={g} value={g}>{g.charAt(0).toUpperCase() + g.slice(1)}</option>)}</select></div>
                  
                  <div className='col-md-3'><label className='fw-semibold fs-6 mb-1'>Blood Group</label><select className='form-select form-select-solid' value={profileForm.blood_group} onChange={e => setProfileForm((s: any) => ({ ...s, blood_group: e.target.value }))}><option value=''>Select...</option>{BLOOD_GROUPS.map(b => <option key={b}>{b}</option>)}</select></div>
                  <div className='col-md-3'><label className='fw-semibold fs-6 mb-1'>Marital Status</label><select className='form-select form-select-solid' value={profileForm.marital_status} onChange={e => setProfileForm((s: any) => ({ ...s, marital_status: e.target.value }))}><option value=''>Select...</option>{MARITAL_STATUSES.map(m => <option key={m} value={m}>{m.charAt(0).toUpperCase() + m.slice(1)}</option>)}</select></div>
                  <div className='col-md-3'><label className='fw-semibold fs-6 mb-1'>Religion</label><input className='form-control form-control-solid' value={profileForm.religion} onChange={e => setProfileForm((s: any) => ({ ...s, religion: e.target.value }))} /></div>
                  <div className='col-md-3'><label className='fw-semibold fs-6 mb-1'>Category</label><select className='form-select form-select-solid' value={profileForm.category} onChange={e => setProfileForm((s: any) => ({ ...s, category: e.target.value }))}><option value=''>Select...</option>{CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}</select></div>
                  
                  <div className='col-12'><label className='fw-semibold fs-6 mb-1'>Profile Photo</label><input type='file' accept='image/*' className='form-control form-control-solid' onChange={e => setProfileImageFile(e.target.files?.[0] || null)} /></div>
                  
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Father Name</label><input className='form-control form-control-solid' value={profileForm.father_name} onChange={e => setProfileForm((s: any) => ({ ...s, father_name: e.target.value }))} /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Mother Name</label><input className='form-control form-control-solid' value={profileForm.mother_name} onChange={e => setProfileForm((s: any) => ({ ...s, mother_name: e.target.value }))} /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Spouse Name</label><input className='form-control form-control-solid' value={profileForm.spouse_name} onChange={e => setProfileForm((s: any) => ({ ...s, spouse_name: e.target.value }))} /></div>
                  
                  <div className='col-12'><label className='fw-semibold fs-6 mb-1'>Highest Qualification</label><input className='form-control form-control-solid' placeholder='e.g. M.Sc Mathematics' value={profileForm.highest_qualification} onChange={e => setProfileForm((s: any) => ({ ...s, highest_qualification: e.target.value }))} /></div>
                  
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Present Address</label><textarea className='form-control form-control-solid' rows={3} value={profileForm.present_address} onChange={e => setProfileForm((s: any) => ({ ...s, present_address: e.target.value }))}></textarea></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Permanent Address</label><textarea className='form-control form-control-solid' rows={3} value={profileForm.permanent_address} onChange={e => setProfileForm((s: any) => ({ ...s, permanent_address: e.target.value }))}></textarea></div>
                  
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Emergency Contact Name</label><input className='form-control form-control-solid' value={profileForm.emergency_contact_name} onChange={e => setProfileForm((s: any) => ({ ...s, emergency_contact_name: e.target.value }))} /></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Emergency Contact Phone</label><input className='form-control form-control-solid' value={profileForm.emergency_contact_phone} onChange={e => setProfileForm((s: any) => ({ ...s, emergency_contact_phone: e.target.value }))} /></div>
                </div>
                <div className='mt-8 text-end'><button className='btn btn-primary' type='submit' disabled={saving}>{saving ? 'Saving...' : 'Save Profile'}</button></div>
              </form>
            )}

            {/* BANK TAB */}
            {activeTab === 'bank' && (
              <form onSubmit={handleSaveBank}>
                <div className='row g-5'>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>Bank Name</label><input className='form-control form-control-solid' placeholder='State Bank of India' value={bankForm.bank_name} onChange={e => setBankForm((s: any) => ({ ...s, bank_name: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>Account Holder Name</label><input className='form-control form-control-solid' value={bankForm.account_holder_name} onChange={e => setBankForm((s: any) => ({ ...s, account_holder_name: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>Account Number</label><input className='form-control form-control-solid' value={bankForm.account_number} onChange={e => setBankForm((s: any) => ({ ...s, account_number: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>IFSC Code</label><input className='form-control form-control-solid' value={bankForm.ifsc_code} onChange={e => setBankForm((s: any) => ({ ...s, ifsc_code: e.target.value.toUpperCase() }))} required /></div>
                  <div className='col-12'><label className='fw-semibold fs-6 mb-1'>Branch Name</label><input className='form-control form-control-solid' value={bankForm.branch_name} onChange={e => setBankForm((s: any) => ({ ...s, branch_name: e.target.value }))} /></div>
                </div>
                <div className='mt-8 text-end'><button className='btn btn-primary' type='submit' disabled={saving}>{saving ? 'Saving...' : 'Save Bank Details'}</button></div>
              </form>
            )}

            {/* EXPERIENCE TAB */}
            {activeTab === 'experience' && (
              <div>
                {experiences.length > 0 && (
                  <div className='mb-8'>
                    {experiences.map(exp => (
                      <div key={exp.id} className='card card-bordered mb-4'>
                        <div className='card-body py-4 d-flex justify-content-between'>
                          <div>
                            <div className='fw-bolder fs-5 text-gray-800'>{exp.school_name}</div>
                            <div className='text-primary fw-semibold fs-6'>{exp.designation}</div>
                            <div className='text-muted fs-7'>{exp.from_date?.split('T')[0]} &rarr; {exp.is_current ? 'Present' : exp.to_date?.split('T')[0]}</div>
                            {exp.reason_for_leaving && <div className='text-muted fs-8 mt-1'>Reason for Leaving: {exp.reason_for_leaving}</div>}
                          </div>
                          <div className='d-flex gap-2'>
                            <button
                              type='button'
                              className='btn btn-icon btn-sm btn-light-primary'
                              onClick={() => {
                                setEditExpId(exp.id)
                                setExpForm({
                                  school_name: exp.school_name,
                                  designation: exp.designation,
                                  from_date: exp.from_date ? exp.from_date.split('T')[0] : '',
                                  to_date: exp.to_date ? exp.to_date.split('T')[0] : '',
                                  is_current: exp.is_current || false,
                                  reason_for_leaving: exp.reason_for_leaving || ''
                                })
                              }}
                            >
                              <i className='ki-duotone ki-pencil fs-4'><span className='path1'></span><span className='path2'></span></i>
                            </button>
                            <button type='button' className='btn btn-icon btn-sm btn-light-danger' onClick={() => handleDeleteExperience(exp.id)}><i className='ki-duotone ki-trash fs-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i></button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                <h5 className='fw-bold text-gray-800 mb-4'>{editExpId ? 'Edit Experience' : 'Add New Experience'}</h5>
                <form onSubmit={handleSaveExperience}>
                  <div className='row g-4'>
                    <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>School/Institution</label><input className='form-control form-control-solid' value={expForm.school_name || ''} onChange={e => setExpForm((s: any) => ({ ...s, school_name: e.target.value }))} required /></div>
                    <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>Designation</label><input className='form-control form-control-solid' value={expForm.designation || ''} onChange={e => setExpForm((s: any) => ({ ...s, designation: e.target.value }))} required /></div>
                    <div className='col-md-4'><label className='required fw-semibold fs-6 mb-1'>From Date</label><input type='date' className='form-control form-control-solid' value={expForm.from_date || ''} onChange={e => setExpForm((s: any) => ({ ...s, from_date: e.target.value }))} required /></div>
                    <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>To Date</label><input type='date' className='form-control form-control-solid' value={expForm.to_date || ''} onChange={e => setExpForm((s: any) => ({ ...s, to_date: e.target.value }))} disabled={expForm.is_current} /></div>
                    <div className='col-md-4 d-flex align-items-end'>
                      <label className='form-check form-check-custom form-check-solid mb-2'>
                        <input className='form-check-input me-2' type='checkbox' checked={expForm.is_current || false} onChange={e => setExpForm((s: any) => ({ ...s, is_current: e.target.checked, to_date: e.target.checked ? '' : s.to_date }))} />
                        <span className='fw-semibold'>Currently working</span>
                      </label>
                    </div>
                    {!expForm.is_current && (
                      <div className='col-12'>
                        <label className='fw-semibold fs-6 mb-1'>Reason for Leaving</label>
                        <input className='form-control form-control-solid' value={expForm.reason_for_leaving || ''} onChange={e => setExpForm((s: any) => ({ ...s, reason_for_leaving: e.target.value }))} />
                      </div>
                    )}
                  </div>
                  <div className='mt-6 text-end'>
                    {editExpId && (
                      <button
                        className='btn btn-light me-2'
                        type='button'
                        onClick={() => {
                          setEditExpId(null)
                          setExpForm({ is_current: false })
                        }}
                      >
                        Cancel Edit
                      </button>
                    )}
                    <button className='btn btn-success' type='submit' disabled={saving}>
                      {saving ? 'Saving...' : editExpId ? 'Save Changes' : 'Add Experience'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* DOCUMENTS TAB */}
            {activeTab === 'documents' && (
              <div>
                <div className='card card-bordered mb-8'>
                  <div className='card-body p-5'>
                    <div className='row g-4'>
                      <div className='col-md-4'>
                        <label className='required fw-semibold fs-6 mb-1'>Document Type</label>
                        <select className='form-select form-select-solid' value={docType} onChange={e => setDocType(e.target.value)}>
                          <option value=''>Select...</option>
                          <option value='Aadhaar Card'>Aadhaar Card</option>
                          <option value='PAN Card'>PAN Card</option>
                          <option value='Degree Certificate'>Degree Certificate</option>
                          <option value='Experience Certificate'>Experience</option>
                          <option value='Other'>Other</option>
                        </select>
                      </div>
                      <div className='col-md-6'>
                        <label className='required fw-semibold fs-6 mb-1'>File (PDF, Image)</label>
                        <input type='file' className='form-control form-control-solid' onChange={e => setDocFile(e.target.files?.[0] || null)} />
                      </div>
                      <div className='col-md-2 d-flex align-items-end'>
                        <button className='btn btn-primary w-100' onClick={handleAddDocument} disabled={saving || !docFile || !docType}>{saving ? 'Upload...' : 'Upload'}</button>
                      </div>
                    </div>
                  </div>
                </div>

                {documents.length > 0 && (
                  <div className='row g-4'>
                    {documents.map(doc => (
                      <div key={doc.id} className='col-md-6'>
                        <div className='card card-bordered'>
                          <div className='card-body p-4 d-flex align-items-center justify-content-between'>
                            <div className='d-flex align-items-center'>
                              <i className='ki-duotone ki-document fs-1 text-primary me-3'><span className='path1'></span><span className='path2'></span></i>
                              <div>
                                <div className='fw-bold text-gray-800'>{doc.document_type}</div>
                                <div className='badge badge-light-primary fs-8'>{doc.verification_status}</div>
                              </div>
                            </div>
                            <div className='d-flex gap-2'>
                              <a href={doc.file_path} target='_blank' rel='noreferrer' className='btn btn-icon btn-sm btn-light-info'><i className='ki-duotone ki-eye fs-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i></a>
                              <button type='button' className='btn btn-icon btn-sm btn-light-danger' onClick={() => handleDeleteDocument(doc.id)}><i className='ki-duotone ki-trash fs-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </Content>
    </>
  )
}

export { TeacherProfilePage }
