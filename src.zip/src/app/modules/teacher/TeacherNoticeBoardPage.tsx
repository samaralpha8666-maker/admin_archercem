import { FC, useState, useEffect } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import axios from 'axios'

const API_URL = import.meta.env.VITE_APP_API_URL

type Notice = {
  id: number
  title: string
  content: string
  category: string
  priority: string
  target_type: string
  status: string
  is_pinned: boolean
  publish_at: string
  expires_at: string
  attachment_url: string
  created_by_role: string
  createdAt: string
}

const CATEGORIES = ['ALL', 'GENERAL', 'ACADEMIC', 'EXAM', 'HOLIDAY', 'URGENT', 'EVENT']

const priorityColor: Record<string, string> = {
  LOW: 'badge-light-secondary',
  NORMAL: 'badge-light-primary',
  HIGH: 'badge-light-warning',
  URGENT: 'badge-light-danger',
}

const categoryColor: Record<string, string> = {
  GENERAL: 'badge-light',
  ACADEMIC: 'badge-light-info',
  EXAM: 'badge-light-warning',
  HOLIDAY: 'badge-light-success',
  URGENT: 'badge-light-danger',
  EVENT: 'badge-light-primary',
}

const TeacherNoticeBoardPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [notices, setNotices] = useState<Notice[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [categoryFilter, setCategoryFilter] = useState('ALL')
  const [searchText, setSearchText] = useState('')
  const [selectedNotice, setSelectedNotice] = useState<Notice | null>(null)

  useEffect(() => {
    fetchNotices()
  }, [categoryFilter])

  const fetchNotices = async () => {
    setLoading(true)
    setError(null)
    try {
      const params: any = {}
      if (categoryFilter !== 'ALL') params.category = categoryFilter
      const res = await axios.get(`${API_URL}/school/${schoolId}/teacher-app/notices`, { params })
      if (res.data.success) {
        setNotices(res.data.data.notices || [])
      }
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to load notices')
    } finally {
      setLoading(false)
    }
  }

  const filtered = notices.filter(n =>
    !searchText || n.title.toLowerCase().includes(searchText.toLowerCase()) ||
    n.content.toLowerCase().includes(searchText.toLowerCase())
  )

  const pinnedNotices = filtered.filter(n => n.is_pinned)
  const regularNotices = filtered.filter(n => !n.is_pinned)

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric'
  })

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* Header */}
        <div className='card mb-5'>
          <div className='card-body py-5'>
            <div className='d-flex align-items-center justify-content-between flex-wrap gap-3'>
              <div>
                <h2 className='fw-bold text-gray-900 mb-1'>📢 Notice Board</h2>
                <div className='text-muted fs-6'>School announcements & notifications for teachers</div>
              </div>
              <div className='d-flex gap-2 flex-wrap'>
                {CATEGORIES.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setCategoryFilter(cat)}
                    className={`btn btn-sm ${categoryFilter === cat ? 'btn-primary' : 'btn-light'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Search */}
            <div className='mt-4 d-flex align-items-center position-relative'>
              <i className='ki-duotone ki-magnifier fs-3 position-absolute ms-4'>
                <span className='path1'></span><span className='path2'></span>
              </i>
              <input
                type='text'
                className='form-control form-control-solid ps-14'
                placeholder='Search notices...'
                value={searchText}
                onChange={e => setSearchText(e.target.value)}
              />
            </div>
          </div>
        </div>

        {loading && (
          <div className='text-center py-10'>
            <span className='spinner-border text-primary'></span>
            <div className='text-muted mt-3'>Loading notices...</div>
          </div>
        )}

        {error && (
          <div className='alert alert-danger'>{error}</div>
        )}

        {!loading && !error && (
          <>
            {/* Pinned Notices */}
            {pinnedNotices.length > 0 && (
              <div className='mb-6'>
                <div className='d-flex align-items-center mb-3'>
                  <i className='ki-duotone ki-pin fs-3 text-warning me-2'>
                    <span className='path1'></span><span className='path2'></span>
                  </i>
                  <h5 className='fw-bold text-gray-800 mb-0'>Pinned Notices</h5>
                </div>
                <div className='row g-4'>
                  {pinnedNotices.map(notice => (
                    <div key={notice.id} className='col-md-6'>
                      <div
                        className='card card-bordered border-warning cursor-pointer h-100'
                        style={{ borderLeft: '4px solid #ffc700' }}
                        onClick={() => setSelectedNotice(notice)}
                      >
                        <div className='card-body p-5'>
                          <div className='d-flex justify-content-between align-items-start mb-2'>
                            <div className='d-flex gap-2 flex-wrap'>
                              <span className={`badge ${categoryColor[notice.category] || 'badge-light'}`}>{notice.category}</span>
                              <span className={`badge ${priorityColor[notice.priority] || 'badge-light'}`}>{notice.priority}</span>
                              <span className='badge badge-light-warning'>📌 Pinned</span>
                            </div>
                            <span className='text-muted fs-8'>{formatDate(notice.publish_at || notice.createdAt)}</span>
                          </div>
                          <h6 className='fw-bold text-gray-900 mb-2'>{notice.title}</h6>
                          <p className='text-muted fs-7 mb-0' style={{ overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical' }}>
                            {notice.content}
                          </p>
                          {notice.attachment_url && (
                            <div className='mt-3'>
                              <a href={notice.attachment_url} target='_blank' rel='noreferrer' className='btn btn-sm btn-light-info' onClick={e => e.stopPropagation()}>
                                <i className='ki-duotone ki-document fs-5'><span className='path1'></span><span className='path2'></span></i> Attachment
                              </a>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Regular Notices */}
            {regularNotices.length > 0 ? (
              <div>
                <h5 className='fw-bold text-gray-800 mb-3'>All Notices ({regularNotices.length})</h5>
                <div className='row g-4'>
                  {regularNotices.map(notice => (
                    <div key={notice.id} className='col-md-6 col-lg-4'>
                      <div
                        className='card card-bordered cursor-pointer h-100 card-hover'
                        onClick={() => setSelectedNotice(notice)}
                        style={{ transition: 'box-shadow 0.2s' }}
                        onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.12)')}
                        onMouseLeave={e => (e.currentTarget.style.boxShadow = '')}
                      >
                        <div className='card-body p-5'>
                          <div className='d-flex justify-content-between align-items-start mb-2'>
                            <div className='d-flex gap-2 flex-wrap'>
                              <span className={`badge ${categoryColor[notice.category] || 'badge-light'}`}>{notice.category}</span>
                              {notice.priority !== 'NORMAL' && (
                                <span className={`badge ${priorityColor[notice.priority]}`}>{notice.priority}</span>
                              )}
                            </div>
                            <span className='text-muted fs-8'>{formatDate(notice.publish_at || notice.createdAt)}</span>
                          </div>
                          <h6 className='fw-bold text-gray-900 mb-2'>{notice.title}</h6>
                          <p className='text-muted fs-7 mb-0' style={{ overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical' }}>
                            {notice.content}
                          </p>
                          {notice.attachment_url && (
                            <div className='mt-3'>
                              <span className='badge badge-light-info'>📎 Attachment</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              !pinnedNotices.length && (
                <div className='card'>
                  <div className='card-body text-center py-15'>
                    <i className='ki-duotone ki-notification-status fs-5x text-muted mb-4'>
                      <span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span>
                    </i>
                    <div className='text-muted fs-5'>No notices found{categoryFilter !== 'ALL' ? ` for category "${categoryFilter}"` : ''}.</div>
                  </div>
                </div>
              )
            )}
          </>
        )}

        {/* Notice Detail Modal */}
        {selectedNotice && (
          <div className='modal fade show d-block' tabIndex={-1} style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} onClick={() => setSelectedNotice(null)}>
            <div className='modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable' onClick={e => e.stopPropagation()}>
              <div className='modal-content'>
                <div className='modal-header'>
                  <div>
                    <div className='d-flex gap-2 mb-2'>
                      <span className={`badge ${categoryColor[selectedNotice.category] || 'badge-light'}`}>{selectedNotice.category}</span>
                      <span className={`badge ${priorityColor[selectedNotice.priority] || 'badge-light'}`}>{selectedNotice.priority}</span>
                      {selectedNotice.is_pinned && <span className='badge badge-light-warning'>📌 Pinned</span>}
                    </div>
                    <h4 className='modal-title fw-bold text-gray-900'>{selectedNotice.title}</h4>
                    <div className='text-muted fs-7 mt-1'>
                      Published on {formatDate(selectedNotice.publish_at || selectedNotice.createdAt)} &bull; By {selectedNotice.created_by_role || 'Admin'}
                    </div>
                  </div>
                  <button type='button' className='btn-close' onClick={() => setSelectedNotice(null)}></button>
                </div>
                <div className='modal-body'>
                  <div className='fs-5 text-gray-800 lh-lg' style={{ whiteSpace: 'pre-wrap' }}>
                    {selectedNotice.content}
                  </div>
                  {selectedNotice.expires_at && (
                    <div className='alert alert-warning mt-4 mb-0'>
                      <strong>Expires on:</strong> {formatDate(selectedNotice.expires_at)}
                    </div>
                  )}
                </div>
                {selectedNotice.attachment_url && (
                  <div className='modal-footer justify-content-start'>
                    <a href={selectedNotice.attachment_url} target='_blank' rel='noreferrer' className='btn btn-info'>
                      <i className='ki-duotone ki-document fs-4'><span className='path1'></span><span className='path2'></span></i> View Attachment
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </Content>
    </>
  )
}

const TeacherNoticeBoardWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[]}>Notice Board</PageTitle>
    <TeacherNoticeBoardPage />
  </>
)

export { TeacherNoticeBoardWrapper, TeacherNoticeBoardPage }
