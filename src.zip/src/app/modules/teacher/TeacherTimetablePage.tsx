import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import axios from 'axios'
import { KTIcon } from '../../../_metronic/helpers'

const API_URL = import.meta.env.VITE_APP_API_URL

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'] as const
type DayKey = typeof DAYS[number]

const DAY_SHORT: Record<DayKey, string> = {
  MONDAY: 'Mon', TUESDAY: 'Tue', WEDNESDAY: 'Wed',
  THURSDAY: 'Thu', FRIDAY: 'Fri', SATURDAY: 'Sat', SUNDAY: 'Sun',
}

type PeriodsSlot = { id: number; name: string; start_time: string; end_time: string }
type TEntry = {
  timetable_entry_id: number
  period_slot: PeriodsSlot | null
  subject: { id: number; name: string; code: string } | null
  class_section: { id: number; label: string; class_name: string; section_name: string } | null
}
type TTData = {
  session_id: number
  session_name: string
  is_current_session: boolean
  timetable: Partial<Record<DayKey, TEntry[]>>
}

const fmtTime = (t: string) => {
  if (!t) return ''
  const [h, m] = t.split(':')
  const hr = parseInt(h)
  return `${hr % 12 || 12}:${m}${hr >= 12 ? 'pm' : 'am'}`
}

function getSlots(tt: Partial<Record<DayKey, TEntry[]>>) {
  const map = new Map<number, PeriodsSlot>()
  DAYS.forEach(d => (tt[d] || []).forEach(e => {
    if (e.period_slot) map.set(e.period_slot.id, e.period_slot)
  }))
  return Array.from(map.values()).sort((a, b) => a.start_time.localeCompare(b.start_time))
}

// Deterministic subject badge color
const LIGHT_COLORS = ['primary', 'success', 'warning', 'info', 'danger'] as const
type LightColor = typeof LIGHT_COLORS[number]
function subjectBadgeColor(name: string): LightColor {
  let h = 0
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h)
  return LIGHT_COLORS[Math.abs(h) % LIGHT_COLORS.length]
}

// ─── Today label ─────────────────────────────────────────────────────────────
function todayDayKey(): DayKey | null {
  const d = new Date().toLocaleString('en-US', { weekday: 'long' }).toUpperCase() as DayKey
  return DAYS.includes(d) ? d : null
}

// ─── Period cell (for grid) ───────────────────────────────────────────────────
const PeriodCell: FC<{ entry: TEntry | undefined }> = ({ entry }) => {
  if (!entry?.subject) {
    return <span className='text-gray-300 fs-8'>—</span>
  }
  const color = subjectBadgeColor(entry.subject.name)
  return (
    <div className='d-flex flex-column align-items-start gap-1'>
      <span className={`badge badge-light-${color} fw-bold fs-8 px-3 py-2`} style={{ whiteSpace: 'normal', textAlign: 'left' }}>
        {entry.subject.name}
        {entry.subject.code ? <span className='ms-1 opacity-75'>({entry.subject.code})</span> : null}
      </span>
      {entry.class_section && (
        <span className='text-gray-500 fs-9 fw-semibold ps-1'>
          <KTIcon iconName='people' className='fs-9 me-1' />
          {entry.class_section.label}
        </span>
      )}
    </div>
  )
}

// ─── Main Component ──────────────────────────────────────────────────────────
const TeacherTimetablePage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')
  const today = todayDayKey()

  // Dynamic layout to expand container to fluid layout (full screen width)
  useEffect(() => {
    const contentContainer = document.getElementById('kt_app_content_container')
    const toolbarContainer = document.getElementById('kt_app_toolbar_container')

    const hasXXLContent = contentContainer?.classList.contains('container-xxl')
    const hasXXLToolbar = toolbarContainer?.classList.contains('container-xxl')

    if (hasXXLContent) {
      contentContainer?.classList.remove('container-xxl')
      contentContainer?.classList.add('container-fluid')
    }
    if (hasXXLToolbar) {
      toolbarContainer?.classList.remove('container-xxl')
      toolbarContainer?.classList.add('container-fluid')
    }

    return () => {
      if (hasXXLContent) {
        contentContainer?.classList.add('container-xxl')
        contentContainer?.classList.remove('container-fluid')
      }
      if (hasXXLToolbar) {
        toolbarContainer?.classList.add('container-xxl')
        toolbarContainer?.classList.remove('container-fluid')
      }
    }
  }, [])

  const [data, setData] = useState<TTData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<'grid' | 'day'>('grid')
  const [activeDay, setActiveDay] = useState<DayKey>(today || 'MONDAY')

  const load = useCallback(async () => {
    if (!schoolId) return
    setLoading(true); setError(null)
    try {
      const res = await axios.get(`${API_URL}/school/${schoolId}/teacher-app/timetable`)
      if (res.data.success) {
        setData(res.data.data)
      } else {
        setError('Failed to load timetable data.')
      }
    } catch (e: any) {
      setError(e?.response?.data?.error || 'Network error. Please try again.')
    } finally {
      setLoading(false)
    }
  }, [schoolId])

  useEffect(() => { load() }, [load])

  const tt = data?.timetable || {}
  const slots = getSlots(tt)
  const totalPeriods = DAYS.reduce((s, d) => s + (tt[d]?.length || 0), 0)
  const uniqueSubjects = new Set(DAYS.flatMap(d => (tt[d] || []).map(e => e.subject?.name).filter(Boolean)))
  const uniqueClasses = new Set(DAYS.flatMap(d => (tt[d] || []).map(e => e.class_section?.label).filter(Boolean)))

  // ── Stat card helper ────────────────────────────────────────────────────────
  const StatCard: FC<{ icon: string; color: string; value: string | number; label: string }> = ({ icon, color, value, label }) => (
    <div className='col-xl-3 col-md-6'>
      <div className='card card-flush bgi-no-repeat bgi-size-contain bgi-position-x-end h-md-50 mb-5 mb-xl-10'>
        <div className='card-header pt-5'>
          <div className='card-title d-flex flex-column'>
            <span className='fs-2hx fw-bold text-gray-900 me-2 lh-1 ls-n2'>{value}</span>
            <span className='text-gray-500 pt-1 fw-semibold fs-6'>{label}</span>
          </div>
        </div>
        <div className='card-body d-flex align-items-end pt-0'>
          <div className={`d-flex align-items-center flex-column mt-3 w-100`}>
            <div className='d-flex justify-content-between fw-bold fs-6 text-gray-500 w-100 mt-auto mb-2'>
              <span className={`badge badge-light-${color} px-3 py-2`}>
                <KTIcon iconName={icon} className={`text-${color} fs-4 me-1`} />
                {label}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* ── Summary Stats Row ─────────────────────────────────────────────── */}
        {data && (
          <div className='row g-5 g-xl-10 mb-5 mb-xl-10'>
            {/* Periods */}
            <div className='col-xl-3 col-md-6'>
              <div className='card card-flush h-xl-100'>
                <div className='card-header pt-5 pb-0'>
                  <div className='card-title d-flex flex-column'>
                    <div className='d-flex align-items-center'>
                      <span className='fs-2hx fw-bold text-gray-900 me-2 lh-1 ls-n2'>{totalPeriods}</span>
                    </div>
                    <span className='text-gray-500 pt-1 fw-semibold fs-6'>Periods / Week</span>
                  </div>
                </div>
                <div className='card-body pt-2 pb-4 d-flex flex-wrap align-items-center'>
                  <div className='symbol symbol-45px me-5'>
                    <div className='symbol-label bg-light-primary'>
                      <KTIcon iconName='calendar' className='fs-2x text-primary' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Subjects */}
            <div className='col-xl-3 col-md-6'>
              <div className='card card-flush h-xl-100'>
                <div className='card-header pt-5 pb-0'>
                  <div className='card-title d-flex flex-column'>
                    <span className='fs-2hx fw-bold text-gray-900 me-2 lh-1'>{uniqueSubjects.size}</span>
                    <span className='text-gray-500 pt-1 fw-semibold fs-6'>Subjects Taught</span>
                  </div>
                </div>
                <div className='card-body pt-2 pb-4 d-flex align-items-center'>
                  <div className='symbol symbol-45px me-5'>
                    <div className='symbol-label bg-light-success'>
                      <KTIcon iconName='book' className='fs-2x text-success' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Classes */}
            <div className='col-xl-3 col-md-6'>
              <div className='card card-flush h-xl-100'>
                <div className='card-header pt-5 pb-0'>
                  <div className='card-title d-flex flex-column'>
                    <span className='fs-2hx fw-bold text-gray-900 me-2 lh-1'>{uniqueClasses.size}</span>
                    <span className='text-gray-500 pt-1 fw-semibold fs-6'>Classes</span>
                  </div>
                </div>
                <div className='card-body pt-2 pb-4 d-flex align-items-center'>
                  <div className='symbol symbol-45px me-5'>
                    <div className='symbol-label bg-light-warning'>
                      <KTIcon iconName='people' className='fs-2x text-warning' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Session */}
            <div className='col-xl-3 col-md-6'>
              <div className='card card-flush h-xl-100'>
                <div className='card-header pt-5 pb-0'>
                  <div className='card-title d-flex flex-column'>
                    <span className='fs-4 fw-bold text-gray-900 lh-1 mb-2'>{data.session_name}</span>
                    {data.is_current_session
                      ? <span className='badge badge-light-success fs-8 w-fit-content'>Current Session</span>
                      : <span className='text-gray-500 fw-semibold fs-6'>Academic Session</span>
                    }
                  </div>
                </div>
                <div className='card-body pt-2 pb-4 d-flex align-items-center'>
                  <div className='symbol symbol-45px me-5'>
                    <div className='symbol-label bg-light-info'>
                      <KTIcon iconName='award' className='fs-2x text-info' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Main Timetable Card ───────────────────────────────────────────── */}
        <div className='card'>

          {/* Card Header */}
          <div className='card-header border-0 pt-6'>
            <div className='card-title'>
              <div className='d-flex align-items-center position-relative my-1'>
                <KTIcon iconName='calendar-2' className='fs-3 position-absolute ms-3' />
                <h3 className='ms-12 fw-bold text-gray-900 mb-0'>
                  My Weekly Timetable
                  {today && tt[today] && (
                    <span className='badge badge-light-primary ms-3 fs-7 fw-bold'>
                      {tt[today]!.length} periods today
                    </span>
                  )}
                </h3>
              </div>
            </div>
            <div className='card-toolbar gap-2'>
              {/* View Toggle */}
              <div className='btn-group btn-group-sm'>
                <button
                  type='button'
                  className={`btn btn-sm ${viewMode === 'grid' ? 'btn-primary' : 'btn-light'}`}
                  onClick={() => setViewMode('grid')}
                >
                  <KTIcon iconName='element-11' className='fs-5 me-1' />Grid
                </button>
                <button
                  type='button'
                  className={`btn btn-sm ${viewMode === 'day' ? 'btn-primary' : 'btn-light'}`}
                  onClick={() => setViewMode('day')}
                >
                  <KTIcon iconName='row-horizontal' className='fs-5 me-1' />Day
                </button>
              </div>
              {/* Refresh */}
              <button
                type='button'
                className='btn btn-sm btn-light-primary'
                onClick={load}
                disabled={loading}
                title='Refresh'
              >
                {loading
                  ? <span className='spinner-border spinner-border-sm' />
                  : <KTIcon iconName='arrows-circle' className='fs-5' />
                }
              </button>
            </div>
          </div>

          {/* Separator */}
          <div className='separator separator-dashed my-0' />

          {/* Card Body */}
          <div className='card-body p-0'>

            {/* Loading */}
            {loading && (
              <div className='d-flex justify-content-center align-items-center py-20'>
                <div className='text-center'>
                  <span className='spinner-border text-primary' style={{ width: '3rem', height: '3rem' }} />
                  <div className='text-muted fw-semibold mt-4 fs-6'>Loading timetable...</div>
                </div>
              </div>
            )}

            {/* Error */}
            {!loading && error && (
              <div className='d-flex flex-column align-items-center justify-content-center py-20'>
                <KTIcon iconName='cross-circle' className='fs-5x text-danger mb-4' />
                <div className='text-gray-700 fw-bold fs-5 mb-2'>Could not load timetable</div>
                <div className='text-muted fs-7 mb-6'>{error}</div>
                <button className='btn btn-sm btn-light-primary' onClick={load}>
                  <KTIcon iconName='arrows-circle' className='fs-5 me-1' />Retry
                </button>
              </div>
            )}

            {/* No Data */}
            {!loading && !error && !data && (
              <div className='d-flex flex-column align-items-center justify-content-center py-20'>
                <KTIcon iconName='calendar-2' className='fs-5x text-gray-300 mb-4' />
                <div className='text-muted fw-semibold fs-5'>No timetable data available</div>
              </div>
            )}

            {/* ═══════════ GRID VIEW ═══════════ */}
            {!loading && !error && data && viewMode === 'grid' && (
              <div className='table-responsive' style={{ overflowX: 'auto' }}>
                <table className='table table-row-dashed table-row-gray-300 align-middle gs-4 gy-0 mb-0' style={{ minWidth: '900px' }}>
                  <thead>
                    <tr className='fw-bold fs-7 text-uppercase text-gray-600 bg-light'>
                      {/* Sticky time column */}
                      <th
                        className='text-center ps-4 py-4 border-end'
                        style={{ minWidth: '120px', position: 'sticky', left: 0, zIndex: 2, background: '#f9f9f9' }}
                      >
                        <div className='d-flex align-items-center justify-content-center gap-1'>
                          <KTIcon iconName='time' className='fs-5 text-primary' />
                          <span>Period</span>
                        </div>
                      </th>
                      {DAYS.map(day => {
                        const isToday = day === today
                        const cnt = tt[day]?.length || 0
                        return (
                          <th
                            key={day}
                            className={`text-center py-4 ${isToday ? 'bg-light-primary' : ''}`}
                            style={{ minWidth: '150px' }}
                          >
                            <div className={`fw-bolder fs-6 ${isToday ? 'text-primary' : 'text-gray-700'}`}>
                              {isToday && <span className='bullet bullet-dot bg-primary h-6px w-6px me-1 mb-1' />}
                              {DAY_SHORT[day]}
                            </div>
                            <div className='text-muted fs-8 fw-semibold'>
                              {cnt > 0 ? `${cnt} period${cnt > 1 ? 's' : ''}` : 'Free'}
                            </div>
                          </th>
                        )
                      })}
                    </tr>
                  </thead>
                  <tbody>
                    {slots.length === 0 ? (
                      <tr>
                        <td colSpan={DAYS.length + 1}>
                          <div className='d-flex flex-column align-items-center justify-content-center py-16'>
                            <KTIcon iconName='calendar' className='fs-4x text-gray-200 mb-4' />
                            <div className='text-muted fw-semibold fs-6'>No timetable assigned yet.</div>
                            <div className='text-muted fs-8'>Ask admin to assign your timetable.</div>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      slots.map(slot => (
                        <tr key={slot.id}>
                          {/* Period label – sticky */}
                          <td
                            className='ps-4 py-4 border-end border-gray-200'
                            style={{ position: 'sticky', left: 0, zIndex: 1, background: '#fff' }}
                          >
                            <div className='d-flex align-items-center gap-2'>
                              <span className='badge badge-light-primary w-22px h-22px d-flex align-items-center justify-content-center p-0 fs-9'>
                                {slots.indexOf(slot) + 1}
                              </span>
                              <div>
                                <div className='fw-bold text-gray-800 fs-7'>{slot.name}</div>
                                <div className='text-muted fs-8'>
                                  {fmtTime(slot.start_time)} – {fmtTime(slot.end_time)}
                                </div>
                              </div>
                            </div>
                          </td>

                          {DAYS.map(day => {
                            const isToday = day === today
                            const entry = (tt[day] || []).find(e => e.period_slot?.id === slot.id)
                            return (
                              <td
                                key={day}
                                className={`text-center py-3 px-3 ${isToday ? 'bg-light' : ''}`}
                              >
                                <PeriodCell entry={entry} />
                              </td>
                            )
                          })}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* ═══════════ DAY VIEW ═══════════ */}
            {!loading && !error && data && viewMode === 'day' && (
              <div>
                {/* Day Pills */}
                <div className='d-flex flex-wrap gap-2 px-8 py-5 border-bottom border-gray-200'>
                  {DAYS.map(day => {
                    const isToday = day === today
                    const cnt = tt[day]?.length || 0
                    const isActive = activeDay === day
                    return (
                      <button
                        key={day}
                        type='button'
                        onClick={() => setActiveDay(day)}
                        className={`btn btn-sm px-4 ${isActive ? 'btn-primary' : 'btn-light'}`}
                      >
                        <span className='fw-bold'>{DAY_SHORT[day]}</span>
                        {isToday && <span className='bullet bullet-dot bg-danger ms-1 mb-1 h-5px w-5px' />}
                        {cnt > 0 && (
                          <span className={`badge badge-sm ms-2 ${isActive ? 'badge-light' : 'badge-light-primary'}`}>
                            {cnt}
                          </span>
                        )}
                      </button>
                    )
                  })}
                </div>

                {/* Day Entries */}
                <div className='px-8 py-6'>
                  <div className='d-flex align-items-center mb-5'>
                    <div className='flex-shrink-0 me-3'>
                      <div className='symbol symbol-40px'>
                        <div className='symbol-label bg-light-primary'>
                          <KTIcon iconName='calendar-2' className='fs-3 text-primary' />
                        </div>
                      </div>
                    </div>
                    <div>
                      <div className='fw-bold text-gray-900 fs-5'>{activeDay}</div>
                      <div className='text-muted fs-7'>
                        {(tt[activeDay] || []).length} period{(tt[activeDay] || []).length !== 1 ? 's' : ''} scheduled
                        {activeDay === today && <span className='badge badge-light-success ms-2 fs-9'>Today</span>}
                      </div>
                    </div>
                  </div>

                  {(tt[activeDay] || []).length === 0 ? (
                    <div className='d-flex flex-column align-items-center justify-content-center py-12 border border-dashed border-gray-300 rounded'>
                      <KTIcon iconName='calendar' className='fs-4x text-gray-300 mb-4' />
                      <div className='text-muted fw-semibold fs-5'>No classes on {DAY_SHORT[activeDay]}</div>
                    </div>
                  ) : (
                    <div className='d-flex flex-column gap-4'>
                      {(tt[activeDay] || [])
                        .slice()
                        .sort((a, b) => (a.period_slot?.start_time || '').localeCompare(b.period_slot?.start_time || ''))
                        .map((entry, idx) => {
                          const sub = entry.subject
                          const slot = entry.period_slot
                          const cls = entry.class_section
                          const color = sub ? subjectBadgeColor(sub.name) : 'secondary'

                          return (
                            <div key={idx} className='card card-bordered shadow-none border-gray-200'>
                              <div className='card-body py-4 px-5'>
                                <div className='d-flex align-items-center gap-4'>

                                  {/* Period Number */}
                                  <div className={`symbol symbol-50px flex-shrink-0`}>
                                    <div className={`symbol-label bg-light-${color}`}>
                                      <span className={`fw-bolder fs-5 text-${color}`}>{idx + 1}</span>
                                    </div>
                                  </div>

                                  {/* Subject info */}
                                  <div className='flex-grow-1'>
                                    <div className='d-flex align-items-center gap-2 mb-1'>
                                      <span className='fw-bolder fs-5 text-gray-900'>
                                        {sub?.name || <span className='text-muted fw-semibold'>Free Period</span>}
                                      </span>
                                      {sub?.code && (
                                        <span className={`badge badge-light-${color} fs-8`}>{sub.code}</span>
                                      )}
                                    </div>
                                    {slot && (
                                      <div className='text-muted fs-7 fw-semibold'>
                                        <KTIcon iconName='time' className='fs-7 me-1' />
                                        {slot.name} &middot; {fmtTime(slot.start_time)} – {fmtTime(slot.end_time)}
                                      </div>
                                    )}
                                    {cls && (
                                      <div className='d-flex align-items-center gap-1 mt-1'>
                                        <KTIcon iconName='people' className='fs-7 text-gray-500' />
                                        <span className='text-gray-600 fw-semibold fs-7'>{cls.label}</span>
                                      </div>
                                    )}
                                  </div>

                                  {/* Right side badge */}
                                  <div className='text-end flex-shrink-0'>
                                    {slot && (
                                      <div className='d-flex flex-column align-items-end gap-1'>
                                        <span className={`badge badge-light-${color} fs-8 fw-bold`}>
                                          {fmtTime(slot.start_time)}
                                        </span>
                                        <span className='text-muted fs-9'>
                                          to {fmtTime(slot.end_time)}
                                        </span>
                                      </div>
                                    )}
                                  </div>

                                </div>
                              </div>
                            </div>
                          )
                        })}
                    </div>
                  )}
                </div>
              </div>
            )}

          </div>
          {/* End card-body */}
        </div>
        {/* End card */}

      </Content>
    </>
  )
}

const TeacherTimetableWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[
      { title: 'Teacher Workspace', path: '/teacher/timetable', isActive: false },
      { title: 'My Timetable', path: '/teacher/timetable', isActive: true },
    ]}>
      My Timetable
    </PageTitle>
    <TeacherTimetablePage />
  </>
)

export { TeacherTimetableWrapper, TeacherTimetablePage }
