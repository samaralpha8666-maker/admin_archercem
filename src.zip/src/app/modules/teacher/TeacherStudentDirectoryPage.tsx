import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import axios from 'axios'
import { KTIcon } from '../../../_metronic/helpers'

const API_URL = import.meta.env.VITE_APP_API_URL

type Section = {
  class_section_id: number
  label: string
  class_name: string
  section_name: string
  is_class_teacher: boolean
}

type Student = {
  id: number
  first_name: string
  last_name: string
  registration_number: string
  phone: string
  email: string
  roll_number: string
  section_label: string
  class_section_id: number
  profile?: {
    profile_image?: string
    dob?: string
    blood_group?: string
    gender?: string
  }
  parent_info?: {
    father_name?: string
    father_phone?: string
    father_occupation?: string
    mother_name?: string
    mother_phone?: string
    mother_occupation?: string
  }
}

// Avatar color based on name
const AVATAR_COLORS = [
  { bg: '#e8e0ff', text: '#5e35b1' },
  { bg: '#d4eeff', text: '#1565c0' },
  { bg: '#d4f5e9', text: '#1b7a4e' },
  { bg: '#fce8ff', text: '#8b1db8' },
  { bg: '#fff3d4', text: '#9a6200' },
  { bg: '#ffd4d4', text: '#c62828' },
  { bg: '#d4ffd4', text: '#2e7d32' },
]
function avatarColor(name: string) {
  let h = 0
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h)
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length]
}

const TeacherStudentDirectoryPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [sections, setSections] = useState<Section[]>([])
  const [students, setStudents] = useState<Student[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [loadingSections, setLoadingSections] = useState(true)
  const [selectedSection, setSelectedSection] = useState('')
  const [search, setSearch] = useState('')
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  useEffect(() => {
    const loadSections = async () => {
      try {
        const res = await axios.get(`${API_URL}/school/${schoolId}/teacher-app/sections`)
        setSections(res.data?.data?.sections || [])
      } catch { } finally {
        setLoadingSections(false)
      }
    }
    loadSections()
  }, [schoolId])

  const fetchStudents = useCallback(async () => {
    setLoading(true)
    try {
      const params: any = { limit: 100 }
      if (selectedSection) params.section_id = selectedSection
      if (search) params.search = search
      const res = await axios.get(`${API_URL}/school/${schoolId}/teacher-app/students/directory`, { params })
      if (res.data.success) {
        setStudents(res.data.data.students || [])
        setTotal(res.data.data.total || 0)
      }
    } catch { } finally {
      setLoading(false)
    }
  }, [schoolId, selectedSection, search])

  useEffect(() => { fetchStudents() }, [fetchStudents])

  const fullName = (s: Student) => `${s.first_name} ${s.last_name}`.trim()
  const handleCall = (phone: string) => window.open(`tel:${phone}`, '_self')

  const hasParentContact = (s: Student) =>
    !!(s.parent_info?.father_phone || s.parent_info?.mother_phone)

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* ── Top Stats Bar ── */}
        <div className='row g-4 mb-6'>
          {[
            { label: 'Total Students', value: total, icon: 'people', color: 'primary' },
            { label: 'Sections Assigned', value: sections.length, icon: 'element-11', color: 'info' },
            { label: 'With Parent Contact', value: students.filter(hasParentContact).length, icon: 'phone', color: 'success' },
          ].map(s => (
            <div className='col-md-4' key={s.label}>
              <div className='card border-0 h-100' style={{ background: `linear-gradient(135deg, #f8f9ff 0%, #fff 100%)` }}>
                <div className='card-body py-5 px-6 d-flex align-items-center gap-4'>
                  <div className={`symbol symbol-50px`}>
                    <div className={`symbol-label bg-light-${s.color}`}>
                      <KTIcon iconName={s.icon} className={`fs-2 text-${s.color}`} />
                    </div>
                  </div>
                  <div>
                    <div className='fs-2hx fw-bold text-gray-900 lh-1'>{s.value}</div>
                    <div className='text-muted fw-semibold fs-7'>{s.label}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* ── Filter Card ── */}
        <div className='card mb-5 border-0 shadow-sm'>
          <div className='card-body py-5 px-7'>
            <div className='d-flex align-items-center justify-content-between flex-wrap gap-4'>
              <div className='d-flex align-items-center gap-3 flex-wrap flex-grow-1'>
                {/* Section Filter */}
                <select
                  className='form-select form-select-solid w-auto'
                  style={{ minWidth: '180px' }}
                  value={selectedSection}
                  onChange={e => setSelectedSection(e.target.value)}
                  disabled={loadingSections}
                >
                  <option value=''>📚 All My Sections</option>
                  {sections.map(s => (
                    <option key={s.class_section_id} value={s.class_section_id}>
                      {s.label} {s.is_class_teacher ? '⭐' : ''}
                    </option>
                  ))}
                </select>

                {/* Search */}
                <div className='d-flex align-items-center position-relative flex-grow-1' style={{ maxWidth: '320px' }}>
                  <KTIcon iconName='magnifier' className='fs-3 position-absolute ms-4 text-muted' />
                  <input
                    type='text'
                    className='form-control form-control-solid ps-13'
                    placeholder='Search by name or reg. no...'
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                  />
                  {search && (
                    <button className='btn btn-icon btn-sm position-absolute end-0 me-1' onClick={() => setSearch('')}>
                      <KTIcon iconName='cross' className='fs-5 text-muted' />
                    </button>
                  )}
                </div>
              </div>

              {/* View Toggle */}
              <div className='btn-group btn-group-sm'>
                <button className={`btn btn-sm ${viewMode === 'grid' ? 'btn-primary' : 'btn-light'}`} onClick={() => setViewMode('grid')}>
                  <KTIcon iconName='element-11' className='fs-5 me-1' />Grid
                </button>
                <button className={`btn btn-sm ${viewMode === 'list' ? 'btn-primary' : 'btn-light'}`} onClick={() => setViewMode('list')}>
                  <KTIcon iconName='row-horizontal' className='fs-5 me-1' />List
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ── Student Display ── */}
        <div className='card border-0 shadow-sm'>
          <div className='card-header border-0 pt-6'>
            <div className='card-title'>
              <h3 className='fw-bolder text-gray-900 mb-0'>
                <KTIcon iconName='people' className='fs-3 me-2 text-primary' />
                Students
              </h3>
            </div>
            <div className='card-toolbar'>
              <span className='badge badge-light-primary fs-7 px-4 py-2'>{total} found</span>
            </div>
          </div>
          <div className='separator separator-dashed my-0' />
          <div className='card-body p-7'>

            {loading ? (
              <div className='d-flex justify-content-center align-items-center py-20'>
                <div className='text-center'>
                  <span className='spinner-border text-primary' style={{ width: '3rem', height: '3rem' }} />
                  <div className='text-muted mt-4 fw-semibold'>Loading students...</div>
                </div>
              </div>
            ) : students.length === 0 ? (
              <div className='d-flex flex-column align-items-center justify-content-center py-20'>
                <KTIcon iconName='people' className='fs-5x text-gray-200 mb-4' />
                <div className='text-muted fw-semibold fs-5'>
                  {search ? `No students found for "${search}"` : 'No students found in your sections'}
                </div>
              </div>
            ) : viewMode === 'grid' ? (
              // ── GRID VIEW ──
              <div className='row g-5'>
                {students.map(student => {
                  const palette = avatarColor(fullName(student))
                  const canCall = hasParentContact(student)
                  return (
                    <div key={student.id} className='col-xl-3 col-lg-4 col-md-6'>
                      <div
                        className='card border h-100 cursor-pointer'
                        style={{ transition: 'all 0.2s ease', borderColor: '#eee' }}
                        onMouseEnter={e => {
                          e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.12)'
                          e.currentTarget.style.transform = 'translateY(-3px)'
                          e.currentTarget.style.borderColor = palette.text + '55'
                        }}
                        onMouseLeave={e => {
                          e.currentTarget.style.boxShadow = ''
                          e.currentTarget.style.transform = ''
                          e.currentTarget.style.borderColor = '#eee'
                        }}
                        onClick={() => setSelectedStudent(student)}
                      >
                        {/* Color band top */}
                        <div style={{ height: '4px', background: palette.text, borderRadius: '8px 8px 0 0' }} />

                        <div className='card-body p-5 text-center'>
                          {/* Avatar */}
                          <div className='symbol symbol-65px symbol-circle mx-auto mb-4'>
                            {student.profile?.profile_image ? (
                              <img src={student.profile.profile_image} alt={fullName(student)} style={{ objectFit: 'cover' }} />
                            ) : (
                              <div className='symbol-label fw-bolder fs-2' style={{ background: palette.bg, color: palette.text }}>
                                {student.first_name?.charAt(0)?.toUpperCase()}
                              </div>
                            )}
                          </div>

                          <div className='fw-bold text-gray-900 fs-6 mb-1'>{fullName(student)}</div>

                          <div className='d-flex align-items-center justify-content-center gap-2 mb-3'>
                            <span className='badge badge-light fs-8'>{student.section_label}</span>
                            {student.roll_number && (
                              <span className='text-muted fs-9'>Roll: {student.roll_number}</span>
                            )}
                          </div>

                          {/* Gender + Blood Group pills */}
                          <div className='d-flex justify-content-center gap-2 mb-4'>
                            {student.profile?.gender && (
                              <span className='badge badge-light-info fs-9 text-capitalize'>{student.profile.gender}</span>
                            )}
                            {student.profile?.blood_group && (
                              <span className='badge badge-light-danger fs-9'>{student.profile.blood_group}</span>
                            )}
                          </div>

                          {/* Call Buttons */}
                          <div className='d-flex justify-content-center gap-2'>
                            {student.parent_info?.father_phone && (
                              <button
                                className='btn btn-sm btn-light-primary d-flex align-items-center gap-1'
                                title={`Father: ${student.parent_info.father_phone}`}
                                onClick={e => { e.stopPropagation(); handleCall(student.parent_info!.father_phone!) }}
                              >
                                <KTIcon iconName='phone' className='fs-6' />
                                <span className='fs-9'>Father</span>
                              </button>
                            )}
                            {student.parent_info?.mother_phone && (
                              <button
                                className='btn btn-sm btn-light-danger d-flex align-items-center gap-1'
                                title={`Mother: ${student.parent_info.mother_phone}`}
                                onClick={e => { e.stopPropagation(); handleCall(student.parent_info!.mother_phone!) }}
                              >
                                <KTIcon iconName='phone' className='fs-6' />
                                <span className='fs-9'>Mother</span>
                              </button>
                            )}
                            {!canCall && (
                              <span className='text-muted fs-9'>No contact</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              // ── LIST VIEW ──
              <div className='table-responsive'>
                <table className='table table-row-dashed table-row-gray-200 align-middle gs-4'>
                  <thead>
                    <tr className='fw-bold fs-8 text-uppercase text-gray-500 bg-light'>
                      <th className='ps-4 py-4'>Student</th>
                      <th>Section</th>
                      <th>Roll No</th>
                      <th>Father</th>
                      <th>Mother</th>
                      <th className='text-end pe-4'>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map(student => {
                      const palette = avatarColor(fullName(student))
                      return (
                        <tr key={student.id} className='cursor-pointer' onClick={() => setSelectedStudent(student)}
                          style={{ transition: 'background 0.15s' }}
                          onMouseEnter={e => e.currentTarget.style.background = '#f8f9fc'}
                          onMouseLeave={e => e.currentTarget.style.background = ''}
                        >
                          <td className='ps-4 py-4'>
                            <div className='d-flex align-items-center gap-3'>
                              <div className='symbol symbol-40px symbol-circle'>
                                {student.profile?.profile_image ? (
                                  <img src={student.profile.profile_image} alt='' style={{ objectFit: 'cover' }} />
                                ) : (
                                  <div className='symbol-label fw-bolder fs-5' style={{ background: palette.bg, color: palette.text }}>
                                    {student.first_name?.charAt(0)?.toUpperCase()}
                                  </div>
                                )}
                              </div>
                              <div>
                                <div className='fw-bold text-gray-900 fs-7'>{fullName(student)}</div>
                                <div className='text-muted fs-9'>{student.registration_number}</div>
                              </div>
                            </div>
                          </td>
                          <td><span className='badge badge-light'>{student.section_label}</span></td>
                          <td className='text-gray-700 fw-semibold'>{student.roll_number || '—'}</td>
                          <td>
                            {student.parent_info?.father_name ? (
                              <div>
                                <div className='fw-semibold text-gray-800 fs-8'>{student.parent_info.father_name}</div>
                                {student.parent_info.father_phone && (
                                  <div className='text-primary fs-9'>{student.parent_info.father_phone}</div>
                                )}
                              </div>
                            ) : <span className='text-muted fs-9'>—</span>}
                          </td>
                          <td>
                            {student.parent_info?.mother_name ? (
                              <div>
                                <div className='fw-semibold text-gray-800 fs-8'>{student.parent_info.mother_name}</div>
                                {student.parent_info.mother_phone && (
                                  <div className='text-danger fs-9'>{student.parent_info.mother_phone}</div>
                                )}
                              </div>
                            ) : <span className='text-muted fs-9'>—</span>}
                          </td>
                          <td className='text-end pe-4'>
                            <div className='d-flex justify-content-end gap-2'>
                              {student.parent_info?.father_phone && (
                                <button className='btn btn-icon btn-sm btn-light-primary' title='Call Father'
                                  onClick={e => { e.stopPropagation(); handleCall(student.parent_info!.father_phone!) }}>
                                  <KTIcon iconName='phone' className='fs-5' />
                                </button>
                              )}
                              {student.parent_info?.mother_phone && (
                                <button className='btn btn-icon btn-sm btn-light-danger' title='Call Mother'
                                  onClick={e => { e.stopPropagation(); handleCall(student.parent_info!.mother_phone!) }}>
                                  <KTIcon iconName='phone' className='fs-5' />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}

          </div>
        </div>

        {/* ── Student Detail Drawer/Modal ── */}
        {selectedStudent && (() => {
          const palette = avatarColor(fullName(selectedStudent))
          return (
            <div className='modal fade show d-block' tabIndex={-1} style={{ backgroundColor: 'rgba(0,0,0,0.45)' }} onClick={() => setSelectedStudent(null)}>
              <div className='modal-dialog modal-dialog-centered' onClick={e => e.stopPropagation()}>
                <div className='modal-content border-0 overflow-hidden' style={{ borderRadius: '16px' }}>

                  {/* Colored header */}
                  <div style={{ background: `linear-gradient(135deg, ${palette.bg} 0%, ${palette.text}22 100%)`, padding: '28px 24px 20px' }}>
                    <div className='d-flex justify-content-between align-items-start'>
                      <div className='d-flex align-items-center gap-4'>
                        <div className='symbol symbol-70px symbol-circle'>
                          {selectedStudent.profile?.profile_image ? (
                            <img src={selectedStudent.profile.profile_image} alt='' style={{ objectFit: 'cover' }} />
                          ) : (
                            <div className='symbol-label fw-bolder fs-1' style={{ background: palette.bg, color: palette.text, border: `3px solid ${palette.text}33` }}>
                              {selectedStudent.first_name?.charAt(0)?.toUpperCase()}
                            </div>
                          )}
                        </div>
                        <div>
                          <h3 className='fw-bold text-gray-900 mb-1'>{fullName(selectedStudent)}</h3>
                          <span className='badge fs-8 px-3' style={{ background: palette.text + '22', color: palette.text }}>{selectedStudent.section_label}</span>
                        </div>
                      </div>
                      <button type='button' className='btn btn-icon btn-sm btn-light' onClick={() => setSelectedStudent(null)}>
                        <KTIcon iconName='cross' className='fs-4' />
                      </button>
                    </div>
                  </div>

                  <div className='modal-body px-7 py-5'>
                    {/* Basic Info Grid */}
                    <div className='row g-4 mb-5'>
                      {[
                        { label: 'Reg. No.', value: selectedStudent.registration_number },
                        { label: 'Roll No.', value: selectedStudent.roll_number },
                        { label: 'Gender', value: selectedStudent.profile?.gender },
                        { label: 'Blood Group', value: selectedStudent.profile?.blood_group },
                        { label: 'Date of Birth', value: selectedStudent.profile?.dob ? new Date(selectedStudent.profile.dob).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : null },
                      ].filter(i => i.value).map(info => (
                        <div className='col-6' key={info.label}>
                          <div className='text-muted fs-9 mb-1'>{info.label}</div>
                          <div className='fw-semibold text-gray-800 text-capitalize fs-7'>{info.value}</div>
                        </div>
                      ))}
                    </div>

                    <div className='separator separator-dashed mb-5' />

                    {/* Contact Section */}
                    <div className='fw-bold text-gray-700 fs-7 mb-4 d-flex align-items-center gap-2'>
                      <KTIcon iconName='phone' className='fs-5 text-primary' /> Parent / Guardian Contacts
                    </div>

                    <div className='d-flex flex-column gap-3'>
                      {selectedStudent.phone && (
                        <div className='d-flex align-items-center justify-content-between rounded p-4' style={{ background: '#f0fdf4' }}>
                          <div className='d-flex align-items-center gap-3'>
                            <div className='symbol symbol-38px'>
                              <div className='symbol-label bg-light-success'><KTIcon iconName='phone' className='fs-4 text-success' /></div>
                            </div>
                            <div>
                              <div className='fs-9 text-muted'>Student</div>
                              <div className='fw-bold text-gray-800'>{selectedStudent.phone}</div>
                            </div>
                          </div>
                          <button className='btn btn-success btn-sm px-5' onClick={() => handleCall(selectedStudent.phone)}>
                            <KTIcon iconName='phone' className='fs-5 me-1' />Call
                          </button>
                        </div>
                      )}
                      {selectedStudent.parent_info?.father_name && (
                        <div className='d-flex align-items-center justify-content-between rounded p-4' style={{ background: '#eff6ff' }}>
                          <div className='d-flex align-items-center gap-3'>
                            <div className='symbol symbol-38px'>
                              <div className='symbol-label bg-light-primary'><KTIcon iconName='profile-user' className='fs-4 text-primary' /></div>
                            </div>
                            <div>
                              <div className='fs-9 text-muted'>Father</div>
                              <div className='fw-bold text-gray-800'>{selectedStudent.parent_info.father_name}</div>
                              {selectedStudent.parent_info.father_phone && (
                                <div className='text-primary fs-8'>{selectedStudent.parent_info.father_phone}</div>
                              )}
                            </div>
                          </div>
                          {selectedStudent.parent_info.father_phone && (
                            <button className='btn btn-primary btn-sm px-5' onClick={() => handleCall(selectedStudent.parent_info!.father_phone!)}>
                              <KTIcon iconName='phone' className='fs-5 me-1' />Call
                            </button>
                          )}
                        </div>
                      )}
                      {selectedStudent.parent_info?.mother_name && (
                        <div className='d-flex align-items-center justify-content-between rounded p-4' style={{ background: '#fff1f2' }}>
                          <div className='d-flex align-items-center gap-3'>
                            <div className='symbol symbol-38px'>
                              <div className='symbol-label bg-light-danger'><KTIcon iconName='heart' className='fs-4 text-danger' /></div>
                            </div>
                            <div>
                              <div className='fs-9 text-muted'>Mother</div>
                              <div className='fw-bold text-gray-800'>{selectedStudent.parent_info.mother_name}</div>
                              {selectedStudent.parent_info.mother_phone && (
                                <div className='text-danger fs-8'>{selectedStudent.parent_info.mother_phone}</div>
                              )}
                            </div>
                          </div>
                          {selectedStudent.parent_info.mother_phone && (
                            <button className='btn btn-danger btn-sm px-5' onClick={() => handleCall(selectedStudent.parent_info!.mother_phone!)}>
                              <KTIcon iconName='phone' className='fs-5 me-1' />Call
                            </button>
                          )}
                        </div>
                      )}
                      {!selectedStudent.phone && !selectedStudent.parent_info?.father_phone && !selectedStudent.parent_info?.mother_phone && (
                        <div className='d-flex flex-column align-items-center py-8'>
                          <KTIcon iconName='phone-slash' className='fs-3x text-gray-200 mb-3' />
                          <div className='text-muted fw-semibold'>No contact information available</div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )
        })()}

      </Content>
    </>
  )
}

const TeacherStudentDirectoryWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[]}>Student Directory</PageTitle>
    <TeacherStudentDirectoryPage />
  </>
)

export { TeacherStudentDirectoryWrapper, TeacherStudentDirectoryPage }
