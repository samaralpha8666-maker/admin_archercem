import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import { getTeacherExamGroups, getTeacherExamResults, getMySections, submitTeacherMarks } from './core/_requests'
import { KTIcon } from '../../../_metronic/helpers'

const TeacherMarksPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [groups, setGroups] = useState<any[]>([])
  const [sections, setSections] = useState<any[]>([])

  const [filterGroup, setFilterGroup] = useState('')
  const [filterSection, setFilterSection] = useState('')
  const [filterExam, setFilterExam] = useState('')

  const [students, setStudents] = useState<any[]>([])
  const [exams, setExams] = useState<any[]>([]) // extracted from subjects data
  
  // marks grid: student_id -> { exam_id -> { marks_obtained, is_absent, remarks } }
  const [marks, setMarks] = useState<Record<number, Record<number, any>>>({})
  
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState<{ type: 'success' | 'danger'; text: string } | null>(null)
  const [loading, setLoading] = useState(false)

  const loadMeta = useCallback(async () => {
    if (!schoolId) return
    try {
      const [gRes, sRes] = await Promise.all([
        getTeacherExamGroups(schoolId),
        getMySections(schoolId)
      ])
      if (gRes.data.success) setGroups(gRes.data.data || [])
      
      // getMySections returns { data: { sections: [...] } } or { data: [...] } depending on the backend
      const secData = sRes.data.data
      const sectionsList = Array.isArray(secData) ? secData : (secData?.sections || [])
      setSections(sectionsList)
    } catch { }
  }, [schoolId])

  useEffect(() => { loadMeta() }, [loadMeta])

  const loadResultsGrid = useCallback(async () => {
    if (!filterGroup || !filterSection) { setStudents([]); setExams([]); return }
    setLoading(true)
    setSaveMsg(null)
    try {
      const { data } = await getTeacherExamResults(schoolId, Number(filterGroup), Number(filterSection))
      if (data.success && data.data && data.data.students && data.data.students.length > 0) {
        setStudents(data.data.students)
        
        // Extract distinct exams from the API response
        if (data.data.exams) {
          setExams(data.data.exams.map((s: any) => ({
            id: s.id,
            name: s.subject_name,
            max_marks: Number(s.max_marks || 0),
            min_marks: Number(s.min_marks || 0)
          })))
        }

        // Initialize state
        const initMarks: Record<number, Record<number, any>> = {}
        data.data.students.forEach((student: any) => {
          initMarks[student.student_id] = {}
          student.subjects?.forEach((sub: any) => {
            initMarks[student.student_id][sub.exam_id] = {
              marks_obtained: sub.marks_obtained != null ? String(sub.marks_obtained) : '',
              is_absent: sub.is_absent || false,
              remarks: sub.remarks || '',
              is_locked: sub.is_locked || false
            }
          })
        })
        setMarks(initMarks)
      } else {
        setStudents([])
        setExams([])
      }
    } catch { 
      setStudents([])
      setExams([])
    } finally { setLoading(false) }
  }, [schoolId, filterGroup, filterSection])

  useEffect(() => { loadResultsGrid() }, [loadResultsGrid])

  const handleMarkChange = (studentId: number, examId: number, field: string, value: any) => {
    setMarks(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [examId]: {
          ...prev[studentId]?.[examId],
          [field]: value
        }
      }
    }))
  }

  const handleSaveAll = async () => {
    if (!filterGroup || !students.length || !exams.length) return
    setSaving(true)
    setSaveMsg(null)

    let totalSaved = 0
    let errors = 0

    // Filter exams if a specific subject is selected
    const examsToSave = filterExam ? exams.filter(e => String(e.id) === filterExam) : exams;

    for (const exam of examsToSave) {
      const payloadResults: any[] = []

      students.forEach(s => {
        const m = marks[s.student_id]?.[exam.id]
        if (!m || m.is_locked) return // Skip locked or missing
        if (m.marks_obtained !== '' || m.is_absent) {
          payloadResults.push({
            student_id: s.student_id,
            marks_obtained: m.is_absent ? 0 : Number(m.marks_obtained || 0),
            is_absent: Boolean(m.is_absent),
            remarks: m.remarks?.trim() || ''
          })
        }
      })

      if (payloadResults.length > 0) {
        try {
          await submitTeacherMarks(schoolId, { exam_id: exam.id, results: payloadResults })
          totalSaved += payloadResults.length
        } catch (e) {
          errors++
        }
      }
    }

    setSaving(false)
    if (errors > 0) {
      setSaveMsg({ type: 'danger', text: `Some marks failed to save. Please try again.` })
    } else if (totalSaved > 0) {
      setSaveMsg({ type: 'success', text: `✓ Marks saved successfully!` })
      loadResultsGrid() // Reload to reflect changes
    } else {
      setSaveMsg({ type: 'danger', text: 'No marks entered to save.' })
    }
  }

  const exportCSV = () => {
    if (!students.length || !exams.length) return
    const filteredExams = exams.filter(exam => filterExam === '' || String(exam.id) === filterExam)
    
    let csvContent = 'Roll No,Student Name,Reg No,'
    csvContent += filteredExams.map(e => `${e.name} (/${e.max_marks})`).join(',')
    if (!filterExam) csvContent += ',Total Obtained,Total Max,Percentage,Status'
    csvContent += '\n'

    students.forEach(s => {
      let row = `${s.roll_number || ''},"${s.full_name || `${s.first_name || ''} ${s.last_name || ''}`.trim()}",${s.registration_number || ''},`
      
      let totalObtained = 0
      let totalMax = 0
      let allPassed = true

      const marksCols = filteredExams.map(exam => {
        const m = marks[s.student_id]?.[exam.id]
        if (!m || m.is_absent) {
          allPassed = false
          return 'AB'
        }
        const val = Number(m.marks_obtained || 0)
        totalObtained += val
        totalMax += exam.max_marks
        if (val < exam.min_marks) allPassed = false
        return val
      })
      
      row += marksCols.join(',')

      if (!filterExam) {
        const pct = totalMax > 0 ? ((totalObtained / totalMax) * 100).toFixed(1) : '0.0'
        const status = allPassed ? 'PASS' : 'FAIL'
        row += `,${totalObtained},${totalMax},${pct}%,${status}`
      }
      
      csvContent += row + '\n'
    })

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `Marksheet_${filterGroup}_Section_${filterSection}.csv`
    link.click()
  }

  const printMarksheet = () => {
    window.print()
  }

  const isReady = filterGroup && filterSection && students.length > 0

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* ── Filters ── */}
        <div className='card card-flush shadow-sm mb-6'>
          <div className='card-header border-0 pt-6 align-items-center flex-wrap gap-4'>
            <h3 className='card-title fw-bold'>My Exams Marks Entry</h3>
            <div className='d-flex gap-3 flex-wrap'>
              <select className='form-select form-select-solid form-select-sm w-200px' value={filterGroup}
                onChange={e => { setFilterGroup(e.target.value); setFilterSection('') }}>
                <option value=''>Select Exam Group</option>
                {groups.map(g => <option key={g.id} value={g.id}>{g.name} ({g.status})</option>)}
              </select>

              <select className='form-select form-select-solid form-select-sm w-200px' value={filterSection}
                disabled={!filterGroup}
                onChange={e => { setFilterSection(e.target.value); setFilterExam('') }}>
                <option value=''>Select Section</option>
                {sections.map((c: any) => (
                  <option key={c.class_section_id || c.section_id || c.id} value={c.class_section_id || c.section_id || c.id}>
                    {c.class_name || c.class?.name} - {c.section_name || c.section?.name}
                  </option>
                ))}
              </select>

              {exams.length > 0 && (
                <select className='form-select form-select-solid form-select-sm w-200px' value={filterExam}
                  onChange={e => setFilterExam(e.target.value)}>
                  <option value=''>All Subjects</option>
                  {exams.map(e => (
                    <option key={e.id} value={e.id}>{e.name}</option>
                  ))}
                </select>
              )}
            </div>
          </div>
        </div>

        {/* ── Empty state ── */}
        {!isReady && !loading ? (
          <div className='card card-flush shadow-sm'>
            <div className='card-body text-center py-16'>
              <KTIcon iconName='pencil' className='fs-5x text-gray-300 mb-4' />
              <p className='text-muted fw-semibold fs-5'>
                Select an Exam Group and Section to enter marks
              </p>
            </div>
          </div>
        ) : loading ? (
          <div className='card card-flush shadow-sm'>
             <div className='card-body text-center py-16'>
                <span className='spinner-border text-primary' />
             </div>
          </div>
        ) : (
          <div className='card card-flush shadow-sm'>
            <div className='card-header border-0 pt-6 align-items-center flex-wrap gap-4'>
              <div>
                <h4 className='fw-bold mb-1'>Marksheet Grid</h4>
                <div className='d-flex gap-3 flex-wrap mt-1'>
                  <span className='badge badge-light-success'>{students.length} Students</span>
                  <span className='badge badge-light-primary'>{exams.length} Subjects</span>
                </div>
              </div>
              <div className='d-flex gap-2'>
                <button className='btn btn-light-success btn-sm' onClick={exportCSV} disabled={!students.length}>
                  <KTIcon iconName='document' className='fs-4 me-1' /> Export CSV
                </button>
                <button className='btn btn-light-info btn-sm' onClick={printMarksheet} disabled={!students.length}>
                  <KTIcon iconName='printer' className='fs-4 me-1' /> Print PDF
                </button>
                <button className='btn btn-primary btn-sm d-print-none' onClick={handleSaveAll} disabled={saving}>
                  {saving ? <><span className='spinner-border spinner-border-sm me-2' />Saving...</> : <><KTIcon iconName='check' className='fs-4 me-1' />Save All Marks</>}
                </button>
              </div>
            </div>

            <div className='card-body pt-4'>
              {saveMsg && (
                <div className={`alert alert-${saveMsg.type} mb-4 fw-semibold d-flex align-items-center gap-3`}>
                  {saveMsg.text}
                  <button className='btn-close ms-auto' onClick={() => setSaveMsg(null)} />
                </div>
              )}
              
              <div className='table-responsive'>
                <table className='table align-middle table-row-dashed fs-6 gy-4'>
                  <thead>
                    <tr className='text-gray-400 fw-bold fs-7 text-uppercase'>
                      <th className='min-w-150px'>Student</th>
                      <th className='min-w-100px'>Roll No.</th>
                      {exams.filter(exam => filterExam === '' || String(exam.id) === filterExam).map(exam => (
                        <th key={exam.id} className='min-w-150px text-center'>
                          {exam.name}
                          <div className='text-muted fw-normal fs-9 text-lowercase'>Max: {exam.max_marks}</div>
                        </th>
                      ))}
                      {!filterExam && (
                        <>
                          <th className='min-w-100px text-center'>Total Marks</th>
                          <th className='min-w-100px text-center'>Percentage</th>
                          <th className='min-w-100px text-center'>Status</th>
                        </>
                      )}
                    </tr>
                  </thead>
                  <tbody className='fw-semibold text-gray-600'>
                    {students.map((s) => (
                      <tr key={s.student_id}>
                        <td>
                          <div className='d-flex align-items-center gap-3'>
                            <div className='symbol symbol-35px'>
                              <div className='symbol-label fw-bolder text-primary bg-light-primary'>
                                {s.first_name?.charAt(0)?.toUpperCase()}
                              </div>
                            </div>
                            <div>
                              <div className='fw-bold text-gray-800'>{s.full_name || `${s.first_name || ''} ${s.last_name || ''}`.trim() || 'Unknown'}</div>
                              {s.registration_number && <div className='fs-9 text-muted'>{s.registration_number}</div>}
                            </div>
                          </div>
                        </td>
                        <td className='text-muted'>{s.roll_number || '—'}</td>
                        
                        {/* Exams columns */}
                        {exams.filter(exam => filterExam === '' || String(exam.id) === filterExam).map(exam => {
                          const m = marks[s.student_id]?.[exam.id] || {}
                          return (
                            <td key={exam.id} className='text-center'>
                              <div className='d-flex align-items-center justify-content-center gap-2'>
                                <input
                                  className='form-control form-control-sm form-control-solid text-center fw-bold w-60px'
                                  type='number'
                                  min='0'
                                  max={exam.max_marks}
                                  value={m.is_absent ? '' : (m.marks_obtained || '')}
                                  disabled={m.is_absent || m.is_locked}
                                  onChange={e => handleMarkChange(s.student_id, exam.id, 'marks_obtained', e.target.value)}
                                />
                                <div className='form-check form-check-custom form-check-solid form-check-sm'>
                                  <input 
                                    className='form-check-input w-15px h-15px' 
                                    type='checkbox' 
                                    checked={m.is_absent || false}
                                    disabled={m.is_locked}
                                    title='Absent'
                                    onChange={e => handleMarkChange(s.student_id, exam.id, 'is_absent', e.target.checked)} 
                                  />
                                </div>
                                {m.is_locked && (
                                <span title='Locked'>
                                  <KTIcon iconName='lock' className='fs-6 text-danger' />
                                </span>
                                )}
                              </div>
                            </td>
                          )
                        })}

                        {/* Totals & Status columns (only in All Subjects view) */}
                        {!filterExam && (() => {
                          let totalObtained = 0
                          let totalMax = 0
                          let allPassed = true
                          let hasAbsent = false

                          exams.forEach(exam => {
                            const m = marks[s.student_id]?.[exam.id]
                            totalMax += exam.max_marks
                            if (!m || m.is_absent) {
                              hasAbsent = true
                              allPassed = false
                            } else {
                              const val = Number(m.marks_obtained || 0)
                              totalObtained += val
                              if (val < exam.min_marks) allPassed = false
                            }
                          })

                          const pct = totalMax > 0 ? ((totalObtained / totalMax) * 100).toFixed(1) : '0.0'
                          
                          return (
                            <>
                              <td className='text-center fw-bold text-gray-800'>
                                {totalObtained} <span className='text-muted fs-8 fw-normal'>/ {totalMax}</span>
                              </td>
                              <td className='text-center'>
                                <span className={`badge badge-light-${Number(pct) >= 60 ? 'success' : Number(pct) >= 33 ? 'warning' : 'danger'}`}>
                                  {pct}%
                                </span>
                              </td>
                              <td className='text-center'>
                                {hasAbsent ? (
                                  <span className='badge badge-light-dark'>INCOMPLETE</span>
                                ) : allPassed ? (
                                  <span className='badge badge-light-success'>PASS</span>
                                ) : (
                                  <span className='badge badge-light-danger'>FAIL</span>
                                )}
                              </td>
                            </>
                          )
                        })()}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div className='card-footer border-0 text-end'>
              <button className='btn btn-primary' onClick={handleSaveAll} disabled={saving}>
                {saving ? <><span className='spinner-border spinner-border-sm me-2' />Saving...</> : 'Save All Marks'}
              </button>
            </div>
          </div>
        )}
      </Content>
    </>
  )
}

const TeacherMarksWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[{ title: 'Teacher Workspace', path: '/teacher/exams', isActive: false }, { title: 'My Exams', path: '/teacher/exams', isActive: true }]}>
      My Exams
    </PageTitle>
    <TeacherMarksPage />
  </>
)

export { TeacherMarksWrapper }
