import React from 'react';

import { LeavePage } from '../../modules/staff/LeavePage';

export const TeacherLeavePage = () => {
  // Reuse the existing staff LeavePage component for teachers.
  // It will fetch leaves based on the logged-in user's role (teacher).
  return (
    <>

      <LeavePage />
    </>
  );
};
