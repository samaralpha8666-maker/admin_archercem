import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { Modal } from 'react-bootstrap'
import { useAuth } from '../auth'
import {
  getStudentDues,
  getInvoices,
  getInvoicePaymentLogs,
  getInvoiceInstallments,
  createInstallmentPlan,
} from './core/_requests'
import { getAcademicSessions, getClasses, getClassSections } from '../academic/core/_requests'
import { getStudents } from '../students/core/_requests'
import { FeeInvoiceModel } from './core/_models'

const STATUS_COLOR: Record<string, string> = {
  UNPAID: 'danger',
  PARTIAL: 'warning',
  PAID: 'success',
  OVERDUE: 'dark',
}

const TrackingPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // ── Meta ──────────────────────────────────────────────────────────────────
  const [sessions, setSessions] = useState<any[]>([])
  const [classes, setClasses] = useState<any[]>([])
  const [students, setStudents] = useState<any[]>([])

  const loadMeta = useCallback(async () => {
    if (!schoolId) return
    try {
      const [sRes, cRes, stRes] = await Promise.all([
        getAcademicSessions(schoolId, 1, 100),
        getClasses(schoolId, 1, 100),
        getStudents(schoolId, { limit: 200 }),
      ])
      if (sRes.data.success) setSessions(sRes.data.data.sessions || [])
      if (cRes.data.success) setClasses(cRes.data.data.classes || [])
      if (stRes.data.success) setStudents(stRes.data.data.students || [])
    } catch { }
  }, [schoolId])

  useEffect(() => {
    loadMeta()
  }, [loadMeta])

  // ── Student Dues Lookup ────────────────────────────────────────────────────
  const [filterStudent, setFilterStudent] = useState('')
  const [filterSession, setFilterSession] = useState('')
  const [dues, setDues] = useState<FeeInvoiceModel[]>([])
  const [duesLoading, setDuesLoading] = useState(false)
  const [duesError, setDuesError] = useState<string | null>(null)
  const [duesSearched, setDuesSearched] = useState(false)

  const searchDues = async () => {
    if (!filterStudent || !filterSession) {
      setDuesError('Please select both a student and a session')
      return
    }
    setDuesLoading(true)
    setDuesError(null)
    setDuesSearched(true)
    try {
      const { data } = await getStudentDues(
        schoolId,
        Number(filterStudent),
        Number(filterSession)
      )
      if (data.success) setDues(Array.isArray(data.data) ? data.data : [])
    } catch (e: any) {
      setDuesError(e.response?.data?.message || 'Failed to fetch dues')
    } finally {
      setDuesLoading(false)
    }
  }

  // ── Invoice Modal ──────────────────────────────────────────────────────────
  const [selectedInvoice, setSelectedInvoice] = useState<FeeInvoiceModel | null>(null)
  const [showInvoiceModal, setShowInvoiceModal] = useState(false)
  const [modalTab, setModalTab] = useState<'BREAKDOWN' | 'LOGS' | 'INSTALLMENTS'>('BREAKDOWN')
  const [paymentLogs, setPaymentLogs] = useState<any[]>([])
  const [installments, setInstallments] = useState<any[]>([])
  const [loadingModalData, setLoadingModalData] = useState(false)
  const [newInstallments, setNewInstallments] = useState<any[]>([])

  const openInvoice = (inv: FeeInvoiceModel) => {
    setSelectedInvoice(inv)
    setModalTab('BREAKDOWN')
    setPaymentLogs([])
    setInstallments([])
    setNewInstallments([])
    setShowInvoiceModal(true)
  }

  const loadModalData = async (tab: typeof modalTab) => {
    if (!selectedInvoice) return
    setModalTab(tab)
    if (tab === 'BREAKDOWN') return
    setLoadingModalData(true)
    try {
      if (tab === 'LOGS') {
        const { data } = await getInvoicePaymentLogs(schoolId, selectedInvoice.id)
        if (data.success) setPaymentLogs(data.data || [])
      } else if (tab === 'INSTALLMENTS') {
        const { data } = await getInvoiceInstallments(schoolId, selectedInvoice.id)
        if (data.success) setInstallments(data.data?.schedule || [])
      }
    } catch { }
    finally {
      setLoadingModalData(false)
    }
  }

  const handleCreateInstallment = async () => {
    if (!selectedInvoice) return
    setLoadingModalData(true)
    try {
      await createInstallmentPlan(schoolId, selectedInvoice.student_id, {
        fee_invoice_id: selectedInvoice.id,
        notes: 'Automated Installment Plan',
        schedule: newInstallments,
      })
      setNewInstallments([])
      await loadModalData('INSTALLMENTS')
    } catch { }
    setLoadingModalData(false)
  }

  // ── All Invoices — Filters ─────────────────────────────────────────────────
  const [invoices, setInvoices] = useState<FeeInvoiceModel[]>([])
  const [invLoading, setInvLoading] = useState(false)
  const [invError, setInvError] = useState<string | null>(null)

  const [invFilterSession, setInvFilterSession] = useState('')
  const [invFilterClass, setInvFilterClass] = useState('')
  const [invFilterSection, setInvFilterSection] = useState('')
  const [invFilterStatus, setInvFilterStatus] = useState('')
  const [invFilterMonth, setInvFilterMonth] = useState('')
  const [invSearch, setInvSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [sections, setSections] = useState<any[]>([])

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(invSearch), 500)
    return () => clearTimeout(t)
  }, [invSearch])

  // Load sections when class changes
  useEffect(() => {
    if (!invFilterClass || !schoolId) {
      setSections([])
      setInvFilterSection('')
      return
    }
    getClassSections(schoolId, Number(invFilterClass))
      .then(res => {
        if (res.data.success) setSections(res.data.data.sections || [])
      })
      .catch(() => setSections([]))
  }, [invFilterClass, schoolId])

  // Load invoices whenever any filter changes
  const loadInvoices = useCallback(async () => {
    if (!schoolId) return
    setInvLoading(true)
    setInvError(null)
    try {
      const params: Record<string, any> = { limit: 200 }
      if (invFilterSession) params.academic_session_id = Number(invFilterSession)
      if (invFilterStatus) params.status = invFilterStatus
      if (invFilterClass) params.class_id = Number(invFilterClass)
      if (invFilterSection) params.section_id = Number(invFilterSection)
      if (invFilterMonth) params.invoice_month = invFilterMonth
      if (debouncedSearch) params.search = debouncedSearch

      const { data } = await getInvoices(schoolId, params)
      if (data.success) setInvoices(Array.isArray(data.data) ? data.data : [])
      else setInvError(data.message || 'Failed to load invoices')
    } catch (e: any) {
      setInvError(e.response?.data?.message || 'Failed to load invoices')
    } finally {
      setInvLoading(false)
    }
  }, [
    schoolId,
    invFilterSession,
    invFilterStatus,
    invFilterClass,
    invFilterSection,
    invFilterMonth,
    debouncedSearch,
  ])

  useEffect(() => {
    loadInvoices()
  }, [loadInvoices])

  const clearFilters = () => {
    setInvFilterSession('')
    setInvFilterClass('')
    setInvFilterSection('')
    setInvFilterStatus('')
    setInvFilterMonth('')
    setInvSearch('')
  }

  const hasActiveFilter =
    invFilterSession || invFilterClass || invFilterSection ||
    invFilterStatus || invFilterMonth || invSearch

  // ── Stats ──────────────────────────────────────────────────────────────────
  const totalPending = invoices
    .filter(i => i.status !== 'PAID')
    .reduce((s, i) => s + Number(i.net_amount) - Number(i.paid_amount), 0)
  const totalPaid = invoices.filter(i => i.status === 'PAID').length
  const unpaidCount = invoices.filter(i => i.status === 'UNPAID').length
  const partialCount = invoices.filter(i => i.status === 'PARTIAL').length

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* ── Stats Cards ── */}
        <div className='row g-5 mb-7'>
          {[
            { label: 'Total Invoices', value: invoices.length, color: 'primary', icon: 'ki-duotone ki-bill' },
            { label: 'Unpaid', value: unpaidCount, color: 'danger', icon: 'ki-duotone ki-cross-circle' },
            { label: 'Partial', value: partialCount, color: 'warning', icon: 'ki-duotone ki-minus-circle' },
            { label: 'Paid Invoices', value: totalPaid, color: 'success', icon: 'ki-duotone ki-check-circle' },
            {
              label: 'Pending Amount',
              value: `₹${totalPending.toLocaleString('en-IN')}`,
              color: 'info',
              icon: 'ki-duotone ki-dollar',
            },
          ].map(({ label, value, color, icon }) => (
            <div className='col-sm-6 col-xl' key={label}>
              <div className={`card card-flush bg-light-${color} border-0 h-100`}>
                <div className='card-body d-flex align-items-center py-5'>
                  <div className={`symbol symbol-45px me-3 bg-${color} bg-opacity-15 rounded-circle`}>
                    <div className='symbol-label d-flex align-items-center justify-content-center'>
                      <i className={`${icon} fs-2 text-${color}`}>
                        <span className='path1' /><span className='path2' />
                      </i>
                    </div>
                  </div>
                  <div>
                    <div className={`fs-3 fw-bolder text-${color}`}>{invLoading ? '—' : value}</div>
                    <div className='text-gray-600 fw-semibold fs-8'>{label}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* ── Student Dues Lookup ── */}
        <div className='card card-flush mb-6 shadow-xs border-0'>
          <div className='card-header border-0 pt-6'>
            <h3 className='card-title fw-bold fs-6'>
              <i className='ki-duotone ki-user-search fs-2 text-danger me-2'>
                <span className='path1' /><span className='path2' /><span className='path3' />
              </i>
              Check Student Pending Dues
            </h3>
          </div>
          <div className='card-body pt-3'>
            <div className='row g-4 align-items-end mb-5'>
              <div className='col-md-4'>
                <label className='fw-semibold fs-7 mb-1 text-gray-600'>Student</label>
                <select
                  className='form-select form-select-solid form-select-sm'
                  value={filterStudent}
                  onChange={e => { setFilterStudent(e.target.value); setDuesSearched(false) }}
                >
                  <option value=''>Select student...</option>
                  {students.map((s: any) => (
                    <option key={s.id} value={s.id}>{s.first_name} {s.last_name}</option>
                  ))}
                </select>
              </div>
              <div className='col-md-4'>
                <label className='fw-semibold fs-7 mb-1 text-gray-600'>Academic Session</label>
                <select
                  className='form-select form-select-solid form-select-sm'
                  value={filterSession}
                  onChange={e => { setFilterSession(e.target.value); setDuesSearched(false) }}
                >
                  <option value=''>Select session...</option>
                  {sessions.map(s => (
                    <option key={s.id} value={s.id}>{s.session_year}{s.is_current ? ' ★' : ''}</option>
                  ))}
                </select>
              </div>
              <div className='col-md-4 d-flex gap-3'>
                <button
                  className='btn btn-danger btn-sm flex-grow-1'
                  onClick={searchDues}
                  disabled={duesLoading}
                >
                  {duesLoading
                    ? <span className='spinner-border spinner-border-sm me-2' />
                    : <i className='ki-duotone ki-magnifier fs-5 me-1'><span className='path1' /><span className='path2' /></i>
                  }
                  View Dues
                </button>
                {duesSearched && (
                  <button
                    className='btn btn-light btn-sm'
                    onClick={() => {
                      setFilterStudent('')
                      setFilterSession('')
                      setDues([])
                      setDuesSearched(false)
                      setDuesError(null)
                    }}
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            {duesError && <div className='alert alert-danger py-3 fw-semibold'>{duesError}</div>}

            {duesSearched && !duesLoading && (
              dues.length === 0 ? (
                <div className='text-center py-10'>
                  <i className='ki-duotone ki-check-circle fs-3x text-success mb-3'>
                    <span className='path1' /><span className='path2' />
                  </i>
                  <p className='text-success fw-bold fs-5 mb-0'>No pending dues! Student is fully paid up. 🎉</p>
                </div>
              ) : (
                <div className='table-responsive'>
                  <table className='table align-middle table-row-dashed fs-7 gy-4'>
                    <thead>
                      <tr className='text-start text-gray-400 fw-bold fs-8 text-uppercase gs-0'>
                        <th>Month</th>
                        <th>Due Date</th>
                        <th>Total</th>
                        <th>Paid</th>
                        <th>Net Due</th>
                        <th>Fine</th>
                        <th>Status</th>
                        <th className='text-end'>Details</th>
                      </tr>
                    </thead>
                    <tbody className='fw-semibold text-gray-600'>
                      {dues.map(inv => (
                        <tr key={inv.id}>
                          <td><span className='fw-bold text-gray-800'>{inv.invoice_month}</span></td>
                          <td className='text-muted'>
                            {inv.due_date ? new Date(inv.due_date).toLocaleDateString('en-IN') : '—'}
                          </td>
                          <td className='fw-bold'>₹{Number(inv.total_amount).toLocaleString('en-IN')}</td>
                          <td className='text-success fw-bold'>₹{Number(inv.paid_amount).toLocaleString('en-IN')}</td>
                          <td className='text-danger fw-bolder'>
                            ₹{(Number(inv.net_amount) - Number(inv.paid_amount)).toLocaleString('en-IN')}
                          </td>
                          <td className='text-warning'>
                            {Number(inv.fine_amount) > 0
                              ? `₹${Number(inv.fine_amount).toLocaleString('en-IN')}`
                              : '—'}
                          </td>
                          <td>
                            <span className={`badge badge-light-${STATUS_COLOR[inv.status] || 'secondary'}`}>
                              {inv.status}
                            </span>
                          </td>
                          <td className='text-end'>
                            <button
                              className='btn btn-sm btn-icon btn-light btn-active-light-primary'
                              onClick={() => openInvoice(inv)}
                              title='View details'
                            >
                              <i className='ki-duotone ki-eye fs-4'>
                                <span className='path1' /><span className='path2' /><span className='path3' />
                              </i>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )
            )}
          </div>
        </div>

        {/* ── All Invoices Table ── */}
        <div className='card card-flush shadow-xs border-0'>
          {/* Filter bar */}
          <div className='card-header align-items-center py-5 gap-3 flex-wrap border-bottom'>
            <div className='card-title flex-grow-1'>
              <div className='d-flex align-items-center position-relative'>
                <i className='ki-duotone ki-magnifier fs-3 position-absolute ms-4'>
                  <span className='path1' /><span className='path2' />
                </i>
                <input
                  type='text'
                  className='form-control form-control-solid w-230px ps-13'
                  placeholder='Search by student name...'
                  value={invSearch}
                  onChange={e => setInvSearch(e.target.value)}
                />
              </div>
            </div>

            <div className='card-toolbar gap-3 flex-wrap'>
              {/* Session */}
              <select
                className='form-select form-select-solid form-select-sm w-auto'
                value={invFilterSession}
                onChange={e => setInvFilterSession(e.target.value)}
              >
                <option value=''>All Sessions</option>
                {sessions.map(s => (
                  <option key={s.id} value={s.id}>{s.session_year}{s.is_current ? ' ★' : ''}</option>
                ))}
              </select>

              {/* Class */}
              <select
                className='form-select form-select-solid form-select-sm w-auto'
                value={invFilterClass}
                onChange={e => {
                  setInvFilterClass(e.target.value)
                  setInvFilterSection('')
                }}
              >
                <option value=''>All Classes</option>
                {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>

              {/* Section — only when class selected */}
              <select
                className='form-select form-select-solid form-select-sm w-auto'
                value={invFilterSection}
                onChange={e => setInvFilterSection(e.target.value)}
                disabled={!invFilterClass}
              >
                <option value=''>All Sections</option>
                {sections.map(s => <option key={s.id} value={s.id}>{s.section?.name || s.name}</option>)}
              </select>

              {/* Status */}
              <select
                className='form-select form-select-solid form-select-sm w-auto'
                value={invFilterStatus}
                onChange={e => setInvFilterStatus(e.target.value)}
              >
                <option value=''>All Status</option>
                {['UNPAID', 'PARTIAL', 'PAID', 'OVERDUE'].map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>

              {/* Month */}
              <select
                className='form-select form-select-solid form-select-sm w-auto'
                value={invFilterMonth}
                onChange={e => setInvFilterMonth(e.target.value)}
              >
                <option value=''>All Months</option>
                {['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'].map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>

              {/* Clear filters button */}
              {hasActiveFilter && (
                <button className='btn btn-sm btn-light-danger fw-bold' onClick={clearFilters}>
                  <i className='bi bi-x-circle me-1'></i>Clear
                </button>
              )}

              {/* Refresh */}
              <button
                className='btn btn-sm btn-light fw-bold'
                onClick={loadInvoices}
                disabled={invLoading}
              >
                <i className={`bi bi-arrow-clockwise me-1 ${invLoading ? 'spin' : ''}`}></i>
                Refresh
              </button>
            </div>
          </div>

          <div className='card-body pt-0'>
            {invError && <div className='alert alert-danger mb-4 mt-4 fw-semibold'>{invError}</div>}

            <div className='table-responsive'>
              <table className='table align-middle table-row-dashed fs-6 gy-5'>
                <thead>
                  <tr className='text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0'>
                    <th className='ps-3'>#</th>
                    <th>Student</th>
                    <th>Month</th>
                    <th>Total</th>
                    <th>Concession</th>
                    <th>Net</th>
                    <th>Paid</th>
                    <th>Balance</th>
                    <th>Status</th>
                    <th className='text-end pe-3'>Action</th>
                  </tr>
                </thead>
                <tbody className='fw-semibold text-gray-600'>
                  {invLoading ? (
                    <tr>
                      <td colSpan={10} className='text-center py-12'>
                        <div className='spinner-border text-primary mb-2'></div>
                        <div className='text-muted fw-semibold fs-7'>Loading invoices...</div>
                      </td>
                    </tr>
                  ) : invoices.length === 0 ? (
                    <tr>
                      <td colSpan={10} className='text-center py-14'>
                        <div className='d-flex flex-column align-items-center'>
                          <i className='ki-duotone ki-bill fs-3x text-gray-300 mb-3'>
                            <span className='path1' /><span className='path2' />
                          </i>
                          <span className='text-gray-500 fw-semibold'>
                            {hasActiveFilter ? 'No invoices match your filters.' : 'No invoices found. Generate invoices first.'}
                          </span>
                          {hasActiveFilter && (
                            <button className='btn btn-sm btn-light-primary mt-3' onClick={clearFilters}>
                              Clear Filters
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ) : (
                    invoices.map((inv, i) => {
                      const balance = Number(inv.net_amount) - Number(inv.paid_amount)
                      return (
                        <tr key={inv.id}>
                          <td className='ps-3'>
                            <span className='text-muted fw-semibold'>{i + 1}</span>
                          </td>
                          <td>
                            <div className='d-flex align-items-center'>
                              <div className='symbol symbol-40px me-3'>
                                {inv.student?.profile?.profile_image ? (
                                  <img
                                    src={inv.student.profile.profile_image}
                                    alt={inv.student.first_name}
                                    className='symbol-label'
                                    style={{ objectFit: 'cover', borderRadius: '50%' }}
                                  />
                                ) : (
                                  <div className='symbol-label fs-5 fw-bold text-primary bg-light-primary'>
                                    {inv.student?.first_name?.charAt(0)?.toUpperCase() || '?'}
                                  </div>
                                )}
                              </div>
                              <div className='d-flex flex-column'>
                                <span className='fw-bold text-gray-800'>
                                  {inv.student
                                    ? `${inv.student.first_name} ${inv.student.last_name || ''}`.trim()
                                    : `Student #${inv.student_id}`}
                                </span>
                                {inv.student && (
                                  <div className='fs-8 text-muted fw-semibold d-flex flex-wrap gap-3 mt-1'>
                                    {inv.student.registration_number && (
                                      <span>
                                        <span className='text-gray-400'>Reg: </span>
                                        {inv.student.registration_number}
                                      </span>
                                    )}
                                    {inv.student.enrollments?.[0]?.roll_number && (
                                      <span>
                                        <span className='text-gray-400'>Roll: </span>
                                        {inv.student.enrollments[0].roll_number}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>

                          <td>
                            <span className='badge badge-light-primary fw-bold'>{inv.invoice_month}</span>
                          </td>
                          <td className='fw-bold'>₹{Number(inv.total_amount).toLocaleString('en-IN')}</td>
                          <td className='text-info fw-bold'>
                            ₹{Number(inv.concession_amount).toLocaleString('en-IN')}
                          </td>
                          <td className='text-dark fw-bold'>₹{Number(inv.net_amount).toLocaleString('en-IN')}</td>
                          <td className='text-success fw-bold'>₹{Number(inv.paid_amount).toLocaleString('en-IN')}</td>
                          <td>
                            <span className={`fw-bolder ${balance > 0 ? 'text-danger' : 'text-success'}`}>
                              ₹{balance.toLocaleString('en-IN')}
                            </span>
                          </td>
                          <td>
                            <span className={`badge badge-light-${STATUS_COLOR[inv.status] || 'secondary'}`}>
                              {inv.status}
                            </span>
                          </td>
                          <td className='text-end pe-3'>
                            <button
                              className='btn btn-sm btn-icon btn-light btn-active-light-primary'
                              onClick={() => openInvoice(inv)}
                              title='View breakdown'
                            >
                              <i className='ki-duotone ki-eye fs-4'>
                                <span className='path1' /><span className='path2' /><span className='path3' />
                              </i>
                            </button>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>

                {/* Footer totals row */}
                {!invLoading && invoices.length > 0 && (
                  <tfoot>
                    <tr className='fw-bold text-gray-700 border-top' style={{ background: '#f5f7fa' }}>
                      <td colSpan={3} className='ps-3 py-4 text-muted fs-7'>
                        {invoices.length} invoice{invoices.length !== 1 ? 's' : ''}
                      </td>
                      <td className='fw-bolder'>
                        ₹{invoices.reduce((s, i) => s + Number(i.total_amount), 0).toLocaleString('en-IN')}
                      </td>
                      <td className='text-info fw-bolder'>
                        ₹{invoices.reduce((s, i) => s + Number(i.concession_amount), 0).toLocaleString('en-IN')}
                      </td>
                      <td className='fw-bolder'>
                        ₹{invoices.reduce((s, i) => s + Number(i.net_amount), 0).toLocaleString('en-IN')}
                      </td>
                      <td className='text-success fw-bolder'>
                        ₹{invoices.reduce((s, i) => s + Number(i.paid_amount), 0).toLocaleString('en-IN')}
                      </td>
                      <td className='text-danger fw-bolder'>
                        ₹{invoices
                          .reduce((s, i) => s + (Number(i.net_amount) - Number(i.paid_amount)), 0)
                          .toLocaleString('en-IN')}
                      </td>
                      <td colSpan={2}></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      </Content>

      {/* ── Invoice Detail Modal ── */}
      <Modal
        show={showInvoiceModal}
        onHide={() => setShowInvoiceModal(false)}
        centered
        size='lg'
      >
        <Modal.Header closeButton className='border-0 pb-0'>
          <Modal.Title className='fs-5 fw-bolder'>
            <i className='ki-duotone ki-bill fs-2 text-primary me-2'>
              <span className='path1' /><span className='path2' />
            </i>
            Invoice — {selectedInvoice?.invoice_month}
            {selectedInvoice && (
              <span className={`badge badge-light-${STATUS_COLOR[selectedInvoice.status] || 'secondary'} ms-3 fs-8`}>
                {selectedInvoice.status}
              </span>
            )}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body className='py-4 px-8'>
          {selectedInvoice && (
            <>
              {/* Tabs */}
              <ul className='nav nav-tabs nav-line-tabs mb-6 fs-6 border-bottom'>
                {(['BREAKDOWN', 'LOGS', 'INSTALLMENTS'] as const).map(tab => (
                  <li className='nav-item' key={tab}>
                    <a
                      className={`nav-link fw-bolder cursor-pointer pb-3 ${modalTab === tab ? 'active text-primary' : 'text-gray-500'}`}
                      onClick={() => loadModalData(tab)}
                    >
                      {tab === 'BREAKDOWN' && '📋 Fee Breakdown'}
                      {tab === 'LOGS' && '📜 Payment Logs'}
                      {tab === 'INSTALLMENTS' && '📅 Installment Plan'}
                    </a>
                  </li>
                ))}
              </ul>

              {loadingModalData ? (
                <div className='text-center py-12'>
                  <span className='spinner-border text-primary'></span>
                </div>
              ) : (
                <>
                  {/* ── BREAKDOWN TAB ── */}
                  {modalTab === 'BREAKDOWN' && (
                    <>
                      <div className='row g-4 mb-5'>
                        {[
                          { label: 'Total Amount', value: Number(selectedInvoice.total_amount), color: 'primary' },
                          { label: 'Concession', value: Number(selectedInvoice.concession_amount), color: 'info' },
                          { label: 'Fine', value: Number(selectedInvoice.fine_amount), color: 'warning' },
                          { label: 'Amount Paid', value: Number(selectedInvoice.paid_amount), color: 'success' },
                        ].map(({ label, value, color }) => (
                          <div key={label} className='col-sm-6 col-md-3'>
                            <div className={`bg-light-${color} rounded-2 p-4 text-center`}>
                              <div className={`fw-bolder text-${color} fs-4`}>
                                ₹{value.toLocaleString('en-IN')}
                              </div>
                              <div className='text-muted fs-8 fw-semibold mt-1'>{label}</div>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className='d-flex align-items-center justify-content-between bg-light-danger rounded-2 px-5 py-4 mb-6'>
                        <span className='fw-bold text-gray-700 fs-6'>Net Balance Due</span>
                        <span className='fw-bolder text-danger fs-3'>
                          ₹{(Number(selectedInvoice.net_amount) - Number(selectedInvoice.paid_amount)).toLocaleString('en-IN')}
                        </span>
                      </div>

                      <div className='fw-bold text-gray-700 mb-3 fs-7 text-uppercase'>Fee Breakdown by Category</div>
                      {selectedInvoice.items && selectedInvoice.items.length > 0 ? (
                        selectedInvoice.items.map(item => (
                          <div
                            key={item.id}
                            className='d-flex align-items-center justify-content-between bg-light rounded-2 px-5 py-3 mb-2'
                          >
                            <div>
                              <span className='fw-semibold text-gray-800'>
                                {item.fee_category?.name || `Category #${item.fee_category_id}`}
                              </span>
                              {item.fee_category?.description && (
                                <div className='text-muted fs-8'>{item.fee_category.description}</div>
                              )}
                            </div>
                            <span className='fw-bolder text-primary fs-5'>
                              ₹{Number(item.amount).toLocaleString('en-IN')}
                            </span>
                          </div>
                        ))
                      ) : (
                        <div className='text-muted text-center py-6 fs-7'>No breakdown items available</div>
                      )}
                    </>
                  )}

                  {/* ── LOGS TAB ── */}
                  {modalTab === 'LOGS' && (
                    paymentLogs.length === 0 ? (
                      <div className='text-center py-12'>
                        <i className='bi bi-receipt text-gray-300' style={{ fontSize: '3rem' }}></i>
                        <p className='text-muted fw-semibold mt-3'>No payment history found for this invoice.</p>
                      </div>
                    ) : (
                      <div className='table-responsive'>
                        <table className='table table-row-bordered align-middle fs-7'>
                          <thead>
                            <tr className='fw-bold text-gray-500 text-uppercase fs-8'>
                              <th>Date</th>
                              <th>Mode</th>
                              <th>Reference</th>
                              <th className='text-end'>Amount Applied</th>
                            </tr>
                          </thead>
                          <tbody>
                            {paymentLogs.map((log: any, idx) => (
                              <tr key={idx}>
                                <td>
                                  {new Date(log.payment?.payment_date || log.createdAt).toLocaleDateString('en-IN')}
                                </td>
                                <td>
                                  <span className='badge badge-light-primary'>
                                    {log.payment?.payment_mode || 'System'}
                                  </span>
                                </td>
                                <td className='text-muted'>{log.payment?.transaction_id || '—'}</td>
                                <td className='text-end text-success fw-bolder'>
                                  ₹{Number(log.amount_applied).toLocaleString('en-IN')}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                          <tfoot>
                            <tr className='fw-bolder border-top'>
                              <td colSpan={3} className='text-end text-gray-700'>Total Applied</td>
                              <td className='text-end text-success'>
                                ₹{paymentLogs
                                  .reduce((s: number, l: any) => s + Number(l.amount_applied), 0)
                                  .toLocaleString('en-IN')}
                              </td>
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                    )
                  )}

                  {/* ── INSTALLMENTS TAB ── */}
                  {modalTab === 'INSTALLMENTS' && (
                    installments.length > 0 ? (
                      <div className='table-responsive'>
                        <table className='table table-row-bordered align-middle fs-7'>
                          <thead>
                            <tr className='fw-bold text-gray-500 text-uppercase fs-8'>
                              <th>Installment</th>
                              <th>Due Date</th>
                              <th className='text-end'>Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            {installments.map((inst: any) => (
                              <tr key={inst.installment_no}>
                                <td className='fw-semibold'>Installment #{inst.installment_no}</td>
                                <td>{new Date(inst.due_date).toLocaleDateString('en-IN')}</td>
                                <td className='text-end fw-bolder text-primary'>
                                  ₹{Number(inst.amount).toLocaleString('en-IN')}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div>
                        <div className='alert alert-light-warning mb-5 py-4 fw-semibold'>
                          No Installment Plan found. You can split the remaining amount (
                          <strong>
                            ₹{(Number(selectedInvoice.net_amount) - Number(selectedInvoice.paid_amount)).toLocaleString('en-IN')}
                          </strong>
                          ) into multiple dues.
                        </div>

                        <div className='mb-4'>
                          <button
                            className='btn btn-sm btn-light-primary fw-bold'
                            onClick={() =>
                              setNewInstallments([
                                ...newInstallments,
                                { installment_no: newInstallments.length + 1, due_date: '', amount: 0 },
                              ])
                            }
                          >
                            <i className='bi bi-plus-circle me-1'></i>Add Installment
                          </button>
                        </div>

                        {newInstallments.map((ni, idx) => (
                          <div key={idx} className='row mb-3 align-items-center g-3'>
                            <div className='col-2'>
                              <span className='badge badge-light-primary fw-bold'>#{ni.installment_no}</span>
                            </div>
                            <div className='col-4'>
                              <input
                                type='date'
                                className='form-control form-control-sm form-control-solid'
                                value={ni.due_date}
                                onChange={e => {
                                  const arr = [...newInstallments]
                                  arr[idx].due_date = e.target.value
                                  setNewInstallments(arr)
                                }}
                              />
                            </div>
                            <div className='col-4'>
                              <input
                                type='number'
                                className='form-control form-control-sm form-control-solid'
                                placeholder='Amount (₹)'
                                value={ni.amount || ''}
                                onChange={e => {
                                  const arr = [...newInstallments]
                                  arr[idx].amount = Number(e.target.value)
                                  setNewInstallments(arr)
                                }}
                              />
                            </div>
                            <div className='col-2'>
                              <button
                                className='btn btn-icon btn-sm btn-light-danger'
                                onClick={() => setNewInstallments(newInstallments.filter((_, i) => i !== idx))}
                              >
                                <i className='bi bi-trash'></i>
                              </button>
                            </div>
                          </div>
                        ))}

                        {newInstallments.length > 0 && (
                          <div className='mt-5 text-end'>
                            <button
                              className='btn btn-primary btn-sm fw-bold px-6'
                              onClick={handleCreateInstallment}
                              disabled={loadingModalData}
                            >
                              {loadingModalData
                                ? <><span className='spinner-border spinner-border-sm me-2'></span>Saving...</>
                                : <><i className='bi bi-check2-circle me-2'></i>Save Plan</>
                              }
                            </button>
                          </div>
                        )}
                      </div>
                    )
                  )}
                </>
              )}
            </>
          )}
        </Modal.Body>

        <Modal.Footer className='border-0 pt-0'>
          <button className='btn btn-light fw-bold' onClick={() => setShowInvoiceModal(false)}>
            Close
          </button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

const TrackingWrapper: FC = () => (
  <>
    <PageTitle
      breadcrumbs={[
        { title: 'Fees', path: '/fees/tracking', isActive: false },
        { title: 'Payment Tracking', path: '/fees/tracking', isActive: true },
      ]}
    >
      Payment Tracking
    </PageTitle>
    <TrackingPage />
  </>
)

export { TrackingWrapper }