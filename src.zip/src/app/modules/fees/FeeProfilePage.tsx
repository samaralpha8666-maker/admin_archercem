import React, { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import { getAcademicSessions, getClasses, getClassSections } from '../academic/core/_requests'
import { getEnrollments } from '../students/core/_requests'
import { getFeeProfile, saveFeeProfile } from './core/_requests'

const FeeProfilePage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // ── Meta
  const [sessions, setSessions] = useState<any[]>([])
  const [classes, setClasses] = useState<any[]>([])
  const [sections, setSections] = useState<any[]>([])
  const [enrollments, setEnrollments] = useState<any[]>([])

  const [selSession, setSelSession] = useState('')
  const [selClass, setSelClass] = useState('')
  const [selSection, setSelSection] = useState('')
  const [selStudent, setSelStudent] = useState('')

  const [loadingMeta, setLoadingMeta] = useState(false)
  const [loadingEnroll, setLoadingEnroll] = useState(false)

  // ── Profile Form
  const [loadingProfile, setLoadingProfile] = useState(false)
  const [savingProfile, setSavingProfile] = useState(false)
  const [profileMsg, setProfileMsg] = useState<{ type: 'success' | 'danger', text: string } | null>(null)

  const [form, setForm] = useState({
    is_hostel_student: false,
    hostel_room_type: '',
    is_transport_user: false,
    transport_fee_amount: '',
    is_scholarship_holder: false,
    notes: ''
  })

  // Init Meta
  const loadMeta = useCallback(async () => {
    if (!schoolId) return
    setLoadingMeta(true)
    try {
      const [sRes, cRes] = await Promise.all([
        getAcademicSessions(schoolId, 1, 100),
        getClasses(schoolId, 1, 100),
      ])
      const sess = sRes.data.success ? (sRes.data.data.sessions || []) : []
      setSessions(sess)
      if (cRes.data.success) setClasses(cRes.data.data.classes || [])
      const cur = sess.find((s: any) => s.is_current)
      if (cur) setSelSession(String(cur.id))
    } catch { }
    finally { setLoadingMeta(false) }
  }, [schoolId])

  useEffect(() => { loadMeta() }, [loadMeta])

  // Drill downs
  const handleClassChange = async (classId: string) => {
    setSelClass(classId); setSelSection(''); setSelStudent('')
    setSections([]); setEnrollments([])
    setProfileMsg(null)
    if (!classId) return
    try {
      const { data } = await getClassSections(schoolId, classId)
      if (data.success) setSections(data.data.sections || [])
    } catch { }
  }

  const handleSectionChange = async (sectionId: string) => {
    setSelSection(sectionId); setSelStudent('')
    setEnrollments([])
    setProfileMsg(null)
    if (!sectionId || !selSession) return
    setLoadingEnroll(true)
    try {
      const { data } = await getEnrollments(schoolId, {
        class_section_id: Number(sectionId),
        session_id: Number(selSession),
        status: 'Active', limit: 200,
      })
      if (data.success) setEnrollments(data.data.enrollments || [])
    } catch { }
    finally { setLoadingEnroll(false) }
  }

  const handleStudentChange = async (enrollId: string) => {
    setSelStudent(enrollId)
    setProfileMsg(null)
    if (!enrollId) return
    
    const enrol = enrollments.find(e => String(e.id) === enrollId)
    if (!enrol) return

    setLoadingProfile(true)
    try {
      const { data } = await getFeeProfile(schoolId, enrol.student_id, Number(selSession))
      if (data.success && data.data) {
        setForm({
          is_hostel_student: data.data.is_hostel_student || false,
          hostel_room_type: data.data.hostel_room_type || '',
          is_transport_user: data.data.is_transport_user || false,
          transport_fee_amount: data.data.transport_fee_amount !== null && data.data.transport_fee_amount !== undefined ? String(data.data.transport_fee_amount) : '',
          is_scholarship_holder: data.data.is_scholarship_holder || false,
          notes: data.data.notes || ''
        })
      } else {
        setForm({ is_hostel_student: false, hostel_room_type: '', is_transport_user: false, transport_fee_amount: '', is_scholarship_holder: false, notes: '' })
      }
    } catch (e) {
      setForm({ is_hostel_student: false, hostel_room_type: '', is_transport_user: false, transport_fee_amount: '', is_scholarship_holder: false, notes: '' })
    } finally {
      setLoadingProfile(false)
    }
  }

  const handleSave = async () => {
    const enrol = enrollments.find(e => String(e.id) === selStudent)
    if (!enrol || !selSession) return

    setSavingProfile(true); setProfileMsg(null)
    try {
      const { data } = await saveFeeProfile(schoolId, enrol.student_id, {
        ...form,
        transport_fee_amount: form.transport_fee_amount ? Number(form.transport_fee_amount) : null,
        academic_session_id: Number(selSession)
      })
      if (data.success) {
        setProfileMsg({ type: 'success', text: 'Fee profile saved successfully.' })
      } else {
        setProfileMsg({ type: 'danger', text: data.message || 'Failed to save fee profile.' })
      }
    } catch (e: any) {
      setProfileMsg({ type: 'danger', text: e.response?.data?.message || 'Failed to save fee profile.' })
    } finally {
      setSavingProfile(false)
    }
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* ── Filter Bar ── */}
        <div className='card card-flush shadow-xs mb-6 border-0'>
          <div className='card-body py-4'>
            <div className='row g-3 align-items-end'>
              <div className='col-lg-3 col-md-6'>
                <label className='fw-bold fs-8 text-uppercase text-muted mb-1 d-block'>Session</label>
                <select className='form-select form-select-sm form-select-solid'
                  value={selSession}
                  onChange={e => { setSelSession(e.target.value); setSelClass(''); setSelSection(''); setSelStudent(''); setProfileMsg(null) }}>
                  <option value=''>Select session...</option>
                  {sessions.map(s => <option key={s.id} value={s.id}>{s.session_year}{s.is_current ? ' ★' : ''}</option>)}
                </select>
              </div>
              <div className='col-lg-2 col-md-3'>
                <label className='fw-bold fs-8 text-uppercase text-muted mb-1 d-block'>Class</label>
                <select className='form-select form-select-sm form-select-solid'
                  value={selClass} onChange={e => handleClassChange(e.target.value)} disabled={!selSession}>
                  <option value=''>Select class...</option>
                  {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className='col-lg-2 col-md-3'>
                <label className='fw-bold fs-8 text-uppercase text-muted mb-1 d-block'>Section</label>
                <select className='form-select form-select-sm form-select-solid'
                  value={selSection} onChange={e => handleSectionChange(e.target.value)} disabled={!selClass}>
                  <option value=''>Select section...</option>
                  {sections.map(cs => <option key={cs.id} value={cs.id}>{cs.section?.name}</option>)}
                </select>
              </div>
              <div className='col'>
                <label className='fw-bold fs-8 text-uppercase text-muted mb-1 d-block'>Student</label>
                <select className='form-select form-select-sm form-select-solid'
                  value={selStudent} onChange={e => handleStudentChange(e.target.value)} disabled={!selSection || loadingEnroll}>
                  <option value=''>{loadingEnroll ? 'Loading students...' : 'Select student...'}</option>
                  {enrollments.map(e => (
                    <option key={e.id} value={e.id}>
                      {e.roll_number ? `[${e.roll_number}] ` : ''}{e.student?.first_name} {e.student?.last_name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* ── Empty state ── */}
        {!selStudent && !loadingMeta && (
           <div className='card card-flush border-0 shadow-xs'>
             <div className='card-body py-20 text-center'>
               <i className='ki-duotone ki-user-edit text-gray-300' style={{ fontSize: '5rem' }}>
                 <span className='path1'></span><span className='path2'></span><span className='path3'></span>
               </i>
               <h5 className='fw-bold text-gray-600 mt-4 mb-1'>Select a Student</h5>
               <p className='text-muted fs-7'>Choose student to manage their Hostel, Transport and Scholarship Profile.</p>
             </div>
           </div>
        )}

        {/* ── Profile Editor ── */}
        {selStudent && (
          <div className='card card-flush'>
            <div className='card-header pt-7'>
              <h3 className='card-title align-items-start flex-column'>
                <span className='card-label fw-bold text-gray-800'>Fee Profile Editor</span>
                <span className='text-gray-400 mt-1 fw-semibold fs-7'>Update exceptional fee statuses</span>
              </h3>
            </div>
            <div className='card-body'>
              {loadingProfile ? (
                 <div className='text-center py-10'>
                    <div className='spinner-border text-primary'></div>
                    <div className='text-muted mt-3'>Loading profile...</div>
                 </div>
              ) : (
                <div className='row g-8'>
                  <div className='col-lg-6'>
                    
                    {profileMsg && (
                      <div className={`alert alert-${profileMsg.type} p-4 mb-6 fs-7`}>
                        {profileMsg.text}
                      </div>
                    )}

                    <div className='mb-7'>
                      <label className='form-check form-switch form-check-custom form-check-solid'>
                        <input className='form-check-input w-40px h-20px' type='checkbox' 
                          checked={form.is_hostel_student} 
                          onChange={e => setForm(p => ({ ...p, is_hostel_student: e.target.checked }))} />
                        <span className='form-check-label fw-bold text-gray-700 fs-6 ms-3'>Hostel Student</span>
                      </label>
                      <div className='text-muted fs-8 mt-2 ms-13'>Enables hostel fee grouping in yearly matrix.</div>
                    </div>

                    {form.is_hostel_student && (
                      <div className='mb-7 ms-13'>
                        <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Room Type</label>
                        <select className='form-select form-select-solid' 
                           value={form.hostel_room_type} 
                           onChange={e => setForm(p => ({ ...p, hostel_room_type: e.target.value }))}>
                           <option value=''>Select Room Type...</option>
                           <option value='SINGLE'>Single</option>
                           <option value='DOUBLE'>Double</option>
                           <option value='DORMITORY'>Dormitory</option>
                        </select>
                      </div>
                    )}

                    <div className='mb-7'>
                      <label className='form-check form-switch form-check-custom form-check-solid'>
                        <input className='form-check-input w-40px h-20px' type='checkbox' 
                          checked={form.is_transport_user} 
                          onChange={e => setForm(p => ({ ...p, is_transport_user: e.target.checked, transport_fee_amount: e.target.checked ? p.transport_fee_amount : '' }))} />
                        <span className='form-check-label fw-bold text-gray-700 fs-6 ms-3'>Transport User</span>
                      </label>
                      <div className='text-muted fs-8 mt-2 ms-13'>Enables transport fee grouping.</div>
                    </div>

                    {form.is_transport_user && (
                      <div className='mb-7 ms-13'>
                        <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Custom Transport Fee Amount (₹)</label>
                        <input 
                          type='number' 
                          className='form-control form-control-solid' 
                          placeholder='Leave blank to use default route/class fee...'
                          value={form.transport_fee_amount} 
                          onChange={e => setForm(p => ({ ...p, transport_fee_amount: e.target.value }))} 
                        />
                        <div className='text-muted fs-8 mt-1'>If set, this amount will override the default transport fee in invoices and matrices.</div>
                      </div>
                    )}

                    <div className='mb-7'>
                      <label className='form-check form-switch form-check-custom form-check-solid'>
                        <input className='form-check-input w-40px h-20px' type='checkbox' 
                          checked={form.is_scholarship_holder} 
                          onChange={e => setForm(p => ({ ...p, is_scholarship_holder: e.target.checked }))} />
                        <span className='form-check-label fw-bold text-gray-700 fs-6 ms-3'>Scholarship Holder</span>
                      </label>
                      <div className='text-muted fs-8 mt-2 ms-13'>Marks student as priority for fee concessions.</div>
                    </div>

                    <div className='mb-7'>
                      <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Notes / Remarks</label>
                      <textarea className='form-control form-control-solid' rows={3}
                        placeholder='Any internal notes regarding fee status...'
                        value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))}></textarea>
                    </div>

                    <div className='mt-8'>
                      <button className='btn btn-primary' onClick={handleSave} disabled={savingProfile}>
                        {savingProfile ? <span className='spinner-border spinner-border-sm me-2'></span> : <i className='ki-duotone ki-save-2 fs-4 me-2'><span className='path1'/><span className='path2'/></i>}
                        Save Profile
                      </button>
                    </div>

                  </div>

                  <div className='col-lg-6'>
                    <div className='bg-light-info rounded p-6'>
                       <h4 className='fw-bold text-info mb-4'>Profile Impact</h4>
                       <ul className='text-gray-700 fs-6 fw-semibold lh-lg'>
                         <li><strong>Hostel:</strong> Modifying hostel status acts as a trigger to dynamically include or remove hostel fee generation in the next invoice cycle.</li>
                         <li><strong>Transport:</strong> Identifies if transport nodes and bus assignments are linked to their fee profile structure.</li>
                         <li><strong>Scholarship:</strong> Highlights the profile during report generation and prompts the user to add applicable concessions during fee collection.</li>
                       </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </Content>
    </>
  )
}

const FeeProfileWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[
      { title: 'Fees', path: '/fees/profile', isActive: false },
      { title: 'Student Fee Profile', path: '/fees/profile', isActive: true },
    ]}>
      Student Fee Profile
    </PageTitle>
    <FeeProfilePage />
  </>
)

export { FeeProfileWrapper }
