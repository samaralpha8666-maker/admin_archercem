import { FC, useState, useEffect, useCallback, useMemo } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import clsx from 'clsx'
import { Modal } from 'react-bootstrap'
import { useAuth } from '../auth'
import { collectPayment, getYearlyMatrix, getInvoiceById, updateInvoice, getStudentPaymentHistory, getFeeProfile } from './core/_requests'
import { FeeInvoiceModel } from './core/_models'
import { getAcademicSessions, getClasses, getClassSections } from '../academic/core/_requests'
import { getEnrollments, getStudentById } from '../students/core/_requests'
import { YearlyMatrixResponse, YearlyMatrixItem } from './core/_models'
import { StudentEnrollmentModel } from '../students/core/_models'

// ─── Render helper: Annual / One-time rows ─────────────────────────────────────
function AnnualRows({
  items,
  selectedAnnualCats,
  toggleAnnualCat,
  tableCols,
  invoiceRemainingMap,
  allMatrixMonths,
}: {
  items: YearlyMatrixItem[]
  selectedAnnualCats: number[]
  toggleAnnualCat: (id: number) => void
  tableCols: string[]
  invoiceRemainingMap: Record<number, number>
  allMatrixMonths: string[]
}) {
  return (
    <>
      {items.map(item => {
        const isSelected = selectedAnnualCats.includes(item.category_id)
        // Check if already fully paid in any applicable month
        const isFullyPaid = Object.values(item.months).some(cell =>
          cell.applicable && (cell.status === 'PAID' || (cell.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
        )
        const colCount = tableCols.length + 1 // item col + month cols

        // Find the active remaining amount for the annual/one-time item using allMatrixMonths
        let cellRemaining = item.total
        let isPartiallyPaid = false
        for (const m of allMatrixMonths) {
          const cell = item.months[m]
          if (cell?.applicable) {
            cellRemaining = (cell.remaining_amount !== undefined && cell.remaining_amount >= 0)
              ? cell.remaining_amount
              : (cell.amount || item.total || 0)
            isPartiallyPaid = cellRemaining < item.total && cellRemaining > 0
            break
          }
        }

        return (
          <tr key={item.category_id} className='border-bottom border-gray-100'>
            <td className='ps-4 py-3' style={{ minWidth: 160 }}>
              <div className='fw-bold text-gray-800 d-flex align-items-center gap-2 flex-wrap'>
                {item.category_name}
                <span className='badge badge-light-warning px-2 py-1' style={{ fontSize: '0.6rem' }}>
                  {item.frequency === 'ONE_TIME' ? 'One-Time' : item.frequency === 'PER_SEMESTER' ? 'Per Semester' : 'Annual'}
                </span>
              </div>
            </td>
            {tableCols.length > 0 ? (
              tableCols.map((m, idx) => {
                const cell = item.months[m]
                const applicable = cell?.applicable && cell.amount > 0
                if (!applicable) return <td key={m} className='text-center py-3'><span className='text-gray-300'>—</span></td>
                // Only show checkbox in first applicable column
                const isFirstApplicable = tableCols.slice(0, idx).every(prev => !item.months[prev]?.applicable)
                if (!isFirstApplicable) return <td key={m} className='text-center py-3'><span className='text-gray-300'>—</span></td>
                return (
                  <td key={m} className='text-center py-3'>
                    <label className='d-inline-flex align-items-center gap-2 cursor-pointer p-2 rounded border border-gray-100 shadow-xs'
                      onClick={() => !isFullyPaid && toggleAnnualCat(item.category_id)}>
                      <input type='checkbox' className='form-check-input h-15px w-15px mt-0 cursor-pointer'
                        checked={isSelected || isFullyPaid} disabled={isFullyPaid} readOnly />
                      <span className={clsx('fw-bolder', isFullyPaid ? 'text-success text-decoration-line-through' : isSelected ? 'text-primary' : 'text-gray-700')}>
                        ₹{cellRemaining.toLocaleString('en-IN')}
                      </span>
                      {isPartiallyPaid && (
                        <span className='text-muted fs-8 ms-1 fw-normal'>
                          (Dues of ₹{item.total.toLocaleString('en-IN')})
                        </span>
                      )}
                      {isFullyPaid && <span className='badge badge-light-success px-2 ms-1' style={{ fontSize: '0.6rem' }}>PAID</span>}
                    </label>
                  </td>
                )
              })
            ) : (
              // No months selected — show annual item spanning a single wide cell
              <td className='py-3 ps-4'>
                <label className='d-inline-flex align-items-center gap-2 cursor-pointer p-2 rounded border border-gray-100 shadow-xs'
                  onClick={() => !isFullyPaid && toggleAnnualCat(item.category_id)}>
                  <input type='checkbox' className='form-check-input h-15px w-15px mt-0 cursor-pointer'
                    checked={isSelected || isFullyPaid} disabled={isFullyPaid} readOnly />
                  <span className={clsx('fw-bolder', isFullyPaid ? 'text-success text-decoration-line-through' : isSelected ? 'text-primary' : 'text-gray-700')}>
                    ₹{cellRemaining.toLocaleString('en-IN')}
                  </span>
                  {isPartiallyPaid && (
                    <span className='text-muted fs-8 ms-1 fw-normal'>
                      (Dues of ₹{item.total.toLocaleString('en-IN')})
                    </span>
                  )}
                  {isFullyPaid && <span className='badge badge-light-success px-2 ms-1' style={{ fontSize: '0.6rem' }}>PAID</span>}
                </label>
              </td>
            )}
          </tr>
        )
      })}
    </>
  )
}

// ─── Render helper: Monthly rows ───────────────────────────────────────────────
function MonthlyRows({
  items,
  tableCols,
  checkedCells,
  toggleMonthlyCell,
  invoiceRemainingMap,
}: {
  items: YearlyMatrixItem[]
  tableCols: string[]
  checkedCells: Record<string, boolean>
  toggleMonthlyCell: (id: number, m: string) => void
  invoiceRemainingMap: Record<number, number>
}) {
  return (
    <>
      {items.map(item => (
        <tr key={item.category_id} className='border-bottom border-gray-100'>
          <td className='ps-4 py-3' style={{ minWidth: 160 }}>
            <div className='fw-bold text-gray-700'>{item.category_name}</div>
          </td>
          {tableCols.map(m => {
            const cell = item.months[m]
            const isApplicable = cell?.applicable
            const isPaid = Boolean(cell?.status === 'PAID' || (cell?.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
            const amt = cell?.amount || 0
            const isChecked = !!checkedCells[`${item.category_id}__${m}`]

            return (
              <td key={m} className='text-center py-3'>
                {isApplicable ? (
                  <label
                    className='d-inline-flex align-items-center gap-1 cursor-pointer p-1 rounded'
                    onClick={() => !isPaid && toggleMonthlyCell(item.category_id, m)}
                  >
                    <input
                      type='checkbox'
                      className={clsx('form-check-input h-15px w-15px mt-0', isPaid ? 'border-success' : 'border-gray-400')}
                      checked={isChecked || isPaid}
                      onChange={() => { }}
                      readOnly
                      disabled={isPaid}
                    />
                    <span className={clsx('fw-bold ms-1 fs-8',
                      isPaid ? 'text-success text-decoration-line-through opacity-75' :
                        isChecked ? 'text-primary' : 'text-gray-600'
                    )}>
                      {amt > 0 ? `₹${amt}` : '—'}
                    </span>
                  </label>
                ) : (
                  <span className='text-gray-300 fw-semibold fs-8'>—</span>
                )}
              </td>
            )
          })}
        </tr>
      ))}
    </>
  )
}

// ─── Main Component ───────────────────────────────────────────────────────────
const FeeCollectionPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // Filters
  const [sessions, setSessions] = useState<any[]>([])
  const [classes, setClasses] = useState<any[]>([])
  const [sections, setSections] = useState<any[]>([])
  const [enrollments, setEnrollments] = useState<StudentEnrollmentModel[]>([])

  const [selSession, setSelSession] = useState('')
  const [selClass, setSelClass] = useState('')
  const [selSection, setSelSection] = useState('')
  const [selStudent, setSelStudent] = useState('')

  const [loadingMeta, setLoadingMeta] = useState(false)
  const [loadingEnroll, setLoadingEnroll] = useState(false)
  const [loadingMatrix, setLoadingMatrix] = useState(false)
  const [matrixError, setMatrixError] = useState<string | null>(null)

  // Student data
  const [studentDetail, setStudentDetail] = useState<any | null>(null)
  const [enrolDetail, setEnrolDetail] = useState<StudentEnrollmentModel | null>(null)

  // Yearly matrix from API
  const [yearlyMatrix, setYearlyMatrix] = useState<YearlyMatrixResponse | null>(null)
  const [oldBalance, setOldBalance] = useState(0)

  // Payment history from API
  const [paymentHistory, setPaymentHistory] = useState<any | null>(null)
  const [feeProfile, setFeeProfile] = useState<any | null>(null)

  // Selection
  const [selectedMonths, setSelectedMonths] = useState<string[]>([])
  const [manualAmountInput, setManualAmountInput] = useState<string>('')
  const [checkedCells, setCheckedCells] = useState<Record<string, boolean>>({})
  const [selectedAnnualCats, setSelectedAnnualCats] = useState<number[]>([])

  // Payment Mode Selection
  const [collectionMode, setCollectionMode] = useState<'MANUAL' | 'AUTO'>('MANUAL')
  const [autoAmount, setAutoAmount] = useState<string>('')
  const [invoiceRemainingMap, setInvoiceRemainingMap] = useState<Record<number, number>>({})

  // Payment form
  const [additionalFee, setAdditionalFee] = useState(0)
  const [concessionPct, setConcessionPct] = useState(0)
  const [paymentMode, setPaymentMode] = useState('Cash')
  const [bankName, setBankName] = useState('')
  const [chequeNo, setChequeNo] = useState('')
  const [chequeDate, setChequeDate] = useState('')
  const [referenceNo, setReferenceNo] = useState('')
  const [remark, setRemark] = useState('')
  const [sendSMS, setSendSMS] = useState(true)
  const [sendWhatsApp, setSendWhatsApp] = useState(true)

  // Submit
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState<string | null>(null)
  const [showModal, setShowModal] = useState(false)
  const [lastReceipt, setLastReceipt] = useState<any | null>(null)

  // ── Invoice Edit Modal (Fine / Concession per invoice) ──────────────────────
  const [invoiceModalOpen, setInvoiceModalOpen] = useState(false)
  const [invoiceModalMonth, setInvoiceModalMonth] = useState('')
  const [invoiceDetail, setInvoiceDetail] = useState<FeeInvoiceModel | null>(null)
  const [invoiceLoading, setInvoiceLoading] = useState(false)
  const [editFine, setEditFine] = useState<number>(0)
  const [editConcession, setEditConcession] = useState<number>(0)
  const [editConcessionPct, setEditConcessionPct] = useState<number>(0)
  const [savingInvoice, setSavingInvoice] = useState(false)
  const [invoiceSaveMsg, setInvoiceSaveMsg] = useState<string | null>(null)

  // Load sessions + classes on mount
  const loadMeta = useCallback(async () => {
    if (!schoolId) return
    setLoadingMeta(true)
    try {
      const [sRes, cRes] = await Promise.all([
        getAcademicSessions(schoolId, 1, 100),
        getClasses(schoolId, 1, 100),
      ])
      const sess = sRes.data.success ? (sRes.data.data.sessions || []) : []
      setSessions(sess)
      if (cRes.data.success) setClasses(cRes.data.data.classes || [])
      const cur = sess.find((s: any) => s.is_current)
      if (cur) setSelSession(String(cur.id))
    } catch { }
    finally { setLoadingMeta(false) }
  }, [schoolId])

  useEffect(() => { loadMeta() }, [loadMeta])

  const handleClassChange = async (classId: string) => {
    setSelClass(classId); setSelSection(''); setSelStudent('')
    setSections([]); setEnrollments([])
    resetAll()
    if (!classId) return
    try {
      const { data } = await getClassSections(schoolId, classId)
      if (data.success) setSections(data.data.sections || [])
    } catch { }
  }

  const handleSectionChange = async (sectionId: string) => {
    setSelSection(sectionId); setSelStudent('')
    setEnrollments([])
    resetAll()
    if (!sectionId || !selSession) return
    setLoadingEnroll(true)
    try {
      const { data } = await getEnrollments(schoolId, {
        class_section_id: Number(sectionId),
        session_id: Number(selSession),
        status: 'Active', limit: 200,
      })
      if (data.success) setEnrollments(data.data.enrollments || [])
    } catch { }
    finally { setLoadingEnroll(false) }
  }

  const handleStudentChange = async (enrollId: string) => {
    setSelStudent(enrollId)
    resetAll()
    if (!enrollId) return
    const enrol = enrollments.find(e => String(e.id) === enrollId)
    if (!enrol) return
    setEnrolDetail(enrol)
    setLoadingMatrix(true)
    try {
      const [profileRes, matrixRes, histRes, feeProfileRes] = await Promise.all([
        getStudentById(schoolId, enrol.student_id),
        getYearlyMatrix(schoolId, enrol.student_id, Number(selSession)),
        getStudentPaymentHistory(schoolId, enrol.student_id, Number(selSession)),
        getFeeProfile(schoolId, enrol.student_id, Number(selSession)),
      ])
      if (profileRes.data.success) setStudentDetail(profileRes.data.data.student)
      if (matrixRes.data.success) setYearlyMatrix(matrixRes.data.data)
      if (feeProfileRes.data.success) setFeeProfile(feeProfileRes.data.data)
      if (histRes.data.success) {
        const hist = histRes.data.data
        setPaymentHistory(hist)
        // Remaining dues = old balance from matrix (only past sessions)
        setOldBalance(Number(matrixRes.data.data.old_balance?.total) || 0)

        // Build invoice remaining map from payment history
        const remainMap: Record<number, number> = {}
        for (const inv of hist.invoices || []) {
          remainMap[inv.invoice_id] = Number(inv.remaining_amount) || 0
        }
        setInvoiceRemainingMap(remainMap)
      }
    } catch (e: any) {
      setMatrixError(e.response?.data?.message || 'Failed to load fee matrix')
    } finally { setLoadingMatrix(false) }
  }

  const resetAll = () => {
    setStudentDetail(null); setEnrolDetail(null); setYearlyMatrix(null)
    setPaymentHistory(null); setOldBalance(0); setInvoiceRemainingMap({})
    setFeeProfile(null)
    setMatrixError(null); setSelectedMonths([]); setCheckedCells({})
    setSelectedAnnualCats([])
    setCollectionMode('MANUAL'); setAutoAmount('')
    setAdditionalFee(0); setConcessionPct(0)
    setSubmitError(null); setBankName(''); setChequeNo(''); setChequeDate('')
    setReferenceNo(''); setRemark('')
  }

  // ── Open Invoice Edit Modal: GET /invoices/:id ──────────────────────────────
  const openInvoiceEdit = async (month: string) => {
    // Find the invoice_id for this month from yearlyMatrix
    // We look across all items for the first non-null invoice_id for this month
    let invoiceId: number | null = null
    for (const item of yearlyMatrix?.items || []) {
      const cell = item.months[month]
      if (cell?.invoice_id) { invoiceId = cell.invoice_id; break }
    }
    if (!invoiceId) {
      // Invoice not yet generated — cannot edit fine/concession yet
      setInvoiceModalMonth(month)
      setInvoiceDetail(null)
      setEditFine(0); setEditConcession(0)
      setEditConcessionPct(0)
      setInvoiceSaveMsg('Invoice not yet generated for this month. Generate invoices first.')
      setInvoiceModalOpen(true)
      return
    }
    setInvoiceModalMonth(month)
    setInvoiceLoading(true)
    setInvoiceModalOpen(true)
    setInvoiceSaveMsg(null)
    try {
      const { data } = await getInvoiceById(schoolId, invoiceId)
      if (data.success) {
        setInvoiceDetail(data.data)
        setEditFine(Number(data.data.fine_amount) || 0)
        setEditConcession(Number(data.data.concession_amount) || 0)
        // Calculate % from loaded values
        const base = Number(data.data.total_amount || 0) + (Number(data.data.fine_amount) || 0)
        const concAmt = Number(data.data.concession_amount) || 0
        setEditConcessionPct(base > 0 ? Math.round((concAmt / base) * 100) : 0)
      }
    } catch (e: any) {
      setInvoiceSaveMsg(e.response?.data?.message || 'Failed to load invoice.')
    } finally { setInvoiceLoading(false) }
  }

  // ── Save Invoice Fine/Concession: PUT /invoices/:id ─────────────────────────
  const saveInvoiceEdit = async () => {
    if (!invoiceDetail) return
    setSavingInvoice(true); setInvoiceSaveMsg(null)
    try {
      const { data } = await updateInvoice(schoolId, invoiceDetail.id, {
        fine_amount: editFine,
        concession_amount: editConcession,
      })
      if (data.success) {
        setInvoiceSaveMsg('✓ Saved! Fine & Concession updated successfully.')
        setInvoiceDetail(data.data)
        // Refresh the matrix and payment history so totals reflect updated net_amount
        if (enrolDetail) {
          const [matrixRes, histRes] = await Promise.all([
            getYearlyMatrix(schoolId, enrolDetail.student_id, Number(selSession)),
            getStudentPaymentHistory(schoolId, enrolDetail.student_id, Number(selSession))
          ])

          if (matrixRes.data.success) setYearlyMatrix(matrixRes.data.data)

          if (histRes.data.success) {
            const hist = histRes.data.data
            setPaymentHistory(hist)
            const remainMap: Record<number, number> = {}
            for (const inv of hist.invoices || []) {
              remainMap[inv.invoice_id] = Number(inv.remaining_amount) || 0
            }
            setInvoiceRemainingMap(remainMap)
          }
        }
      } else {
        setInvoiceSaveMsg(data.message || 'Update failed.')
      }
    } catch (e: any) {
      setInvoiceSaveMsg(e.response?.data?.message || 'Update failed.')
    } finally { setSavingInvoice(false) }
  }

  // Categorize matrix items
  // MONTHLY + QUARTERLY + SEMESTER + HALF_YEARLY use per-month applicable flags → go into the monthly grid
  // ANNUALLY + ONE_TIME → go into the annual/one-time section
  const monthlyItems = useMemo((): YearlyMatrixItem[] =>
    yearlyMatrix?.items.filter(i => i.frequency !== 'ONE_TIME' && i.frequency !== 'ANNUALLY' && i.frequency !== 'PER_SEMESTER') || []
    , [yearlyMatrix])

  const annualItems = useMemo((): YearlyMatrixItem[] =>
    yearlyMatrix?.items.filter(i => i.frequency === 'ONE_TIME' || i.frequency === 'ANNUALLY' || i.frequency === 'PER_SEMESTER') || []
    , [yearlyMatrix])

  const ALL_MATRIX_MONTHS = yearlyMatrix?.months || []
  const MATRIX_MONTHS = ALL_MATRIX_MONTHS.filter(m => {
    if (!yearlyMatrix) return false;
    return yearlyMatrix.items.some(item => item.months[m]?.applicable)
  })

  // Month aggregate status (based on both monthly and annual/one-time items)
  const getMonthAggregateStatus = (m: string) => {
    if (!yearlyMatrix) return 'none'
    let totalApplicable = 0
    let paidCount = 0
    for (const item of yearlyMatrix.items) {
      const cell = item.months[m]
      if (cell && cell.applicable) {
        totalApplicable++
        const isPaid = Boolean(cell.status === 'PAID' || (cell.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
        if (isPaid) paidCount++
      }
    }
    if (totalApplicable === 0) return 'none'
    if (paidCount === totalApplicable) return 'paid'
    return 'pending'
  }

  const getMonthPendingAmount = (m: string) => {
    if (!yearlyMatrix) return 0
    // Get all invoice_ids for this month
    const invoiceIds = new Set<number>()
    for (const item of yearlyMatrix.items) {
      const cell = item.months[m]
      if (cell?.applicable && cell.invoice_id) {
        const isPaid = Boolean(cell.status === 'PAID' || invoiceRemainingMap[cell.invoice_id] === 0)
        if (!isPaid) invoiceIds.add(cell.invoice_id)
      }
    }
    // Sum remaining amounts from payment history map
    let total = 0
    for (const invId of invoiceIds) {
      total += invoiceRemainingMap[invId] ??
        // fallback: sum cell amounts if map not loaded
        yearlyMatrix.items.reduce((s, item) => {
          const cell = item.months[m]
          const isPaid = Boolean(cell?.status === 'PAID' || (cell?.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
          return (cell?.invoice_id === invId && cell.applicable && !isPaid)
            ? s + cell.amount : s
        }, 0)
    }
    return total
  }

  // Toggle individual month pill
  const toggleMonth = (m: string) => {
    const status = getMonthAggregateStatus(m)
    if (status === 'none' || status === 'paid') return

    // Pre-check: Don't allow selecting an ungenerated month
    if (!selectedMonths.includes(m)) {
      const isUngenerated = yearlyMatrix?.items.some(item => {
        const cell = item.months[m]
        if (cell && cell.applicable) {
          const isPaid = Boolean(cell.status === 'PAID' || (cell.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
          return !isPaid && !cell.invoice_id
        }
        return false
      })
      if (isUngenerated) {
        alert("⚠️ INVOICE NOT GENERATED!\n\nThis month's fee has not been invoiced yet.\nPlease generate the invoice properly before collecting fee.")
        return
      }
    }

    setSelectedMonths(prev => {
      if (prev.includes(m)) {
        setCheckedCells(c => {
          const next = { ...c }
          monthlyItems.forEach(item => { delete next[`${item.category_id}__${m}`] })
          return next
        })
        return prev.filter(x => x !== m)
      } else {
        setCheckedCells(c => {
          const next = { ...c }
          monthlyItems.forEach(item => {
            const cell = item.months[m]
            if (cell && cell.applicable) {
              const isPaid = Boolean(cell.status === 'PAID' || (cell.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
              if (!isPaid) {
                next[`${item.category_id}__${m}`] = true
              }
            }
          })
          return next
        })
        return [...prev, m]
      }
    })
  }

  const toggleAllPendingMonths = () => {
    const pending = MATRIX_MONTHS.filter(m => getMonthAggregateStatus(m) === 'pending')
    if (selectedMonths.length === pending.length) {
      setSelectedMonths([])
      setCheckedCells({})
    } else {
      // Pre-check for any ungenerated invoices in pending months
      const isUngenerated = pending.some(m => {
        return monthlyItems.some(item => {
          const cell = item.months[m]
          if (cell && cell.applicable) {
            const isPaid = Boolean(cell.status === 'PAID' || (cell.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
            return !isPaid && !cell.invoice_id
          }
          return false
        })
      })
      if (isUngenerated) {
        alert("⚠️ INVOICE NOT GENERATED!\n\nSome pending months have not been invoiced yet.\nPlease generate the invoice properly before collecting fee.")
        return
      }
      setSelectedMonths(pending)
      const next: Record<string, boolean> = {}
      pending.forEach(m => {
        monthlyItems.forEach(item => {
          const cell = item.months[m]
          if (cell && cell.applicable) {
            const isPaid = Boolean(cell.status === 'PAID' || (cell.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
            if (!isPaid) {
              next[`${item.category_id}__${m}`] = true
            }
          }
        })
      })
      setCheckedCells(next)
    }
  }

  const toggleMonthlyCell = (categoryId: number, m: string) => {
    const item = monthlyItems.find(i => i.category_id === categoryId)
    const cell = item?.months[m]
    if (!cell || !cell.applicable) return
    const isPaid = Boolean(cell.status === 'PAID' || (cell.invoice_id && invoiceRemainingMap[cell.invoice_id] === 0))
    if (isPaid) return

    const key = `${categoryId}__${m}`
    if (!checkedCells[key] && !cell.invoice_id) {
      alert("⚠️ INVOICE NOT GENERATED!\n\nThis fee has not been invoiced yet.\nPlease generate the invoice properly before collecting fee.")
      return
    }
    setCheckedCells(prev => {
      const next = { ...prev }
      if (next[key]) {
        delete next[key]
        const monthStillHasChecked = monthlyItems.some(i => next[`${i.category_id}__${m}`])
        if (!monthStillHasChecked) setSelectedMonths(p => p.filter(x => x !== m))
      } else {
        next[key] = true
        if (!selectedMonths.includes(m)) setSelectedMonths(p => [...p, m])
      }
      return next
    })
  }

  const toggleAnnualCat = (categoryId: number) => {
    if (!selectedAnnualCats.includes(categoryId)) {
      const item = annualItems.find(i => i.category_id === categoryId)
      if (item) {
        let hasInvoice = false
        for (const m of MATRIX_MONTHS) {
          const cell = item.months[m]
          if (cell?.applicable && cell.invoice_id) {
            hasInvoice = true
            break
          }
        }
        if (!hasInvoice) {
          alert("⚠️ INVOICE NOT GENERATED!\n\nThis annual fee has not been invoiced yet.\nPlease generate the invoice properly before collecting fee.")
          return
        }
      }
    }

    setSelectedAnnualCats(prev =>
      prev.includes(categoryId) ? prev.filter(x => x !== categoryId) : [...prev, categoryId]
    )
  }

  // Totals calculation
  const totals = useMemo(() => {
    if (collectionMode === 'AUTO') {
      const amt = Number(autoAmount) || 0
      return {
        monthlySubtotal: 0, annualSubtotal: 0, subtotal: 0, totalFee: 0,
        concessionAmt: 0, netFee: 0, totalReceivable: amt,
        invoiceFine: 0, invoiceConcession: 0
      }
    }

    let monthlySubtotal = 0
    monthlyItems.forEach(item => {
      MATRIX_MONTHS.forEach(m => {
        if (checkedCells[`${item.category_id}__${m}`]) {
          const cell = item.months[m]
          if (cell) {
            const cellRemaining = (cell.remaining_amount !== undefined && cell.remaining_amount >= 0)
              ? cell.remaining_amount
              : (cell.amount || 0)
            monthlySubtotal += cellRemaining
          }
        }
      })
    })

    let annualSubtotal = 0
    annualItems.forEach(item => {
      if (selectedAnnualCats.includes(item.category_id)) {
        for (const m of MATRIX_MONTHS) {
          const cell = item.months[m]
          if (cell?.applicable) {
            const cellRemaining = (cell.remaining_amount !== undefined && cell.remaining_amount >= 0)
              ? cell.remaining_amount
              : (cell.amount || item.total || 0)
            annualSubtotal += cellRemaining
            break
          }
        }
      }
    })

    // ── Collect all selected invoice_ids ──────────────────────────────────────
    const allSelectedInvoiceIds = new Set<number>()
    monthlyItems.forEach(item => {
      MATRIX_MONTHS.forEach(m => {
        if (checkedCells[`${item.category_id}__${m}`]) {
          const cell = item.months[m]
          if (cell?.invoice_id) allSelectedInvoiceIds.add(cell.invoice_id)
        }
      })
    })
    annualItems.forEach(item => {
      if (selectedAnnualCats.includes(item.category_id)) {
        for (const m of MATRIX_MONTHS) {
          const cell = item.months[m]
          if (cell?.applicable && cell.invoice_id) {
            allSelectedInvoiceIds.add(cell.invoice_id)
            break
          }
        }
      }
    })

    // ── Sum fine + concession from paymentHistory for selected invoices ────────
    let invoiceFine = 0
    let invoiceConcession = 0
    for (const inv of paymentHistory?.invoices || []) {
      if (allSelectedInvoiceIds.has(inv.invoice_id)) {
        invoiceFine += Number(inv.fine_amount || 0)
        invoiceConcession += Number(inv.concession_amount || 0)
      }
    }

    const subtotal = monthlySubtotal + annualSubtotal
    const totalFee = subtotal + additionalFee
    const concessionAmt = (totalFee * concessionPct) / 100
    // Add invoiceFine and subtract invoiceConcession properly to compute netFee
    const netFee = Math.max(0, totalFee + invoiceFine - invoiceConcession - concessionAmt)
    const totalReceivable = netFee + oldBalance

    return {
      monthlySubtotal, annualSubtotal, subtotal, totalFee, concessionAmt, netFee,
      totalReceivable, invoiceFine, invoiceConcession
    }
  }, [checkedCells, monthlyItems, selectedAnnualCats, annualItems, MATRIX_MONTHS,
    additionalFee, concessionPct, oldBalance, collectionMode, autoAmount,
    invoiceRemainingMap, paymentHistory])

  useEffect(() => {
    setManualAmountInput('')
  }, [totals.totalReceivable])

  const finalAmountToReceive = manualAmountInput !== '' ? Number(manualAmountInput) : totals.totalReceivable;
  const newBalanceCalculation = Math.max(0, totals.totalReceivable - finalAmountToReceive);

  const getMonthColTotal = (m: string): number => {
    let sum = 0
    monthlyItems.forEach(item => {
      if (checkedCells[`${item.category_id}__${m}`]) {
        const cell = item.months[m]
        if (cell) {
          const cellRemaining = (cell.remaining_amount !== undefined && cell.remaining_amount >= 0)
            ? cell.remaining_amount
            : (cell.amount || 0)
          sum += cellRemaining
        }
      }
    })
    return sum
  }

  const anySelected = selectedMonths.length > 0 || selectedAnnualCats.length > 0

  const handleSubmit = async () => {
    if (!enrolDetail || !selSession) return
    if (totals.totalReceivable <= 0) { setSubmitError('No fee selected.'); return }
    setSubmitting(true); setSubmitError(null)

    // ── Build invoice_payments from checked cells + selected annual items ────────────
    // Each invoice may have multiple fee items (e.g. Tuition + Transport in May).
    // We group by invoice_id and sum amount_applied.
    const checkedAmountsByInvoice = new Map<number, number>()

    // 1. Monthly / Quarterly checked cells
    monthlyItems.forEach(item => {
      MATRIX_MONTHS.forEach(m => {
        if (checkedCells[`${item.category_id}__${m}`]) {
          const cell = item.months[m]
          if (cell && cell.invoice_id) {
            const cellRemaining = (cell.remaining_amount !== undefined && cell.remaining_amount >= 0)
              ? cell.remaining_amount
              : (cell.amount || 0)
            const prev = checkedAmountsByInvoice.get(cell.invoice_id) || 0
            checkedAmountsByInvoice.set(cell.invoice_id, prev + cellRemaining)
          }
        }
      })
    })

    // 2. Annual / One-time selected items
    annualItems.forEach(item => {
      if (selectedAnnualCats.includes(item.category_id)) {
        // Find the applicable month cell to get the invoice_id
        for (const m of MATRIX_MONTHS) {
          const cell = item.months[m]
          if (cell?.applicable && cell.invoice_id) {
            const cellRemaining = (cell.remaining_amount !== undefined && cell.remaining_amount >= 0)
              ? cell.remaining_amount
              : (cell.amount || item.total || 0)
            const prev = checkedAmountsByInvoice.get(cell.invoice_id) || 0
            checkedAmountsByInvoice.set(cell.invoice_id, prev + cellRemaining)
            break
          }
        }
      }
    })

    const invoiceMap = new Map<number, number>()
    checkedAmountsByInvoice.forEach((checkedSum, invoiceId) => {
      const inv = paymentHistory?.invoices?.find((i: any) => i.invoice_id === invoiceId)
      if (inv) {
        const rawSubtotal = inv.items?.reduce((sum: number, item: any) => sum + Number(item.amount || 0), 0) || 0
        const remaining = invoiceRemainingMap[invoiceId] !== undefined ? invoiceRemainingMap[invoiceId] : (Number(inv.remaining_amount) || 0)
        
        if (rawSubtotal > 0 && checkedSum < rawSubtotal - 0.1) {
          const ratio = checkedSum / rawSubtotal
          invoiceMap.set(invoiceId, Number((remaining * ratio).toFixed(2)))
        } else {
          invoiceMap.set(invoiceId, remaining)
        }
      } else {
        invoiceMap.set(invoiceId, checkedSum)
      }
    })

    // Distribute finalAmountToReceive sequentially across the selected invoices
    let remainingToDistribute = finalAmountToReceive;
    const invoice_payments: any[] = [];

    for (const [invoice_id, amount] of invoiceMap.entries()) {
      if (remainingToDistribute <= 0) break;
      const applyAmt = Math.min(amount, remainingToDistribute);
      invoice_payments.push({ invoice_id, amount_applied: applyAmt });
      remainingToDistribute -= applyAmt;
    }

    if (invoice_payments.length === 0) {
      setSubmitError('No valid invoices found for selected items. Generate invoices first.')
      setSubmitting(false)
      return
    }

    // ── Build notes string ────────────────────────────────────────────────
    const monthStrs = selectedMonths.join(', ')
    const annualStrs = annualItems.filter(i => selectedAnnualCats.includes(i.category_id)).map(i => i.category_name).join(', ')

    try {
      const payload: any = {
        student_id: enrolDetail.student_id,
        academic_session_id: Number(selSession),
        amount: finalAmountToReceive,
        payment_method: paymentMode.toUpperCase(),
        payment_date: chequeDate || new Date().toISOString().slice(0, 10),
        reference_number: referenceNo || undefined,
        notes: [
          collectionMode === 'MANUAL' && monthStrs ? `Months: ${monthStrs}` : '',
          collectionMode === 'MANUAL' && annualStrs ? `Annual: ${annualStrs}` : '',
          collectionMode === 'AUTO' ? 'Auto Allocation Mode' : '',
          chequeNo ? `Cheque: ${chequeNo}` : '',
          bankName ? `Bank: ${bankName}` : '',
          remark,
        ].filter(Boolean).join(' | '),
      }

      // If MANUAL, require invoice array, if AUTO leave it out for system allocation
      if (collectionMode === 'MANUAL') {
        if (invoice_payments.length === 0) {
          setSubmitError('No valid invoices found for selected items. Generate invoices first.')
          setSubmitting(false)
          return
        }
        payload.invoice_payments = invoice_payments
      }

      const { data } = await collectPayment(schoolId, payload)
      if (data.success) {
        setLastReceipt(data.data)
        // Refresh matrix + payment history in parallel so all statuses update immediately
        const [matrixRes, histRes] = await Promise.all([
          getYearlyMatrix(schoolId, enrolDetail.student_id, Number(selSession)),
          getStudentPaymentHistory(schoolId, enrolDetail.student_id, Number(selSession)),
        ])
        if (matrixRes.data.success) setYearlyMatrix(matrixRes.data.data)
        if (histRes.data.success) {
          const hist = histRes.data.data
          setPaymentHistory(hist)
          setOldBalance(Number(matrixRes.data.data.old_balance?.total) || 0)

          const remainMap2: Record<number, number> = {}
          for (const inv of hist.invoices || []) {
            remainMap2[inv.invoice_id] = Number(inv.remaining_amount) || 0
          }
          setInvoiceRemainingMap(remainMap2)
        }

        setSelectedMonths([]); setCheckedCells({}); setSelectedAnnualCats([])
        setAutoAmount('')
        setAdditionalFee(0); setConcessionPct(0); setRemark('')
        setBankName(''); setChequeNo(''); setChequeDate(''); setReferenceNo('')
        setShowModal(true)
      } else {
        setSubmitError(data.message || 'Payment failed.')
      }
    } catch (e: any) {
      setSubmitError(e.response?.data?.message || 'Payment failed. Please try again.')
    } finally { setSubmitting(false) }
  }

  // Display derived values
  const sessionYear = sessions.find(s => String(s.id) === selSession)?.session_year || ''
  const selectedEnrol = enrollments.find(e => String(e.id) === selStudent)
  const stName = `${selectedEnrol?.student?.first_name || ''} ${selectedEnrol?.student?.last_name || ''}`.trim().toUpperCase()
  const className = selectedEnrol?.class_section?.class?.name || ''
  const sectionName = selectedEnrol?.class_section?.section?.name || ''
  const fatherName = studentDetail?.parent?.father_name?.toUpperCase() || '—'
  const motherName = studentDetail?.parent?.mother_name?.toUpperCase() || '—'
  const mobile = studentDetail?.mobile_number || studentDetail?.parent?.father_phone || '—'
  const address = studentDetail?.address
    ? [studentDetail.address.current_address, studentDetail.address.current_city].filter(Boolean).join(', ')
    : '—'
  const today = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })

  const pendingMonths = MATRIX_MONTHS.filter(m => getMonthAggregateStatus(m) === 'pending')
  const allPendingSelected = pendingMonths.length > 0 && selectedMonths.length === pendingMonths.length
  // Columns shown in table = only selected months (for monthly fee table)
  const tableCols = MATRIX_MONTHS.filter(m => selectedMonths.includes(m))

  const isAuto = collectionMode === 'AUTO'
  const isManual = collectionMode === 'MANUAL'

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* ── Filter Bar ── */}
        <div className='card card-flush shadow-xs mb-6 border-0'>
          <div className='card-body py-4'>
            <div className='row g-3 align-items-end'>
              <div className='col-lg-3 col-md-6'>
                <label className='fw-bold fs-8 text-uppercase text-muted mb-1 d-block'>Session</label>
                <select className='form-select form-select-sm form-select-solid'
                  value={selSession}
                  onChange={e => { setSelSession(e.target.value); setSelClass(''); setSelSection(''); setSelStudent(''); resetAll() }}>
                  <option value=''>Select session...</option>
                  {sessions.map(s => <option key={s.id} value={s.id}>{s.session_year}{s.is_current ? ' ★' : ''}</option>)}
                </select>
              </div>
              <div className='col-lg-2 col-md-3'>
                <label className='fw-bold fs-8 text-uppercase text-muted mb-1 d-block'>Class</label>
                <select className='form-select form-select-sm form-select-solid'
                  value={selClass} onChange={e => handleClassChange(e.target.value)} disabled={!selSession}>
                  <option value=''>Select class...</option>
                  {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className='col-lg-2 col-md-3'>
                <label className='fw-bold fs-8 text-uppercase text-muted mb-1 d-block'>Section</label>
                <select className='form-select form-select-sm form-select-solid'
                  value={selSection} onChange={e => handleSectionChange(e.target.value)} disabled={!selClass}>
                  <option value=''>Select section...</option>
                  {sections.map(cs => <option key={cs.id} value={cs.id}>{cs.section?.name}</option>)}
                </select>
              </div>
              <div className='col'>
                <label className='fw-bold fs-8 text-uppercase text-muted mb-1 d-block'>Student</label>
                <select className='form-select form-select-sm form-select-solid'
                  value={selStudent} onChange={e => handleStudentChange(e.target.value)} disabled={!selSection || loadingEnroll}>
                  <option value=''>{loadingEnroll ? 'Loading students...' : 'Select student...'}</option>
                  {enrollments.map(e => (
                    <option key={e.id} value={e.id}>
                      {e.roll_number ? `[${e.roll_number}] ` : ''}{e.student?.first_name} {e.student?.last_name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* ── Empty state ── */}
        {!selStudent && !loadingMatrix && (
          <div className='card card-flush border-0 shadow-xs'>
            <div className='card-body py-20 text-center'>
              <i className='bi bi-person-check text-gray-300' style={{ fontSize: '5rem' }}></i>
              <h5 className='fw-bold text-gray-600 mt-4 mb-1'>Select a Student</h5>
              <p className='text-muted fs-7'>Choose session → class → section → student to view their annual fee matrix.</p>
            </div>
          </div>
        )}

        {/* ── Loading ── */}
        {loadingMatrix && (
          <div className='card card-flush border-0 shadow-xs'>
            <div className='card-body py-16 text-center'>
              <div className='spinner-border text-primary mb-3'></div>
              <div className='text-muted fw-semibold'>Loading fee matrix...</div>
            </div>
          </div>
        )}

        {matrixError && (
          <div className='alert alert-danger fw-semibold mb-4'>
            <i className='bi bi-exclamation-triangle me-2'></i>{matrixError}
          </div>
        )}

        {/* ── Main Receipt Card ── */}
        {selStudent && yearlyMatrix && !loadingMatrix && (
          <div className='card card-flush border-0 shadow-sm overflow-hidden'>

            {/* Clean Card Header */}
            <div className='card-header border-bottom py-5'>
              <div className='card-title'>
                <div className='d-flex align-items-center gap-3'>
                  <i className='ki-duotone ki-receipt fs-1 text-primary'><span className='path1' /><span className='path2' /></i>
                  <h2 className='text-gray-800 fw-bold mb-0 fs-5'>Fee Receipt &mdash; {stName || 'Student'}</h2>
                </div>
              </div>
              <div className='card-toolbar'>
                <span className='badge badge-light-primary fw-bold px-3 py-1 fs-8'>
                  Session: {sessionYear}
                </span>
              </div>
            </div>

            <div className='card-body px-8 py-7'>

              {/* ─ 1. Student info grid (Simplified) ─ */}
              <div className='mb-8'>
                <div className='row g-4'>
                  {[
                    { label: 'Student Name', value: `${stName} (${className}${sectionName ? ` ${sectionName}` : ''})`, col: 'col-lg-4' },
                    { label: 'Roll / SID', value: `${enrolDetail?.roll_number || '—'} / ${enrolDetail?.student_id}`, col: 'col-lg-2' },
                    { label: 'Father Name', value: fatherName, col: 'col-lg-3' },
                    { label: 'Mobile', value: mobile, col: 'col-lg-3' },
                    { label: 'Current Dues', value: <span className={clsx('fw-bold', oldBalance > 0 ? 'text-danger' : 'text-success')}>₹{oldBalance.toLocaleString('en-IN')}</span>, col: 'col-lg-2' },
                    { label: 'Address', value: address, col: 'col-lg-10' },
                  ].map(({ label, value, col }) => (
                    <div key={label} className={col}>
                      <div className='text-muted fw-semibold fs-8 text-uppercase mb-1'>{label}</div>
                      <div className='fw-bold text-gray-800 fs-7'>{value}</div>
                    </div>
                  ))}
                </div>

                {/* ─ Fee Profile Badges ─ */}
                {feeProfile && (
                  <div className='d-flex flex-wrap align-items-center gap-3 mt-6 p-4 rounded bg-light'>
                    <div className='fw-bold text-gray-700 me-2'><i className='bi bi-person-lines-fill text-muted me-2'></i>Fee Profile:</div>
                    {feeProfile.is_hostel_student ? (
                      <span className='badge badge-light-primary fw-bold px-3 py-2'>
                        <i className='bi bi-building me-1 text-primary'></i> Hostel ({feeProfile.hostel_room_type})
                      </span>
                    ) : null}
                    {feeProfile.is_transport_user ? (
                      <span className='badge badge-light-info fw-bold px-3 py-2'>
                        <i className='bi bi-bus-front me-1 text-info'></i> Transport
                      </span>
                    ) : null}
                    {feeProfile.is_scholarship_holder ? (
                      <span className='badge badge-light-success fw-bold px-3 py-2'>
                        <i className='bi bi-award me-1 text-success'></i> Scholarship
                      </span>
                    ) : null}
                    {!feeProfile.is_hostel_student && !feeProfile.is_transport_user && !feeProfile.is_scholarship_holder && !feeProfile.notes && (
                      <span className='text-muted fs-8'>Standard Profile</span>
                    )}
                    {feeProfile.notes && (
                      <span className='text-muted fs-8 fst-italic ms-auto'>
                        <i className='bi bi-info-circle me-1'></i> {feeProfile.notes}
                      </span>
                    )}
                  </div>
                )}

                <div className='separator separator-dashed my-8'></div>
              </div>

              {/* ─ 1b. Financial Summary Strip (from payment-history API) ─ */}
              {paymentHistory && (() => {
                const fs = paymentHistory.financial_summary
                const pct = Number(fs?.payment_completion_percent) || 0
                const MONTH_ORDER = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar']
                // sort invoices in calendar order
                const sortedInvoices = [...(paymentHistory.invoices || [])].sort(
                  (a: any, b: any) => MONTH_ORDER.indexOf(a.month) - MONTH_ORDER.indexOf(b.month)
                )
                return (
                  <div className='rounded-2 border border-gray-200 mb-6 overflow-hidden'>
                    {/* Header bar */}
                    <div className='d-flex align-items-center justify-content-between px-6 py-4 border-bottom bg-light'>
                      <div className='d-flex align-items-center gap-2'>
                        <i className='ki-duotone ki-chart-line-star ts-3 text-primary'><span className='path1' /><span className='path2' /><span className='path3' /></i>
                        <span className='fw-bold text-gray-800 fs-7'>Annual Fee Summary</span>
                      </div>
                      <div className='d-flex align-items-center gap-2'>
                        <span className='text-muted fs-8 fw-semibold'>{pct}% Paid</span>
                        <div className='w-100px bg-gray-200 rounded-pill pt-1' style={{ height: 6 }}>
                          <div className='bg-primary rounded-pill' style={{ height: '100%', width: `${Math.min(pct, 100)}%` }} />
                        </div>
                      </div>
                    </div>

                    {/* Stats table-like layout */}
                    <div className='row row-cols-2 row-cols-md-4 g-0'>
                      {[
                        { label: 'Total Charged', value: `₹${Number(fs?.total_charged || 0).toLocaleString('en-IN')}` },
                        { label: 'Total Paid', value: `₹${Number(fs?.total_paid || 0).toLocaleString('en-IN')}`, cls: 'text-primary' },
                        { label: 'Fine', value: `₹${Number(fs?.total_fine || 0).toLocaleString('en-IN')}`, cls: 'text-danger' },
                        { label: 'Remaining', value: `₹${Number(fs?.total_remaining || 0).toLocaleString('en-IN')}`, cls: Number(fs?.total_remaining) > 0 ? 'text-danger' : 'text-primary' },
                      ].map(({ label, value, cls }) => (
                        <div key={label} className='col py-4 px-6 border-end border-bottom border-gray-100 text-center'>
                          <div className='text-muted fw-bold fs-9 text-uppercase mb-1'>{label}</div>
                          <div className={clsx('fw-bold fs-6', cls || 'text-gray-800')}>{value}</div>
                        </div>
                      ))}
                    </div>

                    {/* Month-wise invoice status row */}
                    <div className='px-5 py-3 border-top border-gray-200'>
                      <div className='text-muted fw-bold fs-9 text-uppercase mb-3'>Month-wise Status</div>
                      <div className='d-flex flex-wrap gap-2'>
                        {sortedInvoices.map((inv: any) => {
                          const status =
                            inv.status === 'PAID' ? { badge: 'badge-light-success' } :
                              inv.status === 'PARTIAL' ? { badge: 'badge-light-warning' } :
                                inv.status === 'OVERDUE' ? { badge: 'badge-light-danger' } :
                                  { badge: 'badge-light text-muted' }
                          const remaining = Number(inv.remaining_amount)
                          return (
                            <div key={inv.invoice_id}
                              className={clsx('d-flex flex-column align-items-center rounded-1 px-1 py-2', status.badge)}
                              style={{ minWidth: 55, border: '1px solid rgba(0,0,0,0.05)' }}
                              title={`${inv.month}: ₹${Number(inv.net_amount).toLocaleString('en-IN')} | Paid: ₹${Number(inv.paid_amount).toLocaleString('en-IN')} | Remaining: ₹${remaining.toLocaleString('en-IN')}`}>
                              <span className='fw-bolder fs-9' style={{ color: 'inherit' }}>{inv.month}</span>
                              {remaining > 0 && (
                                <span className='fw-semibold' style={{ fontSize: '0.6rem', color: 'inherit', opacity: 0.8 }}>
                                  ₹{remaining.toLocaleString('en-IN')}
                                </span>
                              )}
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  </div>
                )
              })()}

              {/* ─ Mode Selector ─ */}
              <div className='d-flex align-items-center mb-8 gap-4 bg-light rounded px-6 py-4'>
                <span className='fw-bold text-gray-800 me-2'>Collection Mode:</span>
                <label className='form-check form-check-custom form-check-solid'>
                  <input className='form-check-input' type='radio' name='mode'
                    checked={isManual} onChange={() => setCollectionMode('MANUAL')} />
                  <span className='form-check-label fw-semibold text-gray-700'>Manual (Select specific invoices)</span>
                </label>
                <label className='form-check form-check-custom form-check-solid'>
                  <input className='form-check-input' type='radio' name='mode'
                    checked={isAuto} onChange={() => {
                      setCollectionMode('AUTO')
                      setSelectedMonths([])
                      setCheckedCells({})
                      setSelectedAnnualCats([])
                    }} />
                  <span className='form-check-label fw-semibold text-gray-700'>Auto (System deducts oldest dues)</span>
                </label>
              </div>

              {isAuto && (
                <div className='card border border-primary border-dashed mb-6 bg-light-primary'>
                  <div className='card-body d-flex align-items-center justify-content-between p-6'>
                    <div>
                      <h4 className='text-primary fw-bolder mb-1'>Auto-Allocation Active</h4>
                      <div className='text-gray-600 fs-7'>System will apply this amount against oldest pending invoices automatically.</div>
                    </div>
                    <div className='w-250px'>
                      <label className='fw-bold fs-7 text-gray-700 mb-2'>Enter Amount (₹)</label>
                      <input type='number' className='form-control form-control-primary form-control-solid'
                        value={autoAmount} onChange={e => setAutoAmount(e.target.value)}
                        placeholder='e.g. 5000' />
                    </div>
                  </div>
                </div>
              )}

              {isManual && (
                <>
                  <div className='mb-6'>
                    <div className='d-flex align-items-center justify-content-between mb-4'>
                      <div className='d-flex align-items-center gap-2'>
                        <i className='bi bi-calendar-check fs-4 text-primary pe-1'></i>
                        <span className='fw-bolder text-gray-800 fs-6'>Select Months</span>
                        {monthlyItems.length === 0 && <span className='badge badge-light-warning ms-2'>No monthly fees</span>}
                      </div>
                      {pendingMonths.length > 0 && (
                        <button
                          className={clsx('btn btn-sm rounded-pill fw-bold px-5', allPendingSelected ? 'btn-primary' : 'btn-light-primary')}
                          onClick={toggleAllPendingMonths}
                        >
                          {allPendingSelected ? '✓ Selected All' : '✓ Select All'}
                        </button>
                      )}
                    </div>
                    <div className='d-flex flex-wrap gap-2'>
                      {MATRIX_MONTHS.map(m => {
                        const status = getMonthAggregateStatus(m)
                        const isSelected = selectedMonths.includes(m)
                        const isPaid = status === 'paid'
                        const isApplicable = status !== 'none'
                        const pendingAmt = getMonthPendingAmount(m)

                        return (
                          <button
                            key={m}
                            className={clsx(
                              'btn btn-sm rounded-pill fw-bold px-4 py-2 fs-8 border',
                              isPaid ? 'btn-light-success text-success border-success' :
                                isSelected ? 'btn-primary border-primary text-white' :
                                  isApplicable ? 'btn-light border-gray-300 text-gray-600' :
                                    'btn-light border-gray-200 text-gray-400 opacity-50'
                            )}
                            style={{ minWidth: 60, cursor: (isPaid || !isApplicable) ? 'not-allowed' : 'pointer', transition: 'all 0.15s' }}
                            onClick={() => toggleMonth(m)}
                            disabled={isPaid || !isApplicable}
                            title={isPaid ? 'Paid' : !isApplicable ? 'Not Applicable' : `₹${pendingAmt} pending`}
                          >
                            {isPaid ? '✓ ' : ''}{m}
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {/* ─ 3. Fee Details Table ─ */}
                  <div className='mb-7'>
                    <div className='d-flex align-items-center gap-2 mb-4'>
                      <span className='fs-4'>📋</span>
                      <span className='fw-bolder text-gray-800 fs-6'>Fee Details</span>
                    </div>
                    <div className='table-responsive border rounded-2' style={{ borderColor: '#e5e7eb' }}>
                      <table className='table table-row-bordered table-row-gray-100 align-middle fs-8 mb-0'>
                        <thead>
                          <tr className='text-uppercase text-muted fw-bold' style={{ background: '#f5f7fa' }}>
                            <th className='ps-4 py-4' style={{ minWidth: 160 }}>Item</th>
                            {tableCols.map(m => (
                              <th key={m} className='text-center py-4 px-3' style={{ minWidth: 85 }}>{m.toUpperCase()}</th>
                            ))}
                            {tableCols.length === 0 && (
                              <th className='py-4 ps-4 text-gray-400 fw-normal fs-8 fst-italic'>
                                Select months above to see monthly breakdown →
                              </th>
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {/* Annual / One-Time section */}
                          {annualItems.length > 0 && (
                            <>
                              <tr>
                                <td colSpan={tableCols.length > 0 ? tableCols.length + 1 : 2}
                                  className='py-3 ps-4' style={{ background: '#fffbeb', borderBottom: '1px solid #fde68a' }}>
                                  <div className='fw-bold text-amber-700 fs-8 d-flex align-items-center gap-2' style={{ color: '#92400e' }}>
                                    <i className='bi bi-star-fill text-warning'></i>
                                    ANNUAL / ONE-TIME FEES
                                  </div>
                                </td>
                              </tr>
                              <AnnualRows
                                items={annualItems}
                                selectedAnnualCats={selectedAnnualCats}
                                toggleAnnualCat={toggleAnnualCat}
                                tableCols={tableCols}
                                invoiceRemainingMap={invoiceRemainingMap}
                                allMatrixMonths={MATRIX_MONTHS}
                              />
                            </>
                          )}

                          {/* Monthly section */}
                          {monthlyItems.length > 0 && tableCols.length > 0 && (
                            <>
                              <tr>
                                <td colSpan={tableCols.length + 1}
                                  className='py-3 ps-4' style={{ background: '#eff6ff', borderBottom: '1px solid #bfdbfe' }}>
                                  <div className='fw-bold fs-8 d-flex align-items-center gap-2' style={{ color: '#1e40af' }}>
                                    <i className='bi bi-calendar3 text-primary'></i>
                                    MONTHLY FEES
                                  </div>
                                </td>
                              </tr>
                              <MonthlyRows
                                items={monthlyItems}
                                tableCols={tableCols}
                                checkedCells={checkedCells}
                                toggleMonthlyCell={toggleMonthlyCell}
                                invoiceRemainingMap={invoiceRemainingMap}
                              />
                            </>
                          )}

                          {yearlyMatrix.items.length === 0 && (
                            <tr>
                              <td colSpan={tableCols.length > 0 ? tableCols.length + 1 : 2}
                                className='text-center text-muted py-8 fst-italic'>
                                No fee structure found for this student and session.
                              </td>
                            </tr>
                          )}
                        </tbody>

                        {/* Total + Fine/Concession Edit row — only visible when months selected */}
                        {tableCols.length > 0 && (
                          <tfoot>
                            <tr style={{ background: 'linear-gradient(135deg, #3b4cca 0%, #7b2ff7 100%)' }}>
                              <td className='ps-4 py-3 fw-bolder text-white fs-7 border-0'>Total</td>
                              {tableCols.map(m => (
                                <td key={m} className='text-center py-3 border-0'>
                                  <div className='d-flex flex-column align-items-center gap-1'>
                                    <span className='badge fw-bolder fs-8 px-3 py-2'
                                      style={{ background: 'rgba(255,255,255,0.2)', color: '#fff' }}>
                                      ₹{getMonthColTotal(m).toLocaleString('en-IN')}
                                    </span>
                                    {/* Edit Fine/Concession button — calls GET then PUT /invoices/:id */}
                                    <button
                                      className='btn btn-xs px-2 py-1 fw-bold'
                                      style={{ background: 'rgba(255,255,255,0.15)', color: '#fff', fontSize: '0.65rem', border: '1px solid rgba(255,255,255,0.3)', borderRadius: 4 }}
                                      onClick={() => openInvoiceEdit(m)}
                                      title={`Edit Fine / Concession for ${m}`}
                                    >
                                      <i className='bi bi-pencil-square me-1' style={{ fontSize: '0.65rem' }}></i>Fine/Disc
                                    </button>
                                  </div>
                                </td>
                              ))}
                            </tr>
                          </tfoot>
                        )}
                      </table>
                    </div>
                  </div>

                  {/* ─ 4. Payment Summary + Amount Receivable cards ─ */}
                  {anySelected && (
                    <div className='row g-6 mb-7'>
                      {/* Left - Payment Summary card */}
                      <div className='col-md-6'>
                        <div className='card border h-100 shadow-sm' style={{ borderColor: '#bfdbfe' }}>
                          <div className='card-header min-h-50px border-0 pt-5'>
                            <h3 className='card-title fw-bolder text-gray-800 fs-6 d-flex align-items-center gap-2'>
                              <i className='bi bi-calculator text-primary'></i> Payment Summary
                            </h3>
                          </div>
                          <div className='card-body pt-0 pb-5 px-6'>
                            <div className='d-flex flex-column gap-4'>
                              {/* <div className='d-flex justify-content-between align-items-center'>
                                <span className='text-gray-600 fw-bold fs-7'>Total Fee</span>
                                <input readOnly className='form-control form-control-sm w-130px text-end fw-bold bg-light border-0'
                                  value={totals.subtotal} />
                              </div> */}

                              <div className='d-flex justify-content-between align-items-center'>
                                <span className='text-gray-600 fw-bold fs-7'>Invoice Fine (₹)</span>
                                <input readOnly className='form-control form-control-sm w-130px text-end fw-bold bg-light border-0 text-danger'
                                  value={totals.invoiceFine} />
                              </div>

                              <div className='d-flex justify-content-between align-items-center'>
                                <span className='text-gray-600 fw-bold fs-7'>Invoice Discount (₹)</span>
                                <input readOnly className='form-control form-control-sm w-130px text-end fw-bold bg-light border-0 text-success'
                                  value={totals.invoiceConcession} />
                              </div>

                              {/* <div className='d-flex justify-content-between align-items-center'>
                                <span className='text-gray-600 fw-bold fs-7'>Additional Fee (₹)</span>
                                <input type='number' min='0'
                                  className='form-control form-control-sm w-130px text-end fw-bold border'
                                  value={additionalFee || ''}
                                  //onChange={e => setAdditionalFee(Number(e.target.value))}
                                  placeholder='0' />
                              </div>

                              <div className='d-flex justify-content-between align-items-center'>
                                <span className='text-gray-600 fw-bold fs-7'>Concession (%)</span>
                                <input type='number' min='0' max='100'
                                  className='form-control form-control-sm w-130px text-end fw-bold border'
                                  value={concessionPct || ''}
                                //  onChange={e => setConcessionPct(Math.min(100, Number(e.target.value)))}
                                  placeholder='0' />
                              </div>
                              <div className='d-flex justify-content-between align-items-center'>
                                <span className='text-gray-600 fw-bold fs-7'>Concession Amt</span>
                                <input readOnly className='form-control form-control-sm w-130px text-end fw-bold bg-light border-0 text-danger'
                                  value={totals.concessionAmt.toFixed(2)} />
                              </div> */}
                              <div className='separator my-0'></div>
                              <div className='d-flex justify-content-between align-items-center'>
                                <span className='text-gray-900 fw-bolder fs-6'>Net Fee</span>
                                <span className='text-primary fw-bolder fs-3 bg-light-primary rounded px-3 py-1'>
                                  ₹{totals.netFee.toFixed(2)}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Right */}
                      <div className='col-md-6'>
                        <div className='card border h-100 shadow-sm' style={{ borderColor: '#bbf7d0' }}>
                          <div className='card-header min-h-50px border-0 pt-5'>
                            <h3 className='card-title fw-bolder text-gray-800 fs-6 d-flex align-items-center gap-2'>
                              <i className='bi bi-cash-stack text-success'></i> Amount Receivable
                            </h3>
                          </div>
                          <div className='card-body pt-0 pb-5 px-6 d-flex flex-column gap-3'>
                            <div className='d-flex flex-stack rounded px-4 py-3' style={{ background: '#f0fff4', border: '1px solid #bbf7d0' }}>
                              <span className='text-gray-700 fw-semibold fs-7'>Net Fee</span>
                              <span className='text-success fw-bolder fs-6'>₹{totals.netFee.toFixed(2)}</span>
                            </div>
                            <div className='d-flex flex-stack rounded px-4 py-3' style={{ background: '#fffbeb', border: '1px solid #fde68a' }}>
                              <span className='text-gray-700 fw-semibold fs-7'>Old Balance</span>
                              <span className='text-warning fw-bolder fs-6'>₹{oldBalance.toFixed(2)}</span>
                            </div>
                            <div className='d-flex flex-stack rounded px-5 py-4' style={{ background: '#16a34a' }}>
                              <span className='text-white fw-bolder fs-6'>Amount Received</span>
                              <div className='d-flex align-items-center mb-0'>
                                <span className='text-white fw-bolder fs-2 me-1'>₹</span>
                                <input
                                  type='number'
                                  className='form-control form-control-sm form-control-transparent text-white fw-bolder fs-2 p-0 text-end'
                                  style={{ width: '120px', background: 'transparent', border: 'none', borderBottom: '1px dashed rgba(255,255,255,0.5)', borderRadius: 0, outline: 'none' }}
                                  value={manualAmountInput !== '' ? manualAmountInput : totals.totalReceivable}
                                  onChange={e => setManualAmountInput(e.target.value)}
                                />
                              </div>
                            </div>
                            <div className='d-flex flex-stack rounded px-5 py-3' style={{ background: '#dc2626' }}>
                              <span className='text-white fw-bolder fs-6'>New Balance</span>
                              <span className='text-white fw-bolder fs-4'>₹{newBalanceCalculation.toFixed(2)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* ─ 5. Payment Details form ─ */}
              {(anySelected || isAuto) && (
                <div className='card border border-gray-200 mb-6 shadow-sm'>
                  <div className='card-body p-6'>
                    <div className='d-flex align-items-center gap-2 mb-5'>
                      <i className='bi bi-credit-card-2-front text-dark fs-4'></i>
                      <h5 className='fw-bolder text-gray-900 mb-0'>Payment Details</h5>
                    </div>
                    <div className='row g-5'>
                      <div className='col-md-3'>
                        <label className='fw-bold fs-8 text-uppercase text-muted mb-2 d-block'>Payment Mode</label>
                        <select className='form-select form-select-solid fw-bold text-gray-800'
                          value={paymentMode} onChange={e => setPaymentMode(e.target.value)}>
                          <option>Cash</option>
                          <option>Cheque</option>
                          <option>Online</option>
                          <option>UPI</option>
                          <option>DD</option>
                        </select>
                      </div>
                      <div className='col-md-3'>
                        <label className='fw-bold fs-8 text-uppercase text-muted mb-2 d-block'>Bank Name</label>
                        <input type='text' className='form-control form-control-solid'
                          value={bankName} onChange={e => setBankName(e.target.value)}
                          placeholder='Enter bank name' disabled={paymentMode === 'Cash'} />
                      </div>
                      <div className='col-md-3'>
                        <label className='fw-bold fs-8 text-uppercase text-muted mb-2 d-block'>Cheque / DD No.</label>
                        <input type='text' className='form-control form-control-solid'
                          value={chequeNo} onChange={e => setChequeNo(e.target.value)}
                          placeholder='Enter cheque number' disabled={paymentMode === 'Cash'} />
                      </div>
                      <div className='col-md-3'>
                        <label className='fw-bold fs-8 text-uppercase text-muted mb-2 d-block'>Cheque Date</label>
                        <input type='date' className='form-control form-control-solid'
                          value={chequeDate} onChange={e => setChequeDate(e.target.value)}
                          disabled={paymentMode === 'Cash'} />
                      </div>
                      <div className='col-md-6'>
                        <label className='fw-bold fs-8 text-uppercase text-muted mb-2 d-block'>
                          <i className='bi bi-hash text-primary me-1'></i>
                          Reference / Transaction No.
                        </label>
                        <input type='text' className='form-control form-control-solid'
                          value={referenceNo} onChange={e => setReferenceNo(e.target.value)}
                          placeholder={
                            paymentMode === 'UPI' ? 'UPI Transaction ID' :
                              paymentMode === 'Online' ? 'Bank Transaction No.' :
                                paymentMode === 'Cheque' || paymentMode === 'DD' ? 'Cheque / DD Reference' :
                                  'Reference number (optional)'
                          } />
                      </div>
                      <div className='col-12'>
                        <label className='fw-bold fs-8 text-uppercase text-muted mb-2 d-block'>Remark</label>
                        <textarea className='form-control form-control-solid' rows={2}
                          value={remark} onChange={e => setRemark(e.target.value)}
                          placeholder='Enter any remarks...' />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {submitError && (
                <div className='alert alert-danger fw-semibold mb-4'>
                  <i className='bi bi-exclamation-circle me-2'></i>{submitError}
                </div>
              )}

              {/* ─ 6. Bottom: SMS/WA + Reset + Submit ─ */}
              {(anySelected || isAuto) && (
                <div className='d-flex align-items-center justify-content-between flex-wrap gap-4 pt-2'>
                  <div className='d-flex gap-6'>
                    <div className='form-check form-check-custom form-check-solid'>
                      <input className='form-check-input h-20px w-20px' type='checkbox'
                        id='sendSMS' checked={sendSMS} onChange={e => setSendSMS(e.target.checked)} />
                      <label className='form-check-label fw-bold text-gray-700 fs-7' htmlFor='sendSMS'>
                        <i className='bi bi-chat-left-text text-info me-1'></i> Send SMS
                      </label>
                    </div>
                    <div className='form-check form-check-custom form-check-solid'>
                      <input className='form-check-input h-20px w-20px' type='checkbox'
                        id='sendWA' checked={sendWhatsApp} onChange={e => setSendWhatsApp(e.target.checked)} />
                      <label className='form-check-label fw-bold text-gray-700 fs-7' htmlFor='sendWA'>
                        <i className='bi bi-whatsapp text-success me-1'></i> Send WhatsApp
                      </label>
                    </div>
                  </div>
                  <div className='d-flex gap-3'>
                    <button className='btn btn-light fw-bolder px-8' onClick={resetAll}>
                      <i className='bi bi-arrow-repeat me-2'></i>Reset
                    </button>
                    <button
                      className='btn btn-primary fw-bolder px-10 shadow-sm'
                      onClick={handleSubmit}
                      disabled={submitting || totals.totalReceivable <= 0}
                    >
                      {submitting
                        ? <><span className='spinner-border spinner-border-sm me-2'></span>Processing...</>
                        : <><i className='bi bi-shield-check me-2 fs-5'></i>✓ Submit</>
                      }
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}
      </Content>

      {/* ── Success Modal ── */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered size='sm'>
        <Modal.Body className='p-0 overflow-hidden rounded'>
          <div className='p-8 text-center text-white'
            style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)' }}>
            <i className='bi bi-patch-check-fill' style={{ fontSize: '4.5rem', opacity: 0.9 }}></i>
            <h2 className='text-white fw-bolder mt-3 mb-1'>Payment Successful!</h2>
            <p className='mb-0 fs-8 opacity-75'>Receipt ID: TXN-{lastReceipt?.id || '—'}</p>
          </div>
          <div className='p-6'>
            {/* Amount & Student Summary */}
            <div className='rounded p-4 mb-5 d-flex flex-stack' style={{ background: '#f8f9fb', border: '1px solid #e5e7eb' }}>
              <div>
                <div className='text-muted fs-9 fw-bold text-uppercase mb-1'>Student</div>
                <div className='fw-bolder text-gray-900 fs-7'>{stName}</div>
                <div className='text-muted fs-8'>{className}{sectionName ? ` (${sectionName})` : ''}</div>
              </div>
              <div className='text-end'>
                <div className='text-muted fs-9 fw-bold text-uppercase mb-1'>Amount Paid</div>
                <div className='text-success fw-bolder' style={{ fontSize: '1.6rem', lineHeight: 1.2 }}>
                  ₹{Number(lastReceipt?.amount_paid || 0).toLocaleString('en-IN')}
                </div>
              </div>
            </div>

            {/* Payment Details */}
            <div className='row g-3 fs-8 mb-6'>
              <div className='col-6'>
                <div className='text-muted fw-bold text-uppercase fs-9 mb-1'>Payment Mode</div>
                <div className='fw-bold text-gray-800 d-flex align-items-center gap-1'>
                  <i className='bi bi-credit-card text-primary'></i>
                  {lastReceipt?.payment_mode || paymentMode}
                </div>
              </div>
              <div className='col-6'>
                <div className='text-muted fw-bold text-uppercase fs-9 mb-1'>Date</div>
                <div className='fw-bold text-gray-800'>
                  {lastReceipt?.payment_date ? new Date(lastReceipt.payment_date).toLocaleDateString('en-GB', {
                    day: '2-digit', month: 'short', year: 'numeric'
                  }) : today}
                </div>
              </div>
            </div>

            {/* Balance Remaining - The "Remain" the user requested */}
            <div className='rounded-2 px-4 py-3 mb-6 d-flex align-items-center justify-content-between'
              style={{ background: '#fff', border: '1px dashed #e4e6ef' }}>
              <span className='text-muted fw-bold fs-8'>Balance Remaining</span>
              <span className={clsx('fw-bolder fs-6', oldBalance > 0 ? 'text-danger' : 'text-success')}>
                ₹{oldBalance.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Actions */}
            <div className='d-flex gap-3'>
              <button className='btn btn-light-success fw-bold flex-grow-1 fs-8 py-3'>
                <i className='bi bi-printer me-2'></i>Print Receipt
              </button>
              <button className='btn btn-primary fw-bolder flex-grow-1 fs-8 py-3 shadow-sm'
                onClick={() => setShowModal(false)}>
                Done
              </button>
            </div>
          </div>
        </Modal.Body>
      </Modal>

      {/* ── Invoice Fine / Concession Edit Modal (GET + PUT /invoices/:id) ── */}
      <Modal show={invoiceModalOpen} onHide={() => { setInvoiceModalOpen(false); setInvoiceSaveMsg(null) }} centered size='lg'>
        <Modal.Body className='p-0 overflow-hidden rounded'>
          {/* Header */}
          <div className='px-6 py-5 d-flex align-items-center justify-content-between border-bottom'
            style={{ background: 'linear-gradient(135deg, #3b4cca 0%, #7b2ff7 100%)' }}>
            <div>
              <h4 className='text-white fw-bolder mb-0 fs-5'>
                <i className='bi bi-pencil-square me-2'></i>Edit Fine / Concession
              </h4>
              <span className='text-white opacity-75 fs-8'>Month: {invoiceModalMonth}</span>
            </div>
            <button className='btn btn-sm btn-icon' style={{ color: '#fff', opacity: 0.8 }}
              onClick={() => { setInvoiceModalOpen(false); setInvoiceSaveMsg(null) }}>
              <i className='bi bi-x-lg fs-5'></i>
            </button>
          </div>

          <div className='p-6'>
            {invoiceLoading && (
              <div className='text-center py-8'>
                <div className='spinner-border text-primary mb-2'></div>
                <div className='text-muted fs-7'>Loading invoice details...</div>
              </div>
            )}

            {!invoiceLoading && invoiceDetail && (
              <>
                {/* Invoice summary */}
                <div className='rounded-2 border border-gray-200 mb-5 overflow-hidden'>
                  <div className='row g-0' style={{ background: '#f8f9fb' }}>
                    <div className='col-4 py-3 px-4 border-end border-gray-200'>
                      <div className='text-muted fw-bold fs-9 text-uppercase mb-1'>Invoice ID</div>
                      <div className='fw-bolder text-gray-800'>#{invoiceDetail.id}</div>
                    </div>
                    <div className='col-4 py-3 px-4 border-end border-gray-200'>
                      <div className='text-muted fw-bold fs-9 text-uppercase mb-1'>Base Amount</div>
                      <div className='fw-bolder text-gray-800'>₹{Number(invoiceDetail.total_amount).toLocaleString('en-IN')}</div>
                    </div>
                    <div className='col-4 py-3 px-4'>
                      <div className='text-muted fw-bold fs-9 text-uppercase mb-1'>Status</div>
                      <span className={clsx('badge fw-bold', {
                        'badge-light-success': invoiceDetail.status === 'PAID',
                        'badge-light-danger': invoiceDetail.status === 'OVERDUE',
                        'badge-light-warning': invoiceDetail.status === 'PARTIAL',
                        'badge-light-primary': invoiceDetail.status === 'UNPAID',
                      })}>{invoiceDetail.status}</span>
                    </div>
                  </div>
                </div>

                {/* Items breakdown */}


                {/* Fine / Concession inputs */}
                {/* ── Fine input ── */}
                <div className='mb-4'>
                  <div className='d-flex align-items-center justify-content-between rounded-top px-4 py-3'
                    style={{ background: '#fef2f2', border: '1px solid #fecaca', borderBottom: 'none', borderRadius: '8px 8px 0 0' }}>
                    <span className='fw-bolder fs-7 d-flex align-items-center gap-2' style={{ color: '#dc2626' }}>
                      <i className='bi bi-exclamation-triangle-fill text-danger'></i> Fine / Penalty
                    </span>
                    <span className='fw-bolder fs-6 text-danger'>
                      {editFine > 0 ? `+₹${editFine.toLocaleString('en-IN')}` : '—'}
                    </span>
                  </div>
                  <div className='rounded-bottom px-4 py-3'
                    style={{ background: '#fff5f5', border: '1px solid #fecaca', borderTop: '1px dashed #fecaca', borderRadius: '0 0 8px 8px' }}>
                    <div className='d-flex align-items-center gap-3'>
                      <span className='text-muted fw-bold fs-8 text-uppercase' style={{ minWidth: 80 }}>Amount (₹)</span>
                      <div className='input-group input-group-sm' style={{ maxWidth: 200 }}>
                        <span className='input-group-text fw-bold text-danger bg-white border-danger' style={{ borderColor: '#fca5a5' }}>₹</span>
                        <input
                          type='number' min='0'
                          className='form-control form-control-solid text-end fw-bold'
                          style={{ borderColor: '#fca5a5', color: '#dc2626' }}
                          value={editFine || ''}
                          onChange={e => setEditFine(Number(e.target.value))}
                          placeholder='0'
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* ── Concession input (% + ₹ both) ── */}
                <div className='mb-5'>
                  <div className='d-flex align-items-center justify-content-between rounded-top px-4 py-3'
                    style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderBottom: 'none', borderRadius: '8px 8px 0 0' }}>
                    <span className='fw-bolder fs-7 d-flex align-items-center gap-2' style={{ color: '#16a34a' }}>
                      <i className='bi bi-tag-fill text-success'></i> Concession / Discount
                    </span>
                    <span className='fw-bolder fs-6 text-success'>
                      {editConcession > 0 ? `-₹${editConcession.toLocaleString('en-IN')}` : '—'}
                    </span>
                  </div>
                  <div className='rounded-bottom px-4 py-3'
                    style={{ background: '#f6fff9', border: '1px solid #bbf7d0', borderTop: '1px dashed #86efac', borderRadius: '0 0 8px 8px' }}>
                    <div className='d-flex align-items-center gap-4 flex-wrap'>
                      {/* Percentage input */}
                      <div className='d-flex align-items-center gap-2'>
                        <span className='text-muted fw-bold fs-8 text-uppercase' style={{ minWidth: 30 }}>%</span>
                        <div className='input-group input-group-sm' style={{ maxWidth: 140 }}>
                          <input
                            type='number' min='0' max='100'
                            className='form-control form-control-solid text-end fw-bold'
                            style={{ borderColor: '#86efac', color: '#16a34a' }}
                            value={editConcessionPct || ''}
                            onChange={e => {
                              const pct = Math.min(100, Number(e.target.value))
                              setEditConcessionPct(pct)
                              // Auto-calculate amount from base
                              const base = Number(invoiceDetail?.total_amount || 0) + editFine
                              setEditConcession(Math.round((base * pct) / 100))
                            }}
                            placeholder='0'
                          />
                          <span className='input-group-text fw-bold text-success bg-white' style={{ borderColor: '#86efac' }}>%</span>
                        </div>
                      </div>

                      <span className='text-muted fw-semibold fs-8'>or</span>

                      {/* Amount input */}
                      <div className='d-flex align-items-center gap-2'>
                        <span className='text-muted fw-bold fs-8 text-uppercase' style={{ minWidth: 30 }}>₹</span>
                        <div className='input-group input-group-sm' style={{ maxWidth: 160 }}>
                          <span className='input-group-text fw-bold text-success bg-white' style={{ borderColor: '#86efac' }}>₹</span>
                          <input
                            type='number' min='0'
                            className='form-control form-control-solid text-end fw-bold'
                            style={{ borderColor: '#86efac', color: '#16a34a' }}
                            value={editConcession || ''}
                            onChange={e => {
                              const amt = Number(e.target.value)
                              setEditConcession(amt)
                              // Auto-calculate % from base
                              const base = Number(invoiceDetail?.total_amount || 0) + editFine
                              setEditConcessionPct(base > 0 ? Math.round((amt / base) * 100) : 0)
                            }}
                            placeholder='0'
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Calculated net preview */}
                <div className='rounded-2 p-4 mb-4 d-flex flex-stack' style={{ background: '#f0f9ff', border: '1px solid #bfdbfe' }}>
                  <span className='fw-bold text-gray-700 fs-7'>Net Amount (Preview)</span>
                  <span className='fw-bolder text-primary fs-4'>
                    ₹{Math.max(0, Number(invoiceDetail.total_amount) + editFine - editConcession).toLocaleString('en-IN')}
                  </span>
                </div>

                {invoiceSaveMsg && (
                  <div className={clsx('alert fw-semibold mb-4 py-3', invoiceSaveMsg.startsWith('✓') ? 'alert-success' : 'alert-danger')}>
                    {invoiceSaveMsg}
                  </div>
                )}

                <div className='d-flex gap-3 justify-content-end'>
                  <button className='btn btn-light fw-bold px-6'
                    onClick={() => { setInvoiceModalOpen(false); setInvoiceSaveMsg(null) }}>
                    Cancel
                  </button>
                  <button
                    className='btn btn-primary fw-bolder px-8'
                    onClick={saveInvoiceEdit}
                    disabled={savingInvoice}
                  >
                    {savingInvoice
                      ? <><span className='spinner-border spinner-border-sm me-2'></span>Saving...</>
                      : <><i className='bi bi-check2-circle me-2'></i>Save Changes</>
                    }
                  </button>
                </div>
              </>
            )}

            {/* Invoice not generated yet */}
            {!invoiceLoading && !invoiceDetail && invoiceSaveMsg && (
              <div className='text-center py-6'>
                <i className='bi bi-file-earmark-x text-warning' style={{ fontSize: '3rem' }}></i>
                <p className='fw-semibold text-muted mt-3'>{invoiceSaveMsg}</p>
                <button className='btn btn-light fw-bold px-6'
                  onClick={() => setInvoiceModalOpen(false)}>Close</button>
              </div>
            )}
          </div>
        </Modal.Body>
      </Modal>

    </>
  )
}

// ─── Wrapper with page title ───────────────────────────────────────────────────
const MonthlyCollectionWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[
      { title: 'Fees', path: '/fees/monthly', isActive: false },
      { title: 'Fee Collection', path: '/fees/monthly', isActive: true },
    ]}>
      Fee Collection
    </PageTitle>
    <FeeCollectionPage />
  </>
)

export { MonthlyCollectionWrapper }
