import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { KTIcon } from '../../../_metronic/helpers'
import { useAuth } from '../auth'
import axios from 'axios'
import { toast } from 'react-toastify'

const API_URL = import.meta.env.VITE_APP_API_URL

// ─── Types ────────────────────────────────────────────────────────────────────
type LeaveStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED'
type LeaveType = 'SICK' | 'CASUAL' | 'EARNED' | 'MATERNITY' | 'PATERNITY' | 'UNPAID' | 'OTHER'
type StaffType = 'TEACHER' | 'ADMIN'

interface LeaveRequest {
  id: number
  staff_id: number
  staff_type: StaffType
  staff_name: string
  staff_email: string | null
  staff_designation: string | null
  leave_type: LeaveType
  from_date: string
  to_date: string
  total_days: number
  reason: string | null
  status: LeaveStatus
  admin_remark: string | null
  createdAt: string
}

interface LeaveStats {
  PENDING: number
  APPROVED: number
  REJECTED: number
  CANCELLED: number
}

// ─── Status & Type Config ─────────────────────────────────────────────────────
const STATUS_CONFIG: Record<LeaveStatus, { color: string; label: string; icon: string }> = {
  PENDING:   { color: 'warning',   label: 'Pending',   icon: 'ki-timer' },
  APPROVED:  { color: 'success',   label: 'Approved',  icon: 'ki-check-circle' },
  REJECTED:  { color: 'danger',    label: 'Rejected',  icon: 'ki-cross-circle' },
  CANCELLED: { color: 'secondary', label: 'Cancelled', icon: 'ki-minus-circle' },
}

const LEAVE_TYPE_CONFIG: Record<LeaveType, { color: string; label: string }> = {
  SICK:       { color: 'danger',  label: 'Sick Leave' },
  CASUAL:     { color: 'primary', label: 'Casual Leave' },
  EARNED:     { color: 'success', label: 'Earned Leave' },
  MATERNITY:  { color: 'pink',    label: 'Maternity' },
  PATERNITY:  { color: 'info',    label: 'Paternity' },
  UNPAID:     { color: 'dark',    label: 'Unpaid Leave' },
  OTHER:      { color: 'secondary', label: 'Other' },
}

const LEAVE_TYPES: LeaveType[] = ['SICK', 'CASUAL', 'EARNED', 'MATERNITY', 'PATERNITY', 'UNPAID', 'OTHER']

// ─── Stat Card ────────────────────────────────────────────────────────────────
const StatCard: FC<{ label: string; value: number; color: string; icon: string; active?: boolean; onClick?: () => void }> = ({ label, value, color, icon, active, onClick }) => (
  <div className={`col-6 col-xl-3`}>
    <div
      className={`card border-2 cursor-pointer h-100 ${active ? `border-${color} bg-light-${color}` : 'border-transparent'}`}
      style={{ transition: 'all .2s' }}
      onClick={onClick}
    >
      <div className='card-body py-5 d-flex align-items-center gap-4'>
        <div className={`symbol symbol-50px`}>
          <div className={`symbol-label bg-light-${color}`}>
            <i className={`ki-duotone ${icon} fs-2x text-${color}`}><span className='path1'/><span className='path2'/></i>
          </div>
        </div>
        <div>
          <div className={`fs-2hx fw-bolder text-${color} lh-1`}>{value}</div>
          <div className={`text-${color} opacity-75 fw-semibold fs-8 mt-1`}>{label}</div>
        </div>
      </div>
    </div>
  </div>
)

// ─── Review Modal ─────────────────────────────────────────────────────────────
const ReviewModal: FC<{
  leave: LeaveRequest
  onClose: () => void
  onSubmit: (action: 'APPROVED' | 'REJECTED', remark: string) => Promise<void>
}> = ({ leave, onClose, onSubmit }) => {
  const [action, setAction] = useState<'APPROVED' | 'REJECTED'>('APPROVED')
  const [remark, setRemark] = useState('')
  const [loading, setLoading] = useState(false)

  const handle = async () => {
    setLoading(true)
    await onSubmit(action, remark)
    setLoading(false)
  }

  return (
    <div className='modal fade show d-block' style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className='modal-dialog modal-dialog-centered'>
        <div className='modal-content'>
          <div className='modal-header'>
            <h5 className='modal-title fw-bold'>Leave Request Review</h5>
            <button className='btn-close' onClick={onClose} />
          </div>
          <div className='modal-body'>
            {/* Staff Info */}
            <div className='d-flex align-items-center bg-light-primary rounded p-4 mb-5'>
              <div className='symbol symbol-45px symbol-circle me-3'>
                <div className='symbol-label bg-primary text-white fw-bold fs-5'>{leave.staff_name.charAt(0)}</div>
              </div>
              <div>
                <div className='fw-bold text-gray-800 fs-6'>{leave.staff_name}</div>
                <div className='text-muted fs-8'>{leave.staff_designation || leave.staff_type} · {leave.staff_email}</div>
              </div>
            </div>

            {/* Leave Details */}
            <div className='row g-3 mb-5'>
              <div className='col-6'>
                <div className='text-muted fs-8 fw-semibold mb-1'>Leave Type</div>
                <span className={`badge badge-light-${LEAVE_TYPE_CONFIG[leave.leave_type]?.color || 'primary'} fs-7`}>
                  {LEAVE_TYPE_CONFIG[leave.leave_type]?.label || leave.leave_type}
                </span>
              </div>
              <div className='col-6'>
                <div className='text-muted fs-8 fw-semibold mb-1'>Duration</div>
                <div className='fw-bold text-gray-800 fs-7'>{leave.total_days} day{leave.total_days !== 1 ? 's' : ''}</div>
              </div>
              <div className='col-6'>
                <div className='text-muted fs-8 fw-semibold mb-1'>From</div>
                <div className='fw-semibold text-gray-700 fs-7'>{leave.from_date}</div>
              </div>
              <div className='col-6'>
                <div className='text-muted fs-8 fw-semibold mb-1'>To</div>
                <div className='fw-semibold text-gray-700 fs-7'>{leave.to_date}</div>
              </div>
              {leave.reason && (
                <div className='col-12'>
                  <div className='text-muted fs-8 fw-semibold mb-1'>Reason</div>
                  <div className='text-gray-700 fs-7'>{leave.reason}</div>
                </div>
              )}
            </div>

            {/* Action Selection */}
            <div className='mb-4'>
              <label className='fw-semibold fs-7 text-gray-600 mb-2 d-block'>Action</label>
              <div className='d-flex gap-3'>
                <label className={`btn btn-sm flex-fill ${action === 'APPROVED' ? 'btn-success' : 'btn-light-success'}`}>
                  <input type='radio' className='btn-check' checked={action === 'APPROVED'} onChange={() => setAction('APPROVED')} />
                  <i className='ki-duotone ki-check fs-4 me-1'><span className='path1'/><span className='path2'/></i>
                  Approve
                </label>
                <label className={`btn btn-sm flex-fill ${action === 'REJECTED' ? 'btn-danger' : 'btn-light-danger'}`}>
                  <input type='radio' className='btn-check' checked={action === 'REJECTED'} onChange={() => setAction('REJECTED')} />
                  <i className='ki-duotone ki-cross fs-4 me-1'><span className='path1'/><span className='path2'/></i>
                  Reject
                </label>
              </div>
            </div>
            <div>
              <label className='fw-semibold fs-7 text-gray-600 mb-1'>Admin Remark (optional)</label>
              <textarea
                className='form-control form-control-solid'
                rows={2}
                placeholder='Reason ya notes...'
                value={remark}
                onChange={e => setRemark(e.target.value)}
              />
            </div>
          </div>
          <div className='modal-footer'>
            <button className='btn btn-light' onClick={onClose}>Cancel</button>
            <button
              className={`btn btn-${action === 'APPROVED' ? 'success' : 'danger'}`}
              onClick={handle}
              disabled={loading}
            >
              {loading && <span className='spinner-border spinner-border-sm me-2' />}
              {action === 'APPROVED' ? 'Approve Leave' : 'Reject Leave'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Add Leave Modal ──────────────────────────────────────────────────────────
const AddLeaveModal: FC<{
  schoolId: string
  onClose: () => void
  onSuccess: () => void
}> = ({ schoolId, onClose, onSuccess }) => {
  const { currentUser } = useAuth()
  const isTeacherMode = currentUser?.role === 'teacher'

  const [form, setForm] = useState({
    staff_id: isTeacherMode ? String(currentUser?.id || '') : '',
    staff_type: 'TEACHER' as StaffType,
    leave_type: 'CASUAL' as LeaveType,
    from_date: '',
    to_date: '',
    reason: ''
  })
  const [teachers, setTeachers] = useState<any[]>([])
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (isTeacherMode) return
    axios.get(`${API_URL}/school/${schoolId}/teachers?limit=200`).then(r => {
      setTeachers(r.data?.data || [])
    }).catch(() => {})
  }, [schoolId, isTeacherMode])

  const totalDays = form.from_date && form.to_date
    ? Math.max(0, Math.round((new Date(form.to_date).getTime() - new Date(form.from_date).getTime()) / 86400000) + 1)
    : 0

  const handleSave = async () => {
    if ((!isTeacherMode && !form.staff_id) || !form.from_date || !form.to_date) {
      toast.warning('Required fields missing.')
      return
    }
    setSaving(true)
    try {
      const url = isTeacherMode
        ? `${API_URL}/school/${schoolId}/teacher-app/leaves`
        : `${API_URL}/school/${schoolId}/leave/requests`
      await axios.post(url, form)
      toast.success('Leave request create ho gayi!')
      onSuccess()
      onClose()
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Leave create nahi ho saki.')
    } finally {
      setSaving(false)
    }
  }

  const f = (field: string, value: string) => setForm(prev => ({ ...prev, [field]: value }))

  return (
    <div className='modal fade show d-block' style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className='modal-dialog modal-dialog-centered modal-lg'>
        <div className='modal-content'>
          <div className='modal-header bg-primary'>
            <h5 className='modal-title text-white fw-bold'>
              <i className='ki-duotone ki-plus-circle fs-2 text-white me-2'><span className='path1'/><span className='path2'/></i>
              Add Leave Request
            </h5>
            <button className='btn-close btn-close-white' onClick={onClose} />
          </div>
          <div className='modal-body'>
            <div className='row g-4'>
              {!isTeacherMode && (
                <>
                  <div className='col-md-6'>
                    <label className='required fw-semibold fs-7 mb-1'>Staff Type</label>
                    <select className='form-select form-select-solid' value={form.staff_type} onChange={e => f('staff_type', e.target.value)}>
                      <option value='TEACHER'>Teaching Staff</option>
                      <option value='ADMIN'>Admin / Non-Teaching</option>
                    </select>
                  </div>
                  <div className='col-md-6'>
                    <label className='required fw-semibold fs-7 mb-1'>Staff Member</label>
                    <select className='form-select form-select-solid' value={form.staff_id} onChange={e => f('staff_id', e.target.value)}>
                      <option value=''>-- Select --</option>
                      {teachers.map((t: any) => (
                        <option key={t.id} value={t.id}>{t.name || `${t.first_name} ${t.last_name}`}</option>
                      ))}
                    </select>
                  </div>
                </>
              )}
              <div className='col-md-6'>
                <label className='required fw-semibold fs-7 mb-1'>Leave Type</label>
                <select className='form-select form-select-solid' value={form.leave_type} onChange={e => f('leave_type', e.target.value)}>
                  {LEAVE_TYPES.map(lt => (
                    <option key={lt} value={lt}>{LEAVE_TYPE_CONFIG[lt].label}</option>
                  ))}
                </select>
              </div>
              <div className='col-md-3'>
                <label className='required fw-semibold fs-7 mb-1'>From Date</label>
                <input type='date' className='form-control form-control-solid' value={form.from_date} onChange={e => f('from_date', e.target.value)} />
              </div>
              <div className='col-md-3'>
                <label className='required fw-semibold fs-7 mb-1'>To Date</label>
                <input type='date' className='form-control form-control-solid' value={form.to_date} onChange={e => f('to_date', e.target.value)} />
              </div>
              {totalDays > 0 && (
                <div className='col-12'>
                  <div className='alert alert-info py-3 d-flex align-items-center mb-0'>
                    <i className='ki-duotone ki-calendar fs-2 text-info me-3'><span className='path1'/><span className='path2'/></i>
                    <div>Total Leave Duration: <strong>{totalDays} day{totalDays !== 1 ? 's' : ''}</strong></div>
                  </div>
                </div>
              )}
              <div className='col-12'>
                <label className='fw-semibold fs-7 mb-1'>Reason (optional)</label>
                <textarea className='form-control form-control-solid' rows={2} placeholder='Leave ka reason...' value={form.reason} onChange={e => f('reason', e.target.value)} />
              </div>
            </div>
          </div>
          <div className='modal-footer'>
            <button className='btn btn-light' onClick={onClose}>Cancel</button>
            <button className='btn btn-primary' onClick={handleSave} disabled={saving}>
              {saving && <span className='spinner-border spinner-border-sm me-2' />}
              Submit Leave
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Main Leave Page ──────────────────────────────────────────────────────────
const LeaveManagementPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')
  const isTeacherMode = currentUser?.role === 'teacher'

  const [requests, setRequests] = useState<LeaveRequest[]>([])
  const [stats, setStats] = useState<LeaveStats>({ PENDING: 0, APPROVED: 0, REJECTED: 0, CANCELLED: 0 })
  const [loading, setLoading] = useState(false)
  const [totalCount, setTotalCount] = useState(0)

  // Filters
  const [filterStatus, setFilterStatus] = useState<string>('ALL')
  const [filterStaffType, setFilterStaffType] = useState<string>('ALL')
  const [filterLeaveType, setFilterLeaveType] = useState<string>('ALL')
  const [search, setSearch] = useState('')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [page, setPage] = useState(1)
  const limit = 15

  // Modals
  const [reviewTarget, setReviewTarget] = useState<LeaveRequest | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)

  const fetchRequests = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    try {
      const params: any = { page, limit }
      if (filterStatus !== 'ALL') params.status = filterStatus
      if (!isTeacherMode && filterStaffType !== 'ALL') params.staff_type = filterStaffType
      if (fromDate) params.from_date = fromDate
      if (toDate) params.to_date = toDate

      const url = isTeacherMode 
        ? `${API_URL}/school/${schoolId}/teacher-app/leaves`
        : `${API_URL}/school/${schoolId}/leave/requests`

      const { data } = await axios.get(url, { params })
      if (data.success) {
        setRequests(data.data.requests || [])
        setStats(data.data.stats || { PENDING: 0, APPROVED: 0, REJECTED: 0, CANCELLED: 0 })
        setTotalCount(data.data.total || 0)
      }
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Leave requests load nahi hue.')
    } finally {
      setLoading(false)
    }
  }, [schoolId, page, filterStatus, filterStaffType, fromDate, toDate, isTeacherMode])

  useEffect(() => { fetchRequests() }, [fetchRequests])

  const handleReview = async (action: 'APPROVED' | 'REJECTED', remark: string) => {
    if (!reviewTarget) return
    try {
      await axios.patch(`${API_URL}/school/${schoolId}/leave/requests/${reviewTarget.id}/review`, { action, admin_remark: remark })
      toast.success(action === 'APPROVED' ? '✅ Leave approve ho gayi!' : '❌ Leave reject kar di gayi.')
      setReviewTarget(null)
      fetchRequests()
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Review nahi ho saka.')
    }
  }

  const handleCancel = async (id: number) => {
    if (!window.confirm('Is leave request ko cancel karein?')) return
    try {
      const url = isTeacherMode 
        ? `${API_URL}/school/${schoolId}/teacher-app/leaves/${id}/cancel`
        : `${API_URL}/school/${schoolId}/leave/requests/${id}/cancel`
      await axios.patch(url)
      toast.success('Leave cancel ho gayi.')
      fetchRequests()
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Cancel nahi ho saka.')
    }
  }

  const handleDelete = async (id: number) => {
    if (!window.confirm('Is record ko permanently delete karein?')) return
    try {
      await axios.delete(`${API_URL}/school/${schoolId}/leave/requests/${id}`)
      toast.success('Record delete ho gaya.')
      fetchRequests()
    } catch {
      toast.error('Delete nahi ho saka.')
    }
  }

  const filtered = requests.filter(r => {
    if (isTeacherMode) return true
    if (!search) return true
    const s = search.toLowerCase()
    return r.staff_name.toLowerCase().includes(s) || (r.staff_email || '').toLowerCase().includes(s)
  }).filter(r => filterLeaveType === 'ALL' ? true : r.leave_type === filterLeaveType)

  const totalPages = Math.ceil(totalCount / limit)

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* ── Page Header ── */}
        <div className='d-flex align-items-center justify-content-between mb-6'>
          <div>
            <h1 className='text-gray-900 fw-bolder fs-2 mb-1'>
              {isTeacherMode ? 'My Leave Workspace' : 'Leave Management'}
            </h1>
            <div className='text-muted fs-7'>
              {isTeacherMode ? 'Apne leave requests ko check aur request karein' : 'Staff leave requests ko manage aur approve karein'}
            </div>
          </div>
          {isTeacherMode && (
            <button className='btn btn-primary' onClick={() => setShowAddModal(true)}>
              <i className='ki-duotone ki-plus-circle fs-2 me-1'><span className='path1'/><span className='path2'/></i>
              Add Leave Request
            </button>
          )}
        </div>

        {/* ── Stat Cards (clickable filters) ── */}
        <div className='row g-4 mb-6'>
          <StatCard label='Pending' value={stats.PENDING} color='warning' icon='ki-timer' active={filterStatus === 'PENDING'} onClick={() => setFilterStatus(prev => prev === 'PENDING' ? 'ALL' : 'PENDING')} />
          <StatCard label='Approved' value={stats.APPROVED} color='success' icon='ki-check-circle' active={filterStatus === 'APPROVED'} onClick={() => setFilterStatus(prev => prev === 'APPROVED' ? 'ALL' : 'APPROVED')} />
          <StatCard label='Rejected' value={stats.REJECTED} color='danger' icon='ki-cross-circle' active={filterStatus === 'REJECTED'} onClick={() => setFilterStatus(prev => prev === 'REJECTED' ? 'ALL' : 'REJECTED')} />
          <StatCard label='Cancelled' value={stats.CANCELLED} color='secondary' icon='ki-minus-circle' active={filterStatus === 'CANCELLED'} onClick={() => setFilterStatus(prev => prev === 'CANCELLED' ? 'ALL' : 'CANCELLED')} />
        </div>

        {/* ── Filter Card ── */}
        <div className='card card-flush mb-5'>
          <div className='card-body py-4'>
            <div className='row g-3 align-items-end'>
              {!isTeacherMode ? (
                <>
                  <div className='col-md-3'>
                    <label className='fw-semibold fs-8 text-gray-600 mb-1'>Search</label>
                    <div className='d-flex align-items-center position-relative'>
                      <i className='ki-duotone ki-magnifier fs-3 position-absolute ms-3'><span className='path1'/><span className='path2'/></i>
                      <input className='form-control form-control-solid form-control-sm ps-10' placeholder='Staff name or email...' value={search} onChange={e => setSearch(e.target.value)} />
                    </div>
                  </div>
                  <div className='col-md-2'>
                    <label className='fw-semibold fs-8 text-gray-600 mb-1'>Staff Type</label>
                    <select className='form-select form-select-solid form-select-sm' value={filterStaffType} onChange={e => { setFilterStaffType(e.target.value); setPage(1) }}>
                      <option value='ALL'>All Staff</option>
                      <option value='TEACHER'>Teaching</option>
                      <option value='ADMIN'>Admin / Non-Teaching</option>
                    </select>
                  </div>
                </>
              ) : null}
              <div className={isTeacherMode ? 'col-md-4' : 'col-md-2'}>
                <label className='fw-semibold fs-8 text-gray-600 mb-1'>Leave Type</label>
                <select className='form-select form-select-solid form-select-sm' value={filterLeaveType} onChange={e => setFilterLeaveType(e.target.value)}>
                  <option value='ALL'>All Types</option>
                  {LEAVE_TYPES.map(lt => <option key={lt} value={lt}>{LEAVE_TYPE_CONFIG[lt].label}</option>)}
                </select>
              </div>
              <div className={isTeacherMode ? 'col-md-3' : 'col-md-2'}>
                <label className='fw-semibold fs-8 text-gray-600 mb-1'>From</label>
                <input type='date' className='form-control form-control-solid form-control-sm' value={fromDate} onChange={e => { setFromDate(e.target.value); setPage(1) }} />
              </div>
              <div className={isTeacherMode ? 'col-md-3' : 'col-md-2'}>
                <label className='fw-semibold fs-8 text-gray-600 mb-1'>To</label>
                <input type='date' className='form-control form-control-solid form-control-sm' value={toDate} onChange={e => { setToDate(e.target.value); setPage(1) }} />
              </div>
              <div className={isTeacherMode ? 'col-md-2' : 'col-md-1'}>
                <button className='btn btn-light btn-sm w-100' onClick={() => { setFromDate(''); setToDate(''); setSearch(''); setFilterStatus('ALL'); setFilterStaffType('ALL'); setFilterLeaveType('ALL'); setPage(1) }}>
                  Reset
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ── Leave Table ── */}
        <div className='card card-flush'>
          <div className='card-header py-5'>
            <h3 className='card-title fw-bold text-gray-800'>
              Leave Requests
              {filterStatus !== 'ALL' && (
                <span className={`badge badge-light-${STATUS_CONFIG[filterStatus as LeaveStatus]?.color} ms-2`}>{filterStatus}</span>
              )}
            </h3>
            <div className='card-toolbar'>
              <span className='text-muted fs-8 me-3'>{totalCount} total records</span>
              <button className='btn btn-light-primary btn-sm' onClick={fetchRequests} disabled={loading}>
                <i className='ki-duotone ki-arrows-loop fs-4'><span className='path1'/><span className='path2'/></i>
                {loading ? 'Loading...' : 'Refresh'}
              </button>
            </div>
          </div>

          <div className='card-body pt-0'>
            {loading ? (
              <div className='text-center py-12'>
                <div className='spinner-border text-primary' style={{ width: 40, height: 40 }} />
                <div className='text-muted mt-3 fs-6'>Leave records load ho rahe hain...</div>
              </div>
            ) : filtered.length === 0 ? (
              <div className='text-center py-12'>
                <i className='ki-duotone ki-calendar-search fs-5x text-gray-300 mb-4'><span className='path1'/><span className='path2'/><span className='path3'/><span className='path4'/></i>
                <div className='text-muted fs-6'>Koi leave request nahi mili</div>
                <div className='text-muted fs-8 mt-1'>Filter change karein ya naya request add karein</div>
              </div>
            ) : (
              <div className='table-responsive'>
                <table className='table align-middle table-row-dashed table-row-gray-200 fs-7 gy-4'>
                  <thead>
                    <tr className='text-start text-gray-400 fw-bold text-uppercase fs-8 gs-0'>
                      <th className='w-30px'>#</th>
                      {!isTeacherMode && <th className='min-w-180px'>Staff Member</th>}
                      <th className='min-w-100px'>Leave Type</th>
                      <th className='min-w-200px'>Duration</th>
                      <th>Reason</th>
                      <th className='min-w-100px'>Status</th>
                      <th className='min-w-120px text-end'>Actions</th>
                    </tr>
                  </thead>
                  <tbody className='fw-semibold text-gray-600'>
                    {filtered.map((r, idx) => {
                      const sc = STATUS_CONFIG[r.status]
                      const ltc = LEAVE_TYPE_CONFIG[r.leave_type]
                      return (
                        <tr key={r.id}>
                          <td className='text-muted fs-8'>{(page - 1) * limit + idx + 1}</td>
                          {!isTeacherMode && (
                            <td>
                              <div className='d-flex align-items-center'>
                                <div className='symbol symbol-circle symbol-35px me-3'>
                                  <div className={`symbol-label bg-light-primary text-primary fw-bold fs-7`}>
                                    {r.staff_name.charAt(0).toUpperCase()}
                                  </div>
                                </div>
                                <div>
                                  <div className='text-gray-800 fw-bold text-hover-primary mb-0'>{r.staff_name}</div>
                                  <div className='text-muted fs-9'>{r.staff_designation || r.staff_type}</div>
                                </div>
                              </div>
                            </td>
                          )}
                          <td>
                            <span className={`badge badge-light-${ltc?.color || 'primary'} fw-semibold`}>{ltc?.label || r.leave_type}</span>
                          </td>
                          <td>
                            <div className='fw-bold text-gray-800'>{r.from_date} → {r.to_date}</div>
                            <div className='text-muted fs-9'>{r.total_days} day{r.total_days !== 1 ? 's' : ''}</div>
                          </td>
                          <td>
                            <div className='text-gray-600 fs-8 mw-200px text-truncate' title={r.reason || ''}>
                              {r.reason || <span className='text-muted'>—</span>}
                            </div>
                          </td>
                          <td>
                            <span className={`badge badge-light-${sc.color} d-flex align-items-center gap-1 w-fit`}>
                              <i className={`ki-duotone ${sc.icon} fs-7 text-${sc.color}`}><span className='path1'/><span className='path2'/></i>
                              {sc.label}
                            </span>
                            {r.admin_remark && (
                              <div className='text-muted fs-9 mt-1 fst-italic'>&quot;{r.admin_remark}&quot;</div>
                            )}
                          </td>
                          <td className='text-end'>
                            <div className='d-flex gap-1 justify-content-end'>
                              {!isTeacherMode && r.status === 'PENDING' && (
                                <button className='btn btn-icon btn-sm btn-light-success' title='Review' onClick={() => setReviewTarget(r)}>
                                  <i className='ki-duotone ki-check fs-4'><span className='path1'/><span className='path2'/></i>
                                </button>
                              )}
                              {r.status === 'PENDING' && (
                                <button className='btn btn-icon btn-sm btn-light-warning' title='Cancel' onClick={() => handleCancel(r.id)}>
                                  <i className='ki-duotone ki-cross fs-4'><span className='path1'/><span className='path2'/></i>
                                </button>
                              )}
                              {!isTeacherMode && (
                                <button className='btn btn-icon btn-sm btn-light-danger' title='Delete' onClick={() => handleDelete(r.id)}>
                                  <i className='ki-duotone ki-trash fs-4'><span className='path1'/><span className='path2'/><span className='path3'/><span className='path4'/><span className='path5'/></i>
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className='d-flex justify-content-between align-items-center mt-5 pt-3 border-top border-gray-200'>
                <div className='text-muted fs-8'>
                  Showing {Math.min((page - 1) * limit + 1, totalCount)}–{Math.min(page * limit, totalCount)} of {totalCount}
                </div>
                <div className='d-flex gap-2'>
                  <button className='btn btn-sm btn-light' disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
                    <i className='ki-duotone ki-left fs-4'><span className='path1'/><span className='path2'/></i>
                  </button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).filter(p => Math.abs(p - page) <= 2).map(p => (
                    <button key={p} className={`btn btn-sm ${p === page ? 'btn-primary' : 'btn-light'}`} onClick={() => setPage(p)}>{p}</button>
                  ))}
                  <button className='btn btn-sm btn-light' disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
                    <i className='ki-duotone ki-right fs-4'><span className='path1'/><span className='path2'/></i>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

      </Content>

      {/* Modals */}
      {reviewTarget && (
        <ReviewModal leave={reviewTarget} onClose={() => setReviewTarget(null)} onSubmit={handleReview} />
      )}
      {showAddModal && (
        <AddLeaveModal schoolId={schoolId} onClose={() => setShowAddModal(false)} onSuccess={fetchRequests} />
      )}
    </>
  )
}

// ─── Wrapper ──────────────────────────────────────────────────────────────────
const LeaveWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[{ title: 'Staff', path: '/staff/teachers', isSeparator: false, isActive: false }]}>
      Leave Management
    </PageTitle>
    <LeaveManagementPage />
  </>
)

export { LeaveWrapper, LeaveManagementPage as LeavePage }
