import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { BulkTeacherModal } from './BulkTeacherModal'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { Modal, Button, Alert } from 'react-bootstrap'
import { toAbsoluteUrl, getInstitutionType } from '../../../_metronic/helpers'
import { useAuth } from '../auth'
import { getAcademicSessions, getTeacherAllocations } from '../academic/core/_requests'
import {
  createTeacher, getTeachers, getTeacherById, updateTeacherCore,
  updateTeacherProfile, updateTeacherBank,
  addTeacherExperience, updateTeacherExperience, deleteTeacherExperience,
  addTeacherDocument, deleteTeacherDocument, updateTeacherDocumentStatus,
  toggleTeacherStatus, updateTeacherPermissions,
  downloadTeachersExcel, downloadTeachersPdf,
} from '../teachers/core/_requests'
import {
  TeacherModel, TeacherExperience,
  CreateTeacherPayload, UpdateTeacherProfilePayload,
  UpdateTeacherBankPayload, AddTeacherExperiencePayload,
} from '../teachers/core/_models'

// ─── Constants ────────────────────────────────────────────────────────────────
const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
const CATEGORIES = ['General', 'OBC', 'SC', 'ST', 'EWS', 'Other']
const GENDERS = ['male', 'female', 'other']
const MARITAL_STATUSES = ['single', 'married', 'divorced', 'widowed']
const EMPLOYMENT_TYPES = ['permanent', 'contract', 'part-time', 'guest']

// ─── Teacher Permission Modules (View + Manage per module) ───────────────────
const PERMISSION_MODULES = [
  { key: 'students',      label: 'Students' },
  { key: 'attendance',    label: 'Attendance' },
  { key: 'timetable',     label: 'Timetable' },
  { key: 'exams',         label: 'Examinations' },
  { key: 'results',       label: 'Results' },
  { key: 'fees',          label: 'Fees' },
  { key: 'library',       label: 'Library' },
  { key: 'communication', label: 'Communication' },
  { key: 'notices',       label: 'Notices' },
  { key: 'reports',       label: 'Reports' },
  { key: 'transport',     label: 'Transport' },
  { key: 'hostel',        label: 'Hostel' },
]

type Tab = 'profile' | 'bank' | 'experience' | 'documents' | 'permissions'

// ─── Completion Progress Bar ──────────────────────────────────────────────────
const CompletionBar: FC<{ pct: number; status?: { profile: boolean; experience: boolean; documents: boolean; bank_details: boolean } }> = ({ pct, status }) => {
  const color = pct === 100 ? 'success' : pct >= 50 ? 'warning' : 'danger'
  return (
    <div>
      <div className='d-flex justify-content-between mb-1'>
        <span className={`fs-8 fw-bold text-${color}`}>{pct ?? 0}% Complete</span>
      </div>
      <div className='h-4px w-100 bg-light-secondary rounded'>
        <div className={`bg-${color} rounded h-4px`} style={{ width: `${pct ?? 0}%`, transition: 'width 0.4s ease' }}></div>
      </div>
      {status && (
        <div className='d-flex gap-2 mt-1 flex-wrap'>
          {[
            { key: 'profile', label: 'Profile' },
            { key: 'experience', label: 'Exp' },
            { key: 'bank_details', label: 'Bank' },
            { key: 'documents', label: 'Docs' },
          ].map(({ key, label }) => (
            <span key={key} className={`badge fs-9 badge-light-${(status as any)[key] ? 'success' : 'danger'}`}>
              {(status as any)[key] ? '✓' : '✗'} {label}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Check Icon ───────────────────────────────────────────────────────────────
const CheckIcon: FC<{ exists: boolean; title?: string }> = ({ exists, title }) => (
  <span title={title}>
    {exists
      ? <i className="ki-duotone ki-check-circle fs-2 text-success"><span className="path1"></span><span className="path2"></span></i>
      : <i className="ki-duotone ki-cross-circle fs-2 text-gray-300"><span className="path1"></span><span className="path2"></span></i>
    }
  </span>
)

// ─── Main Page ────────────────────────────────────────────────────────────────
const TeachersPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // ─── List State ──────────────────────────────────────────────────────────
  const [teachers, setTeachers] = useState<TeacherModel[]>([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [listError, setListError] = useState<string | null>(null)
  const [listSuccess, setListSuccess] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<'standard' | 'excel'>('standard')

  // ─── Academic Session & Allocations State ────────────────────────────────
  const [sessions, setSessions] = useState<any[]>([])
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null)
  const [allocations, setAllocations] = useState<any[]>([])
  const [allocationsLoading, setAllocationsLoading] = useState<boolean>(false)

  // Load academic sessions on mount
  useEffect(() => {
    if (schoolId) {
      getAcademicSessions(schoolId, 1, 100)
        .then(res => {
          if (res.data?.success) {
            const list = res.data.data.sessions || []
            setSessions(list)
            const cur = list.find((s: any) => s.is_current) || list[0]
            if (cur) {
              setCurrentSessionId(cur.id)
            }
          }
        })
        .catch(() => {})
    }
  }, [schoolId])

  // Load teacher allocations when session changes
  useEffect(() => {
    if (schoolId && currentSessionId) {
      setAllocationsLoading(true)
      getTeacherAllocations(schoolId, { academic_session_id: currentSessionId })
        .then(res => {
          if (res.data?.success) {
            setAllocations(res.data.data || [])
          }
        })
        .catch(() => {})
        .finally(() => setAllocationsLoading(false))
    } else {
      setAllocations([])
    }
  }, [schoolId, currentSessionId])

  // ─── Create/Edit Modal State ──────────────────────────────────────────────────
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showBulkModal, setShowBulkModal] = useState(false)
  const [createSaving, setCreateSaving] = useState(false)
  const [createError, setCreateError] = useState<string | null>(null)
  const [isEditMode, setIsEditMode] = useState(false)
  const [currentTeacherId, setCurrentTeacherId] = useState<number | null>(null)
  const [createForm, setCreateForm] = useState<CreateTeacherPayload & { password?: string }>({
    name: '', email: '', password: '', mobile_number: '',
    profession_id: undefined, employment_type: 'permanent',
    joining_date: new Date().toISOString().split('T')[0],
  })

  // ─── Manage Modal State ──────────────────────────────────────────────────
  const [showManageModal, setShowManageModal] = useState(false)
  const [activeTab, setActiveTab] = useState<Tab>('profile')
  const [selectedTeacher, setSelectedTeacher] = useState<TeacherModel | null>(null)
  const [manageSaving, setManageSaving] = useState(false)
  const [manageError, setManageError] = useState<string | null>(null)
  const [manageSuccess, setManageSuccess] = useState<string | null>(null)

  // Sub-forms
  const [profileImageFile, setProfileImageFile] = useState<File | null>(null)
  const [profileForm, setProfileForm] = useState<UpdateTeacherProfilePayload>({
    dob: '', gender: 'male', blood_group: 'O+', marital_status: 'single',
    religion: '', category: 'General', father_name: '', mother_name: '',
    spouse_name: '', highest_qualification: '', present_address: '',
    permanent_address: '', emergency_contact_name: '', emergency_contact_phone: '',
  })

  const [bankForm, setBankForm] = useState<UpdateTeacherBankPayload>({
    bank_name: '', account_number: '', ifsc_code: '',
    branch_name: '', account_holder_name: '',
  })

  const [expForm, setExpForm] = useState<AddTeacherExperiencePayload>({
    school_name: '', designation: '', from_date: '', to_date: '',
    is_current: false, reason_for_leaving: '',
  })

  const [experiences, setExperiences] = useState<TeacherExperience[]>([])
  const [editExpId, setEditExpId] = useState<number | null>(null)
  const [editExpForm, setEditExpForm] = useState<Partial<AddTeacherExperiencePayload>>({})
  const [expActionLoading, setExpActionLoading] = useState<number | null>(null)

  const [docType, setDocType] = useState('')
  const [docFile, setDocFile] = useState<File | null>(null)
  const [docDragOver, setDocDragOver] = useState(false)
  const [documents, setDocuments] = useState<any[]>([])
  const [docActionLoading, setDocActionLoading] = useState<number | null>(null)

  // ─── Permissions State ───────────────────────────────────────────────────
  const [selectedPerms, setSelectedPerms] = useState<string[]>([])

  // ─── Load Teachers ────────────────────────────────────────────────────────
  const fetchTeachers = useCallback(async () => {
    if (!schoolId) return
    setLoading(true); setListError(null)
    try {
      const { data } = await getTeachers(schoolId, { limit: 100 })
      if (data.success) setTeachers(data.data.teachers || [])
    } catch (err: any) {
      setListError(err.response?.data?.message || 'Failed to load teachers')
    } finally { setLoading(false) }
  }, [schoolId])

  useEffect(() => { fetchTeachers() }, [fetchTeachers])

  const showListSuccess = (msg: string) => {
    setListSuccess(msg)
    setTimeout(() => setListSuccess(null), 3000)
    fetchTeachers()
  }

  const handleExportExcel = async () => {
    try {
      await downloadTeachersExcel(schoolId, { search })
    } catch (err: any) {
      alert('Failed to export Excel. Please try again.')
    }
  }

  const handleExportPdf = async () => {
    try {
      await downloadTeachersPdf(schoolId, { search })
    } catch (err: any) {
      alert('Failed to export PDF. Please try again.')
    }
  }

  // ─── Create / Edit Teacher Core ───────────────────────────────────────────
  const handleOpenCreateModal = (teacher?: TeacherModel) => {
    setCreateError(null)
    if (teacher) {
      setIsEditMode(true)
      setCurrentTeacherId(teacher.id)
      setCreateForm({
        name: teacher.name,
        email: teacher.email,
        password: '',
        mobile_number: teacher.phone || '',
        profession_id: teacher.profession_id,
        employment_type: teacher.employment_type || 'permanent',
        joining_date: teacher.joining_date?.split('T')[0] || new Date().toISOString().split('T')[0],
      })
    } else {
      setIsEditMode(false)
      setCurrentTeacherId(null)
      setCreateForm({
        name: '', email: '', password: '', mobile_number: '',
        profession_id: undefined, employment_type: 'permanent',
        joining_date: new Date().toISOString().split('T')[0],
      })
    }
    setShowCreateModal(true)
  }

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    setCreateSaving(true); setCreateError(null)
    try {
      if (isEditMode && currentTeacherId) {
        const { password, ...rest } = createForm
        const payload: Partial<CreateTeacherPayload> = password ? { ...rest, password } : rest
        await updateTeacherCore(schoolId, currentTeacherId, payload)
        showListSuccess('Teacher updated successfully!')
      } else {
        await createTeacher(schoolId, createForm as CreateTeacherPayload)
        showListSuccess('Teacher added successfully!')
      }
      setShowCreateModal(false)
    } catch (err: any) {
      if (err.response?.status === 409) {
        setCreateError(err.response?.data?.message || 'Conflict: Email or Mobile number is already taken.')
      } else {
        setCreateError(err.response?.data?.message || 'Failed to process request.')
      }
    } finally { setCreateSaving(false) }
  }

  // ─── Manage Modal ─────────────────────────────────────────────────────────
  const openManageModal = async (teacher: TeacherModel) => {
    setSelectedTeacher(teacher)
    setActiveTab('profile')
    setManageError(null); setManageSuccess(null)
    setProfileImageFile(null)
    setExperiences([]); setDocuments([])
    setDocType(''); setDocFile(null)
    setEditExpId(null); setEditExpForm({})
    setShowManageModal(true)

    try {
      const { data } = await getTeacherById(schoolId, teacher.id)
      const t = data.data.teacher
      setSelectedTeacher(t)
      setSelectedPerms(Array.isArray(t.permissions) ? t.permissions : [])

      if (t.profile) {
        setProfileForm({
          dob: t.profile.dob || '', gender: t.profile.gender || 'male',
          blood_group: t.profile.blood_group || 'O+',
          marital_status: t.profile.marital_status || 'single',
          religion: t.profile.religion || '', category: t.profile.category || 'General',
          father_name: t.profile.father_name || '', mother_name: t.profile.mother_name || '',
          spouse_name: t.profile.spouse_name || '',
          highest_qualification: t.profile.highest_qualification || '',
          present_address: t.profile.present_address || '',
          permanent_address: t.profile.permanent_address || '',
          emergency_contact_name: t.profile.emergency_contact_name || '',
          emergency_contact_phone: t.profile.emergency_contact_phone || '',
        })
      }
      if (t.bank_details) {
        setBankForm({
          bank_name: t.bank_details.bank_name || '',
          account_number: t.bank_details.account_number || '',
          ifsc_code: t.bank_details.ifsc_code || '',
          branch_name: t.bank_details.branch_name || '',
          account_holder_name: t.bank_details.account_holder_name || '',
        })
      }
      if (t.experiences) setExperiences(t.experiences)
      if (t.documents) setDocuments(t.documents)
    } catch { }
  }

  const manageToast = (msg: string) => {
    setManageSuccess(msg)
    setTimeout(() => setManageSuccess(null), 3000)
    fetchTeachers()
    // Re-fetch full detail to refresh completion_status
    if (selectedTeacher) {
      getTeacherById(schoolId, selectedTeacher.id)
        .then(r => setSelectedTeacher(r.data.data.teacher))
        .catch(() => { })
    }
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedTeacher) return
    setManageSaving(true); setManageError(null)
    try {
      await updateTeacherProfile(schoolId, selectedTeacher.id, profileForm, profileImageFile)
      manageToast('Profile updated successfully!')
    } catch (err: any) { setManageError(err.response?.data?.message || 'Error saving profile') }
    finally { setManageSaving(false) }
  }

  const handleSaveBank = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedTeacher) return
    setManageSaving(true); setManageError(null)
    try {
      await updateTeacherBank(schoolId, selectedTeacher.id, bankForm)
      manageToast('Bank details saved successfully!')
    } catch (err: any) { setManageError(err.response?.data?.message || 'Error saving bank details') }
    finally { setManageSaving(false) }
  }

  const handleAddExperience = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedTeacher) return
    setManageSaving(true); setManageError(null)
    try {
      await addTeacherExperience(schoolId, selectedTeacher.id, expForm)
      // Refresh experiences
      const { data } = await getTeacherById(schoolId, selectedTeacher.id)
      setExperiences(data.data.teacher.experiences || [])
      setSelectedTeacher(data.data.teacher)
      setExpForm({ school_name: '', designation: '', from_date: '', to_date: '', is_current: false, reason_for_leaving: '' })
      setManageSuccess('Experience added!')
      setTimeout(() => setManageSuccess(null), 2000)
      fetchTeachers()
    } catch (err: any) { setManageError(err.response?.data?.message || 'Error adding experience') }
    finally { setManageSaving(false) }
  }

  const handleAddDocument = async () => {
    if (!selectedTeacher || !docType.trim() || !docFile) return
    setManageSaving(true); setManageError(null)
    try {
      await addTeacherDocument(schoolId, selectedTeacher.id, docType, docFile)
      const { data } = await getTeacherById(schoolId, selectedTeacher.id)
      setDocuments(data.data.teacher.documents || [])
      setSelectedTeacher(data.data.teacher)
      setDocType(''); setDocFile(null)
      setManageSuccess('Document uploaded successfully!')
      setTimeout(() => setManageSuccess(null), 3000)
      fetchTeachers()
    } catch (err: any) { setManageError(err.response?.data?.message || 'Failed to upload document') }
    finally { setManageSaving(false) }
  }

  const handleDocFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault(); setDocDragOver(false)
    const file = e.dataTransfer.files?.[0]
    if (file) setDocFile(file)
  }

  // ─── Experience Edit / Delete ──────────────────────────────────────────────
  const handleDeleteExperience = async (expId: number) => {
    if (!selectedTeacher || !window.confirm('Delete this experience entry?')) return
    setExpActionLoading(expId)
    try {
      await deleteTeacherExperience(schoolId, selectedTeacher.id, expId)
      setExperiences(prev => prev.filter(e => e.id !== expId))
      setManageSuccess('Experience deleted.')
      setTimeout(() => setManageSuccess(null), 2000)
      fetchTeachers()
    } catch (err: any) { setManageError(err.response?.data?.message || 'Error deleting experience') }
    finally { setExpActionLoading(null) }
  }

  const handleUpdateExperience = async (expId: number) => {
    if (!selectedTeacher) return
    setExpActionLoading(expId)
    try {
      await updateTeacherExperience(schoolId, selectedTeacher.id, expId, editExpForm)
      const { data } = await getTeacherById(schoolId, selectedTeacher.id)
      setExperiences(data.data.teacher.experiences || [])
      setSelectedTeacher(data.data.teacher)
      setEditExpId(null); setEditExpForm({})
      setManageSuccess('Experience updated!')
      setTimeout(() => setManageSuccess(null), 2000)
      fetchTeachers()
    } catch (err: any) { setManageError(err.response?.data?.message || 'Error updating experience') }
    finally { setExpActionLoading(null) }
  }

  // ─── Document Delete / Status ──────────────────────────────────────────────
  const handleDeleteDocument = async (docId: number) => {
    if (!selectedTeacher || !window.confirm('Delete this document permanently?')) return
    setDocActionLoading(docId)
    try {
      await deleteTeacherDocument(schoolId, selectedTeacher.id, docId)
      setDocuments(prev => prev.filter(d => d.id !== docId))
      setManageSuccess('Document deleted.')
      setTimeout(() => setManageSuccess(null), 2000)
      fetchTeachers()
    } catch (err: any) { setManageError(err.response?.data?.message || 'Error deleting document') }
    finally { setDocActionLoading(null) }
  }

  const handleUpdateDocStatus = async (docId: number, status: 'Verified' | 'Rejected' | 'Pending') => {
    if (!selectedTeacher) return
    setDocActionLoading(docId)
    try {
      await updateTeacherDocumentStatus(schoolId, selectedTeacher.id, docId, status)
      setDocuments(prev => prev.map(d => d.id === docId ? { ...d, verification_status: status } : d))
      setManageSuccess(`Document marked as ${status}.`)
      setTimeout(() => setManageSuccess(null), 2000)
    } catch (err: any) { setManageError(err.response?.data?.message || 'Error updating status') }
    finally { setDocActionLoading(null) }
  }

  const handleToggleStatus = async (teacher: TeacherModel) => {
    try {
      await toggleTeacherStatus(schoolId, teacher.id)
      showListSuccess(`${teacher.name} marked as ${teacher.is_active ? 'Inactive' : 'Active'}`)
    } catch (err: any) {
      setListError(err.response?.data?.message || 'Failed to toggle status')
    }
  }

  const handleSavePermissions = async () => {
    if (!selectedTeacher) return
    setManageSaving(true); setManageError(null)
    try {
      await updateTeacherPermissions(schoolId, selectedTeacher.id, { permissions: selectedPerms })
      manageToast('Permissions updated successfully!')
      // update local selectedTeacher permissions
      setSelectedTeacher(prev => prev ? { ...prev, permissions: selectedPerms } : prev)
    } catch (err: any) {
      setManageError(err.response?.data?.message || 'Error updating permissions')
    } finally { setManageSaving(false) }
  }

  const togglePerm = (key: string) => {
    setSelectedPerms(prev =>
      prev.includes(key) ? prev.filter(p => p !== key) : [...prev, key]
    )
  }

  // ─── Filter ───────────────────────────────────────────────────────────────
  const filtered = teachers.filter(t =>
    `${t.name} ${t.email} ${t.phone || ''}`.toLowerCase().includes(search.toLowerCase())
  )

  const stats = {
    total: teachers.length,
    active: teachers.filter(t => t.is_active).length,
    complete: teachers.filter(t => (t.completion_percentage || 0) === 100).length,
  }

  // Completion status from currently selected teacher for Manage modal sidebar
  const cs = selectedTeacher?.completion_status

  return (
    <>
      <Content>

        {listError && <div className='alert alert-danger mb-4'>{listError}</div>}
        {listSuccess && <div className='alert alert-success mb-4'>{listSuccess}</div>}

        {/* ── Teachers Table with compact stats in header ── */}
        <div className='card card-flush'>
          <div className='card-header align-items-center py-5 gap-3'>
            {/* Title + compact stat pills */}
            <div className='card-title'>
              <h3 className='fw-bold mb-0 me-4'>Teachers</h3>
              {!loading && (
                <div className='d-flex align-items-center gap-3'>
                  <span className='d-flex align-items-center gap-1 text-gray-600 fs-7 fw-semibold'>
                    <span className='bullet bullet-dot bg-primary h-6px w-6px'></span>
                    Total: <span className='text-primary fw-bold ms-1'>{stats.total}</span>
                  </span>
                  <span className='d-flex align-items-center gap-1 text-gray-600 fs-7 fw-semibold'>
                    <span className='bullet bullet-dot bg-primary h-6px w-6px'></span>
                    Active: <span className='text-primary fw-bold ms-1'>{stats.active}</span>
                  </span>
                  <span className='d-flex align-items-center gap-1 text-gray-600 fs-7 fw-semibold'>
                    <span className='bullet bullet-dot bg-primary h-6px w-6px'></span>
                    Complete: <span className='text-primary fw-bold ms-1'>{stats.complete}</span>
                  </span>
                </div>
              )}
            </div>
            {/* Search + Add button */}
            <div className='card-toolbar gap-3'>
              {/* Academic Session Filter */}
              <div className='w-150px'>
                <select
                  className='form-select form-select-solid'
                  value={currentSessionId || ''}
                  onChange={e => setCurrentSessionId(e.target.value ? Number(e.target.value) : null)}
                  title='Filter by Academic Session'
                >
                  <option value=''>All Sessions</option>
                  {sessions.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.session_year} {s.is_current ? '(Current)' : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div className='d-flex align-items-center position-relative'>
                <i className='ki-duotone ki-magnifier fs-3 position-absolute ms-4'>
                  <span className='path1'></span><span className='path2'></span>
                </i>
                <input
                  type='text'
                  className='form-control form-control-solid w-200px ps-14'
                  placeholder='Search...'
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </div>
              <button className='btn btn-light-success btn-sm' onClick={handleExportExcel} title="Export as Excel">
                <i className='ki-duotone ki-file-down fs-3'><span className='path1'></span><span className='path2'></span></i> Export Excel
              </button>
              <button className='btn btn-light-danger btn-sm' onClick={handleExportPdf} title="Export as PDF">
                <i className='ki-duotone ki-document fs-3'><span className='path1'></span><span className='path2'></span></i> Export PDF
              </button>
              <button className='btn btn-light-primary btn-sm' onClick={() => setShowBulkModal(true)}>
                <i className='ki-duotone ki-file-up fs-3'><span className='path1'></span><span className='path2'></span></i> Bulk Import
              </button>
              <button className='btn btn-primary btn-sm' onClick={() => handleOpenCreateModal()}>
                <i className='ki-duotone ki-plus fs-3'></i> Add Teacher
              </button>
              <div className='btn-group ms-2' role='group'>
                  <button className={`btn btn-sm btn-icon ${viewMode === 'standard' ? 'btn-primary' : 'btn-light-primary'}`} onClick={() => setViewMode('standard')} title="Standard View">
                      <i className='ki-duotone ki-element-11 fs-3'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span></i>
                  </button>
                  <button className={`btn btn-sm btn-icon ${viewMode === 'excel' ? 'btn-primary' : 'btn-light-primary'}`} onClick={() => setViewMode('excel')} title="Excel View">
                      <i className='ki-duotone ki-row-horizontal fs-3'><span className='path1'></span><span className='path2'></span></i>
                  </button>
              </div>
            </div>
          </div>

          <div className='card-body pt-0'>
            <div className='table-responsive'>
              {viewMode === 'standard' ? (
                <table className='table align-middle table-row-dashed fs-7 gy-4'>
                  <thead>
                    <tr className='text-start text-muted fw-bold fs-7 text-uppercase gs-0 border-bottom border-gray-100'>
                      <th className='w-30px'>#</th>
                      <th className='min-w-180px'>Teacher</th>
                      <th>Type</th>
                      <th className='min-w-150px'>{getInstitutionType() === 'COACHING' ? 'Allocated Batches' : 'Classes & Subjects'}</th>
                      <th className='text-center'>Profile</th>
                      <th className='text-center'>Bank</th>
                      <th className='text-center'>Exp</th>
                      <th className='text-center'>Docs</th>
                      <th className='min-w-100px'>Completion</th>
                      <th>Status</th>
                      <th className='text-end min-w-80px'>Actions</th>
                    </tr>
                  </thead>
                  <tbody className='text-gray-600 fw-semibold'>
                    {loading ? (
                      <tr><td colSpan={11} className='text-center py-10'>
                        <span className='spinner-border spinner-border-sm text-primary me-2'></span>
                        <span className='text-muted'>Loading teachers...</span>
                      </td></tr>
                    ) : filtered.length === 0 ? (
                      <tr><td colSpan={11} className='text-center py-12'>
                        <div className='d-flex flex-column align-items-center'>
                          <i className='ki-duotone ki-teacher fs-3x text-gray-300 mb-3'><span className='path1'></span><span className='path2'></span></i>
                          <div className='text-muted fs-6'>No teachers found.</div>
                          <button className='btn btn-sm btn-light-primary mt-3' onClick={() => handleOpenCreateModal()}>Add First Teacher</button>
                        </div>
                      </td></tr>
                    ) : filtered.map((t, idx) => {
                      const cs = t.completion_status
                      const pct = t.completion_percentage ?? 0
                      const docsCount = Array.isArray(t.documents) ? t.documents.length : 0

                      return (
                        <tr key={t.id}>
                          <td className='text-gray-400 fs-8'>{idx + 1}</td>
                          <td>
                            <div className='d-flex align-items-center'>
                              <div className='symbol symbol-35px me-3'>
                                {(t.profile as any)?.profile_image ? (
                                  <img src={(t.profile as any).profile_image} alt='profile' style={{ objectFit: 'cover' }} />
                                ) : (
                                  <img src={toAbsoluteUrl('media/svg/avatars/blank.svg')} alt='Avatar' />
                                )}
                              </div>
                              <div>
                                <div className='text-gray-800 fw-bold fs-6'>{t.name}</div>
                                <div className='text-muted fs-8'>{t.email}</div>
                              </div>
                            </div>
                          </td>
                          <td>
                            <span className='badge badge-light-primary fs-8'>{t.employment_type || '—'}</span>
                          </td>
                          <td>
                            <div className='d-flex flex-wrap max-w-250px gap-1'>
                              {(() => {
                                const teacherAllocations = allocations.filter(
                                  a => a.teacher?.id === t.id || a.teacher_id === t.id
                                )
                                if (teacherAllocations.length === 0) {
                                  return <span className='text-muted fs-8'>No allocations</span>
                                }
                                const maxVisible = 2
                                const hasMore = teacherAllocations.length > maxVisible
                                const visibleAllocations = teacherAllocations.slice(0, maxVisible)
                                
                                return (
                                  <>
                                    {visibleAllocations.map(a => {
                                      const isCoaching = getInstitutionType() === 'COACHING'
                                      const isClassTeacher = a.is_class_teacher
                                      const subjectName = a.subject?.name
                                      const className = a.class_name || a.class_section?.class?.name
                                      const sectionName = a.section_name || a.class_section?.section?.name
                                      
                                      let badgeLabel = ''
                                      if (isCoaching) {
                                        badgeLabel = className ? (subjectName ? `${className} (${subjectName})` : className) : 'Batch'
                                      } else {
                                        const classSec = className ? (sectionName ? `${className}-${sectionName}` : className) : 'Class'
                                        if (isClassTeacher) {
                                          badgeLabel = `${classSec} (Class Teacher)`
                                        } else {
                                          badgeLabel = subjectName ? `${classSec} (${subjectName})` : classSec
                                        }
                                      }
                                      
                                      return (
                                        <span
                                          key={a.id}
                                          className={`badge badge-light-${isClassTeacher ? 'success' : 'primary'} fs-8`}
                                        >
                                          {badgeLabel}
                                        </span>
                                      )
                                    })}
                                    
                                    {hasMore && (
                                      <span
                                        className='badge badge-light-secondary fs-8 cursor-pointer'
                                        title={teacherAllocations.slice(maxVisible).map(a => {
                                          const isCoaching = getInstitutionType() === 'COACHING'
                                          const isClassTeacher = a.is_class_teacher
                                          const subjectName = a.subject?.name
                                          const className = a.class_name || a.class_section?.class?.name
                                          const sectionName = a.section_name || a.class_section?.section?.name
                                          if (isCoaching) {
                                            return className ? (subjectName ? `${className} (${subjectName})` : className) : 'Batch'
                                          } else {
                                            const classSec = className ? (sectionName ? `${className}-${sectionName}` : className) : 'Class'
                                            return isClassTeacher ? `${classSec} (Class Teacher)` : (subjectName ? `${classSec} (${subjectName})` : classSec)
                                          }
                                        }).join(', ')}
                                      >
                                        + {teacherAllocations.length - maxVisible} more
                                      </span>
                                    )}
                                  </>
                                )
                              })()}
                            </div>
                          </td>
                          <td className='text-center'><CheckIcon exists={!!cs?.profile} title='Profile' /></td>
                          <td className='text-center'><CheckIcon exists={!!cs?.bank_details} title='Bank' /></td>
                          <td className='text-center'><CheckIcon exists={!!cs?.experience} title='Experience' /></td>
                          <td className='text-center'>
                            {docsCount > 0
                              ? <span className='badge badge-light-primary'>{docsCount}</span>
                              : <CheckIcon exists={false} title='Documents' />}
                          </td>
                          <td>
                            <div className='d-flex align-items-center gap-2'>
                              <div className='progress h-6px w-70px bg-light-primary rounded'>
                                <div
                                  className='progress-bar bg-primary rounded'
                                  style={{ width: `${pct}%` }}
                                />
                              </div>
                              <span className='text-primary fw-bold fs-8'>{pct}%</span>
                            </div>
                          </td>
                          <td>
                            <button
                              className={`btn btn-sm fw-bold ${t.is_active ? 'btn-light-success' : 'btn-light-danger'}`}
                              onClick={() => handleToggleStatus(t)}
                              title={t.is_active ? 'Click to Deactivate' : 'Click to Activate'}
                            >
                              <i className={`ki-duotone ${t.is_active ? 'ki-check-circle' : 'ki-cross-circle'} fs-5 me-1`}>
                                <span className='path1'></span><span className='path2'></span>
                              </i>
                              {t.is_active ? 'Active' : 'Inactive'}
                            </button>
                          </td>
                          <td className='text-end'>
                            <button
                                className='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1'
                                title='Edit'
                                onClick={() => handleOpenCreateModal(t)}
                            >
                                <i className='ki-duotone ki-pencil fs-2'><span className='path1'></span><span className='path2'></span></i>
                            </button>
                            <button
                              className='btn btn-sm btn-light-primary fw-semibold'
                              onClick={() => openManageModal(t)}
                            >
                              Manage
                            </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              ) : (
                <table className='table table-bordered table-striped align-middle fs-8 gy-3 text-nowrap'>
                  <thead className='bg-light'>
                    <tr className='text-start text-muted fw-bolder fs-8 text-uppercase gs-0 border-bottom border-gray-300'>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Employment Type</th>
                      <th>{getInstitutionType() === 'COACHING' ? 'Allocated Batches' : 'Classes & Subjects'}</th>
                      <th>Joining Date</th>
                      <th>DOB</th>
                      <th>Gender</th>
                      <th>Blood Group</th>
                      <th>Highest Qualification</th>
                      <th>Father Name</th>
                      <th>Mother Name</th>
                      <th>Emergency Name</th>
                      <th>Emergency Phone</th>
                      <th>Present Address</th>
                      <th>Permanent Address</th>
                      <th>Bank Name</th>
                      <th>Account Number</th>
                      <th>IFSC Code</th>
                      <th>Status</th>
                      <th className='text-end min-w-100px'>Actions</th>
                    </tr>
                  </thead>
                  <tbody className='text-gray-600 fw-semibold'>
                    {loading ? (
                        <tr><td colSpan={21} className='text-center py-10'><span className='spinner-border spinner-border-sm text-primary me-2'></span>Loading teachers...</td></tr>
                    ) : filtered.length === 0 ? (
                        <tr><td colSpan={21} className='text-center py-5'>No teachers found</td></tr>
                    ) : filtered.map(t => {
                        const profile = t.profile || {} as any;
                        const bank = t.bank_details || {} as any;
                        const teacherAllocations = allocations.filter(
                          a => a.teacher?.id === t.id || a.teacher_id === t.id
                        )
                        const allocationStr = teacherAllocations.map(a => {
                          const isCoaching = getInstitutionType() === 'COACHING'
                          const isClassTeacher = a.is_class_teacher
                          const subjectName = a.subject?.name
                          const className = a.class_name || a.class_section?.class?.name
                          const sectionName = a.section_name || a.class_section?.section?.name
                          if (isCoaching) {
                            return className ? (subjectName ? `${className} (${subjectName})` : className) : 'Batch'
                          } else {
                            const classSec = className ? (sectionName ? `${className}-${sectionName}` : className) : 'Class'
                            return isClassTeacher ? `${classSec} (Class Teacher)` : (subjectName ? `${classSec} (${subjectName})` : classSec)
                          }
                        }).join(', ') || '—'

                        return (
                          <tr key={t.id}>
                             <td className='text-dark fw-bold'>
                               <div className='d-flex align-items-center'>
                                 <div className='symbol symbol-25px symbol-circle me-2'>
                                   {profile.profile_image ? (
                                     <img src={profile.profile_image} alt='profile' style={{ objectFit: 'cover' }} />
                                   ) : (
                                     <div className='symbol-label fs-6 fw-bold text-primary bg-light-primary'>
                                       {t.name?.charAt(0)?.toUpperCase()}
                                     </div>
                                   )}
                                 </div>
                                 <span>{t.name}</span>
                               </div>
                             </td>
                             <td>{t.email || '—'}</td>
                             <td>{t.phone || '—'}</td>
                             <td className='text-capitalize'>{t.employment_type || '—'}</td>
                             <td>{allocationStr}</td>
                             <td>{t.joining_date ? new Date(t.joining_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}</td>
                             <td>{profile.dob ? profile.dob.split('T')[0] : '—'}</td>
                             <td className='text-capitalize'>{profile.gender || '—'}</td>
                             <td>{profile.blood_group || '—'}</td>
                             <td>{profile.highest_qualification || '—'}</td>
                             <td>{profile.father_name || '—'}</td>
                             <td>{profile.mother_name || '—'}</td>
                             <td>{profile.emergency_contact_name || '—'}</td>
                             <td>{profile.emergency_contact_phone || '—'}</td>
                             <td>{profile.present_address || '—'}</td>
                             <td>{profile.permanent_address || '—'}</td>
                             <td>{bank.bank_name || '—'}</td>
                             <td>{bank.account_number || '—'}</td>
                             <td>{bank.ifsc_code || '—'}</td>
                             <td>
                               <span className={`badge badge-light-${t.is_active ? 'success' : 'danger'} fw-bold`}>
                                 {t.is_active ? 'Active' : 'Inactive'}
                               </span>
                             </td>
                             <td className='text-end'>
                               <button
                                   className='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1'
                                   title='Edit'
                                   onClick={() => handleOpenCreateModal(t)}
                               >
                                   <i className='ki-duotone ki-pencil fs-2'><span className='path1'></span><span className='path2'></span></i>
                               </button>
                               <button
                                 className='btn btn-sm btn-light-primary fw-semibold'
                                 onClick={() => openManageModal(t)}
                               >
                                 Manage
                               </button>
                             </td>
                          </tr>
                        )
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </Content>

      {/* ── Bulk Import Modal ── */}
      <BulkTeacherModal
        show={showBulkModal}
        onHide={() => setShowBulkModal(false)}
        onSuccess={() => showListSuccess('Teachers bulk imported successfully!')}
        schoolId={schoolId}
      />

      {/* ── Quick Create/Edit Modal ── */}
      <Modal show={showCreateModal} onHide={() => !createSaving && setShowCreateModal(false)} centered backdrop='static'>
        <Modal.Header closeButton className='border-0 pb-0'>
          <Modal.Title>
            <i className={`ki-duotone ${isEditMode ? 'ki-pencil' : 'ki-user-edit'} fs-2x text-primary me-2`}><span className='path1'></span><span className='path2'></span></i>
            {isEditMode ? 'Edit Teacher Details' : 'Add New Teacher'}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className='px-lg-10 pt-4 pb-8'>
          {!isEditMode && <p className='text-muted fs-7 mb-6'>Enter basic info to register. Profile, bank & experience can be updated later.</p>}
          {createError && <Alert variant='danger' dismissible onClose={() => setCreateError(null)}>{createError}</Alert>}
          <form onSubmit={handleCreate}>
            <div className='row g-4'>
              <div className='col-12 fv-row'>
                <label className='required fw-semibold fs-6 mb-1'>Full Name</label>
                <input className='form-control form-control-solid' placeholder='e.g. Ramesh Kumar'
                  value={createForm.name} onChange={e => setCreateForm(s => ({ ...s, name: e.target.value }))} required />
              </div>
              <div className='col-md-6 fv-row'>
                <label className='required fw-semibold fs-6 mb-1'>Email</label>
                <input type='email' className='form-control form-control-solid' placeholder='teacher@school.com'
                  value={createForm.email} onChange={e => setCreateForm(s => ({ ...s, email: e.target.value }))} required />
              </div>
              <div className='col-md-6 fv-row'>
                <label className={`${isEditMode ? '' : 'required'} fw-semibold fs-6 mb-1`}>Password {isEditMode && '(Leave blank to retain)'}</label>
                <input type='password' className='form-control form-control-solid' placeholder='Min 6 chars'
                  value={createForm.password || ''} onChange={e => setCreateForm(s => ({ ...s, password: e.target.value }))} required={!isEditMode} minLength={6} />
              </div>
              <div className='col-md-6 fv-row'>
                <label className='fw-semibold fs-6 mb-1'>Mobile</label>
                <input className='form-control form-control-solid' placeholder='10-digit number'
                  value={createForm.mobile_number} onChange={e => setCreateForm(s => ({ ...s, mobile_number: e.target.value }))} maxLength={10} />
              </div>
              <div className='col-md-6 fv-row'>
                <label className='fw-semibold fs-6 mb-1'>Employment Type</label>
                <select className='form-select form-select-solid' value={createForm.employment_type}
                  onChange={e => setCreateForm(s => ({ ...s, employment_type: e.target.value }))}>
                  {EMPLOYMENT_TYPES.map(et => <option key={et} value={et}>{et.charAt(0).toUpperCase() + et.slice(1)}</option>)}
                </select>
              </div>
              <div className='col-md-6 fv-row'>
                <label className='fw-semibold fs-6 mb-1'>Joining Date</label>
                <input type='date' className='form-control form-control-solid'
                  value={createForm.joining_date} onChange={e => setCreateForm(s => ({ ...s, joining_date: e.target.value }))} />
              </div>
            </div>
            <div className='d-flex justify-content-end pt-8'>
              <Button variant='light' onClick={() => setShowCreateModal(false)} className='me-3' disabled={createSaving}>Cancel</Button>
              <Button variant='primary' type='submit' disabled={createSaving}>
                {createSaving ? <span className='spinner-border spinner-border-sm'></span> : isEditMode ? 'Update Teacher' : 'Add Teacher'}
              </Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>

      {/* ── Manage Modal (Tabbed) ── */}
      <Modal show={showManageModal} onHide={() => !manageSaving && setShowManageModal(false)} size='xl' centered backdrop='static'>
        <Modal.Header closeButton className='bg-light py-4'>
          <div className='d-flex align-items-center w-100 gap-4'>
            <div className='symbol symbol-45px'>
              {(selectedTeacher?.profile as any)?.profile_image ? (
                <img src={(selectedTeacher?.profile as any).profile_image} alt='profile' style={{ objectFit: 'cover' }} />
              ) : (
                <div className={`symbol-label fs-2 fw-bold text-white ${(selectedTeacher?.completion_percentage ?? 0) === 100 ? 'bg-success' : 'bg-primary'}`}>
                  {selectedTeacher?.name?.charAt(0) ?? '?'}
                </div>
              )}
            </div>
            <div className='flex-grow-1'>
              <div className='fw-bolder fs-4'>{selectedTeacher?.name}</div>
              <div className='text-muted fs-7'>{selectedTeacher?.email} · {selectedTeacher?.profession?.name || 'No Profession'}</div>
            </div>
            <div className='d-none d-md-block' style={{ minWidth: 200 }}>
              <CompletionBar
                pct={selectedTeacher?.completion_percentage ?? 0}
                status={selectedTeacher?.completion_status}
              />
            </div>
          </div>
        </Modal.Header>

        <div className='d-flex' style={{ minHeight: 520 }}>
          {/* Sidebar Tabs */}
          <div className='w-230px bg-light px-4 py-7 border-end border-gray-200 flex-shrink-0'>
            {[
                          { id: 'profile' as Tab, label: 'Personal Profile', icon: 'ki-user-edit', done: cs?.profile },
              { id: 'bank' as Tab, label: 'Bank Details', icon: 'ki-bank', done: cs?.bank_details },
              { id: 'experience' as Tab, label: 'Experience', icon: 'ki-briefcase', done: cs?.experience },
              { id: 'documents' as Tab, label: 'Documents', icon: 'ki-folder', done: cs?.documents },
              { id: 'permissions' as Tab, label: 'Permissions', icon: 'ki-shield-tick', done: undefined },
            ].map(tab => (
              <div key={tab.id} className='mb-2'>
                <div
                  onClick={() => setActiveTab(tab.id)}
                  className={`d-flex align-items-center p-3 rounded-2 cursor-pointer ${activeTab === tab.id ? 'bg-white shadow-sm' : 'bg-hover-light-primary'}`}
                  style={{ cursor: 'pointer', transition: 'all 0.15s' }}
                >
                  <i className={`ki-duotone ${tab.icon} fs-2 me-3 ${activeTab === tab.id ? 'text-primary' : 'text-gray-500'}`}>
                    <span className='path1'></span><span className='path2'></span>
                  </i>
                  <span className={`fw-semibold fs-6 flex-grow-1 ${activeTab === tab.id ? 'text-primary' : 'text-gray-700'}`}>{tab.label}</span>
                  {tab.done === true && <i className='ki-duotone ki-check-circle fs-4 text-success'><span className='path1'></span><span className='path2'></span></i>}
                  {tab.done === false && <i className='ki-duotone ki-cross-circle fs-4 text-danger'><span className='path1'></span><span className='path2'></span></i>}
                </div>
              </div>
            ))}
          </div>

          {/* Content Area */}
          <div className='flex-grow-1 p-8' style={{ maxHeight: '72vh', overflowY: 'auto' }}>
            {manageError && <Alert variant='danger' dismissible onClose={() => setManageError(null)}>{manageError}</Alert>}
            {manageSuccess && <Alert variant='success' dismissible onClose={() => setManageSuccess(null)}>{manageSuccess}</Alert>}

            {/* ─ Profile Tab ─ */}
            {activeTab === 'profile' && (
              <form onSubmit={handleSaveProfile}>
                <h4 className='fw-bold mb-6'>Personal Profile</h4>
                <div className='row g-4 mb-8'>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Date of Birth</label><input type='date' className='form-control form-control-solid' value={profileForm.dob} onChange={e => setProfileForm(s => ({ ...s, dob: e.target.value }))} /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Gender</label><select className='form-select form-select-solid' value={profileForm.gender} onChange={e => setProfileForm(s => ({ ...s, gender: e.target.value }))}>{GENDERS.map(g => <option key={g} value={g}>{g.charAt(0).toUpperCase() + g.slice(1)}</option>)}</select></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Blood Group</label><select className='form-select form-select-solid' value={profileForm.blood_group} onChange={e => setProfileForm(s => ({ ...s, blood_group: e.target.value }))}>{BLOOD_GROUPS.map(b => <option key={b}>{b}</option>)}</select></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Marital Status</label><select className='form-select form-select-solid' value={profileForm.marital_status} onChange={e => setProfileForm(s => ({ ...s, marital_status: e.target.value }))}>{MARITAL_STATUSES.map(m => <option key={m} value={m}>{m.charAt(0).toUpperCase() + m.slice(1)}</option>)}</select></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Religion</label><input className='form-control form-control-solid' value={profileForm.religion} onChange={e => setProfileForm(s => ({ ...s, religion: e.target.value }))} /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Category</label><select className='form-select form-select-solid' value={profileForm.category} onChange={e => setProfileForm(s => ({ ...s, category: e.target.value }))}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Father Name</label><input className='form-control form-control-solid' value={profileForm.father_name} onChange={e => setProfileForm(s => ({ ...s, father_name: e.target.value }))} /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Mother Name</label><input className='form-control form-control-solid' value={profileForm.mother_name} onChange={e => setProfileForm(s => ({ ...s, mother_name: e.target.value }))} /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-1'>Spouse Name</label><input className='form-control form-control-solid' value={profileForm.spouse_name} onChange={e => setProfileForm(s => ({ ...s, spouse_name: e.target.value }))} /></div>
                  <div className='col-12'><label className='fw-semibold fs-6 mb-1'>Highest Qualification</label><input className='form-control form-control-solid' placeholder='e.g. M.Sc Mathematics' value={profileForm.highest_qualification} onChange={e => setProfileForm(s => ({ ...s, highest_qualification: e.target.value }))} /></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Present Address</label><textarea className='form-control form-control-solid' rows={2} value={profileForm.present_address} onChange={e => setProfileForm(s => ({ ...s, present_address: e.target.value }))}></textarea></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Permanent Address</label><textarea className='form-control form-control-solid' rows={2} value={profileForm.permanent_address} onChange={e => setProfileForm(s => ({ ...s, permanent_address: e.target.value }))}></textarea></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Emergency Contact Name</label><input className='form-control form-control-solid' value={profileForm.emergency_contact_name} onChange={e => setProfileForm(s => ({ ...s, emergency_contact_name: e.target.value }))} /></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-1'>Emergency Contact Phone</label><input className='form-control form-control-solid' value={profileForm.emergency_contact_phone} onChange={e => setProfileForm(s => ({ ...s, emergency_contact_phone: e.target.value }))} /></div>
                  <div className='col-12'><label className='fw-semibold fs-6 mb-1'>Profile Image</label><input type='file' className='form-control form-control-solid' accept='image/*' onChange={e => setProfileImageFile(e.target.files?.[0] || null)} /></div>
                </div>
                <div className='text-end'><Button variant='primary' type='submit' disabled={manageSaving}>{manageSaving ? 'Saving...' : 'Save Profile'}</Button></div>
              </form>
            )}

            {/* ─ Bank Tab ─ */}
            {activeTab === 'bank' && (
              <form onSubmit={handleSaveBank}>
                <h4 className='fw-bold mb-6'>Bank Details</h4>
                <div className='row g-4 mb-8'>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>Bank Name</label><input className='form-control form-control-solid' placeholder='e.g. State Bank of India' value={bankForm.bank_name} onChange={e => setBankForm(s => ({ ...s, bank_name: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>Account Holder Name</label><input className='form-control form-control-solid' value={bankForm.account_holder_name} onChange={e => setBankForm(s => ({ ...s, account_holder_name: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>Account Number</label><input className='form-control form-control-solid' placeholder='Account number' value={bankForm.account_number} onChange={e => setBankForm(s => ({ ...s, account_number: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>IFSC Code</label><input className='form-control form-control-solid' placeholder='e.g. SBIN0001234' value={bankForm.ifsc_code} onChange={e => setBankForm(s => ({ ...s, ifsc_code: e.target.value.toUpperCase() }))} required /></div>
                  <div className='col-12'><label className='fw-semibold fs-6 mb-1'>Branch Name</label><input className='form-control form-control-solid' placeholder='e.g. Main Branch, Delhi' value={bankForm.branch_name} onChange={e => setBankForm(s => ({ ...s, branch_name: e.target.value }))} /></div>
                </div>
                <div className='text-end'><Button variant='primary' type='submit' disabled={manageSaving}>{manageSaving ? 'Saving...' : 'Save Bank Details'}</Button></div>
              </form>
            )}

            {/* ─ Experience Tab ─ */}
            {activeTab === 'experience' && (
              <div>
                <h4 className='fw-bold mb-2'>Work Experience</h4>
                <p className='text-muted fs-7 mb-6'>Manage teacher's previous and current employment records.</p>

                {/* Experience List */}
                {experiences.length > 0 && (
                  <div className='mb-6'>
                    {experiences.map((exp) => (
                      <div key={exp.id} className='card card-bordered mb-3'>
                        {editExpId === exp.id ? (
                          // ── Inline Edit Form ──
                          <div className='card-body p-5'>
                            <div className='row g-3 mb-3'>
                              <div className='col-md-6'>
                                <label className='fw-semibold fs-7 mb-1'>School / Institution</label>
                                <input className='form-control form-control-sm form-control-solid'
                                  value={editExpForm.school_name ?? exp.school_name}
                                  onChange={e => setEditExpForm(s => ({ ...s, school_name: e.target.value }))} />
                              </div>
                              <div className='col-md-6'>
                                <label className='fw-semibold fs-7 mb-1'>Designation</label>
                                <input className='form-control form-control-sm form-control-solid'
                                  value={editExpForm.designation ?? exp.designation}
                                  onChange={e => setEditExpForm(s => ({ ...s, designation: e.target.value }))} />
                              </div>
                              <div className='col-md-4'>
                                <label className='fw-semibold fs-7 mb-1'>From Date</label>
                                <input type='date' className='form-control form-control-sm form-control-solid'
                                  value={editExpForm.from_date ?? exp.from_date?.split('T')[0]}
                                  onChange={e => setEditExpForm(s => ({ ...s, from_date: e.target.value }))} />
                              </div>
                              <div className='col-md-4'>
                                <label className='fw-semibold fs-7 mb-1'>To Date</label>
                                <input type='date' className='form-control form-control-sm form-control-solid'
                                  value={editExpForm.to_date ?? exp.to_date?.split('T')[0] ?? ''}
                                  disabled={editExpForm.is_current ?? exp.is_current}
                                  onChange={e => setEditExpForm(s => ({ ...s, to_date: e.target.value }))} />
                              </div>
                              <div className='col-md-4 d-flex align-items-end pb-1'>
                                <div className='form-check form-switch form-check-custom form-check-solid form-check-sm'>
                                  <input className='form-check-input' type='checkbox'
                                    checked={editExpForm.is_current ?? exp.is_current}
                                    onChange={e => setEditExpForm(s => ({ ...s, is_current: e.target.checked, to_date: e.target.checked ? '' : s.to_date }))} />
                                  <label className='form-check-label fs-8 ms-2'>Current Job</label>
                                </div>
                              </div>
                              <div className='col-12'>
                                <label className='fw-semibold fs-7 mb-1'>Reason for Leaving</label>
                                <input className='form-control form-control-sm form-control-solid'
                                  placeholder='Optional'
                                  value={editExpForm.reason_for_leaving ?? exp.reason_for_leaving ?? ''}
                                  onChange={e => setEditExpForm(s => ({ ...s, reason_for_leaving: e.target.value }))} />
                              </div>
                            </div>
                            <div className='d-flex gap-2 justify-content-end'>
                              <button type='button' className='btn btn-sm btn-light'
                                onClick={() => { setEditExpId(null); setEditExpForm({}) }}>Cancel</button>
                              <button type='button' className='btn btn-sm btn-primary'
                                disabled={expActionLoading === exp.id}
                                onClick={() => handleUpdateExperience(exp.id!)}>
                                {expActionLoading === exp.id
                                  ? <span className='spinner-border spinner-border-sm'></span>
                                  : 'Save Changes'}
                              </button>
                            </div>
                          </div>
                        ) : (
                          // ── View Row ──
                          <div className='card-body py-4 px-5 d-flex justify-content-between align-items-start'>
                            <div>
                              <div className='fw-bolder text-gray-800 fs-6'>{exp.school_name}</div>
                              <div className='text-primary fw-semibold fs-7'>{exp.designation}</div>
                              <div className='text-muted fs-8 mt-1'>
                                {exp.from_date?.split('T')[0]} &rarr; {exp.is_current ? 'Present' : (exp.to_date?.split('T')[0] || '—')}
                              </div>
                              {exp.reason_for_leaving && <div className='text-muted fs-8'>Reason: {exp.reason_for_leaving}</div>}
                            </div>
                            <div className='d-flex align-items-center gap-2'>
                              {exp.is_current && <span className='badge badge-light-success me-1'>Current</span>}
                              <button type='button' className='btn btn-icon btn-sm btn-light-primary'
                                title='Edit'
                                onClick={() => {
                                  setEditExpId(exp.id!)
                                  setEditExpForm({
                                    school_name: exp.school_name,
                                    designation: exp.designation,
                                    from_date: exp.from_date?.split('T')[0],
                                    to_date: exp.to_date?.split('T')[0] ?? '',
                                    is_current: exp.is_current,
                                    reason_for_leaving: exp.reason_for_leaving ?? ''
                                  })
                                }}>
                                <i className='ki-duotone ki-pencil fs-4'><span className='path1'></span><span className='path2'></span></i>
                              </button>
                              <button type='button' className='btn btn-icon btn-sm btn-light-danger'
                                title='Delete'
                                disabled={expActionLoading === exp.id}
                                onClick={() => handleDeleteExperience(exp.id!)}>
                                {expActionLoading === exp.id
                                  ? <span className='spinner-border spinner-border-sm'></span>
                                  : <i className='ki-duotone ki-trash fs-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i>
                                }
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {experiences.length === 0 && (
                  <div className='text-center py-6 text-muted mb-4'>
                    <i className='ki-duotone ki-briefcase fs-3x text-gray-300 d-block mb-2'><span className='path1'></span><span className='path2'></span></i>
                    <div className='fs-7'>No experience records yet.</div>
                  </div>
                )}

                {/* Add new experience form */}
                <div className='separator separator-dashed my-5'></div>
                <h6 className='fw-bold text-gray-700 mb-4'>Add New Experience</h6>
                <form onSubmit={handleAddExperience}>
                  <div className='row g-4 mb-6'>
                    <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>School / Institution</label><input className='form-control form-control-solid' placeholder='School name' value={expForm.school_name} onChange={e => setExpForm(s => ({ ...s, school_name: e.target.value }))} required /></div>
                    <div className='col-md-6'><label className='required fw-semibold fs-6 mb-1'>Designation</label><input className='form-control form-control-solid' placeholder='e.g. Senior Math Teacher' value={expForm.designation} onChange={e => setExpForm(s => ({ ...s, designation: e.target.value }))} required /></div>
                    <div className='col-md-4'><label className='required fw-semibold fs-6 mb-1'>From Date</label><input type='date' className='form-control form-control-solid' value={expForm.from_date} onChange={e => setExpForm(s => ({ ...s, from_date: e.target.value }))} required /></div>
                    <div className='col-md-4'>
                      <label className='fw-semibold fs-6 mb-1'>To Date</label>
                      <input type='date' className='form-control form-control-solid' value={expForm.to_date} onChange={e => setExpForm(s => ({ ...s, to_date: e.target.value }))} disabled={expForm.is_current} />
                    </div>
                    <div className='col-md-4 d-flex align-items-end pb-2'>
                      <div className='form-check form-switch form-check-custom form-check-solid ms-2'>
                        <input className='form-check-input' type='checkbox' checked={expForm.is_current} onChange={e => setExpForm(s => ({ ...s, is_current: e.target.checked, to_date: e.target.checked ? '' : s.to_date }))} />
                        <label className='form-check-label fw-semibold ms-2'>Currently Working Here</label>
                      </div>
                    </div>
                    <div className='col-12'><label className='fw-semibold fs-6 mb-1'>Reason for Leaving</label><input className='form-control form-control-solid' placeholder='Optional' value={expForm.reason_for_leaving} onChange={e => setExpForm(s => ({ ...s, reason_for_leaving: e.target.value }))} /></div>
                  </div>
                  <div className='text-end'><Button variant='success' type='submit' disabled={manageSaving}>{manageSaving ? 'Adding...' : 'Add Experience'}</Button></div>
                </form>
              </div>
            )}

            {/* ─ Documents Tab ─ */}
            {activeTab === 'documents' && (
              <div>
                <h4 className='fw-bold mb-2'>Documents</h4>
                <p className='text-muted fs-7 mb-6'>Upload teacher's official documents. Supported: PDF, JPG, PNG, DOC, DOCX.</p>

                {/* Upload Form */}
                <div className='card card-bordered mb-7' style={{ border: '1px solid #e4e6ef' }}>
                  <div className='card-body p-6'>
                    <div className='row g-4 mb-5'>
                      <div className='col-12'>
                        <label className='required fw-semibold fs-6 mb-2'>Document Type</label>
                        <select
                          className='form-select form-select-solid'
                          value={docType}
                          onChange={e => setDocType(e.target.value)}
                        >
                          <option value=''>-- Select Document Type --</option>
                          <option value='Aadhaar Card'>Aadhaar Card</option>
                          <option value='PAN Card'>PAN Card</option>
                          <option value='Degree Certificate'>Degree Certificate</option>
                          <option value='Mark Sheet'>Mark Sheet</option>
                          <option value='Experience Certificate'>Experience Certificate</option>
                          <option value='Appointment Letter'>Appointment Letter</option>
                          <option value='Police Verification'>Police Verification</option>
                          <option value='Passport'>Passport</option>
                          <option value='Driving License'>Driving License</option>
                          <option value='Other'>Other</option>
                        </select>
                      </div>
                    </div>

                    {/* Drag & Drop File Picker */}
                    <div
                      className={`rounded-2 text-center py-8 px-4 mb-5 position-relative ${docDragOver ? 'bg-light-primary border border-primary' : 'bg-light'}`}
                      style={{
                        border: `2px dashed ${docDragOver ? '#009ef7' : '#d1d3e0'}`,
                        cursor: 'pointer',
                        transition: 'all 0.2s ease'
                      }}
                      onDragOver={e => { e.preventDefault(); setDocDragOver(true) }}
                      onDragLeave={() => setDocDragOver(false)}
                      onDrop={handleDocFileDrop}
                      onClick={() => (document.getElementById('teacher-doc-file-input') as HTMLInputElement)?.click()}
                    >
                      <input
                        id='teacher-doc-file-input'
                        type='file'
                        accept='.pdf,.jpg,.jpeg,.png,.doc,.docx'
                        style={{ display: 'none' }}
                        onChange={e => setDocFile(e.target.files?.[0] || null)}
                      />
                      {docFile ? (
                        <div className='d-flex align-items-center justify-content-center gap-3'>
                          <div className='symbol symbol-45px'>
                            <div className='symbol-label bg-light-success'>
                              <i className='ki-duotone ki-file-up fs-2 text-success'><span className='path1'></span><span className='path2'></span></i>
                            </div>
                          </div>
                          <div className='text-start'>
                            <div className='fw-bold text-gray-800 fs-6'>{docFile.name}</div>
                            <div className='text-muted fs-8'>{(docFile.size / 1024).toFixed(1)} KB · Click to change file</div>
                          </div>
                          <button
                            type='button'
                            className='btn btn-icon btn-sm btn-light-danger ms-3'
                            onClick={e => { e.stopPropagation(); setDocFile(null) }}
                            title='Remove file'
                          >
                            <i className='ki-duotone ki-cross fs-3'><span className='path1'></span><span className='path2'></span></i>
                          </button>
                        </div>
                      ) : (
                        <div>
                          <i className='ki-duotone ki-file-up fs-3x text-gray-400 mb-3 d-block'><span className='path1'></span><span className='path2'></span></i>
                          <div className='fw-semibold text-gray-600 fs-6'>Drag & Drop file here, or <span className='text-primary'>click to browse</span></div>
                          <div className='text-muted fs-8 mt-1'>PDF, JPG, PNG, DOC, DOCX · Max 10MB</div>
                        </div>
                      )}
                    </div>

                    <div className='d-flex justify-content-end'>
                      <Button
                        variant='primary'
                        onClick={handleAddDocument}
                        disabled={manageSaving || !docType.trim() || !docFile}
                      >
                        {manageSaving
                          ? <><span className='spinner-border spinner-border-sm me-2'></span>Uploading...</>
                          : <><i className='ki-duotone ki-cloud-add fs-3 me-1'><span className='path1'></span><span className='path2'></span></i>Upload Document</>
                        }
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Documents List */}
                <h6 className='fw-bold text-gray-700 mb-4'>Uploaded Documents ({documents.length})</h6>
                {documents.length === 0 ? (
                  <div className='text-center py-8 text-muted'>
                    <i className='ki-duotone ki-folder fs-3x text-gray-300 d-block mb-3'><span className='path1'></span><span className='path2'></span></i>
                    <div className='fs-6'>No documents uploaded yet.</div>
                    <div className='fs-8 mt-1'>Upload the teacher's documents above.</div>
                  </div>
                ) : (
                  <div className='row g-3'>
                    {documents.map((doc, i) => {
                      const ext = doc.file_path?.split('.').pop()?.toLowerCase() || ''
                      const isPdf = ext === 'pdf'
                      const isImg = ['jpg', 'jpeg', 'png', 'webp'].includes(ext)
                      const isLoading = docActionLoading === doc.id
                      return (
                        <div key={doc.id || i} className='col-md-6'>
                          <div className='card card-bordered h-100' style={{ border: '1px solid #e4e6ef' }}>
                            <div className='card-body p-4'>
                              {/* File Info */}
                              <div className='d-flex align-items-center gap-3 mb-3'>
                                <div className='symbol symbol-40px flex-shrink-0'>
                                  <div className={`symbol-label ${isPdf ? 'bg-light-danger' : isImg ? 'bg-light-info' : 'bg-light-warning'}`}>
                                    <i className={`ki-duotone ${isPdf ? 'ki-file-right' : isImg ? 'ki-picture' : 'ki-document'} fs-2 ${isPdf ? 'text-danger' : isImg ? 'text-info' : 'text-warning'}`}>
                                      <span className='path1'></span><span className='path2'></span>
                                    </i>
                                  </div>
                                </div>
                                <div className='flex-grow-1 min-w-0'>
                                  <div className='fw-bold text-gray-800 fs-7'>{doc.document_type}</div>
                                  <div className='text-muted fs-8 text-truncate' title={doc.file_path}>{doc.file_path?.split('/').pop()}</div>
                                </div>
                              </div>
                              {/* Actions Row */}
                              <div className='d-flex align-items-center justify-content-between gap-2'>
                                <select
                                  className='form-select form-select-sm fs-8 fw-semibold'
                                  style={{ maxWidth: 130 }}
                                  value={doc.verification_status}
                                  disabled={isLoading}
                                  onChange={e => handleUpdateDocStatus(doc.id, e.target.value as 'Verified' | 'Rejected' | 'Pending')}
                                >
                                  <option value='Pending'>⏳ Pending</option>
                                  <option value='Verified'>✓ Verified</option>
                                  <option value='Rejected'>✗ Rejected</option>
                                </select>
                                <div className='d-flex gap-1'>
                                  <a
                                    href={doc.file_path}
                                    target='_blank'
                                    rel='noreferrer'
                                    className='btn btn-icon btn-sm btn-light-primary'
                                    title='View Document'
                                  >
                                    <i className='ki-duotone ki-eye fs-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                                  </a>
                                  <button
                                    type='button'
                                    className='btn btn-icon btn-sm btn-light-danger'
                                    title='Delete Document'
                                    disabled={isLoading}
                                    onClick={() => handleDeleteDocument(doc.id)}
                                  >
                                    {isLoading
                                      ? <span className='spinner-border spinner-border-sm'></span>
                                      : <i className='ki-duotone ki-trash fs-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i>
                                    }
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            )}

            {/* ─ Permissions Tab ─ */}
            {activeTab === 'permissions' && (
              <div>
                <p className='text-muted fs-7 mb-6'>Select the modules this teacher can view or manage.</p>

                <div className='row g-4'>
                  {PERMISSION_MODULES.map(mod => {
                    const viewKey = `view_${mod.key}`
                    const manageKey = `manage_${mod.key}`
                    const hasView = selectedPerms.includes(viewKey)
                    const hasManage = selectedPerms.includes(manageKey)
                    return (
                      <div key={mod.key} className='col-md-4 col-sm-6'>
                        <div className='border border-gray-200 rounded-2 p-4 h-100' style={{ background: '#fff' }}>
                          <div className='fw-bold text-gray-800 fs-6 mb-3'>{mod.label}</div>
                          <div className='d-flex gap-4'>
                            <label
                              className='d-flex align-items-center gap-2 cursor-pointer'
                              style={{ cursor: 'pointer' }}
                            >
                              <div className='form-check form-check-custom form-check-solid form-check-sm mb-0'>
                                <input
                                  className='form-check-input'
                                  type='checkbox'
                                  checked={hasView}
                                  onChange={() => togglePerm(viewKey)}
                                />
                              </div>
                              <span className={`fs-7 fw-semibold ${hasView ? 'text-primary' : 'text-gray-600'}`}>View</span>
                            </label>
                            <label
                              className='d-flex align-items-center gap-2 cursor-pointer'
                              style={{ cursor: 'pointer' }}
                            >
                              <div className='form-check form-check-custom form-check-solid form-check-sm mb-0'>
                                <input
                                  className='form-check-input'
                                  type='checkbox'
                                  checked={hasManage}
                                  onChange={() => togglePerm(manageKey)}
                                />
                              </div>
                              <span className={`fs-7 fw-semibold ${hasManage ? 'text-primary' : 'text-gray-600'}`}>Manage</span>
                            </label>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>

                <div className='d-flex justify-content-end pt-8'>
                  <Button variant='primary' onClick={handleSavePermissions} disabled={manageSaving}>
                    {manageSaving
                      ? <><span className='spinner-border spinner-border-sm me-2'></span>Saving...</>
                      : 'Save Permissions'
                    }
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </Modal>
    </>
  )
}

const TeachersWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[{ title: 'Staff', path: '/staff/teachers', isActive: false }, { title: 'Teachers', path: '/staff/teachers', isActive: true }]}>
      All Teachers
    </PageTitle>
    <TeachersPage />
  </>
)

export { TeachersWrapper }
