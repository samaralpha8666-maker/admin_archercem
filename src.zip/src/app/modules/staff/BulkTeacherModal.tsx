import { FC, useState, useRef } from 'react'
import { Modal, Button, Alert } from 'react-bootstrap'
import * as XLSX from 'xlsx'
import { bulkImportTeachers } from '../teachers/core/_requests'
import { toast } from 'react-hot-toast'

interface Props {
  show: boolean
  onHide: () => void
  onSuccess: () => void
  schoolId: string
}

export const BulkTeacherModal: FC<Props> = ({ show, onHide, onSuccess, schoolId }) => {
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet([{
      'Full Name': 'Amit Sharma',
      'Email': 'amit.sharma@example.com',
      'Mobile Number': '9876543210',
      'Password': 'TeacherPassword123', // Optional
      'Employment Type': 'permanent', // permanent, contract, part-time, guest
      'Joining Date': new Date().toISOString().split('T')[0] // YYYY-MM-DD
    }]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template');
    XLSX.writeFile(wb, 'Teacher_Import_Template.xlsx');
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setError(null)
    const reader = new FileReader()
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result
        if (typeof bstr !== 'string') return
        const wb = XLSX.read(bstr, { type: 'binary' })
        const wsname = wb.SheetNames[0]
        const ws = wb.Sheets[wsname]
        const jsonData = XLSX.utils.sheet_to_json(ws)
        
        const formattedData = jsonData.map((row: any, index: number) => ({
          _id: index, // temporary id for editing
          name: row['Full Name'] || '',
          email: row['Email'] || '',
          mobile_number: row['Mobile Number'] ? String(row['Mobile Number']) : '',
          password: row['Password'] ? String(row['Password']) : '',
          employment_type: row['Employment Type'] ? String(row['Employment Type']).toLowerCase() : 'permanent',
          joining_date: row['Joining Date'] ? String(row['Joining Date']) : new Date().toISOString().split('T')[0]
        }))
        
        setData(formattedData)
      } catch (err) {
        setError('Failed to parse Excel file. Ensure it matches the template.')
      }
    }
    reader.readAsBinaryString(file)
  }

  const handleEditCell = (index: number, field: string, value: string) => {
    const updated = [...data]
    updated[index][field] = value
    setData(updated)
  }

  const handleRemoveRow = (index: number) => {
    const updated = [...data]
    updated.splice(index, 1)
    setData(updated)
  }

  const handleSubmit = async () => {
    if (data.length === 0) return

    setLoading(true)
    setError(null)
    
    // Validate minimally first
    const invalidRows = data.filter(r => !r.name)
    if (invalidRows.length > 0) {
      setError('Some rows are missing the required Full Name field. Check highlighted inputs.')
      setLoading(false)
      return
    }

    try {
      const payload = {
        teachers: data.map(r => ({
          name: r.name,
          email: r.email || undefined,
          mobile_number: r.mobile_number || undefined,
          password: r.password || undefined,
          employment_type: r.employment_type || 'permanent',
          joining_date: r.joining_date || undefined
        }))
      }
      
      await bulkImportTeachers(schoolId, payload)
      toast.success(`${data.length} teachers bulk imported successfully!`)
      setData([])
      onSuccess()
      onHide()
    } catch (err: any) {
      setError(err.response?.data?.error || err.response?.data?.message || 'Failed to bulk import teachers.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal show={show} onHide={() => { setData([]); onHide() }} size='xl' centered backdrop='static'>
      <Modal.Header closeButton className='bg-light py-4'>
        <Modal.Title>
          <i className='ki-duotone ki-file-up fs-2x text-primary me-2'>
            <span className='path1'></span><span className='path2'></span>
          </i> 
          Bulk Teacher Registration
        </Modal.Title>
      </Modal.Header>
      
      <Modal.Body className='px-lg-10 pt-4 pb-8'>
        {/* Helper Information Box */}
        <div className='p-5 bg-light-primary border border-primary border-dashed rounded mb-8 d-flex align-items-center'>
          <i className='ki-duotone ki-information-5 fs-2x text-primary me-4'>
            <span className='path1'></span><span className='path2'></span><span className='path3'></span>
          </i>
          <div className='text-gray-800 fs-7'>
            <span className='fw-bold text-primary'>Excel Upload Instructions:</span> Please download the pre-formatted Excel template, populate the columns, and upload it below. Valid employment types are <span className='fw-bold text-success'>permanent, contract, part-time, guest</span>. Unspecified passwords will defaults to <span className='fw-bold text-danger'>Teacher@123</span>.
          </div>
        </div>

        {error && <Alert variant='danger' dismissible onClose={() => setError(null)}>{error}</Alert>}
        
        {data.length === 0 ? (
          <div className='text-center py-10 border border-gray-300 border-dashed rounded bg-white hover-elevate-up transition-3s'>
            <i className='ki-duotone ki-cloud-upload fs-5x text-muted mb-4'>
              <span className='path1'></span><span className='path2'></span>
            </i>
            <h4 className='fw-bold mb-5 text-gray-800'>Import Teachers from Excel</h4>
            <div className='d-flex justify-content-center gap-4 mb-4'>
              <Button variant='light-primary' className='btn-sm fw-bold' onClick={downloadTemplate}>
                <i className='ki-duotone ki-file-down fs-3 me-2'>
                  <span className='path1'></span><span className='path2'></span>
                </i> 
                Download Template
              </Button>
              <Button variant='primary' className='btn-sm fw-bold' onClick={() => fileInputRef.current?.click()}>
                <i className='ki-duotone ki-add-folder fs-3 me-2'>
                  <span className='path1'></span><span className='path2'></span>
                </i> 
                Select Excel File
              </Button>
              <input type='file' accept='.xlsx, .xls' ref={fileInputRef} className='d-none' onChange={handleFileUpload} />
            </div>
            <p className='text-muted fs-7 mx-auto w-50'>
              Make sure your Excel columns are named exactly: <span className='fw-bold text-gray-800'>Full Name, Email, Mobile Number, Password, Employment Type, Joining Date</span>
            </p>
          </div>
        ) : (
          <div>
            <div className='d-flex justify-content-between align-items-center mb-5'>
              <div>
                <h5 className='fw-bold m-0 text-gray-800'>Preview & Validate {data.length} Records</h5>
                <span className='text-muted fs-7'>Correct any validation issues highlighted in red directly in the grid.</span>
              </div>
              <Button variant='light-danger' size='sm' className='fw-bold' onClick={() => setData([])} disabled={loading}>Clear All</Button>
            </div>
            
            <div className='table-responsive border rounded' style={{ maxHeight: '400px', overflowY: 'auto' }}>
              <table className='table table-row-bordered table-row-gray-200 align-middle gs-0 gy-2 m-0'>
                <thead className='bg-light position-sticky top-0 z-index-1'>
                  <tr className='fw-bold text-gray-800 border-bottom border-gray-300 bg-light'>
                    <th className='px-4 min-w-150px'>Full Name *</th>
                    <th className='px-4 min-w-180px'>Email</th>
                    <th className='px-4 min-w-120px'>Mobile Number</th>
                    <th className='px-4 min-w-120px'>Password</th>
                    <th className='px-4 min-w-120px'>Employment Type</th>
                    <th className='px-4 min-w-120px'>Joining Date</th>
                    <th className='px-4 w-50px text-end'>Del</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((row, index) => {
                    const isNameInvalid = !row.name
                    const isMobInvalid = row.mobile_number && (row.mobile_number.length < 10 || row.mobile_number.length > 15)
                    const isEmailInvalid = row.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)
                    const isTypeInvalid = row.employment_type && !['permanent', 'contract', 'part-time', 'guest'].includes(row.employment_type)

                    return (
                      <tr key={index}>
                        <td className='p-2'>
                          <input type='text' className={`form-control form-control-sm form-control-solid border ${isNameInvalid ? 'border-danger bg-light-danger' : 'border-transparent'}`} value={row.name} onChange={(e) => handleEditCell(index, 'name', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='email' className={`form-control form-control-sm form-control-solid border ${isEmailInvalid ? 'border-danger bg-light-danger' : 'border-transparent'}`} value={row.email} onChange={(e) => handleEditCell(index, 'email', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='text' className={`form-control form-control-sm form-control-solid border ${isMobInvalid ? 'border-danger bg-light-danger' : 'border-transparent'}`} value={row.mobile_number} onChange={(e) => handleEditCell(index, 'mobile_number', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='text' className='form-control form-control-sm form-control-solid border border-transparent' placeholder='Teacher@123' value={row.password} onChange={(e) => handleEditCell(index, 'password', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <select className={`form-select form-select-sm form-select-solid border ${isTypeInvalid ? 'border-danger bg-light-danger' : 'border-transparent'}`} value={row.employment_type} onChange={(e) => handleEditCell(index, 'employment_type', e.target.value)}>
                            <option value='permanent'>Permanent</option>
                            <option value='contract'>Contract</option>
                            <option value='part-time'>Part-time</option>
                            <option value='guest'>Guest</option>
                          </select>
                        </td>
                        <td className='p-2'>
                          <input type='date' className='form-control form-control-sm form-control-solid border border-transparent' value={row.joining_date} onChange={(e) => handleEditCell(index, 'joining_date', e.target.value)} />
                        </td>
                        <td className='p-2 text-end'>
                          <button type='button' className='btn btn-icon btn-bg-light btn-active-color-danger btn-sm' onClick={() => handleRemoveRow(index)}>
                            <i className='ki-duotone ki-trash fs-5'>
                              <span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span>
                            </i>
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </Modal.Body>
      
      <Modal.Footer className='border-0 bg-light py-4'>
        <Button variant='light' onClick={() => { setData([]); onHide() }} disabled={loading} className='fw-bold btn-sm'>
          Cancel
        </Button>
        {data.length > 0 && (
          <Button variant='primary' onClick={handleSubmit} disabled={loading} className='fw-bold btn-sm d-flex align-items-center gap-2'>
            {loading ? (
              <>
                <span className='spinner-border spinner-border-sm' role='status' aria-hidden='true'></span>
                Saving...
              </>
            ) : (
              <>
                <i className='ki-duotone ki-double-check fs-4'>
                  <span className='path1'></span><span className='path2'></span>
                </i>
                Complete Import
              </>
            )}
          </Button>
        )}
      </Modal.Footer>
    </Modal>
  )
}
