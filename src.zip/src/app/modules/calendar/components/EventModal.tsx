import React, { useState, useEffect } from 'react';
import { Modal } from 'react-bootstrap';
import { KTIcon } from '../../../../_metronic/helpers';
import axios from 'axios';
import { toast } from 'react-toastify';
import { getTeachers } from '../../teachers/core/_requests';

const API_URL = import.meta.env.VITE_APP_API_URL;

interface EventModalProps {
  show: boolean;
  onHide: () => void;
  onSave: (eventData: any) => Promise<void>;
  event?: any; // null if creating
  selectedDate?: { start: Date; end: Date; allDay: boolean } | null;
  currentUser: any;
  schoolId: string;
  fetchEvents: () => void;
}

const EventModal: React.FC<EventModalProps> = ({ show, onHide, onSave, event, selectedDate, currentUser, schoolId, fetchEvents }) => {
  const [loading, setLoading] = useState(false);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [selectedTeacherId, setSelectedTeacherId] = useState('');
  const [selectedAttendees, setSelectedAttendees] = useState<any[]>([]);
  
  const [formData, setFormData] = useState({
    title: '',
    type: 'event',
    start_time: '',
    end_time: '',
    is_all_day: false,
    audience: 'specific',
    location: '',
    color: '#3788d8',
    description: ''
  });

  const isTeacher = currentUser?.role === 'teacher';
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';
  const recipients = event?.extendedProps?.recipients || [];
  
  // Find if current user is a recipient
  const myRecipientRecord = recipients.find((r: any) => String(r.user_id) === String(currentUser?.id) && r.role === currentUser?.role);

  const canManageAttendees = isAdmin || (isTeacher && (!event || String(event.extendedProps?.created_by) === String(currentUser?.id)));

  useEffect(() => {
    if (show) {
      setSelectedAttendees([]);
      if (canManageAttendees) {
        getTeachers(schoolId, { limit: 100 }).then((res: any) => {
          if (res.data?.success) {
            setTeachers(res.data.data.teachers || []);
          }
        }).catch((err: any) => console.error("Error fetching teachers", err));
      }

      if (event) {
        setFormData({
          title: event.title || '',
          type: event.extendedProps?.type || 'event',
          start_time: formatDateTimeLocal(event.start),
          end_time: formatDateTimeLocal(event.end || event.start),
          is_all_day: event.allDay || false,
          audience: event.extendedProps?.audience || 'specific',
          location: event.extendedProps?.location || '',
          color: event.backgroundColor || '#3788d8',
          description: event.extendedProps?.description || ''
        });
      } else if (selectedDate) {
        setFormData(prev => ({
          ...prev,
          title: '',
          start_time: formatDateTimeLocal(selectedDate.start),
          end_time: formatDateTimeLocal(selectedDate.end),
          is_all_day: selectedDate.allDay,
          type: isTeacher ? 'task' : 'event',
          audience: isTeacher ? 'specific' : 'all'
        }));
      } else {
        setFormData(prev => ({
          ...prev,
          title: '',
          start_time: formatDateTimeLocal(new Date()),
          end_time: formatDateTimeLocal(new Date(Date.now() + 3600000)),
          is_all_day: false,
          type: isTeacher ? 'task' : 'event',
          audience: isTeacher ? 'specific' : 'all'
        }));
      }
    }
  }, [show, event, selectedDate, isTeacher, isAdmin, schoolId]);

  const formatDateTimeLocal = (date: Date) => {
    if (!date) return '';
    const d = new Date(date);
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const submitData = {
        ...formData,
        attendees: !event && formData.type === 'meeting'
          ? selectedAttendees.map(t => ({ id: t.id, role: 'teacher' }))
          : undefined
      };
      await onSave(submitData);
      onHide();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // RSVP Handler
  const handleRsvp = async (status: 'accepted' | 'declined') => {
    try {
      setLoading(true);
      await axios.post(`${API_URL}/school/${schoolId}/calendar/${event.id}/rsvp`, { status });
      toast.success(`RSVP updated to ${status}`);
      fetchEvents();
      onHide();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Error updating RSVP");
    } finally {
      setLoading(false);
    }
  };

  // Recipient Management
  const handleAddRecipient = async () => {
    if (!selectedTeacherId) return;

    if (!event) {
      const teacher = teachers.find(t => String(t.id) === String(selectedTeacherId));
      if (teacher && !selectedAttendees.some(a => String(a.id) === String(selectedTeacherId))) {
        setSelectedAttendees(prev => [...prev, teacher]);
      }
      setSelectedTeacherId('');
      return;
    }

    try {
      setLoading(true);
      await axios.post(`${API_URL}/school/${schoolId}/calendar/${event.id}/recipients`, {
        attendees: [{ id: selectedTeacherId, role: 'teacher' }]
      });
      toast.success("Recipient added successfully");
      fetchEvents();
      setSelectedTeacherId('');
      onHide();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Error adding recipient");
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveRecipient = async (recipientId: number) => {
    if (!event) {
      setSelectedAttendees(prev => prev.filter(t => t.id !== recipientId));
      return;
    }

    if (!window.confirm("Remove this recipient?")) return;
    try {
      setLoading(true);
      await axios.delete(`${API_URL}/school/${schoolId}/calendar/${event.id}/recipients/${recipientId}`);
      toast.success("Recipient removed");
      fetchEvents();
      onHide();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Error removing recipient");
    } finally {
      setLoading(false);
    }
  };

  const displayRecipients = event
    ? recipients
    : selectedAttendees.map(t => ({ id: t.id, user_id: t.id, role: 'teacher', status: 'pending', name: t.name, email: t.email }));

  return (
    <Modal show={show} onHide={onHide} centered size={(event && recipients.length > 0) || formData.type === 'meeting' ? "lg" : undefined}>
      <div className="modal-header">
        <h2 className="fw-bolder">{event ? 'Edit Calendar Item' : 'Add New Item'}</h2>
        <div className="btn btn-icon btn-sm btn-active-icon-primary" onClick={onHide}>
          <KTIcon iconName="cross" className="fs-1" />
        </div>
      </div>
      <div className="modal-body scroll-y mx-5 mx-xl-15 my-7">
        <div className="row">
          <div className={event ? "col-lg-7" : "col-12"}>
            <form onSubmit={handleSubmit}>
              <div className="d-flex flex-column mb-8 fv-row">
                <label className="d-flex align-items-center fs-6 fw-bold mb-2">
                  <span className="required">Title</span>
                </label>
                <input type="text" className="form-control form-control-solid" name="title" value={formData.title} onChange={handleChange} required placeholder="Enter title" />
              </div>

              <div className="row g-9 mb-8">
                <div className="col-md-6 fv-row">
                  <label className="required fs-6 fw-bold mb-2">Type</label>
                  <select className="form-select form-select-solid" name="type" value={formData.type} onChange={handleChange}>
                    {!isTeacher && <option value="event">Event</option>}
                    <option value="meeting">Meeting</option>
                    <option value="task">Task</option>
                    {!isTeacher && <option value="holiday">Holiday</option>}
                  </select>
                </div>
                {!isTeacher && (
                  <div className="col-md-6 fv-row">
                    <label className="required fs-6 fw-bold mb-2">Audience</label>
                    <select className="form-select form-select-solid" name="audience" value={formData.audience} onChange={handleChange}>
                      <option value="all">Everyone</option>
                      <option value="teachers">Teachers Only</option>
                      <option value="specific">Specific Users</option>
                    </select>
                  </div>
                )}
              </div>

              <div className="row g-9 mb-8">
                <div className="col-md-6 fv-row">
                  <label className="required fs-6 fw-bold mb-2">Start</label>
                  <input type={formData.is_all_day ? "date" : "datetime-local"} className="form-control form-control-solid" name="start_time" value={formData.is_all_day ? formData.start_time.slice(0,10) : formData.start_time} onChange={handleChange} required />
                </div>
                <div className="col-md-6 fv-row">
                  <label className="required fs-6 fw-bold mb-2">End</label>
                  <input type={formData.is_all_day ? "date" : "datetime-local"} className="form-control form-control-solid" name="end_time" value={formData.is_all_day ? formData.end_time.slice(0,10) : formData.end_time} onChange={handleChange} required />
                </div>
              </div>

              <div className="mb-8">
                <div className="form-check form-check-custom form-check-solid">
                  <input className="form-check-input" type="checkbox" name="is_all_day" id="is_all_day" checked={formData.is_all_day} onChange={handleChange} />
                  <label className="form-check-label fw-bold" htmlFor="is_all_day">
                    All Day Event
                  </label>
                </div>
              </div>

              <div className="d-flex flex-column mb-8">
                <label className="fs-6 fw-bold mb-2">Location</label>
                <input type="text" className="form-control form-control-solid" name="location" value={formData.location} onChange={handleChange} placeholder="Optional location" />
              </div>

              <div className="d-flex flex-column mb-8">
                <label className="fs-6 fw-bold mb-2">Description</label>
                <textarea className="form-control form-control-solid" rows={3} name="description" value={formData.description} onChange={handleChange} placeholder="Event details..."></textarea>
              </div>

              <div className="text-center pt-15">
                <button type="reset" className="btn btn-light me-3" onClick={onHide} disabled={loading}>
                  Discard
                </button>
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  <span className="indicator-label">{loading ? 'Saving...' : 'Submit'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* RIGHT SIDE: RSVP & RECIPIENTS */}
          {(event || formData.type === 'meeting') && (
            <div className="col-lg-5">
              <div className="bg-light rounded p-5 mb-5 border border-gray-300">
                <h4 className="fw-bolder mb-4">Attendees & RSVP</h4>
                
                {myRecipientRecord && (
                  <div className="mb-6 p-4 bg-white rounded border border-primary">
                    <div className="fs-6 fw-bold mb-2">Are you going?</div>
                    <div className="d-flex gap-2">
                      <button 
                        className={`btn btn-sm ${myRecipientRecord.status === 'accepted' ? 'btn-success' : 'btn-light-success'}`}
                        onClick={() => handleRsvp('accepted')} disabled={loading}>
                        Accept
                      </button>
                      <button 
                        className={`btn btn-sm ${myRecipientRecord.status === 'declined' ? 'btn-danger' : 'btn-light-danger'}`}
                        onClick={() => handleRsvp('declined')} disabled={loading}>
                        Decline
                      </button>
                    </div>
                  </div>
                )}

                {canManageAttendees && (
                  <div className="mb-6">
                    <div className="d-flex gap-2">
                      <select className="form-select form-select-sm" value={selectedTeacherId} onChange={e => setSelectedTeacherId(e.target.value)}>
                        <option value="">Select Teacher...</option>
                        {teachers.map(t => (
                          <option key={t.id} value={t.id}>{t.name} ({t.email})</option>
                        ))}
                      </select>
                      <button type="button" className="btn btn-primary btn-sm" onClick={handleAddRecipient} disabled={loading || !selectedTeacherId}>Add</button>
                    </div>
                  </div>
                )}

                <div className="mh-300px overflow-auto">
                  {displayRecipients.length > 0 ? (
                    <table className="table table-row-dashed table-row-gray-200 align-middle">
                      <tbody>
                        {displayRecipients.map((r: any) => (
                          <tr key={r.id}>
                            <td>
                              <div className="fw-bold fs-7">{r.name || `${r.role} - ID: ${r.user_id}`}</div>
                              <span className={`badge badge-light-${r.status === 'accepted' ? 'success' : r.status === 'declined' ? 'danger' : 'warning'} fs-9`}>
                                {r.status}
                              </span>
                            </td>
                            {canManageAttendees && (
                              <td className="text-end">
                                <button type="button" className="btn btn-icon btn-sm btn-light-danger" onClick={() => handleRemoveRecipient(r.id)}>
                                  <KTIcon iconName="trash" className="fs-5" />
                                </button>
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <div className="text-muted fs-7 text-center py-5">No specific attendees</div>
                  )}
                </div>

              </div>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
};

export default EventModal;
