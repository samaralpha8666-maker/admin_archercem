import React, { useState } from 'react';
import { Modal } from 'react-bootstrap';
import { KTIcon } from '../../../../_metronic/helpers';
import { toast } from 'react-toastify';

interface BulkHolidayModalProps {
  show: boolean;
  onHide: () => void;
  onSave: (events: any[]) => Promise<void>;
}

interface PresetHoliday {
  title: string;
  date: string;
  category: 'National' | 'Religious' | 'Observance';
}

const INDIAN_HOLIDAYS_2026: PresetHoliday[] = [
  { title: "New Year's Day", date: "2026-01-01", category: "Observance" },
  { title: "Republic Day", date: "2026-01-26", category: "National" },
  { title: "Maha Shivratri", date: "2026-02-17", category: "Religious" },
  { title: "Holi", date: "2026-03-03", category: "Religious" },
  { title: "Eid al-Fitr", date: "2026-03-20", category: "Religious" },
  { title: "Mahavir Jayanti", date: "2026-04-01", category: "Religious" },
  { title: "Good Friday", date: "2026-04-03", category: "Religious" },
  { title: "Ambedkar Jayanti", date: "2026-04-14", category: "Observance" },
  { title: "Budha Purnima", date: "2026-05-01", category: "Religious" },
  { title: "World Environment Day", date: "2026-06-05", category: "Observance" },
  { title: "Muharram", date: "2026-06-26", category: "Religious" },
  { title: "Independence Day", date: "2026-08-15", category: "National" },
  { title: "Janmashtami", date: "2026-09-04", category: "Religious" },
  { title: "Milad-un-Nabi", date: "2026-09-25", category: "Religious" },
  { title: "Mahatma Gandhi Jayanti", date: "2026-10-02", category: "National" },
  { title: "Dussehra", date: "2026-10-21", category: "Religious" },
  { title: "Diwali", date: "2026-11-08", category: "Religious" },
  { title: "Guru Nanak Jayanti", date: "2026-11-24", category: "Religious" },
  { title: "Christmas Day", date: "2026-12-25", category: "Religious" }
];

const categoryBadgeColor = (category: string) => {
  switch (category) {
    case 'National': return 'badge-light-danger text-danger';
    case 'Religious': return 'badge-light-primary text-primary';
    default: return 'badge-light-warning text-warning';
  }
};

const formatDateReadable = (dateStr: string) => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
};

const BulkHolidayModal: React.FC<BulkHolidayModalProps> = ({ show, onHide, onSave }) => {
  const [activeTab, setActiveTab] = useState<'public' | 'manual'>('public');
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Custom manual entries rows state
  const [rows, setRows] = useState([
    { id: Date.now(), title: '', start_time: '', end_time: '' }
  ]);

  // Track added holidays in current modal session
  const [addedHolidays, setAddedHolidays] = useState<string[]>([]);
  // Track selected holidays for bulk import
  const [selectedTitles, setSelectedTitles] = useState<string[]>([]);
  // Track loading status of specific holidays being added individually
  const [individualLoading, setIndividualLoading] = useState<Record<string, boolean>>({});

  const addRow = () => {
    setRows([...rows, { id: Date.now() + Math.random(), title: '', start_time: '', end_time: '' }]);
  };

  const removeRow = (id: number) => {
    setRows(rows.filter(r => r.id !== id));
  };

  const handleChange = (id: number, field: string, value: string) => {
    setRows(rows.map(r => r.id === id ? { ...r, [field]: value } : r));
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validRows = rows.filter(r => r.title.trim() && r.start_time);
    if (validRows.length === 0) {
      onHide();
      return;
    }

    setLoading(true);
    try {
      const payload = validRows.map(r => ({
        title: r.title,
        type: 'holiday',
        start_time: `${r.start_time}T00:00:00`,
        end_time: `${r.end_time || r.start_time}T23:59:59`,
        is_all_day: true,
        audience: 'all',
        color: '#ffc700',
      }));

      await onSave(payload);
      toast.success(`${payload.length} manual holidays saved successfully`);
      onHide();
      setRows([{ id: Date.now(), title: '', start_time: '', end_time: '' }]);
    } catch (error) {
      console.error(error);
      toast.error("Failed to save manual holidays");
    } finally {
      setLoading(false);
    }
  };

  // Add a single preset holiday instantly
  const handleAddSingleHoliday = async (holiday: PresetHoliday) => {
    setIndividualLoading(prev => ({ ...prev, [holiday.title]: true }));
    try {
      const payload = [{
        title: holiday.title,
        type: 'holiday',
        start_time: `${holiday.date}T00:00:00`,
        end_time: `${holiday.date}T23:59:59`,
        is_all_day: true,
        audience: 'all',
        color: '#ffc700',
      }];

      await onSave(payload);
      setAddedHolidays(prev => [...prev, holiday.title]);
      // Remove from selected list if it was selected
      setSelectedTitles(prev => prev.filter(t => t !== holiday.title));
      toast.success(`"${holiday.title}" added to calendar`);
    } catch (error) {
      console.error(error);
      toast.error(`Failed to add "${holiday.title}"`);
    } finally {
      setIndividualLoading(prev => ({ ...prev, [holiday.title]: false }));
    }
  };

  // Bulk import all selected preset holidays
  const handleImportSelected = async () => {
    if (selectedTitles.length === 0) return;
    setLoading(true);
    try {
      const selectedHolidays = INDIAN_HOLIDAYS_2026.filter(h => selectedTitles.includes(h.title));
      const payload = selectedHolidays.map(h => ({
        title: h.title,
        type: 'holiday',
        start_time: `${h.date}T00:00:00`,
        end_time: `${h.date}T23:59:59`,
        is_all_day: true,
        audience: 'all',
        color: '#ffc700',
      }));

      await onSave(payload);
      setAddedHolidays(prev => [...prev, ...selectedTitles]);
      setSelectedTitles([]);
      toast.success(`${payload.length} holidays imported successfully`);
    } catch (error) {
      console.error(error);
      toast.error("Failed to import selected holidays");
    } finally {
      setLoading(false);
    }
  };

  // Handle single checkbox toggle
  const handleToggleSelect = (title: string) => {
    if (selectedTitles.includes(title)) {
      setSelectedTitles(prev => prev.filter(t => t !== title));
    } else {
      setSelectedTitles(prev => [...prev, title]);
    }
  };

  // Filter preset holidays by search query and exclude already added ones in the session
  const filteredPresets = INDIAN_HOLIDAYS_2026.filter(h => {
    const matchesSearch = h.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  const allFilteredSelected = filteredPresets
    .filter(h => !addedHolidays.includes(h.title))
    .every(h => selectedTitles.includes(h.title)) && 
    filteredPresets.filter(h => !addedHolidays.includes(h.title)).length > 0;

  const handleSelectAllFiltered = () => {
    const unaddedFiltered = filteredPresets.filter(h => !addedHolidays.includes(h.title));
    if (allFilteredSelected) {
      // Deselect all filtered
      const unaddedFilteredTitles = unaddedFiltered.map(h => h.title);
      setSelectedTitles(prev => prev.filter(t => !unaddedFilteredTitles.includes(t)));
    } else {
      // Select all filtered
      const unaddedFilteredTitles = unaddedFiltered.map(h => h.title);
      setSelectedTitles(prev => Array.from(new Set([...prev, ...unaddedFilteredTitles])));
    }
  };

  return (
    <Modal show={show} onHide={onHide} size="lg" centered>
      <div className="modal-header pb-3">
        <h2 className="fw-bolder mb-0">Bulk Add Holidays</h2>
        <div className="btn btn-icon btn-sm btn-active-icon-primary" onClick={onHide}>
          <KTIcon iconName="cross" className="fs-1" />
        </div>
      </div>
      
      <div className="modal-body mx-3 my-4">
        {/* Navigation Tabs */}
        <ul className="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-6 fw-bold mb-8">
          <li className="nav-item">
            <span 
              className={`nav-link text-active-primary py-3 cursor-pointer ${activeTab === 'public' ? 'active' : ''}`}
              onClick={() => setActiveTab('public')}
            >
              <i className="bi bi-cloud-download me-2 fs-5"></i> Import Public Holidays (2026)
            </span>
          </li>
          <li className="nav-item">
            <span 
              className={`nav-link text-active-primary py-3 cursor-pointer ${activeTab === 'manual' ? 'active' : ''}`}
              onClick={() => setActiveTab('manual')}
            >
              <i className="bi bi-pencil-square me-2 fs-5"></i> Manual Entries
            </span>
          </li>
        </ul>

        {activeTab === 'public' ? (
          <div>
            <p className="text-muted mb-6">
              Quickly search and import standard Indian public holidays for the 2026 academic year. Select multiple holidays to import in bulk or add them individually.
            </p>
            
            {/* Search and Bulk Actions header */}
            <div className="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-6">
              <div className="d-flex align-items-center position-relative w-100 w-sm-300px">
                <i className="bi bi-search position-absolute ms-4 text-muted"></i>
                <input 
                  type="text" 
                  className="form-control form-control-solid ps-12 fs-7 py-3" 
                  placeholder="Search holidays..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {selectedTitles.length > 0 && (
                <button 
                  type="button" 
                  className="btn btn-success btn-sm d-flex align-items-center gap-2"
                  onClick={handleImportSelected}
                  disabled={loading}
                >
                  <i className="bi bi-cloud-arrow-up fs-5"></i>
                  {loading ? 'Importing...' : `Import Selected (${selectedTitles.length})`}
                </button>
              )}
            </div>

            {/* Public Holidays Table */}
            <div className="table-responsive" style={{ maxHeight: '380px', overflowY: 'auto' }}>
              <table className="table table-row-dashed table-row-gray-300 align-middle gs-3 gy-4 mb-0">
                <thead>
                  <tr className="fw-bolder text-muted fs-8 text-uppercase bg-light">
                    <th className="w-45px text-center">
                      <div className="form-check form-check-sm form-check-custom form-check-solid justify-content-center">
                        <input 
                          className="form-check-input" 
                          type="checkbox" 
                          checked={allFilteredSelected}
                          onChange={handleSelectAllFiltered}
                          disabled={filteredPresets.filter(h => !addedHolidays.includes(h.title)).length === 0}
                        />
                      </div>
                    </th>
                    <th>Holiday Name</th>
                    <th>Category</th>
                    <th>Date</th>
                    <th className="text-end">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPresets.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-10 text-muted">
                        <i className="bi bi-emoji-frown fs-2 d-block mb-2"></i>
                        No matching holidays found
                      </td>
                    </tr>
                  ) : filteredPresets.map((holiday) => {
                    const isAdded = addedHolidays.includes(holiday.title);
                    const isSelected = selectedTitles.includes(holiday.title);
                    const isItemLoading = individualLoading[holiday.title];

                    return (
                      <tr key={holiday.title} className={isAdded ? 'bg-light-success bg-opacity-25' : ''}>
                        <td className="text-center">
                          <div className="form-check form-check-sm form-check-custom form-check-solid justify-content-center">
                            <input 
                              className="form-check-input" 
                              type="checkbox" 
                              checked={isSelected}
                              disabled={isAdded || loading}
                              onChange={() => handleToggleSelect(holiday.title)}
                            />
                          </div>
                        </td>
                        <td>
                          <span className="fw-bolder text-gray-800 fs-7">{holiday.title}</span>
                        </td>
                        <td>
                          <span className={`badge ${categoryBadgeColor(holiday.category)} fw-bold fs-9`}>
                            {holiday.category}
                          </span>
                        </td>
                        <td>
                          <span className="text-muted fw-bold fs-7">{formatDateReadable(holiday.date)}</span>
                        </td>
                        <td className="text-end">
                          {isAdded ? (
                            <span className="badge badge-light-success d-inline-flex align-items-center gap-1 py-2 px-3 fw-bold">
                              <i className="bi bi-check-lg text-success"></i> Added
                            </span>
                          ) : (
                            <button 
                              type="button" 
                              className="btn btn-sm btn-light-primary py-2 px-3"
                              disabled={loading || isItemLoading}
                              onClick={() => handleAddSingleHoliday(holiday)}
                            >
                              {isItemLoading ? (
                                <span className="spinner-border spinner-border-sm align-middle me-1"></span>
                              ) : (
                                <i className="bi bi-plus-lg me-1"></i>
                              )}
                              Add
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <form onSubmit={handleManualSubmit}>
            <p className="text-muted mb-6">
              Add multiple custom holidays manually at once. All items will be marked as full-day school holidays on the calendar.
            </p>
            
            <div className="table-responsive" style={{ maxHeight: '350px', overflowY: 'auto' }}>
              <table className="table table-borderless align-middle gs-3 gy-3 mb-0">
                <thead>
                  <tr className="fw-bold text-muted border-bottom fs-8 text-uppercase">
                    <th>Holiday Title (e.g. Founder's Day)</th>
                    <th>Start Date</th>
                    <th>End Date (Optional)</th>
                    <th className="text-end">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.id}>
                      <td>
                        <input 
                          type="text" 
                          className="form-control form-control-solid fs-7" 
                          placeholder="Title" 
                          value={row.title} 
                          onChange={(e) => handleChange(row.id, 'title', e.target.value)} 
                          required 
                        />
                      </td>
                      <td>
                        <input 
                          type="date" 
                          className="form-control form-control-solid fs-7" 
                          value={row.start_time} 
                          onChange={(e) => handleChange(row.id, 'start_time', e.target.value)} 
                          required 
                        />
                      </td>
                      <td>
                        <input 
                          type="date" 
                          className="form-control form-control-solid fs-7" 
                          value={row.end_time} 
                          onChange={(e) => handleChange(row.id, 'end_time', e.target.value)} 
                        />
                      </td>
                      <td className="text-end">
                        {rows.length > 1 && (
                          <button 
                            type="button" 
                            className="btn btn-icon btn-light-danger btn-sm" 
                            onClick={() => removeRow(row.id)}
                          >
                            <KTIcon iconName="trash" className="fs-3" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-5 d-flex justify-content-between align-items-center">
              <button type="button" className="btn btn-sm btn-light-primary d-flex align-items-center gap-1" onClick={addRow}>
                <i className="bi bi-plus-lg"></i> Add Row
              </button>
              
              <div className="d-flex gap-2">
                <button type="button" className="btn btn-sm btn-light" onClick={onHide} disabled={loading}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-sm btn-primary" disabled={loading}>
                  {loading ? 'Saving...' : `Save ${rows.filter(r => r.title && r.start_time).length} Holidays`}
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </Modal>
  );
};

export default BulkHolidayModal;
