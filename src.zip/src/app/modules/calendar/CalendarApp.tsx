import React, { useState, useEffect, useCallback } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import listPlugin from '@fullcalendar/list';
import axios from 'axios';
import { useAuth } from '../auth';
import { PageTitle } from '../../../_metronic/layout/core';
import EventModal from './components/EventModal';
import BulkHolidayModal from './components/BulkHolidayModal';
import { toast } from 'react-toastify';
import { KTIcon } from '../../../_metronic/helpers';
import './CalendarApp.css';

const formatEventTime = (date: Date | null) => {
  if (!date) return '';
  let hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? 'p' : 'a';
  hours = hours % 12;
  hours = hours ? hours : 12;
  const minutesStr = minutes < 10 ? '0' + minutes : minutes;
  return `${hours}:${minutesStr}${ampm}`;
};

const renderEventContent = (eventInfo: any) => {
  const isTimetable = eventInfo.event.extendedProps?.isTimetable;
  if (isTimetable) {
    return (
      <div className="fc-event-main-frame">
        <div className="fc-event-title fc-sticky">{eventInfo.event.title}</div>
      </div>
    );
  }
  const timeStr = eventInfo.event.allDay ? '' : formatEventTime(eventInfo.event.start);
  return (
    <div className="custom-fc-event-content">
      {timeStr && <span className="custom-fc-event-time">{timeStr}</span>}
      <span className="custom-fc-event-title">{eventInfo.event.title}</span>
    </div>
  );
};




const API_URL = import.meta.env.VITE_APP_API_URL;

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'] as const;
type DayKey = typeof DAYS[number];
const DAY_SHORT: Record<DayKey, string> = {
  MONDAY: 'Mon', TUESDAY: 'Tue', WEDNESDAY: 'Wed',
  THURSDAY: 'Thu', FRIDAY: 'Fri', SATURDAY: 'Sat', SUNDAY: 'Sun',
};
const fmtTime = (t: string) => {
  if (!t) return '';
  const [h, m] = t.split(':');
  const hr = parseInt(h);
  return `${hr % 12 || 12}:${m}${hr >= 12 ? 'pm' : 'am'}`;
};
const PASTEL_COLORS = [
  { bg: '#e8e0ff', text: '#5e35b1', border: '#c5b8f8' }, // purple
  { bg: '#d4eeff', text: '#1565c0', border: '#a8d4f8' }, // blue
  { bg: '#d4f5e9', text: '#1b7a4e', border: '#95dfc0' }, // green
  { bg: '#fce8ff', text: '#8b1db8', border: '#e4a8f8' }, // pink-purple
  { bg: '#fff3d4', text: '#9a6200', border: '#f5d68a' }, // amber
  { bg: '#d4f0ff', text: '#0277bd', border: '#90d4f5' }, // sky
  { bg: '#ffd4d4', text: '#c62828', border: '#f5a0a0' }, // rose
  { bg: '#d4ffd4', text: '#2e7d32', border: '#90e890' }, // mint
] as const;

function subjectColor(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
  return PASTEL_COLORS[Math.abs(h) % PASTEL_COLORS.length];
}

const CalendarApp: React.FC = () => {
  const { currentUser } = useAuth();
  const schoolId = String(currentUser?.schoolId || '');

  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('All');

  const fetchEvents = useCallback(async () => {
    if (!schoolId) return;
    setLoading(true);
    try {
      const res = await axios.get(`${API_URL}/school/${schoolId}/calendar`);
      if (res.data.success) {
        const mappedEvents = res.data.data.map((e: any) => {
          const lowerTitle = (e.title || '').toLowerCase();
          const isPurpleHoliday = e.type === 'holiday' && (
            lowerTitle.includes('muharram') || 
            lowerTitle.includes('eid') || 
            lowerTitle.includes('diwali') || 
            lowerTitle.includes('christmas')
          );
          
          return {
            id: e.id,
            title: e.title,
            start: e.start_time,
            end: e.end_time,
            allDay: e.is_all_day,
            classNames: [
              e.type === 'holiday' 
                ? (isPurpleHoliday ? 'event-holiday-purple' : 'event-holiday-yellow') 
                : `event-type-${e.type || 'event'}`
            ],
            backgroundColor: 'transparent',
            borderColor: 'transparent',
            extendedProps: {
              type: e.type,
              audience: e.audience,
              location: e.location,
              description: e.description,
              created_by: e.created_by,
              recipients: e.recipients || []
            }
          };
        });


        // Also fetch timetable if teacher to map as background/read-only events
        let ttEvents: any[] = [];
        if (currentUser?.role === 'teacher') {
          try {
            const ttRes = await axios.get(`${API_URL}/school/${schoolId}/teacher-app/timetable`);
            if (ttRes.data.success && ttRes.data.data?.timetable) {
              const tt = ttRes.data.data.timetable;
              const DAYS = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
              // Extremely simplified: Create recurring events for timetable
              Object.keys(tt).forEach(day => {
                const dayIdx = DAYS.indexOf(day);
                tt[day].forEach((period: any) => {
                  if (period.period_slot) {
                    ttEvents.push({
                      id: `tt_${period.timetable_entry_id}`,
                      title: `${period.subject?.name || 'Class'} (${period.class_section?.label || ''})`,
                      startTime: period.period_slot.start_time,
                      endTime: period.period_slot.end_time,
                      daysOfWeek: [dayIdx],
                      backgroundColor: '#e4e6ef',
                      textColor: '#3f4254',
                      borderColor: 'transparent',
                      editable: false,
                      extendedProps: { isTimetable: true }
                    });
                  }
                });
              });
            }
          } catch (e) { console.error("Could not load timetable for calendar", e); }
        }

        setEvents([...mappedEvents, ...ttEvents]);
      }
    } catch (error) {
      console.error('Error fetching calendar data', error);
      toast.error("Failed to load calendar events");
    } finally {
      setLoading(false);
    }
  }, [schoolId, currentUser]);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const handleDateSelect = (selectInfo: any) => {
    setSelectedDate(selectInfo);
    setSelectedEvent(null);
    setShowModal(true);
  };

  const handleEventClick = (clickInfo: any) => {
    if (clickInfo.event.extendedProps.isTimetable) return; // Don't edit timetable here
    
    // Prevent teachers from editing holidays
    if (currentUser?.role === 'teacher' && clickInfo.event.extendedProps.type === 'holiday') {
        toast.info("Holidays are managed by the school administration.");
        return;
    }

    setSelectedEvent(clickInfo.event);
    setSelectedDate(null);
    setShowModal(true);
  };

  const handleEventDrop = async (dropInfo: any) => {
    if (dropInfo.event.extendedProps.isTimetable) {
      dropInfo.revert();
      return;
    }

    // Prevent teachers from dragging holidays
    if (currentUser?.role === 'teacher' && dropInfo.event.extendedProps.type === 'holiday') {
        dropInfo.revert();
        toast.error("You cannot modify school holidays.");
        return;
    }

    try {
      await axios.put(`${API_URL}/school/${schoolId}/calendar/${dropInfo.event.id}`, {
        start_time: dropInfo.event.startStr,
        end_time: dropInfo.event.endStr || dropInfo.event.startStr,
        is_all_day: dropInfo.event.allDay
      });
      toast.success("Event time updated");
    } catch (error) {
      console.error(error);
      toast.error("Unauthorized or failed to update event");
      dropInfo.revert();
    }
  };

  const handleSaveEvent = async (formData: any) => {
    try {
      if (selectedEvent) {
        await axios.put(`${API_URL}/school/${schoolId}/calendar/${selectedEvent.id}`, formData);
        toast.success("Event updated successfully");
      } else {
        await axios.post(`${API_URL}/school/${schoolId}/calendar`, formData);
        toast.success("Event created successfully");
      }
      fetchEvents();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Error saving event");
      throw error;
    }
  };

  const handleSaveBulkHolidays = async (events: any[]) => {
    try {
      await axios.post(`${API_URL}/school/${schoolId}/calendar/bulk`, { events });
      toast.success(`${events.length} holidays added successfully`);
      fetchEvents();
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Error saving bulk holidays");
      throw error;
    }
  };

  const filteredEvents = events.filter(e => {
    if (activeTab === 'All') return true;
    if (activeTab === 'Events') return e.extendedProps?.type === 'event';
    if (activeTab === 'Meetings') return e.extendedProps?.type === 'meeting';
    if (activeTab === 'Tasks') return e.extendedProps?.type === 'task';
    if (activeTab === 'Holidays') return e.extendedProps?.type === 'holiday';
    return true;
  });

  const isTeacher = currentUser?.role === 'teacher';
  const calendarTabs = [
    { id: 'All', label: isTeacher ? 'All Scheduled' : 'All Events', icon: 'bi-calendar-event' },
    { id: 'Events', label: 'Events', icon: 'bi-star' },
    { id: 'Meetings', label: 'Meetings', icon: 'bi-people' },
    { id: 'Tasks', label: 'Task Reminders', icon: 'bi-card-checklist' },
    { id: 'Holidays', label: 'Holidays', icon: 'bi-calendar-heart' }
  ];

  return (
    <>
      <PageTitle breadcrumbs={[]}>Calendar</PageTitle>

      <div className="card custom-calendar-wrapper">
        <div className="card-header pt-7">
          <div className="card-title">
            <ul className="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder">
            {calendarTabs.map(tab => (
              <li className="nav-item" key={tab.id}>
                <a
                  className={`nav-link text-active-primary ms-0 me-10 py-5 cursor-pointer ${activeTab === tab.id ? 'active' : ''}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.label}
                </a>
              </li>
            ))}
            </ul>
          </div>
          <div className="card-toolbar gap-3">
            {!isTeacher && (
              <button className="btn btn-bulk-holidays btn-sm" onClick={() => setShowBulkModal(true)}>
                <i className="bi bi-calendar-heart fs-2"></i> Bulk Holidays
              </button>
            )}
            <button className="btn btn-new-event btn-sm" onClick={() => { setSelectedEvent(null); setSelectedDate(null); setShowModal(true); }}>
              <i className="bi bi-plus fs-2"></i> New
            </button>
          </div>
        </div>

        <div className="card-body p-9">
          {activeTab === 'All' && isTeacher ? (
            <AllScheduledView schoolId={schoolId} calendarEvents={events} />
          ) : (
            <FullCalendar
              plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin, listPlugin]}
              initialView={window.innerWidth < 768 ? 'listMonth' : 'dayGridMonth'}
              headerToolbar={{
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
              }}
              editable={true}
              selectable={true}
              selectMirror={true}
              dayMaxEvents={true}
              events={filteredEvents}
              select={handleDateSelect}
              eventClick={handleEventClick}
              eventDrop={handleEventDrop}
              eventResize={handleEventDrop}
              eventContent={renderEventContent}
              height="auto"
            />
          )}
        </div>
      </div>

      <EventModal
        show={showModal}
        onHide={() => setShowModal(false)}
        onSave={handleSaveEvent}
        event={selectedEvent}
        selectedDate={selectedDate}
        currentUser={currentUser}
        schoolId={schoolId}
        fetchEvents={fetchEvents}
      />

      <BulkHolidayModal 
        show={showBulkModal}
        onHide={() => setShowBulkModal(false)}
        onSave={handleSaveBulkHolidays}
      />
    </>
  );
};

export default CalendarApp;

// ─── All Scheduled View ──────────────────────────────────────────────────────
const AllScheduledView: React.FC<{ schoolId: string; calendarEvents: any[] }> = ({ schoolId, calendarEvents }) => {
  const [ttData, setTtData] = React.useState<any>(null);
  const [ttLoading, setTtLoading] = React.useState(false);
  const [viewMode, setViewMode] = React.useState<'grid' | 'day'>('grid');
  const todayStr = new Date().toLocaleString('en-US', { weekday: 'long' }).toUpperCase() as DayKey;
  const today = DAYS.includes(todayStr) ? todayStr : null;
  const [activeDay, setActiveDay] = React.useState<DayKey>(today || 'MONDAY');

  React.useEffect(() => {
    if (!schoolId) return;
    setTtLoading(true);
    axios.get(`${API_URL}/school/${schoolId}/teacher-app/timetable`)
      .then(res => { if (res.data.success) setTtData(res.data.data); })
      .catch(() => {})
      .finally(() => setTtLoading(false));
  }, [schoolId]);

  const tt = ttData?.timetable || {};
  // Collect all unique period slots
  const slotMap = new Map<number, any>();
  DAYS.forEach(d => (tt[d] || []).forEach((e: any) => {
    if (e.period_slot) slotMap.set(e.period_slot.id, e.period_slot);
  }));
  const slots = Array.from(slotMap.values()).sort((a, b) => a.start_time.localeCompare(b.start_time));
  const totalPeriods = DAYS.reduce((s, d) => s + (tt[d]?.length || 0), 0);

  // Upcoming events from calendar (next 5 non-timetable events)
  const upcomingEvents = calendarEvents
    .filter(e => !e.extendedProps?.isTimetable && new Date(e.start) >= new Date())
    .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime())
    .slice(0, 5);

  const typeColor: Record<string, string> = {
    event: 'primary', meeting: 'success', task: 'danger', holiday: 'warning'
  };
  const typeIcon: Record<string, string> = {
    event: 'star', meeting: 'people', task: 'check-square', holiday: 'calendar-heart'
  };

  return (
    <div className="row g-5">
      {/* ── Left: Timetable ── */}
      <div className="col-xl-8">
        {/* Stats Row */}
        <div className="row g-4 mb-6">
          {[
            { label: 'Periods / Week', value: totalPeriods, icon: 'calendar', color: 'primary' },
            { label: 'Session', value: ttData?.session_name || '—', icon: 'award', color: 'info' },
            { label: 'Today', value: today ? (tt[today]?.length || 0) + ' periods' : '—', icon: 'time', color: 'success' },
          ].map(s => (
            <div className="col-4" key={s.label}>
              <div className="card card-flush border-0 bg-light h-100">
                <div className="card-body py-4 px-5 d-flex align-items-center gap-4">
                  <div className={`symbol symbol-45px`}>
                    <div className={`symbol-label bg-light-${s.color}`}>
                      <KTIcon iconName={s.icon} className={`fs-2 text-${s.color}`} />
                    </div>
                  </div>
                  <div>
                    <div className="fw-bolder fs-5 text-gray-900">{s.value}</div>
                    <div className="text-muted fw-semibold fs-8">{s.label}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Timetable Card */}
        <div className="card border-0 shadow-sm">
          <div className="card-header border-0 pt-5">
            <div className="card-title">
              <h3 className="fw-bolder text-gray-900 mb-0">
                <KTIcon iconName="calendar-2" className="fs-3 me-2 text-primary" />
                My Weekly Timetable
                {today && tt[today] && (
                  <span className="badge badge-light-primary ms-3 fs-8">
                    {tt[today]!.length} periods today
                  </span>
                )}
              </h3>
            </div>
            <div className="card-toolbar">
              <div className="btn-group btn-group-sm">
                <button className={`btn btn-sm ${viewMode === 'grid' ? 'btn-primary' : 'btn-light'}`} onClick={() => setViewMode('grid')}>
                  <KTIcon iconName="element-11" className="fs-6 me-1" />Grid
                </button>
                <button className={`btn btn-sm ${viewMode === 'day' ? 'btn-primary' : 'btn-light'}`} onClick={() => setViewMode('day')}>
                  <KTIcon iconName="row-horizontal" className="fs-6 me-1" />Day
                </button>
              </div>
            </div>
          </div>
          <div className="separator separator-dashed my-0" />
          <div className="card-body p-0">
            {ttLoading && (
              <div className="d-flex justify-content-center py-16">
                <span className="spinner-border text-primary" />
              </div>
            )}
            {!ttLoading && viewMode === 'grid' && (
              <div className="table-responsive">
                <table className="table table-row-dashed table-row-gray-200 align-middle gs-4 gy-0 mb-0" style={{ minWidth: '700px' }}>
                  <thead>
                    <tr className="fw-bold fs-8 text-uppercase text-gray-500 bg-light">
                      <th className="ps-4 py-4 border-end" style={{ minWidth: '110px', position: 'sticky', left: 0, background: '#f9f9f9', zIndex: 2 }}>
                        <KTIcon iconName="time" className="fs-6 text-primary me-1" />Period
                      </th>
                      {DAYS.map(day => (
                        <th key={day} className={`text-center py-4 ${day === today ? 'bg-light-primary' : ''}`} style={{ minWidth: '130px' }}>
                          <div className={`fw-bolder ${day === today ? 'text-primary' : 'text-gray-700'}`}>
                            {day === today && <span className="bullet bullet-dot bg-primary h-5px w-5px me-1 mb-1" />}
                            {DAY_SHORT[day]}
                          </div>
                          <div className="text-muted fs-9">{tt[day]?.length ? `${tt[day]!.length}p` : 'Free'}</div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {slots.length === 0 ? (
                      <tr><td colSpan={DAYS.length + 1}>
                        <div className="d-flex flex-column align-items-center py-14">
                          <KTIcon iconName="calendar" className="fs-4x text-gray-200 mb-3" />
                          <div className="text-muted fw-semibold">No timetable assigned yet</div>
                        </div>
                      </td></tr>
                    ) : slots.map(slot => (
                      <tr key={slot.id}>
                        <td className="ps-4 py-3 border-end border-gray-200" style={{ position: 'sticky', left: 0, background: '#fff', zIndex: 1 }}>
                          <div className="fw-bold text-gray-800 fs-7">{slot.name}</div>
                          <div className="text-muted fs-9">{fmtTime(slot.start_time)} – {fmtTime(slot.end_time)}</div>
                        </td>
                        {DAYS.map(day => {
                          const entry = (tt[day] || []).find((e: any) => e.period_slot?.id === slot.id);
                          const palette = entry?.subject ? subjectColor(entry.subject.name) : null;
                          const isToday = day === today;
                          return (
                            <td key={day} className={`py-2 px-2 align-top ${isToday ? 'bg-light' : ''}`} style={{ minWidth: '130px', verticalAlign: 'top' }}>
                              {entry?.subject && palette ? (
                                <div style={{
                                  background: palette.bg,
                                  borderTop: `3px dashed ${palette.border}`,
                                  borderRadius: '8px',
                                  padding: '10px 10px 12px',
                                  minHeight: '85px',
                                  display: 'flex',
                                  flexDirection: 'column',
                                  justifyContent: 'space-between',
                                  cursor: 'default'
                                }}>
                                  <div style={{ fontSize: '10px', color: palette.text, opacity: 0.8, fontWeight: 600, letterSpacing: '0.3px' }}>
                                    {fmtTime(slot.start_time)} – {fmtTime(slot.end_time)}
                                  </div>
                                  <div style={{ fontSize: '13px', color: palette.text, fontWeight: 700, lineHeight: '1.3', marginTop: '6px' }}>
                                    {entry.subject.name}
                                    {entry.subject.code && <span style={{ fontWeight: 400, opacity: 0.7, fontSize: '11px', marginLeft: '4px' }}>({entry.subject.code})</span>}
                                  </div>
                                  {entry.class_section && (
                                    <div style={{ fontSize: '10px', color: palette.text, opacity: 0.65, marginTop: '5px', fontWeight: 600 }}>
                                      <KTIcon iconName="people" className="fs-9 me-1" />
                                      {entry.class_section.label}
                                    </div>
                                  )}
                                </div>
                              ) : (
                                <div style={{ minHeight: '85px' }} />
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {!ttLoading && viewMode === 'day' && (
              <div>
                <div className="d-flex flex-wrap gap-2 px-6 py-4 border-bottom">
                  {DAYS.map(day => (
                    <button key={day} type="button" onClick={() => setActiveDay(day)}
                      className={`btn btn-sm ${activeDay === day ? 'btn-primary' : 'btn-light'}`}>
                      {DAY_SHORT[day]}
                      {day === today && <span className="bullet bullet-dot bg-danger ms-1 mb-1" />}
                      {tt[day]?.length > 0 && <span className={`badge ms-1 badge-sm ${activeDay === day ? 'badge-light' : 'badge-light-primary'}`}>{tt[day]!.length}</span>}
                    </button>
                  ))}
                </div>
                <div className="px-6 py-5">
                  {(tt[activeDay] || []).length === 0 ? (
                    <div className="d-flex flex-column align-items-center py-12 border border-dashed border-gray-300 rounded">
                      <KTIcon iconName="calendar" className="fs-4x text-gray-200 mb-3" />
                      <div className="text-muted fw-semibold">No classes on {DAY_SHORT[activeDay]}</div>
                    </div>
                  ) : (
                    <div className="d-flex flex-column gap-3">
                      {(tt[activeDay] || []).sort((a: any, b: any) => (a.period_slot?.start_time || '').localeCompare(b.period_slot?.start_time || '')).map((entry: any, idx: number) => {
                        const color = entry.subject ? subjectColor(entry.subject.name) : 'secondary';
                        return (
                          <div key={idx} className="d-flex align-items-center gap-4 p-4 rounded bg-light">
                            <div className={`symbol symbol-45px`}><div className={`symbol-label bg-light-${color}`}>
                              <span className={`fw-bolder fs-5 text-${color}`}>{idx + 1}</span>
                            </div></div>
                            <div className="flex-grow-1">
                              <div className="fw-bolder text-gray-900 fs-6">{entry.subject?.name || <span className="text-muted">Free Period</span>}</div>
                              {entry.period_slot && <div className="text-muted fs-8"><KTIcon iconName="time" className="fs-8 me-1" />{entry.period_slot.name} · {fmtTime(entry.period_slot.start_time)} – {fmtTime(entry.period_slot.end_time)}</div>}
                              {entry.class_section && <div className="text-muted fs-8"><KTIcon iconName="people" className="fs-8 me-1" />{entry.class_section.label}</div>}
                            </div>
                            {entry.period_slot && <span className={`badge badge-light-${color} fs-8 fw-bold`}>{fmtTime(entry.period_slot.start_time)}</span>}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Right: Upcoming Events ── */}
      <div className="col-xl-4">
        <div className="card border-0 shadow-sm h-100">
          <div className="card-header border-0 pt-5">
            <h3 className="card-title fw-bolder text-gray-900">
              <KTIcon iconName="notification" className="fs-3 me-2 text-warning" />
              Upcoming
            </h3>
          </div>
          <div className="separator separator-dashed my-0" />
          <div className="card-body py-4 px-5">
            {upcomingEvents.length === 0 ? (
              <div className="d-flex flex-column align-items-center py-10">
                <KTIcon iconName="calendar-heart" className="fs-4x text-gray-200 mb-3" />
                <div className="text-muted fw-semibold fs-7">No upcoming events</div>
              </div>
            ) : (
              <div className="d-flex flex-column gap-4">
                {upcomingEvents.map((ev, i) => {
                  const type = ev.extendedProps?.type || 'event';
                  const color = typeColor[type] || 'primary';
                  const icon = typeIcon[type] || 'star';
                  const date = new Date(ev.start);
                  return (
                    <div key={i} className="d-flex align-items-center gap-3">
                      <div className={`symbol symbol-40px flex-shrink-0`}>
                        <div className={`symbol-label bg-light-${color}`}>
                          <KTIcon iconName={icon} className={`fs-4 text-${color}`} />
                        </div>
                      </div>
                      <div className="flex-grow-1">
                        <div className="fw-bolder text-gray-900 fs-7">{ev.title}</div>
                        <div className="text-muted fs-9">
                          {date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </div>
                      </div>
                      <span className={`badge badge-light-${color} fs-9`}>{type}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
