export interface StudentAttendanceRecord {
    student_id: number;
    first_name: string;
    last_name: string;
    mobile_number: string;
    roll_number?: string | null;
    enrollment_id: number;
    attendance_id: number | null;
    status: 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY' | 'LEAVE' | null;
    remark: string | null;
    attendance_mode: string | null;
    entry_time: string | null;
    exit_time: string | null;
}

export interface StudentAttendanceFetchResponse {
    success: boolean;
    message: string;
    data: {
        attendances: StudentAttendanceRecord[];
    };
}

export interface MarkStudentAttendancePayload {
    class_section_id: number;
    academic_session_id?: number | null;
    date: string; // YYYY-MM-DD
    students: {
        student_id: number;
        status: string;
        remark?: string | null;
    }[];
}

export interface StaffAttendanceRecord {
    staff_id: number;
    staff_type: 'TEACHER' | 'ADMIN';
    name?: string;
    first_name?: string;
    last_name?: string;
    designation: string;
    attendance_id: number | null;
    status: 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY' | 'LEAVE' | null;
    remark: string | null;
    entry_time: string | null;
    exit_time: string | null;
}

export interface StaffAttendanceFetchResponse {
    success: boolean;
    message: string;
    data: {
        attendances: StaffAttendanceRecord[];
    };
}

export interface MarkStaffAttendancePayload {
    date: string; // YYYY-MM-DD
    staffList: {
        staff_id: number;
        staff_type: 'TEACHER' | 'ADMIN';
        status: string;
        remark?: string | null;
    }[];
}

export interface ClassMatrixStudent {
    student_id: number;
    name: string;
    attendance: Record<string, string>; // "YYYY-MM-DD": "STATUS"
    period_attendance?: Record<string, Record<string, string>>; // "YYYY-MM-DD": { "period_id": "STATUS" }
    summary: {
        present: number;
        absent: number;
        late: number;
        leave: number;
        half_day: number;
        total_periods?: number;
    };
}

export interface ClassMonthlyMatrixResponse {
    success: boolean;
    message: string;
    data: {
        matrix_report: {
            class_section_id: string;
            month: number;
            year: number;
            attendance_mode?: string;
            matrix: ClassMatrixStudent[];
        };
    };
}

export interface StudentMonthlyRecord {
    id: number;
    student_id: number;
    class_section_id: number;
    academic_session_id: number;
    date: string;
    status: string;
    attendance_mode: string;
    entry_time: string | null;
    exit_time: string | null;
    remark: string | null;
}

export interface StudentMonthlyReportResponse {
    success: boolean;
    message: string;
    data: {
        report: {
            student_id: string;
            month: number;
            year: number;
            summary: {
                total_marked: number;
                present: number;
                absent: number;
                late: number;
                half_day: number;
                leave: number;
            };
            attendance_mode?: string;
            period_matrix?: Record<string, Record<string, any>>;
            records: StudentMonthlyRecord[];
        };
    };
}

export interface StaffMatrixRecord {
    staff_id: number;
    staff_type: 'TEACHER' | 'ADMIN';
    name: string;
    designation: string;
    attendance: Record<string, string>; // "YYYY-MM-DD": "STATUS"
    summary: {
        present: number;
        absent: number;
        late: number;
        leave: number;
        half_day: number;
    };
}

export interface StaffMonthlyMatrixResponse {
    success: boolean;
    message: string;
    data: {
        matrix_report: {
            month: number;
            year: number;
            matrix: StaffMatrixRecord[];
        };
    };
}

export interface StaffMonthlyRecord {
    id: number;
    staff_id: number;
    staff_type: 'TEACHER' | 'ADMIN';
    date: string;
    status: string;
    attendance_mode: string;
    entry_time: string | null;
    exit_time: string | null;
    remark: string | null;
}

export interface StaffMonthlyReportResponse {
    success: boolean;
    message: string;
    data: {
        report: {
            staff_id: string;
            staff_type: string;
            month: number;
            year: number;
            summary: {
                total_marked: number;
                present: number;
                absent: number;
                late: number;
                half_day: number;
                leave: number;
            };
            records: StaffMonthlyRecord[];
        };
    };
}

export interface AdminDashboardStatsResponse {
    success: boolean;
    message: string;
    data: {
        dashboard_stats: {
            date: string;
            session_id: number;
            attendance_mode: string;
            overall: {
                total_enrolled: number;
                total_present: number;
                total_absent: number;
                total_late: number;
                total_leave: number;
                total_not_marked: number;
                percentage: number;
            };
            class_wise: {
                class_section_id: number;
                class_name: string;
                total: number;
                present: number;
                absent: number;
                late: number;
                leave: number;
                not_marked: number;
                percentage: number;
            }[];
        };
    };
}

export interface AdminMonthlyReportResponse {
    success: boolean;
    message: string;
    data: {
        report: {
            month: number;
            year: number;
            session_id: number;
            threshold_percentage: number;
            total_students: number;
            low_attendance_warnings: any[];
            records: {
                student_id: number;
                roll_number: string;
                name: string;
                mobile: string;
                class_name: string;
                attendance: Record<string, string>;
                summary: {
                    present: number;
                    absent: number;
                    late: number;
                    leave: number;
                    half_day: number;
                    total_marked_days: number;
                };
                percentage: number;
            }[];
        };
    };
}

