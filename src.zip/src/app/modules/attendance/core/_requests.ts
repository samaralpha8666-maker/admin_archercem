import axios from 'axios'
import {
    StudentAttendanceFetchResponse,
    MarkStudentAttendancePayload,
    StaffAttendanceFetchResponse,
    MarkStaffAttendancePayload,
    ClassMonthlyMatrixResponse,
    StudentMonthlyReportResponse,
    StaffMonthlyMatrixResponse,
    StaffMonthlyReportResponse,
    AdminDashboardStatsResponse,
    AdminMonthlyReportResponse
} from './_models'

const API_URL = import.meta.env.VITE_APP_API_URL

// 1. Daily Attendance Register Fetch (GET)
// curl --location 'http://localhost:3000/api/school/30/attendance/students?class_section_id=1&date=2024-04-10'
export function getStudentAttendance(schoolId: string | number, classSectionId: string | number, date: string, timetableEntryId?: number | string) {
    return axios.get<StudentAttendanceFetchResponse>(`${API_URL}/school/${schoolId}/attendance/students`, {
        params: { class_section_id: classSectionId, date, timetable_entry_id: timetableEntryId }
    })
}

// 2. Manual Attendance Submit/Update (POST)
// curl --location 'http://localhost:3000/api/school/30/attendance/students/mark'
export function markStudentAttendance(schoolId: string | number, payload: MarkStudentAttendancePayload) {
    return axios.post<{ success: boolean; message: string; data: any }>(
        `${API_URL}/school/${schoolId}/attendance/students/mark`,
        payload
    )
}

// 3. All Staff Register Fetch API (GET)
// curl --location 'http://localhost:3000/api/school/30/attendance/staff?date=2024-04-10'
export function getStaffAttendance(schoolId: string | number, date: string) {
    return axios.get<StaffAttendanceFetchResponse>(`${API_URL}/school/${schoolId}/attendance/staff`, {
        params: { date }
    })
}

// 4. Mark Staff Attendance (POST)
// curl --location 'http://localhost:3000/api/school/30/attendance/staff/mark'
export function markStaffAttendance(schoolId: string | number, payload: MarkStaffAttendancePayload) {
    return axios.post<{ success: boolean; message: string; data: any }>(
        `${API_URL}/school/${schoolId}/attendance/staff/mark`,
        payload
    )
}

// 5. Class Monthly Matrix API (GET)
// curl --location 'http://localhost:3000/api/school/30/attendance/class-matrix?class_section_id=1&month=4&year=2024'
export function getClassMonthlyMatrix(
    schoolId: string | number,
    classSectionId: string | number,
    month: number,
    year: number
) {
    return axios.get<ClassMonthlyMatrixResponse>(`${API_URL}/school/${schoolId}/attendance/class-matrix`, {
        params: { class_section_id: classSectionId, month, year }
    })
}

// 5.b Class Period Monthly Matrix API (GET)
export function getClassPeriodMonthlyMatrix(
    schoolId: string | number,
    classSectionId: string | number,
    month: number,
    year: number,
    sessionId: string | number
) {
    return axios.get<ClassMonthlyMatrixResponse>(`${API_URL}/school/${schoolId}/attendance/class-period-matrix`, {
        params: { class_section_id: classSectionId, month, year, session_id: sessionId }
    })
}

// 6. Student Monthly Report API (GET)
// curl --location 'http://localhost:3000/api/school/30/attendance/students/1/report?month=04&year=2024'
export function getStudentMonthlyReport(
    schoolId: string | number,
    studentId: string | number,
    month: number | string,
    year: number
) {
    return axios.get<StudentMonthlyReportResponse>(
        `${API_URL}/school/${schoolId}/attendance/students/${studentId}/report`,
        {
            params: { month, year }
        }
    )
}

// 7. Staff Monthly Matrix API (GET)
// curl --location 'http://localhost:3000/api/school/[SCHOOL_ID]/attendance/staff/matrix?month=4&year=2026'
export function getStaffMonthlyMatrix(
    schoolId: string | number,
    month: number,
    year: number
) {
    return axios.get<StaffMonthlyMatrixResponse>(`${API_URL}/school/${schoolId}/attendance/staff/matrix`, {
        params: { month, year }
    })
}

// 8. Individual Staff Monthly Report API (GET)
// curl --location 'http://localhost:3000/api/school/[SCHOOL_ID]/attendance/staff/TEACHER/1/report?month=4&year=2026'
export function getStaffMonthlyReport(
    schoolId: string | number,
    staffType: 'TEACHER' | 'ADMIN',
    staffId: string | number,
    month: number | string,
    year: number
) {
    return axios.get<StaffMonthlyReportResponse>(
        `${API_URL}/school/${schoolId}/attendance/staff/${staffType}/${staffId}/report`,
        {
            params: { month, year }
        }
    )
}

// 9. Admin Dashboard Stats (GET)
export function getAdminDashboardStats(schoolId: string | number, date: string, sessionId?: string | number) {
    return axios.get<AdminDashboardStatsResponse>(`${API_URL}/school/${schoolId}/admin/attendance/dashboard-stats`, {
        params: { date, session_id: sessionId }
    })
}

// 10. Admin Monthly Reports (GET)
export function getAdminMonthlyReports(
    schoolId: string | number,
    month: number,
    year: number,
    threshold?: number
) {
    return axios.get<AdminMonthlyReportResponse>(`${API_URL}/school/${schoolId}/admin/attendance/reports/monthly`, {
        params: { month, year, threshold }
    })
}

// 11. Admin Mark Student Daily Attendance Override (POST)
export function adminMarkStudentAttendance(schoolId: string | number, payload: MarkStudentAttendancePayload) {
    return axios.post<{ success: boolean; message: string; data: any }>(
        `${API_URL}/school/${schoolId}/admin/attendance/mark`,
        payload
    )
}

// 12. Admin Mark Student Period Attendance Override (POST)
export function adminMarkStudentPeriodAttendance(schoolId: string | number, payload: MarkStudentAttendancePayload & { timetable_entry_id: number }) {
    return axios.post<{ success: boolean; message: string; data: any }>(
        `${API_URL}/school/${schoolId}/admin/attendance/mark-period`,
        payload
    )
}

// 13. Admin Mark Staff Attendance Override (POST)
export function adminMarkStaffAttendance(schoolId: string | number, payload: MarkStaffAttendancePayload) {
    return axios.post<{ success: boolean; message: string; data: any }>(
        `${API_URL}/school/${schoolId}/admin/staff-attendance/mark`,
        payload
    )
}
