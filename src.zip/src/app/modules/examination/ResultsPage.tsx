import { FC, useState, useCallback } from 'react'
import { Modal } from 'react-bootstrap'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import {
  getExamGroups, getMarksheet,
  downloadStudentReportCardPdf, downloadBulkReportCardsZip, applyGraceMarks
} from './core/_requests'
import { ExamGroup, ExamSubject, MarksheetStudent, ExamResult } from './core/_models'
import { getClasses } from '../academic/core/_requests'
import { toast } from 'react-toastify'

const fmt = (n: string | number | null | undefined) => n != null ? Number(n).toFixed(1) : '—'

// ── Grace marks modal ─────────────────────────────────────────────────────────
const GraceModal: FC<{
  show: boolean
  result: (ExamResult & { student_name?: string }) | null
  schoolId: string
  onClose: () => void
  onSaved: () => void
}> = ({ show, result, schoolId, onClose, onSaved }) => {
  const [val, setVal] = useState('')
  const [saving, setSaving] = useState(false)

  const handleApply = async () => {
    if (!result || !val) return
    setSaving(true)
    try {
      await applyGraceMarks(schoolId, result.id, Number(val))
      toast.success(`Grace marks applied to ${result.student_name}`)
      onSaved()
      onClose()
      setVal('')
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Failed to apply grace marks')
    } finally { setSaving(false) }
  }

  return (
    <Modal show={show} onHide={onClose} centered size='sm'>
      <Modal.Header closeButton>
        <Modal.Title className='fw-bold fs-5'>Apply Grace Marks</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {result && (
          <>
            <p className='text-gray-700 mb-4'>
              Student: <strong>{result.student_name}</strong><br />
              Current Marks: <strong>{result.marks_obtained}</strong>
              {(result as any).grace_marks > 0 && (
                <span className='badge badge-light-warning ms-2'>+{(result as any).grace_marks} Grace already</span>
              )}
            </p>
            <label className='form-label fw-bold'>Grace Marks to Add</label>
            <input
              type='number' min={0} max={20}
              className='form-control form-control-solid'
              placeholder='e.g. 5'
              value={val}
              onChange={e => setVal(e.target.value)}
            />
            <div className='text-muted fs-8 mt-2'>These marks will be added to the student's total (max 20).</div>
          </>
        )}
      </Modal.Body>
      <Modal.Footer>
        <button className='btn btn-light btn-sm' onClick={onClose}>Cancel</button>
        <button className='btn btn-warning btn-sm fw-bold' onClick={handleApply} disabled={saving || !val}>
          {saving ? <span className='spinner-border spinner-border-sm me-2' /> : null}
          Apply Grace Marks
        </button>
      </Modal.Footer>
    </Modal>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
const ResultsPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // ── Institution type ───────────────────────────────────────────────────────
  const isCollege = currentUser?.institution_type === 'COLLEGE'
  const classLabel = isCollege ? 'Course' : 'Class'

  const [groups, setGroups] = useState<ExamGroup[]>([])
  const [classes, setClasses] = useState<any[]>([])
  const [filterGroup, setFilterGroup] = useState('')
  const [filterClass, setFilterClass] = useState('')
  const [loading, setLoading] = useState(false)
  const [metaLoaded, setMetaLoaded] = useState(false)

  const [exams, setExams] = useState<ExamSubject[]>([])
  const [students, setStudents] = useState<MarksheetStudent[]>([])
  const [results, setResults] = useState<ExamResult[]>([])

  const [downloadingReport, setDownloadingReport] = useState<number | null>(null)
  const [downloadingZip, setDownloadingZip] = useState(false)

  // Grace marks modal state
  const [graceTarget, setGraceTarget] = useState<(ExamResult & { student_name?: string }) | null>(null)

  const loadMeta = useCallback(async () => {
    if (metaLoaded || !schoolId) return
    try {
      const [gRes, cRes] = await Promise.all([getExamGroups(schoolId), getClasses(schoolId, 1, 100)])
      if (gRes.data.success) setGroups(gRes.data.data || [])
      if (cRes.data.success) setClasses(cRes.data.data.classes || [])
      setMetaLoaded(true)
    } catch { }
  }, [schoolId, metaLoaded])

  if (!metaLoaded) loadMeta()

  const loadMarksheet = async () => {
    if (!filterGroup || !filterClass) return
    setLoading(true)
    try {
      const { data } = await getMarksheet(schoolId, Number(filterGroup), Number(filterClass))
      if (data.success) {
        setExams(data.data.exams || [])
        setStudents(data.data.students || [])
        setResults(data.data.results || [])
      }
    } catch { } finally { setLoading(false) }
  }

  const getResult = (studentId: number, examId: number) =>
    results.find(r => r.student_id === studentId && r.exam_id === examId)

  const getStudentTotal = (studentId: number) =>
    exams.reduce((sum, exam) => {
      const r = getResult(studentId, exam.id)
      return sum + (r && !r.is_absent ? Number(r.marks_obtained) : 0)
    }, 0)

  const getStudentMaxTotal = () => exams.reduce((sum, e) => sum + Number(e.max_marks), 0)

  const getStudentPct = (studentId: number) => {
    const max = getStudentMaxTotal()
    return max ? (getStudentTotal(studentId) / max) * 100 : 0
  }

  const selectedGroup = groups.find(g => String(g.id) === filterGroup)
  const selectedClass = classes.find(c => String(c.id) === filterClass)

  // ── Actions ─────────────────────────────────────────────────────────────────
  const handleDownloadPdf = async (studentId: number, name: string) => {
    if (!filterGroup) return
    setDownloadingReport(studentId)
    try {
      const res = await downloadStudentReportCardPdf(schoolId, Number(filterGroup), studentId)
      const url = window.URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' }))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `ReportCard_${name.replace(/\s+/g, '_')}.pdf`)
      document.body.appendChild(link); link.click(); link.remove()
      window.URL.revokeObjectURL(url)
    } catch { toast.error('Failed to download PDF') }
    finally { setDownloadingReport(null) }
  }

  const handleDownloadZip = async () => {
    if (!filterGroup || !filterClass) return
    setDownloadingZip(true)
    try {
      const res = await downloadBulkReportCardsZip(schoolId, Number(filterGroup), Number(filterClass))
      const url = window.URL.createObjectURL(new Blob([res.data], { type: 'application/zip' }))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `ReportCards_${selectedGroup?.name || 'Group'}_${selectedClass?.name || 'Class'}.zip`)
      document.body.appendChild(link); link.click(); link.remove()
      window.URL.revokeObjectURL(url)
      toast.success('ZIP downloaded successfully!')
    } catch { toast.error('Failed to download ZIP') }
    finally { setDownloadingZip(false) }
  }

  const handlePrint = () => {
    const content = document.getElementById('marksheet-print-area')?.innerHTML
    if (!content) return
    const win = window.open('', '_blank', 'width=900,height=700')
    if (!win) return
    win.document.write(`<html><head><title>Marksheet</title>
    <style>
      body{font-family:Arial,sans-serif;font-size:12px;padding:20px}
      table{width:100%;border-collapse:collapse}
      th,td{border:1px solid #ddd;padding:6px 10px;text-align:center}
      th{background:#f0f0f0;font-weight:bold;font-size:11px;text-transform:uppercase}
      .pass{color:#17c653;font-weight:bold}.fail{color:#f1416c;font-weight:bold}
      .absent{color:#888;font-style:italic}
      h2{text-align:center;margin-bottom:4px}p{text-align:center;color:#666;margin-bottom:20px}
      @media print{@page{size:A4 landscape;margin:10mm}}
    </style></head><body>${content}</body></html>`)
    win.document.close()
    setTimeout(() => win.print(), 300)
  }

  const isGroupLocked = selectedGroup?.status === 'PUBLISHED'

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* ── Filter Bar ── */}
        <div className='card card-flush shadow-sm mb-6'>
          <div className='card-header border-0 pt-5 pb-5 align-items-center flex-wrap gap-3'>
            <div className='d-flex align-items-center gap-3'>
              <h3 className='card-title fw-bold mb-0'>{isCollege ? 'Course' : 'Class'} Marksheet</h3>
              {isGroupLocked && (
                <span className='badge badge-light-danger fw-semibold'>
                  <i className='ki-duotone ki-lock fs-7 me-1' />Published & Locked
                </span>
              )}
            </div>
            <div className='d-flex gap-3 flex-wrap'>
              <select className='form-select form-select-solid form-select-sm w-200px' value={filterGroup}
                onChange={e => { setFilterGroup(e.target.value); setExams([]); setStudents([]); setResults([]) }}>
                <option value=''>Select Exam Group</option>
                {groups.map(g => (
                  <option key={g.id} value={g.id}>
                    {g.name} {g.status === 'PUBLISHED' ? '🔒' : g.status === 'COMPLETED' ? '✓' : ''}
                  </option>
                ))}
              </select>
              <select className='form-select form-select-solid form-select-sm w-160px' value={filterClass}
                disabled={!filterGroup}
                onChange={e => setFilterClass(e.target.value)}>
                <option value=''>Select {classLabel}</option>
                {classes.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <button className='btn btn-primary btn-sm' onClick={loadMarksheet} disabled={!filterGroup || !filterClass || loading}>
                {loading ? <span className='spinner-border spinner-border-sm me-2' /> : <i className='ki-duotone ki-eye fs-4 me-1'><span className='path1' /><span className='path2' /></i>}
                Load Marksheet
              </button>
            </div>
          </div>
        </div>

        {/* ── Empty state ── */}
        {!students.length && !loading && (
          <div className='card card-flush shadow-sm'>
            <div className='card-body text-center py-16'>
              <i className='ki-duotone ki-book fs-5x text-gray-300 mb-4'><span className='path1' /><span className='path2' /><span className='path3' /></i>
              <p className='text-muted fw-semibold fs-5'>Select an Exam Group and {classLabel} to view the marksheet</p>
            </div>
          </div>
        )}

        {/* ── Marksheet ── */}
        {students.length > 0 && (
          <div className='card card-flush shadow-sm'>
            <div className='card-header border-0 pt-5 align-items-center flex-wrap gap-3'>
              <div>
                <h4 className='fw-bold mb-1'>{selectedGroup?.name} — {selectedClass?.name}</h4>
                <span className='text-muted fs-7'>{students.length} Students · {exams.length} Subjects</span>
              </div>
              <div className='d-flex gap-3 flex-wrap'>
                {/* ⭐ Bulk ZIP download */}
                <button className='btn btn-sm btn-light-success fw-semibold' onClick={handleDownloadZip} disabled={downloadingZip}>
                  {downloadingZip
                    ? <><span className='spinner-border spinner-border-sm me-2' />Generating ZIP...</>
                    : <><i className='ki-duotone ki-file-down fs-4 me-1'><span className='path1' /><span className='path2' /></i>Download All PDFs (ZIP)</>}
                </button>
                <button className='btn btn-sm btn-light-primary fw-semibold' onClick={handlePrint}>
                  <i className='ki-duotone ki-printer fs-4 me-1'><span className='path1' /><span className='path2' /><span className='path3' /></i>
                  Print Marksheet
                </button>
              </div>
            </div>

            {/* Stats cards */}
            <div className='card-body pt-4 pb-0'>
              <div className='row g-4 mb-6'>
                {[
                  { label: 'Total Students', value: students.length, color: 'primary' },
                  { label: 'Subjects', value: exams.length, color: 'info' },
                  { label: 'Max Total Marks', value: getStudentMaxTotal(), color: 'warning' },
                  {
                    label: 'Pass %',
                    value: `${students.length ? ((students.filter(s => getStudentPct(s.id) >= 33).length / students.length) * 100).toFixed(0) : 0}%`,
                    color: 'success'
                  },
                ].map(({ label, value, color }) => (
                  <div className='col-sm-3' key={label}>
                    <div className={`card bg-light-${color} border-0 py-4 px-5`}>
                      <div className={`fs-2 fw-bolder text-${color}`}>{value}</div>
                      <div className='text-muted fw-semibold fs-8'>{label}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Marksheet table */}
            <div className='card-body pt-0' id='marksheet-print-area'>
              <h2 className='text-center fw-bold mb-1 d-none d-print-block'>{selectedGroup?.name}</h2>
              <p className='text-center text-muted mb-4 d-none d-print-block'>{selectedClass?.name}</p>

              <div className='table-responsive'>
                <table className='table align-middle table-row-bordered fs-7 gy-2 mb-0'>
                  <thead className='sticky-top bg-white'>
                    <tr className='fw-bold text-uppercase text-gray-500 fs-8'>
                      <th className='text-start ps-4' style={{ minWidth: 50 }}>#</th>
                      <th className='text-start' style={{ minWidth: 180 }}>Student</th>
                      <th style={{ minWidth: 70 }}>Roll No.</th>
                      {exams.map(e => (
                        <th key={e.id} style={{ minWidth: 100 }}>
                          {e.subject?.name || `#${e.id}`}
                          <div className='fw-normal text-muted fs-9 text-lowercase'>(/{e.max_marks})</div>
                          {(e as any).has_components && (
                            <div className='badge badge-light-info fs-9 fw-normal mt-1'>Split</div>
                          )}
                        </th>
                      ))}
                      <th style={{ minWidth: 90 }}>Total</th>
                      <th style={{ minWidth: 80 }}>%</th>
                      <th style={{ minWidth: 80 }}>Grade</th>
                      <th style={{ minWidth: 80 }}>Result</th>
                      <th className='text-end pe-4' style={{ minWidth: 140 }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((s, idx) => {
                      const total = getStudentTotal(s.id)
                      const max = getStudentMaxTotal()
                      const pct = max ? (total / max * 100) : 0
                      const isPass = pct >= 33
                      const hasAbsent = exams.some(e => getResult(s.id, e.id)?.is_absent)
                      const grades = exams.map(e => getResult(s.id, e.id)?.grade_name).filter(Boolean)
                      const topGrade = grades[0] || null

                      // Check if any result for this student is locked
                      const anyLocked = exams.some(e => (getResult(s.id, e.id) as any)?.is_locked)
                      // Collect grace marks
                      const totalGrace = exams.reduce((sum, e) => sum + (Number((getResult(s.id, e.id) as any)?.grace_marks) || 0), 0)
                      // Any re-evaluation applied
                      const reEvalApplied = exams.some(e => (getResult(s.id, e.id) as any)?.re_evaluation_status === 'APPLIED')

                      return (
                        <tr key={s.id}>
                          <td className='ps-4 text-muted'>{idx + 1}</td>
                          <td>
                            <div className='d-flex align-items-center gap-2'>
                              <div className='symbol symbol-30px'>
                                <div className='symbol-label fw-bolder text-primary bg-light-primary fs-7'>
                                  {s.first_name.charAt(0).toUpperCase()}
                                </div>
                              </div>
                              <div>
                                <div className='fw-bold text-gray-800'>{s.first_name} {s.last_name}</div>
                                <div className='d-flex gap-1 mt-1'>
                                  {anyLocked && <span className='badge badge-light-danger fs-9'><i className='ki-duotone ki-lock fs-9 me-1' />Locked</span>}
                                  {totalGrace > 0 && <span className='badge badge-light-warning fs-9'>+{totalGrace} Grace</span>}
                                  {reEvalApplied && <span className='badge badge-light-info fs-9'>Re-eval</span>}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className='text-center text-muted'>{s.enrollments?.[0]?.roll_number || '—'}</td>
                          {exams.map(e => {
                            const r = getResult(s.id, e.id)
                            return (
                              <td key={e.id} className='text-center'>
                                {!r
                                  ? <span className='text-gray-300'>—</span>
                                  : r.is_absent
                                    ? <span className='text-muted fw-semibold'>AB</span>
                                    : (
                                      <div>
                                        <span className={`fw-bolder ${Number(r.marks_obtained) >= Number(e.min_marks) ? 'text-success' : 'text-danger'}`}>
                                          {fmt(r.marks_obtained)}
                                        </span>
                                        {/* Show split marks as tooltip-style sub info */}
                                        {(e as any).has_components && (
                                          <div className='text-muted fs-9'>
                                            {(r as any).theory_marks != null && `T:${(r as any).theory_marks} `}
                                            {(r as any).practical_marks != null && `P:${(r as any).practical_marks}`}
                                            {(r as any).internal_marks != null && `I:${(r as any).internal_marks} `}
                                            {(r as any).external_marks != null && `E:${(r as any).external_marks}`}
                                          </div>
                                        )}
                                        {r.grade_name && <div className='badge badge-light-primary fs-9 mt-1'>{r.grade_name}</div>}
                                        {(r as any).grace_marks > 0 && (
                                          <div className='badge badge-light-warning fs-9 mt-1'>+{(r as any).grace_marks}G</div>
                                        )}
                                      </div>
                                    )
                                }
                              </td>
                            )
                          })}
                          <td className='text-center fw-bolder fs-6 text-gray-800'>{total}</td>
                          <td className='text-center'>
                            <span className={`fw-bold ${pct >= 60 ? 'text-success' : pct >= 33 ? 'text-warning' : 'text-danger'}`}>
                              {pct.toFixed(1)}%
                            </span>
                          </td>
                          <td className='text-center'>
                            {topGrade
                              ? <span className='badge badge-light-success fw-bold px-3'>{topGrade}</span>
                              : <span className='text-muted'>—</span>}
                          </td>
                          <td className='text-center'>
                            <span className={`badge fw-bold ${isPass ? 'badge-light-success' : 'badge-light-danger'}`}>
                              {hasAbsent ? 'AB' : isPass ? 'PASS' : 'FAIL'}
                            </span>
                          </td>
                          <td className='text-end pe-4'>
                            <div className='d-flex gap-2 justify-content-end'>
                              {/* Download individual PDF */}
                              <button
                                className='btn btn-icon btn-sm btn-light-primary'
                                title='Download Report Card PDF'
                                disabled={downloadingReport === s.id}
                                onClick={() => handleDownloadPdf(s.id, `${s.first_name} ${s.last_name}`)}
                              >
                                {downloadingReport === s.id
                                  ? <span className='spinner-border spinner-border-sm' />
                                  : <i className='ki-duotone ki-file-down fs-4'><span className='path1' /><span className='path2' /></i>}
                              </button>
                              {/* Grace marks button (only if not locked) */}
                              {!isGroupLocked && (
                                <button
                                  className='btn btn-icon btn-sm btn-light-warning'
                                  title='Apply Grace Marks'
                                  onClick={() => {
                                    // Pick first result for this student that has marks
                                    const firstResult = exams
                                      .map(e => getResult(s.id, e.id))
                                      .find(r => r && !r.is_absent)
                                    if (firstResult) {
                                      setGraceTarget({ ...firstResult, student_name: `${s.first_name} ${s.last_name}` })
                                    }
                                  }}
                                >
                                  <i className='ki-duotone ki-star fs-4'><span className='path1' /><span className='path2' /></i>
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                  <tfoot>
                    <tr className='bg-light fw-bolder fs-7 text-gray-700'>
                      <td colSpan={3} className='ps-4 text-uppercase'>{isCollege ? 'Course' : 'Class'} Average</td>
                      {exams.map(e => {
                        const examResults = results.filter(r => r.exam_id === e.id && !r.is_absent)
                        const avg = examResults.length
                          ? examResults.reduce((s, r) => s + Number(r.marks_obtained), 0) / examResults.length
                          : 0
                        return <td key={e.id} className='text-center'>{avg.toFixed(1)}</td>
                      })}
                      <td className='text-center'>
                        {students.length
                          ? (students.reduce((s, st) => s + getStudentTotal(st.id), 0) / students.length).toFixed(1)
                          : '—'}
                      </td>
                      <td className='text-center'>
                        {students.length
                          ? ((students.reduce((s, st) => s + getStudentPct(st.id), 0)) / students.length).toFixed(1) + '%'
                          : '—'}
                      </td>
                      <td colSpan={3}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ── Grace Marks Modal ── */}
        <GraceModal
          show={Boolean(graceTarget)}
          result={graceTarget}
          schoolId={schoolId}
          onClose={() => setGraceTarget(null)}
          onSaved={loadMarksheet}
        />
      </Content>
    </>
  )
}

const ResultsWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[{ title: 'Examination', path: '/examination/results', isActive: false }, { title: 'Results', path: '/examination/results', isActive: true }]}>
      Exam Results
    </PageTitle>
    <ResultsPage />
  </>
)

export { ResultsWrapper }
