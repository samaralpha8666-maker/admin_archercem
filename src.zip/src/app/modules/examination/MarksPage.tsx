import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import { getExamGroups, getGroupExams, getMarksheet, bulkMarksEntry } from './core/_requests'
import { ExamGroup, ExamSubject, MarksheetStudent, ExamResult } from './core/_models'
import { getClasses } from '../academic/core/_requests'

// ── Type for the flexible marks entry row ─────────────────────────────────────
type MarkRow = {
  marks: string          // simple total
  theory: string
  practical: string
  internal: string
  external: string
  absent: boolean
  remarks: string
}
const emptyRow = (): MarkRow => ({ marks: '', theory: '', practical: '', internal: '', external: '', absent: false, remarks: '' })

const MarksPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // ── Institution type: dynamic labels ─────────────────────────────
  const isCollege = currentUser?.institution_type === 'COLLEGE'
  const classLabel = isCollege ? 'Course' : 'Class'
  const subjectLabel = isCollege ? 'Paper' : 'Subject'

  const [groups, setGroups] = useState<ExamGroup[]>([])
  const [classes, setClasses] = useState<any[]>([])
  const [groupExams, setGroupExams] = useState<ExamSubject[]>([])
  const [students, setStudents] = useState<MarksheetStudent[]>([])
  const [existingResults, setExistingResults] = useState<ExamResult[]>([])

  const [filterGroup, setFilterGroup] = useState('')
  const [filterClass, setFilterClass] = useState('')
  const [filterExam, setFilterExam] = useState('')

  const [marks, setMarks] = useState<Record<number, MarkRow>>({})
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState<{ type: 'success' | 'danger'; text: string } | null>(null)
  const [loading, setLoading] = useState(false)

  const loadMeta = useCallback(async () => {
    if (!schoolId) return
    try {
      const [gRes, cRes] = await Promise.all([getExamGroups(schoolId), getClasses(schoolId, 1, 100)])
      if (gRes.data.success) setGroups(gRes.data.data || [])
      if (cRes.data.success) setClasses(cRes.data.data.classes || [])
    } catch { }
  }, [schoolId])

  useEffect(() => { loadMeta() }, [loadMeta])

  // When group changes, load exams for that group
  useEffect(() => {
    if (!filterGroup) { setGroupExams([]); setFilterExam(''); return }
    getGroupExams(schoolId, Number(filterGroup)).then(r => {
      if (r.data.success) setGroupExams(r.data.data || [])
    }).catch(() => { })
  }, [filterGroup, schoolId])

  // When group + class + exam selected → load marksheet
  const loadMarksheet = useCallback(async () => {
    if (!filterGroup || !filterClass) { setStudents([]); setExistingResults([]); return }
    setLoading(true)
    try {
      const { data } = await getMarksheet(schoolId, Number(filterGroup), Number(filterClass))
      if (data.success) {
        setStudents(data.data.students || [])
        setExistingResults(data.data.results || [])
        const initMarks: Record<number, MarkRow> = {}
        ;(data.data.students || []).forEach(s => {
          const existing = (data.data.results || []).find(r => r.student_id === s.id && String(r.exam_id) === filterExam)
          initMarks[s.id] = {
            marks: existing?.marks_obtained != null ? String(existing.marks_obtained) : '',
            theory: existing?.theory_marks != null ? String(existing.theory_marks) : '',
            practical: existing?.practical_marks != null ? String(existing.practical_marks) : '',
            internal: existing?.internal_marks != null ? String(existing.internal_marks) : '',
            external: existing?.external_marks != null ? String(existing.external_marks) : '',
            absent: existing?.is_absent || false,
            remarks: existing?.remarks || '',
          }
        })
        setMarks(initMarks)
      }
    } catch { } finally { setLoading(false) }
  }, [schoolId, filterGroup, filterClass, filterExam])

  useEffect(() => { loadMarksheet() }, [loadMarksheet])

  const handleMarkChange = (studentId: number, field: keyof MarkRow, value: any) => {
    setMarks(prev => ({ ...prev, [studentId]: { ...prev[studentId], [field]: value } }))
  }

  const selectedExam = groupExams.find(e => String(e.id) === filterExam)
  const hasSplit = Boolean(selectedExam?.has_components)
  const isCoScho = Boolean((selectedExam as any)?.is_co_scholastic)

  const handleSave = async () => {
    if (!filterExam || !students.length) return
    setSaving(true); setSaveMsg(null)
    try {
      const payload = students
        .filter(s => {
          const m = marks[s.id]
          if (!m) return false
          if (m.absent) return true
          if (hasSplit) {
            return isCollege
              ? (m.internal !== '' || m.external !== '')
              : (m.theory !== '' || m.practical !== '')
          }
          return m.marks !== ''
        })
        .map(s => {
          const m = marks[s.id]
          const entry: any = { student_id: Number(s.id), is_absent: Boolean(m.absent) }
          if (!m.absent) {
            if (hasSplit) {
              if (isCollege) {
                if (m.internal !== '') entry.internal_marks = Number(m.internal)
                if (m.external !== '') entry.external_marks = Number(m.external)
              } else {
                if (m.theory !== '') entry.theory_marks = Number(m.theory)
                if (m.practical !== '') entry.practical_marks = Number(m.practical)
              }
            } else {
              entry.marks_obtained = Number(m.marks || 0)
            }
            if (m.remarks?.trim()) entry.remarks = m.remarks.trim()
          }
          return entry
        })

      if (payload.length === 0) {
        setSaveMsg({ type: 'danger', text: 'No marks entered to save.' })
        setSaving(false); return
      }

      const { data } = await bulkMarksEntry(schoolId, Number(filterExam), payload)
      setSaveMsg({ type: 'success', text: `✓ ${data.count || 0} student marks saved successfully!` })
      loadMarksheet()
    } catch (e: any) {
      const msg = e.response?.data?.message || e.message || 'Failed to save marks'
      setSaveMsg({ type: 'danger', text: `❌ ${msg}` })
    } finally { setSaving(false) }
  }

  const isReady = filterGroup && filterClass && filterExam && students.length > 0

  // ── Helpers for per-student live preview ──────────────────────────────────────
  const getLiveTotal = (m: MarkRow): number => {
    if (m.absent) return 0
    if (hasSplit) {
      if (isCollege) return Number(m.internal || 0) + Number(m.external || 0)
      return Number(m.theory || 0) + Number(m.practical || 0)
    }
    return Number(m.marks || 0)
  }
  const getMax = (): number => {
    if (!selectedExam) return 100
    if (hasSplit && isCollege) return Number((selectedExam as any).internal_max || 0) + Number((selectedExam as any).external_max || 0)
    if (hasSplit) return Number((selectedExam as any).theory_max || 0) + Number((selectedExam as any).practical_max || 0)
    return Number(selectedExam.max_marks || 100)
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* ── Filters ── */}
        <div className='card card-flush shadow-sm mb-6'>
          <div className='card-header border-0 pt-6 align-items-center flex-wrap gap-4'>
            <h3 className='card-title fw-bold'>Bulk Marks Entry</h3>
            <div className='d-flex gap-3 flex-wrap'>
              <select className='form-select form-select-solid form-select-sm w-180px' value={filterGroup}
                onChange={e => { setFilterGroup(e.target.value); setFilterExam(''); setFilterClass('') }}>
                <option value=''>Select Exam Group</option>
                {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>

              <select className='form-select form-select-solid form-select-sm w-150px' value={filterClass}
                disabled={!filterGroup}
                onChange={e => setFilterClass(e.target.value)}>
                <option value=''>Select {classLabel}</option>
                {classes.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>

              <select className='form-select form-select-solid form-select-sm w-200px' value={filterExam}
                disabled={!filterGroup || !groupExams.length}
                onChange={e => setFilterExam(e.target.value)}>
                <option value=''>Select {subjectLabel}</option>
                {groupExams.map(e => (
                  <option key={e.id} value={e.id}>
                    {e.subject?.name || `Exam #${e.id}`}
                    {(e as any).has_components ? ' ⚡ Split' : ''} (/{e.max_marks})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* ── Empty state ── */}
        {!isReady ? (
          <div className='card card-flush shadow-sm'>
            <div className='card-body text-center py-16'>
              <i className='ki-duotone ki-pencil fs-5x text-gray-300 mb-4'><span className='path1' /><span className='path2' /></i>
              <p className='text-muted fw-semibold fs-5'>
                Select an Exam Group, {classLabel} and {subjectLabel} to begin marks entry
              </p>
            </div>
          </div>
        ) : (
          <div className='card card-flush shadow-sm'>
            {/* ── Card Header ── */}
            <div className='card-header border-0 pt-6 align-items-center flex-wrap gap-4'>
              <div>
                <h4 className='fw-bold mb-1'>{selectedExam?.subject?.name} — Marks Entry</h4>
                <div className='d-flex gap-3 flex-wrap mt-1'>
                  {hasSplit ? (
                    isCollege ? (
                      <>
                        <span className='badge badge-light-info'>Internal: {(selectedExam as any).internal_max}</span>
                        <span className='badge badge-light-primary'>External: {(selectedExam as any).external_max}</span>
                        <span className='badge badge-light-warning'>Total Max: {getMax()}</span>
                      </>
                    ) : (
                      <>
                        <span className='badge badge-light-info'>Theory: {(selectedExam as any).theory_max}</span>
                        <span className='badge badge-light-primary'>Practical: {(selectedExam as any).practical_max}</span>
                        <span className='badge badge-light-warning'>Total Max: {getMax()}</span>
                      </>
                    )
                  ) : (
                    <>
                      <span className='badge badge-light-warning'>Max: {selectedExam?.max_marks}</span>
                      <span className='badge badge-light-danger'>Min Pass: {selectedExam?.min_marks}</span>
                    </>
                  )}
                  {isCoScho && <span className='badge badge-light-dark'>Co-scholastic (Grade only)</span>}
                  <span className='badge badge-light-success'>{students.length} Students</span>
                </div>
              </div>
              <button className='btn btn-primary btn-sm' onClick={handleSave} disabled={saving}>
                {saving ? <><span className='spinner-border spinner-border-sm me-2' />Saving...</> : <><i className='ki-duotone ki-check fs-4 me-1'><span className='path1' /><span className='path2' /></i>Save All Marks</>}
              </button>
            </div>

            <div className='card-body pt-4'>
              {saveMsg && (
                <div className={`alert alert-${saveMsg.type} mb-4 fw-semibold d-flex align-items-center gap-3`}>
                  {saveMsg.text}
                  <button className='btn-close ms-auto' onClick={() => setSaveMsg(null)} />
                </div>
              )}
              {loading ? (
                <div className='text-center py-10'><span className='spinner-border text-primary' /></div>
              ) : (
                <div className='table-responsive'>
                  <table className='table align-middle table-row-dashed fs-6 gy-4'>
                    <thead>
                      <tr className='text-gray-400 fw-bold fs-7 text-uppercase'>
                        <th>#</th>
                        <th>Student</th>
                        <th>Roll No.</th>
                        {/* Dynamic headers based on exam type */}
                        {!hasSplit ? (
                          <th>Marks <span className='text-danger'>*</span><div className='text-muted fw-normal fs-9 text-lowercase'>out of {selectedExam?.max_marks}</div></th>
                        ) : isCollege ? (
                          <>
                            <th>Internal <span className='text-danger'>*</span><div className='text-muted fw-normal fs-9 text-lowercase'>/{(selectedExam as any).internal_max}</div></th>
                            <th>External <span className='text-danger'>*</span><div className='text-muted fw-normal fs-9 text-lowercase'>/{(selectedExam as any).external_max}</div></th>
                          </>
                        ) : (
                          <>
                            <th>Theory <span className='text-danger'>*</span><div className='text-muted fw-normal fs-9 text-lowercase'>/{(selectedExam as any).theory_max}</div></th>
                            <th>Practical <span className='text-danger'>*</span><div className='text-muted fw-normal fs-9 text-lowercase'>/{(selectedExam as any).practical_max}</div></th>
                          </>
                        )}
                        <th>Total</th>
                        <th>Absent</th>
                        <th>Grade</th>
                        <th>Remarks</th>
                      </tr>
                    </thead>
                    <tbody className='fw-semibold text-gray-600'>
                      {students.map((s, idx) => {
                        const existing = existingResults.find(r => r.student_id === s.id && String(r.exam_id) === filterExam)
                        const m = marks[s.id] || emptyRow()
                        const total = getLiveTotal(m)
                        const maxM = getMax()
                        const pct = maxM > 0 ? (total / maxM) * 100 : 0
                        const isPass = total >= Number(selectedExam?.min_marks || 0)
                        const isLocked = (existing as any)?.is_locked

                        return (
                          <tr key={s.id} className={m.absent ? 'opacity-50' : ''}>
                            <td><span className='text-muted'>{idx + 1}</span></td>
                            <td>
                              <div className='d-flex align-items-center gap-3'>
                                <div className='symbol symbol-35px'>
                                  <div className='symbol-label fw-bolder text-primary bg-light-primary'>
                                    {s.first_name.charAt(0).toUpperCase()}
                                  </div>
                                </div>
                                <div>
                                  <div className='fw-bold text-gray-800'>{s.first_name} {s.last_name}</div>
                                  <div className='d-flex gap-2 mt-1'>
                                    {existing && <span className='badge badge-light-info fs-9'>Saved: {existing.marks_obtained}</span>}
                                    {isLocked && <span className='badge badge-light-danger fs-9'><i className='ki-duotone ki-lock fs-9 me-1' />Locked</span>}
                                    {(existing as any)?.grace_marks > 0 && (
                                      <span className='badge badge-light-warning fs-9'>+{(existing as any).grace_marks} Grace</span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className='text-muted'>{s.enrollments?.[0]?.roll_number || '—'}</td>

                            {/* ── Marks columns — dynamic ── */}
                            {!hasSplit ? (
                              <td style={{ width: 130 }}>
                                <input
                                  className={`form-control form-control-sm form-control-solid text-center fw-bold
                                    ${!m.absent && m.marks && !isCoScho ? (isPass ? 'border-success' : 'border-danger') : ''}`}
                                  type={isCoScho ? 'text' : 'number'}
                                  min='0' max={selectedExam?.max_marks}
                                  value={m.absent ? '' : m.marks}
                                  disabled={m.absent || Boolean(isLocked)}
                                  placeholder={isCoScho ? 'A/B/C...' : '—'}
                                  onChange={e => handleMarkChange(s.id, 'marks', e.target.value)}
                                />
                              </td>
                            ) : isCollege ? (
                              <>
                                <td style={{ width: 110 }}>
                                  <input className='form-control form-control-sm form-control-solid text-center fw-bold'
                                    type='number' min='0' max={(selectedExam as any).internal_max}
                                    value={m.absent ? '' : m.internal} disabled={m.absent || Boolean(isLocked)}
                                    placeholder='—' onChange={e => handleMarkChange(s.id, 'internal', e.target.value)} />
                                </td>
                                <td style={{ width: 110 }}>
                                  <input className='form-control form-control-sm form-control-solid text-center fw-bold'
                                    type='number' min='0' max={(selectedExam as any).external_max}
                                    value={m.absent ? '' : m.external} disabled={m.absent || Boolean(isLocked)}
                                    placeholder='—' onChange={e => handleMarkChange(s.id, 'external', e.target.value)} />
                                </td>
                              </>
                            ) : (
                              <>
                                <td style={{ width: 110 }}>
                                  <input className='form-control form-control-sm form-control-solid text-center fw-bold'
                                    type='number' min='0' max={(selectedExam as any).theory_max}
                                    value={m.absent ? '' : m.theory} disabled={m.absent || Boolean(isLocked)}
                                    placeholder='—' onChange={e => handleMarkChange(s.id, 'theory', e.target.value)} />
                                </td>
                                <td style={{ width: 110 }}>
                                  <input className='form-control form-control-sm form-control-solid text-center fw-bold'
                                    type='number' min='0' max={(selectedExam as any).practical_max}
                                    value={m.absent ? '' : m.practical} disabled={m.absent || Boolean(isLocked)}
                                    placeholder='—' onChange={e => handleMarkChange(s.id, 'practical', e.target.value)} />
                                </td>
                              </>
                            )}

                            {/* Total live preview */}
                            <td className='text-center'>
                              {m.absent ? (
                                <span className='text-muted'>AB</span>
                              ) : (
                                <span className={`fw-bold ${hasSplit ? '' : (isPass ? 'text-success' : 'text-danger')}`}>
                                  {total > 0 ? total : '—'}
                                </span>
                              )}
                            </td>

                            <td>
                              <div className='form-check form-check-custom form-check-solid form-check-sm'>
                                <input className='form-check-input' type='checkbox' checked={m.absent}
                                  disabled={Boolean(isLocked)}
                                  onChange={e => handleMarkChange(s.id, 'absent', e.target.checked)} />
                                <label className='form-check-label text-muted fs-8'>Absent</label>
                              </div>
                            </td>

                            <td>
                              {m.absent
                                ? <span className='badge badge-light-dark'>AB</span>
                                : existing?.grade_name
                                  ? <span className='badge badge-light-success fw-bold'>{existing.grade_name}</span>
                                  : total > 0
                                    ? <span className={`badge badge-light-${pct >= 60 ? 'success' : pct >= 33 ? 'warning' : 'danger'} fw-bold`}>{pct.toFixed(0)}%</span>
                                    : <span className='text-muted'>—</span>
                              }
                            </td>

                            <td style={{ width: 160 }}>
                              <input className='form-control form-control-sm form-control-solid'
                                value={m.remarks} disabled={Boolean(isLocked)}
                                placeholder='Optional...'
                                onChange={e => handleMarkChange(s.id, 'remarks', e.target.value)} />
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className='card-footer border-0 d-flex justify-content-between align-items-center'>
              <span className='text-muted fs-7'>
                {hasSplit
                  ? isCollege
                    ? `Internal + External marks. Max total: ${getMax()}`
                    : `Theory + Practical marks. Max total: ${getMax()}`
                  : `Simple marks out of ${selectedExam?.max_marks}`}
              </span>
              <button className='btn btn-primary' onClick={handleSave} disabled={saving}>
                {saving ? <><span className='spinner-border spinner-border-sm me-2' />Saving...</> : 'Save All Marks'}
              </button>
            </div>
          </div>
        )}
      </Content>
    </>
  )
}

const MarksWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[{ title: 'Examination', path: '/examination/marks', isActive: false }, { title: 'Marks Entry', path: '/examination/marks', isActive: true }]}>
      Marks Entry
    </PageTitle>
    <MarksPage />
  </>
)

export { MarksWrapper }
