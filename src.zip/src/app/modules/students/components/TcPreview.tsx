import { FC, useState } from 'react'
import { StudentModel } from '../core/_models'
import { useAuth } from '../../auth'

interface TcFormData {
  serial_number: string
  issue_date: string
  total_working_days: number
  days_present: number
  conduct: string
  reason_for_leaving: string
  promotion_eligible: 'Yes' | 'No' | 'Refer to Marksheet'
  class_studied: string
  subjects_studied: string
  remarks: string
}

interface TcPreviewProps {
  student: StudentModel
  formData: TcFormData
  verificationHash: string
  isLocked: boolean
  onIssue?: () => void
  canIssue?: boolean
  onDownloadPdf?: (theme: string) => Promise<void>
}

type TcTheme = 'navy' | 'gold' | 'maroon'

const THEME_CONFIG: Record<
  TcTheme,
  {
    borderStyle: string
    borderColor: string
    titleColor: string
    sealColor: string
    backgroundGradient: string
    buttonColor: string
  }
> = {
  navy: {
    borderStyle: 'double 6px #1E293B',
    borderColor: '#1E293B',
    titleColor: '#0F172A',
    sealColor: '#3B82F6',
    backgroundGradient: 'linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%)',
    buttonColor: 'info',
  },
  gold: {
    borderStyle: 'solid 8px #D97706',
    borderColor: '#D97706',
    titleColor: '#854D0E',
    sealColor: '#F59E0B',
    backgroundGradient: 'linear-gradient(135deg, #FFFBEB 0%, #FEF3C7 100%)',
    buttonColor: 'warning',
  },
  maroon: {
    borderStyle: 'solid 8px #881337',
    borderColor: '#881337',
    titleColor: '#4C0519',
    sealColor: '#9F1239',
    backgroundGradient: 'linear-gradient(135deg, #FFF1F2 0%, #FFE4E6 100%)',
    buttonColor: 'danger',
  },
}

export const TcPreview: FC<TcPreviewProps> = ({
  student,
  formData,
  verificationHash,
  isLocked,
  onIssue,
  canIssue = true,
  onDownloadPdf,
}) => {
  const { currentUser } = useAuth()
  const [theme, setTheme] = useState<TcTheme>('gold')
  const [showPrincipalStamp, setShowPrincipalStamp] = useState(true)

  const schoolName = currentUser?.school_name || 'APNACAMPUS INTERNATIONAL SCHOOL'
  const watermarkText = schoolName.split(' ')[0].toUpperCase()

  const activeTheme = THEME_CONFIG[theme]

  const activeEnrollment = student.enrollments?.find((e) => e.status === 'Active')
  const classLabel = activeEnrollment?.class_section?.class?.name
    ? `Class ${activeEnrollment.class_section.class.name}-${activeEnrollment.class_section.section?.name || ''}`
    : formData.class_studied || 'Class 10 - A'

  const admissionDate = activeEnrollment?.enrollment_date
    ? new Date(activeEnrollment.enrollment_date).toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
      })
    : '—'

  const dobStr = student.profile?.dob || ''
  const dobInWords = dobStr
    ? new Date(dobStr).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      })
    : '—'

  const formattedIssueDate = new Date(formData.issue_date || new Date()).toLocaleDateString(
    'en-IN',
    {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    }
  )

  const [downloading, setDownloading] = useState(false)

  const handleDownload = async () => {
    if (onDownloadPdf && isLocked) {
      setDownloading(true)
      try {
        await onDownloadPdf(theme)
      } catch (err) {
        console.error('Download failed:', err)
      } finally {
        setDownloading(false)
      }
    } else {
      window.print()
    }
  }

  // Simple clean SVG QR code mockup
  const renderQrCode = () => {
    return (
      <svg width='75' height='75' viewBox='0 0 100 100' className='bg-white p-1 rounded border border-gray-300'>
        {/* QR Borders */}
        <rect x='5' y='5' width='25' height='25' fill='#000' />
        <rect x='10' y='10' width='15' height='15' fill='#fff' />
        <rect x='13' y='13' width='9' height='9' fill='#000' />

        <rect x='70' y='5' width='25' height='25' fill='#000' />
        <rect x='75' y='10' width='15' height='15' fill='#fff' />
        <rect x='78' y='13' width='9' height='9' fill='#000' />

        <rect x='5' y='70' width='25' height='25' fill='#000' />
        <rect x='10' y='75' width='15' height='15' fill='#fff' />
        <rect x='13' y='78' width='9' height='9' fill='#000' />

        {/* QR Noise Points */}
        <rect x='40' y='10' width='8' height='8' fill='#000' />
        <rect x='52' y='5' width='6' height='12' fill='#000' />
        <rect x='45' y='25' width='12' height='6' fill='#000' />
        <rect x='35' y='40' width='15' height='15' fill='#000' />
        <rect x='55' y='35' width='10' height='20' fill='#000' />
        <rect x='75' y='45' width='18' height='8' fill='#000' />
        <rect x='85' y='58' width='10' height='10' fill='#000' />
        <rect x='70' y='75' width='12' height='6' fill='#000' />
        <rect x='85' y='72' width='10' height='22' fill='#000' />
        <rect x='40' y='70' width='15' height='15' fill='#000' />
        <rect x='45' y='88' width='20' height='7' fill='#000' />
        <rect x='10' y='45' width='15' height='8' fill='#000' />
        <rect x='18' y='58' width='8' height='10' fill='#000' />
      </svg>
    )
  }

  return (
    <div className='d-flex flex-column gap-5 h-100'>
      {/* Dynamic Print CSS Inject */}
      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          /* Hide everything except the exact TC Certificate preview sheet */
          body * {
            visibility: hidden;
          }
          #printable-tc-sheet, #printable-tc-sheet * {
            visibility: visible;
          }
          #printable-tc-sheet {
            position: absolute;
            left: 0;
            top: 0;
            width: 100% !important;
            height: 100% !important;
            border: ${activeTheme.borderStyle} !important;
            background: #ffffff !important;
            margin: 0 !important;
            box-shadow: none !important;
            page-break-after: avoid;
            page-break-before: avoid;
          }
          /* Setup A4 dimensions */
          @page {
            size: A4;
            margin: 12mm 15mm 12mm 15mm;
          }
        }
      `}} />

      {/* Control Ribbon (Hidden in Print) */}
      <div className='card card-flush border border-gray-200 d-print-none'>
        <div className='card-body py-3 d-flex flex-stack flex-wrap gap-3'>
          {/* Theme Selector */}
          <div className='d-flex align-items-center gap-2'>
            <span className='fw-bold text-gray-700 fs-7'>Board Theme:</span>
            <div className='btn-group btn-group-sm' role='group'>
              {(['gold', 'navy', 'maroon'] as TcTheme[]).map((t) => (
                <button
                  key={t}
                  type='button'
                  className={`btn btn-light-${THEME_CONFIG[t].buttonColor} text-capitalize fw-bold ${
                    theme === t ? 'active font-bold bg-secondary' : ''
                  }`}
                  onClick={() => setTheme(t)}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Stamp toggle */}
          <div className='form-check form-switch form-check-custom form-check-solid'>
            <input
              className='form-check-input h-20px w-35px'
              type='checkbox'
              id='stampToggle'
              checked={showPrincipalStamp}
              onChange={(e) => setShowPrincipalStamp(e.target.checked)}
            />
            <label className='form-check-label fw-bold text-gray-700 fs-7' htmlFor='stampToggle'>
              Principal Signature Stamp
            </label>
          </div>

          {/* Actions */}
          <div className='d-flex gap-2'>
            {!isLocked && (
              <button
                className='btn btn-success btn-sm fw-bold'
                disabled={!canIssue}
                onClick={onIssue}
              >
                <i className='ki-duotone ki-shield-tick fs-5 me-1'><span className='path1'></span><span className='path2'></span></i>
                Issue & Save TC
              </button>
            )}
            <button
              className='btn btn-primary btn-sm fw-bold'
              onClick={handleDownload}
              disabled={(!isLocked && !canIssue) || downloading}
            >
              {downloading ? (
                <span className='spinner-border spinner-border-sm me-2' role='status' aria-hidden='true'></span>
              ) : (
                <i className='ki-duotone ki-printer fs-5 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span></i>
              )}
              {downloading ? 'Downloading...' : 'Print / Download PDF'}
            </button>
          </div>
        </div>
      </div>

      {/* Premium Sheet Container */}
      <div className='d-flex justify-content-center bg-light-neutral py-5 rounded border border-gray-200 flex-grow-1' style={{ overflowX: 'auto' }}>
        {/* Visual A4 proportion card inside the browser with shadow */}
        <div
          id='printable-tc-sheet'
          className='bg-white shadow p-12 text-gray-800 position-relative'
          style={{
            width: '210mm',
            minHeight: '297mm',
            border: activeTheme.borderStyle,
            borderColor: activeTheme.borderColor,
            background: activeTheme.backgroundGradient,
            boxSizing: 'border-box',
            fontFamily: "'Inter', sans-serif",
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}
        >
          {/* Centered watermark backdrop (non-obstructive) */}
          <div
            className='position-absolute top-50 start-50 translate-middle pointer-events-none'
            style={{
              opacity: 0.04,
              fontSize: '8rem',
              fontWeight: 900,
              transform: 'translate(-50%, -50%) rotate(-45deg)',
              color: '#000000',
              whiteSpace: 'nowrap',
              letterSpacing: '5px',
              zIndex: 0,
            }}
          >
            {watermarkText}
          </div>

          <div style={{ zIndex: 1, position: 'relative' }}>
            {/* School Header */}
            <div className='d-flex align-items-center justify-content-between border-bottom border-gray-800 pb-5 mb-6'>
              <div className='d-flex align-items-center gap-4'>
                <div className='symbol symbol-60px bg-dark-clarity p-2 rounded'>
                  <span className='fs-2 fw-bolder text-gray-900'>{watermarkText.substring(0, 2)}</span>
                </div>
                <div>
                  <h1 className='fw-black m-0 fs-3 tracking-wide text-uppercase' style={{ color: activeTheme.titleColor }}>
                    {schoolName}
                  </h1>
                  <p className='m-0 fs-8 text-muted fw-bold'>
                    Affiliated to CBSE Board (Affilation No. 24890011) · New Delhi
                  </p>
                  <p className='m-0 fs-9 text-muted fw-semibold'>
                    Sector-12, Dwarka, New Delhi - 110075 · support@{watermarkText.toLowerCase()}.com
                  </p>
                </div>
              </div>
              <div className='text-end'>
                <span className='badge badge-outline badge-dark fw-black fs-8 text-uppercase tracking-wider px-3 py-1'>
                  Transfer Certificate
                </span>
              </div>
            </div>

            {/* Sub-Header / Certificate Meta */}
            <div className='row mb-6 text-gray-800 fw-bold fs-7'>
              <div className='col-6'>
                <span>TC Serial No: </span>
                <span className='text-primary font-bold ms-1'>{formData.serial_number || '—'}</span>
              </div>
              <div className='col-6 text-end'>
                <span>Admission No: </span>
                <span className='ms-1'>{student.registration_number || '—'}</span>
              </div>
              <div className='col-6 mt-2'>
                <span>Date of Issue: </span>
                <span className='ms-1'>{formattedIssueDate}</span>
              </div>
              <div className='col-6 text-end mt-2'>
                <span>Status: </span>
                <span className={`badge badge-light-${isLocked ? 'success' : 'warning'} ms-1 fw-bold fs-9`}>
                  {isLocked ? 'OFFICIALLY ISSUED' : 'DRAFT VERSION'}
                </span>
              </div>
            </div>

            {/* Certificate Body (Official CBSE Format) */}
            <div className='d-flex flex-column gap-4 text-gray-800 fs-7 lh-base'>
              <p className='m-0 text-justify'>
                This is to certify that <strong className='fs-6 text-gray-900'>{student.first_name} {student.last_name}</strong>,
                son/daughter of <strong className='text-gray-900'>{student.parent?.mother_name || '—'}</strong> (Mother)
                and <strong className='text-gray-900'>{student.parent?.father_name || '—'}</strong> (Father), was admitted to this
                institution on <strong className='text-gray-900'>{admissionDate}</strong> and has successfully cleared all outstanding school clearances.
              </p>

              <table className='table table-bordered border-gray-400 my-3 gy-2 fs-7 align-middle'>
                <tbody>
                  <tr>
                    <td className='fw-bold text-gray-700 w-45'>1. Date of Birth (in figures):</td>
                    <td className='fw-semibold text-gray-900'>{student.profile?.dob || '—'}</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>(in words):</td>
                    <td className='fw-semibold text-gray-900 text-capitalize'>{dobInWords}</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>2. Nationality:</td>
                    <td className='fw-semibold text-gray-900'>{student.profile?.nationality || 'Indian'}</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>3. Caste Category (SC / ST / OBC):</td>
                    <td className='fw-semibold text-gray-900'>{student.profile?.category || 'General'}</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>4. Class in which pupil last studied:</td>
                    <td className='fw-bold text-gray-900'>{classLabel}</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>5. Subjects Studied:</td>
                    <td className='fw-semibold text-gray-900'>{formData.subjects_studied || '—'}</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>6. Qualified for Promotion to higher class:</td>
                    <td className='fw-bold text-gray-900'>{formData.promotion_eligible}</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>7. Total Number of Academic Working Days:</td>
                    <td className='fw-semibold text-gray-900'>{formData.total_working_days} days</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>8. Total Number of Days Present:</td>
                    <td className='fw-semibold text-gray-900'>{formData.days_present} days</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>9. General Conduct & Character:</td>
                    <td className='fw-bold text-gray-900'>{formData.conduct}</td>
                  </tr>
                  <tr>
                    <td className='fw-bold text-gray-700'>10. Reason for leaving the School:</td>
                    <td className='fw-semibold text-gray-900'>{formData.reason_for_leaving || '—'}</td>
                  </tr>
                  {formData.remarks && (
                    <tr>
                      <td className='fw-bold text-gray-700'>11. Any other remarks:</td>
                      <td className='fw-semibold text-gray-900'>{formData.remarks}</td>
                    </tr>
                  )}
                </tbody>
              </table>

              <p className='m-0 text-justify fs-8 text-muted'>
                Note: In case of discrepancy, the records maintained at the school administration archives shall prevail as final authority.
              </p>
            </div>
          </div>

          {/* Footer Seals, Signatures, and Verification QR */}
          <div className='border-top border-gray-800 pt-8 mt-8' style={{ zIndex: 1, position: 'relative' }}>
            <div className='d-flex justify-content-between align-items-end'>
              {/* QR Block */}
              <div className='d-flex align-items-center gap-3'>
                {renderQrCode()}
                <div>
                  <div className='fw-bold text-gray-900 fs-8'>Digital Verification Secure QR</div>
                  <div className='text-muted fs-9' style={{ wordBreak: 'break-all', maxWidth: '180px' }}>
                    Verify authenticity online. Hash: {verificationHash.substring(0, 16)}...
                  </div>
                </div>
              </div>

              {/* principal & teacher signatures */}
              <div className='d-flex gap-12 align-items-end text-center fs-8 fw-bold text-gray-800'>
                <div style={{ width: '100px' }}>
                  <div className='border-bottom border-gray-400 mb-2' style={{ height: '30px' }}></div>
                  Class Teacher
                </div>
                <div style={{ width: '100px' }}>
                  <div className='border-bottom border-gray-400 mb-2' style={{ height: '30px' }}></div>
                  Checked By
                </div>
                <div style={{ width: '120px', position: 'relative' }}>
                  {showPrincipalStamp && (
                    <div
                      className='position-absolute start-50 translate-middle-x'
                      style={{
                        bottom: '20px',
                        color: activeTheme.sealColor,
                        fontFamily: "'Courier New', Courier, monospace",
                        transform: 'rotate(-8deg)',
                        opacity: 0.85,
                        pointerEvents: 'none',
                      }}
                    >
                      {/* Principal signature stamp mockup */}
                      <div className='border border-2 border-dashed px-2 py-1 rounded fs-9 fw-black tracking-widest text-uppercase'>
                        APPROVED
                        <br />
                        PRINCIPAL
                        <br />
                        <span className='fs-10'>APNACAMPUS</span>
                      </div>
                    </div>
                  )}
                  <div className='border-bottom border-gray-400 mb-2' style={{ height: '30px' }}></div>
                  Principal Stamp
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
