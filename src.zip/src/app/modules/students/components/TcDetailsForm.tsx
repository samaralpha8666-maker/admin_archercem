import { FC, useState, useEffect } from 'react'
import { StudentModel } from '../core/_models'

interface TcFormData {
  serial_number: string
  issue_date: string
  total_working_days: number
  days_present: number
  conduct: string
  reason_for_leaving: string
  promotion_eligible: 'Yes' | 'No' | 'Refer to Marksheet'
  class_studied: string
  subjects_studied: string
  remarks: string
}

interface TcDetailsFormProps {
  student: StudentModel
  formData: TcFormData
  onChange: (data: TcFormData, isValid: boolean) => void
}

export const TcDetailsForm: FC<TcDetailsFormProps> = ({ student, formData, onChange }) => {
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Format student details
  const activeEnrollment = student.enrollments?.find((e) => e.status === 'Active')
  const classLabel = activeEnrollment?.class_section?.class?.name
    ? `Class ${activeEnrollment.class_section.class.name} - Section ${activeEnrollment.class_section.section?.name || ''}`
    : 'Not enrolled'

  const admissionDateStr = activeEnrollment?.enrollment_date || ''
  const dobStr = student.profile?.dob || ''

  // Validate fields in real-time
  const validateForm = (data: TcFormData): Record<string, string> => {
    const newErrors: Record<string, string> = {}

    // Required fields check
    if (!data.serial_number.trim()) {
      newErrors.serial_number = 'Serial number is required.'
    }
    if (!data.conduct.trim()) {
      newErrors.conduct = 'General conduct details are required.'
    }
    if (!data.reason_for_leaving.trim()) {
      newErrors.reason_for_leaving = 'Reason for leaving is required.'
    }
    if (!data.subjects_studied.trim()) {
      newErrors.subjects_studied = 'Subjects studied list is required.'
    }

    // Days present <= total working days validation
    if (data.days_present < 0) {
      newErrors.days_present = 'Days present cannot be negative.'
    }
    if (data.total_working_days < 0) {
      newErrors.total_working_days = 'Total working days cannot be negative.'
    }
    if (data.days_present > data.total_working_days) {
      newErrors.days_present = 'Days present cannot exceed total working days.'
    }

    // Date validations (DOB < Admission Date < Issue Date)
    if (dobStr && admissionDateStr) {
      const dob = new Date(dobStr)
      const admissionDate = new Date(admissionDateStr)
      const issueDate = new Date(data.issue_date)

      if (admissionDate <= dob) {
        newErrors.dates = 'Warning: Admission date should be greater than Date of Birth.'
      }
      if (issueDate <= admissionDate) {
        newErrors.issue_date = 'Issue date must be after the Student Admission date.'
      }
    }

    return newErrors
  }

  const handleFieldChange = (field: keyof TcFormData, value: any) => {
    const updated = {
      ...formData,
      [field]: value,
    }
    const validationErrors = validateForm(updated)
    setErrors(validationErrors)

    const isValid = Object.keys(validationErrors).length === 0
    onChange(updated, isValid)
  }

  // Pre-validate on load
  useEffect(() => {
    const validationErrors = validateForm(formData)
    setErrors(validationErrors)
    onChange(formData, Object.keys(validationErrors).length === 0)
  }, [student])

  return (
    <div className='card card-flush border border-gray-200'>
      <div className='card-header pt-5'>
        <h3 className='card-title align-items-start flex-column'>
          <span className='card-label fw-bold text-gray-800 fs-5'>Certificate Information & Parameters</span>
          <span className='text-muted mt-1 fw-semibold fs-7'>
            Populate specific exit details required on the Transfer Certificate
          </span>
        </h3>
      </div>

      <div className='card-body pt-3'>
        {/* Read-Only Database Fields Info */}
        <div className='bg-light-neutral rounded p-4 mb-6 border border-dashed border-gray-300'>
          <h5 className='text-gray-800 fw-bold fs-7 mb-3'>Locked Database Profile Records (Read-Only)</h5>
          <div className='row g-4 fs-8'>
            <div className='col-md-3 col-6'>
              <div className='text-muted fw-semibold'>Student Name</div>
              <div className='text-gray-800 fw-bold fs-7 mt-1'>
                {student.first_name} {student.last_name}
              </div>
            </div>
            <div className='col-md-3 col-6'>
              <div className='text-muted fw-semibold'>Admission Number</div>
              <div className='text-gray-800 fw-bold fs-7 mt-1'>
                {student.registration_number || '—'}
              </div>
            </div>
            <div className='col-md-3 col-6'>
              <div className='text-muted fw-semibold'>Class & Section</div>
              <div className='text-gray-800 fw-bold fs-7 mt-1'>{classLabel}</div>
            </div>
            <div className='col-md-3 col-6'>
              <div className='text-muted fw-semibold'>Date of Birth</div>
              <div className='text-gray-800 fw-bold fs-7 mt-1'>
                {dobStr ? new Date(dobStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}
              </div>
            </div>
            <div className='col-md-3 col-6'>
              <div className='text-muted fw-semibold'>Father's Name</div>
              <div className='text-gray-800 fw-bold fs-7 mt-1'>{student.parent?.father_name || '—'}</div>
            </div>
            <div className='col-md-3 col-6'>
              <div className='text-muted fw-semibold'>Mother's Name</div>
              <div className='text-gray-800 fw-bold fs-7 mt-1'>{student.parent?.mother_name || '—'}</div>
            </div>
            <div className='col-md-3 col-6'>
              <div className='text-muted fw-semibold'>Admission Date</div>
              <div className='text-gray-800 fw-bold fs-7 mt-1'>
                {admissionDateStr ? new Date(admissionDateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}
              </div>
            </div>
            <div className='col-md-3 col-6'>
              <div className='text-muted fw-semibold'>Nationality</div>
              <div className='text-gray-800 fw-bold fs-7 mt-1'>{student.profile?.nationality || '—'}</div>
            </div>
          </div>
        </div>

        {/* Global Warnings */}
        {errors.dates && (
          <div className='alert alert-danger fs-8 py-2 px-3 mb-4 d-flex align-items-center'>
            <i className='ki-duotone ki-shield-cross text-danger fs-5 me-2'>
              <span className='path1'></span>
              <span className='path2'></span>
            </i>
            <span>{errors.dates}</span>
          </div>
        )}

        {/* Form Controls */}
        <div className='row g-4'>
          {/* Certificate Number */}
          <div className='col-md-6'>
            <label className='required form-label fw-bold text-gray-800 fs-7'>Certificate / Serial Number</label>
            <input
              type='text'
              className={`form-control form-control-solid form-control-sm fs-7 ${errors.serial_number ? 'is-invalid' : ''}`}
              placeholder='e.g., 2026/APNA/TC-0012'
              value={formData.serial_number}
              onChange={(e) => handleFieldChange('serial_number', e.target.value)}
            />
            {errors.serial_number && <div className='invalid-feedback fs-8'>{errors.serial_number}</div>}
          </div>

          {/* Date of Issue */}
          <div className='col-md-6'>
            <label className='required form-label fw-bold text-gray-800 fs-7'>Date of Issue</label>
            <input
              type='date'
              className={`form-control form-control-solid form-control-sm fs-7 ${errors.issue_date ? 'is-invalid' : ''}`}
              value={formData.issue_date}
              onChange={(e) => handleFieldChange('issue_date', e.target.value)}
            />
            {errors.issue_date && <div className='invalid-feedback fs-8'>{errors.issue_date}</div>}
          </div>

          {/* Total Working Days */}
          <div className='col-md-6'>
            <label className='required form-label fw-bold text-gray-800 fs-7'>Total Academic Working Days</label>
            <input
              type='number'
              className={`form-control form-control-solid form-control-sm fs-7 ${errors.days_present ? 'is-invalid' : ''}`}
              value={formData.total_working_days}
              onChange={(e) => handleFieldChange('total_working_days', parseInt(e.target.value) || 0)}
            />
          </div>

          {/* Days Present */}
          <div className='col-md-6'>
            <label className='required form-label fw-bold text-gray-800 fs-7'>Total Days Present</label>
            <input
              type='number'
              className={`form-control form-control-solid form-control-sm fs-7 ${errors.days_present ? 'is-invalid' : ''}`}
              value={formData.days_present}
              onChange={(e) => handleFieldChange('days_present', parseInt(e.target.value) || 0)}
            />
            {errors.days_present && <div className='text-danger fs-8 mt-1'>{errors.days_present}</div>}
          </div>

          {/* Subjects Studied */}
          <div className='col-12'>
            <label className='required form-label fw-bold text-gray-800 fs-7'>Subjects Studied (Comma separated)</label>
            <input
              type='text'
              className={`form-control form-control-solid form-control-sm fs-7 ${errors.subjects_studied ? 'is-invalid' : ''}`}
              placeholder='e.g., English, Mathematics, General Science, Social Studies, Hindi'
              value={formData.subjects_studied}
              onChange={(e) => handleFieldChange('subjects_studied', e.target.value)}
            />
            {errors.subjects_studied && <div className='invalid-feedback fs-8'>{errors.subjects_studied}</div>}
          </div>

          {/* Promotion Eligibility */}
          <div className='col-md-6'>
            <label className='required form-label fw-bold text-gray-800 fs-7'>Qualified for Promotion?</label>
            <select
              className='form-select form-select-solid form-select-sm fs-7'
              value={formData.promotion_eligible}
              onChange={(e) => handleFieldChange('promotion_eligible', e.target.value)}
            >
              <option value='Yes'>Yes, promoted to higher class</option>
              <option value='No'>No, detained in current class</option>
              <option value='Refer to Marksheet'>Refer to Marksheet results</option>
            </select>
          </div>

          {/* General Conduct */}
          <div className='col-md-6'>
            <label className='required form-label fw-bold text-gray-800 fs-7'>General Conduct & Character</label>
            <select
              className='form-select form-select-solid form-select-sm fs-7'
              value={formData.conduct}
              onChange={(e) => handleFieldChange('conduct', e.target.value)}
            >
              <option value='Excellent'>Excellent</option>
              <option value='Very Good'>Very Good</option>
              <option value='Good'>Good</option>
              <option value='Satisfactory'>Satisfactory</option>
              <option value='Poor'>Needs Improvement</option>
            </select>
          </div>

          {/* Reason for Leaving */}
          <div className='col-12'>
            <label className='required form-label fw-bold text-gray-800 fs-7'>Reason for Leaving School</label>
            <input
              type='text'
              className={`form-control form-control-solid form-control-sm fs-7 ${errors.reason_for_leaving ? 'is-invalid' : ''}`}
              placeholder='e.g., Parent transferred to another city / Admission in higher secondary school'
              value={formData.reason_for_leaving}
              onChange={(e) => handleFieldChange('reason_for_leaving', e.target.value)}
            />
            {errors.reason_for_leaving && <div className='invalid-feedback fs-8'>{errors.reason_for_leaving}</div>}
          </div>

          {/* Remarks */}
          <div className='col-12'>
            <label className='form-label fw-bold text-gray-800 fs-7'>Other Academic Remarks</label>
            <textarea
              className='form-control form-control-solid form-control-sm fs-7'
              rows={2}
              placeholder='Add any other extra-curricular achievements, scholarships or remarks...'
              value={formData.remarks}
              onChange={(e) => handleFieldChange('remarks', e.target.value)}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
