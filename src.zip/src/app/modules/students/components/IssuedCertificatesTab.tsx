import { FC, useState, useEffect, useCallback } from 'react'
import { TransferCertificateModel, StudentModel } from '../core/_models'
import { SessionModel, ClassModel } from '../../academic/core/_models'
import { Modal, Button, Form } from 'react-bootstrap'
import { useAuth } from '../../auth'
import { getClassSections } from '../../academic/core/_requests'
import { getTransferCertificates } from '../core/_requests'

interface IssuedCertificatesTabProps {
  certificates: TransferCertificateModel[]
  students: StudentModel[]
  sessions: SessionModel[]
  classes: ClassModel[]
  onSelectReprint: (tc: TransferCertificateModel) => void
  onRevokeTc: (tcId: number, reason: string, revokedBy: string) => void
  onDownloadPdf?: (tcId: number, studentName: string) => void
}

export const IssuedCertificatesTab: FC<IssuedCertificatesTabProps> = ({
  certificates,
  students,
  sessions,
  classes = [],
  onSelectReprint,
  onRevokeTc,
  onDownloadPdf,
}) => {
  const { currentUser } = useAuth()
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [filterClass, setFilterClass] = useState('')
  const [filterSession, setFilterSession] = useState('')
  const [filterSection, setFilterSection] = useState('')
  const [archiveSections, setArchiveSections] = useState<any[]>([])
  const [filterStatus, setFilterStatus] = useState<TransferCertificateModel['status'] | ''>('')
  
  const [certificatesList, setCertificatesList] = useState<TransferCertificateModel[]>([])
  const [loading, setLoading] = useState(false)

  // Debounce Search Parameter to minimize API requests
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 400)
    return () => clearTimeout(t)
  }, [search])

  // Fetch Archives Dynamic List from Backend via API
  const fetchCertificatesFromBackend = useCallback(async () => {
    setLoading(true)
    try {
      const params: any = {
        page: 1,
        limit: 100
      }
      if (debouncedSearch) params.search = debouncedSearch
      if (filterSession) params.session_id = Number(filterSession)
      if (filterStatus) params.status = filterStatus

      if (filterClass) {
        const classObj = classes.find(c => c.name === filterClass)
        if (classObj) params.class_id = classObj.id
      }

      if (filterSection) {
        const secObj = archiveSections.find(s => s.name === filterSection)
        if (secObj) params.section_id = secObj.id
      }

      const res = await getTransferCertificates(currentUser?.schoolId || '', params)
      if (res.data.success) {
        setCertificatesList(res.data.data.certificates || [])
      }
    } catch (err) {
      console.error('Failed to load certificates:', err)
      setCertificatesList([])
    } finally {
      setLoading(false)
    }
  }, [currentUser?.schoolId, debouncedSearch, filterSession, filterClass, filterSection, filterStatus, classes, archiveSections])

  useEffect(() => {
    fetchCertificatesFromBackend()
  }, [fetchCertificatesFromBackend])
  
  const handleClassChange = async (className: string) => {
    setFilterClass(className)
    setFilterSection('')
    setArchiveSections([])
    
    if (!className) return
    
    const selectedClassObj = classes.find(c => c.name === className)
    if (selectedClassObj) {
      try {
        const res = await getClassSections(currentUser?.schoolId || '', selectedClassObj.id)
        if (res.data.success) {
          setArchiveSections(
            res.data.data.sections?.map((s: any) => s.section).filter(Boolean) || []
          )
        }
      } catch (err) {
        console.error('Failed to load sections for archive:', err)
      }
    }
  }
  
  // Revocation Modal States
  const [showRevokeModal, setShowRevokeModal] = useState(false)
  const [targetTc, setTargetTc] = useState<TransferCertificateModel | null>(null)
  const [revokeReason, setRevokeReason] = useState('')
  const [error, setError] = useState('')

  // Map students for easy lookup
  const getStudentInfo = (studentId: number) => {
    return students.find((s) => s.id === studentId)
  }

  // Filter Certificates (Dynamically bind to the active API list!)
  const filteredCerts = certificatesList

  const openRevokeModal = (tc: TransferCertificateModel) => {
    setTargetTc(tc)
    setRevokeReason('')
    setError('')
    setShowRevokeModal(true)
  }

  const handleSaveRevocation = () => {
    if (!revokeReason.trim()) {
      setError('Please specify a valid reason for revoking the Transfer Certificate.')
      return
    }

    if (targetTc) {
      const actor = currentUser?.first_name
        ? `${currentUser.first_name} ${currentUser.last_name || ''}`.trim()
        : 'Admin'
      onRevokeTc(targetTc.id, revokeReason.trim(), actor)
      setShowRevokeModal(false)
    }
  }

  return (
    <div className='card card-flush border border-gray-200'>
      {/* Filters Toolbar */}
      <div className='card-header pt-5 align-items-center gap-3 flex-wrap min-h-auto pb-4'>
        <div className='card-title m-0'>
          <h3 className='fw-bold text-gray-800 fs-5 d-flex align-items-center gap-2 m-0'>
            <i className='ki-duotone ki-archive text-primary fs-3'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
            Issued Certificate Archives
          </h3>
        </div>

        <div className='card-toolbar d-flex align-items-center gap-3 flex-wrap'>
          {/* Search */}
          <div className='d-flex align-items-center position-relative my-1'>
            <i className='ki-duotone ki-magnifier fs-5 position-absolute ms-3'>
              <span className='path1'></span>
              <span className='path2'></span>
            </i>
            <input
              type='text'
              className='form-control form-control-solid form-control-sm ps-10 w-200px fs-7'
              placeholder='Search archives...'
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {/* Academic Session Filter */}
          <select
            className='form-select form-select-solid form-select-sm w-150px fs-7 text-primary fw-bold'
            value={filterSession}
            onChange={(e) => setFilterSession(e.target.value)}
          >
            <option value=''>All Sessions</option>
            {sessions.map((s) => (
              <option key={s.id} value={s.id}>
                Session {s.session_year} {s.is_current ? '★' : ''}
              </option>
            ))}
          </select>

          {/* Dynamic Class Filter */}
          <select
            className='form-select form-select-solid form-select-sm w-130px fs-7 text-gray-800 fw-semibold'
            value={filterClass}
            onChange={(e) => handleClassChange(e.target.value)}
          >
            <option value=''>All Classes</option>
            {classes.map((c) => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Dynamic Section Filter */}
          <select
            className='form-select form-select-solid form-select-sm w-130px fs-7 text-gray-800 fw-semibold'
            value={filterSection}
            onChange={(e) => setFilterSection(e.target.value)}
            disabled={!filterClass}
          >
            <option value=''>All Sections</option>
            {archiveSections.map((s) => (
              <option key={s.id} value={s.name}>
                Section {s.name}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            className='form-select form-select-solid form-select-sm w-120px fs-7 text-gray-800 fw-semibold'
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
          >
            <option value=''>All Status</option>
            <option value='Issued'>Issued</option>
            <option value='Revoked'>Revoked</option>
          </select>
        </div>
      </div>

      {/* Grid table */}
      <div className='card-body pt-0'>
        {loading ? (
          <div className='text-center py-10'>
            <span className='spinner-border spinner-border-sm text-primary me-2' role='status' aria-hidden='true'></span>
            <span className='text-muted fs-6 m-0 fw-semibold'>Loading archive certificates...</span>
          </div>
        ) : filteredCerts.length === 0 ? (
          <div className='text-center py-10'>
            <i className='ki-duotone ki-folder fs-3x text-gray-300 mb-3'>
              <span className='path1'></span>
              <span className='path2'></span>
            </i>
            <p className='text-muted fs-6 m-0'>No previously issued certificates found matching filters.</p>
          </div>
        ) : (
          <div className='table-responsive'>
            <table className='table align-middle table-row-dashed fs-7 gy-4 dataTable no-footer'>
              <thead>
                <tr className='text-start text-gray-400 fw-bold fs-8 text-uppercase gs-0 border-bottom border-gray-200'>
                  <th>Serial Number</th>
                  <th>Student Info</th>
                  <th>Admission No</th>
                  <th>Exit Session</th>
                  <th>Class studied</th>
                  <th>Date Issued</th>
                  <th>Issued By</th>
                  <th>Status</th>
                  <th className='text-end'>Actions</th>
                </tr>
              </thead>
              <tbody className='fw-semibold text-gray-600'>
                {filteredCerts.map((cert) => {
                  const student = getStudentInfo(cert.student_id)
                  const isRevoked = cert.status === 'Revoked'
                  const sessionObj = sessions.find((s) => s.id === cert.academic_session_id)
                  const sessionLabel = sessionObj ? sessionObj.session_year : '2024-25'

                  return (
                    <tr key={cert.id} className={isRevoked ? 'bg-light-danger opacity-75' : ''}>
                      <td>
                        <span className='fw-bold text-gray-900 fs-7'>{cert.serial_number}</span>
                      </td>
                      <td>
                        {student ? (
                          <div className='d-flex align-items-center'>
                            <div className='d-flex flex-column'>
                              <span className='text-gray-800 fw-bold fs-7 hover-primary'>
                                {student.first_name} {student.last_name}
                              </span>
                              <span className='text-muted fs-9'>{student.email}</span>
                            </div>
                          </div>
                        ) : (
                          <span className='text-muted'>Unknown Student</span>
                        )}
                      </td>
                      <td>{student?.registration_number || '—'}</td>
                      <td>
                        <span className='badge badge-light-info fw-bold fs-8'>
                          {sessionLabel}
                        </span>
                      </td>
                      <td>{cert.class_studied}</td>
                      <td>
                        {new Date(cert.issue_date).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </td>
                      <td>{cert.issued_by}</td>
                      <td>
                        <span className={`badge badge-light-${isRevoked ? 'danger' : 'success'} fw-bold`}>
                          {cert.status}
                        </span>
                      </td>
                      <td className='text-end'>
                        <div className='d-flex gap-2 justify-content-end'>
                          <button
                            className='btn btn-sm btn-light-primary fw-bold btn-icon-only'
                            title='Reprint / View Certificate'
                            onClick={() => onSelectReprint(cert)}
                          >
                            <i className='ki-duotone ki-printer fs-5 m-0'>
                              <span className='path1'></span>
                              <span className='path2'></span>
                              <span className='path3'></span>
                              <span className='path4'></span>
                            </i>
                          </button>

                          {!isRevoked && onDownloadPdf && (
                            <button
                              className='btn btn-sm btn-light-success fw-bold btn-icon-only'
                              title='Download Official PDF'
                              onClick={() => onDownloadPdf(cert.id, student ? `${student.first_name} ${student.last_name}` : 'Student')}
                            >
                              <i className='ki-duotone ki-download fs-5 m-0'>
                                <span className='path1'></span>
                                <span className='path2'></span>
                              </i>
                            </button>
                          )}

                          {!isRevoked && (
                            <button
                              className='btn btn-sm btn-light-danger fw-bold'
                              onClick={() => openRevokeModal(cert)}
                            >
                              Revoke
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Revocation Modal */}
      <Modal show={showRevokeModal} onHide={() => setShowRevokeModal(false)} centered>
        <Modal.Header closeButton className='border-0'>
          <Modal.Title className='fw-bold text-gray-800'>
            Revoke Transfer Certificate
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className='py-4 px-lg-10'>
          {error && <div className='alert alert-danger fs-7 py-2 px-3 mb-4'>{error}</div>}

          {targetTc && (
            <div className='notice d-flex bg-light-danger rounded p-4 mb-5 border-start border-danger border-3'>
              <i className='ki-duotone ki-shield-cross fs-2x text-danger me-3'>
                <span className='path1'></span>
                <span className='path2'></span>
              </i>
              <div>
                <div className='fw-bold text-gray-800'>Revoking Serial: {targetTc.serial_number}</div>
                <div className='text-muted fs-7 mt-1'>
                  Revoking a certificate invalidates its digital status. The verification URL will show this certificate as revoked. This action is irreversible.
                </div>
              </div>
            </div>
          )}

          <Form.Group className='mb-3'>
            <Form.Label className='required fw-semibold fs-6 mb-2'>Reason for Revocation</Form.Label>
            <Form.Control
              as='textarea'
              rows={3}
              placeholder='e.g., Issued in error / Student admission reinstated / Correction needed in details...'
              value={revokeReason}
              onChange={(e) => setRevokeReason(e.target.value)}
              className='form-control-solid'
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer className='border-0 pt-0'>
          <Button variant='light' onClick={() => setShowRevokeModal(false)} className='btn-sm fw-bold'>
            Cancel
          </Button>
          <Button variant='danger' onClick={handleSaveRevocation} className='btn-sm fw-bold px-4'>
            Revoke Certificate
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}
