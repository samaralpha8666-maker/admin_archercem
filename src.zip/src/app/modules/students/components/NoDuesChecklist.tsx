import { FC, useState } from 'react'
import { NoDuesStatus } from '../core/_models'
import { useAuth } from '../../auth'
import { Modal, Button, Form } from 'react-bootstrap'

interface NoDuesChecklistProps {
  noDues: NoDuesStatus[]
  onChange: (newDues: NoDuesStatus[]) => void
}

const DEPARTMENT_METADATA: Record<
  NoDuesStatus['department'],
  { label: string; icon: string; desc: string; color: string }
> = {
  Finance: {
    label: 'Finance & Accounts',
    icon: 'ki-dollar',
    desc: 'Verify tuition fees, transport fees, and other pending bills.',
    color: 'success',
  },
  Library: {
    label: 'Library Clearance',
    icon: 'ki-book',
    desc: 'Ensure all issued books are returned and library fines are cleared.',
    color: 'primary',
  },
  Hostel: {
    label: 'Hostel & Mess',
    icon: 'ki-home-2',
    desc: 'Check room occupancy status, mess bills, and key handovers.',
    color: 'info',
  },
  SportsLab: {
    label: 'Sports & Laboratories',
    icon: 'ki-award',
    desc: 'Verify sports kit returns and physics/chemistry/computer lab dues.',
    color: 'warning',
  },
}

export const NoDuesChecklist: FC<NoDuesChecklistProps> = ({ noDues, onChange }) => {
  const { currentUser } = useAuth()
  const [showOverrideModal, setShowOverrideModal] = useState(false)
  const [targetDept, setTargetDept] = useState<NoDuesStatus['department'] | null>(null)
  const [overrideReason, setOverrideReason] = useState('')
  const [error, setError] = useState('')

  const clearedCount = noDues.filter((d) => d.cleared).length
  const totalCount = noDues.length
  const progressPercent = Math.round((clearedCount / totalCount) * 100)

  const handleToggleClearance = (dept: NoDuesStatus['department']) => {
    const updated = noDues.map((item) => {
      if (item.department === dept) {
        if (item.cleared) {
          // If already cleared, undo it
          return {
            ...item,
            cleared: false,
            checkedBy: undefined,
            clearedAt: undefined,
            overrideReason: undefined,
          }
        } else {
          // Mark as cleared regularly
          return {
            ...item,
            cleared: true,
            checkedBy: currentUser?.first_name ? `${currentUser.first_name} ${currentUser.last_name || ''}`.trim() : 'Admin',
            clearedAt: new Date().toISOString(),
            overrideReason: undefined,
          }
        }
      }
      return item
    })
    onChange(updated)
  }

  const openOverrideModal = (dept: NoDuesStatus['department']) => {
    setTargetDept(dept)
    setOverrideReason('')
    setError('')
    setShowOverrideModal(true)
  }

  const handleSaveOverride = () => {
    if (!overrideReason.trim()) {
      setError('Please provide a valid reason for the administrative override.')
      return
    }

    const updated = noDues.map((item) => {
      if (item.department === targetDept) {
        return {
          ...item,
          cleared: true,
          checkedBy: currentUser?.first_name ? `${currentUser.first_name} ${currentUser.last_name || ''}`.trim() : 'Admin Override',
          clearedAt: new Date().toISOString(),
          overrideReason: overrideReason.trim(),
        }
      }
      return item
    })

    onChange(updated)
    setShowOverrideModal(false)
  }

  return (
    <div className='card card-flush border border-gray-200 h-100'>
      <div className='card-header pt-5'>
        <h3 className='card-title align-items-start flex-column'>
          <span className='card-label fw-bold text-gray-800 fs-5'>Departmental No-Dues Clearance</span>
          <span className='text-muted mt-1 fw-semibold fs-7'>
            Clear all department clearances or provide admin override reasons
          </span>
        </h3>
        <div className='card-toolbar'>
          <span className={`badge badge-light-${progressPercent === 100 ? 'success' : 'warning'} fw-bold`}>
            {clearedCount} of {totalCount} Cleared
          </span>
        </div>
      </div>

      <div className='card-body pt-3'>
        {/* Progress Bar */}
        <div className='mb-6'>
          <div className='d-flex align-items-center justify-content-between mb-2'>
            <span className='text-gray-500 fs-7 fw-semibold'>Overall Clearance Status</span>
            <span className='text-gray-800 fs-6 fw-bold'>{progressPercent}%</span>
          </div>
          <div className='h-8px w-100 bg-light-primary rounded'>
            <div
              className={`h-8px rounded bg-${progressPercent === 100 ? 'success' : 'primary'}`}
              style={{ width: `${progressPercent}%`, transition: 'width 0.4s ease' }}
            ></div>
          </div>
        </div>

        {/* Clearances List */}
        <div className='d-flex flex-column gap-5'>
          {noDues.map((item) => {
            const meta = DEPARTMENT_METADATA[item.department]
            return (
              <div
                key={item.department}
                className={`d-flex flex-stack p-4 rounded-3 border border-dashed ${
                  item.cleared ? 'bg-light-success border-success-clarity' : 'bg-light border-gray-300'
                }`}
                style={{ transition: 'all 0.25s ease' }}
              >
                <div className='d-flex align-items-center me-3'>
                  <div className={`symbol symbol-40px me-4 bg-light-${meta.color} rounded-circle d-flex align-items-center justify-content-center text-${meta.color}`}>
                    <i className={`ki-duotone ${meta.icon} fs-2`}>
                      <span className='path1'></span>
                      <span className='path2'></span>
                      <span className='path3'></span>
                    </i>
                  </div>

                  <div className='d-flex flex-column'>
                    <div className='fw-bold text-gray-800 fs-6'>{meta.label}</div>
                    <div className='text-muted fs-8 text-wrap' style={{ maxWidth: '350px' }}>
                      {meta.desc}
                    </div>
                    {item.cleared && (
                      <div className='fs-8 text-success-emphasis fw-semibold mt-1 d-flex flex-wrap align-items-center gap-1'>
                        <i className='ki-duotone ki-shield-tick text-success fs-7'>
                          <span className='path1'></span>
                          <span className='path2'></span>
                        </i>
                        Cleared by {item.checkedBy} on {new Date(item.clearedAt || '').toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                        {item.overrideReason && (
                          <span className='badge badge-light-danger fw-bold fs-9 ms-1' title={`Override Reason: ${item.overrideReason}`}>
                            Overridden
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                <div className='d-flex align-items-center gap-2 flex-shrink-0'>
                  {item.cleared ? (
                    <button
                      className='btn btn-icon btn-sm btn-light-danger rounded-circle'
                      title='Undo Clearance'
                      onClick={() => handleToggleClearance(item.department)}
                    >
                      <i className='ki-duotone ki-cross fs-6'>
                        <span className='path1'></span>
                        <span className='path2'></span>
                      </i>
                    </button>
                  ) : (
                    <>
                      <button
                        className='btn btn-sm btn-light-success fw-bold px-3 py-1'
                        onClick={() => handleToggleClearance(item.department)}
                      >
                        Clear
                      </button>
                      <button
                        className='btn btn-sm btn-light-danger fw-bold px-3 py-1'
                        onClick={() => openOverrideModal(item.department)}
                      >
                        Override
                      </button>
                    </>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Override Reason Modal */}
      <Modal show={showOverrideModal} onHide={() => setShowOverrideModal(false)} centered>
        <Modal.Header closeButton className='border-0'>
          <Modal.Title className='fw-bold text-gray-800'>
            Administrative Dues Override
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className='py-4 px-lg-10'>
          {error && <div className='alert alert-danger fs-7 py-2 px-3 mb-4'>{error}</div>}

          {targetDept && (
            <div className='notice d-flex bg-light-warning rounded p-4 mb-5 border-start border-warning border-3'>
              <i className='ki-duotone ki-information-2 fs-2x text-warning me-3'>
                <span className='path1'></span>
                <span className='path2'></span>
                <span className='path3'></span>
              </i>
              <div>
                <div className='fw-bold text-gray-800'>{DEPARTMENT_METADATA[targetDept].label}</div>
                <div className='text-muted fs-7 mt-1'>
                  You are overriding outstanding dues/clearances for this department. A valid audit log reason is required.
                </div>
              </div>
            </div>
          )}

          <Form.Group className='mb-3'>
            <Form.Label className='required fw-semibold fs-6 mb-2'>Override Reason</Form.Label>
            <Form.Control
              as='textarea'
              rows={3}
              placeholder='e.g., Security deposit adjusted / Management approved / Promised to clear post-exit...'
              value={overrideReason}
              onChange={(e) => setOverrideReason(e.target.value)}
              className='form-control-solid'
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer className='border-0 pt-0'>
          <Button variant='light' onClick={() => setShowOverrideModal(false)} className='btn-sm fw-bold'>
            Cancel
          </Button>
          <Button variant='danger' onClick={handleSaveOverride} className='btn-sm fw-bold px-4'>
            Clear Dues via Override
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}
