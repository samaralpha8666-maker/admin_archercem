import { FC, useState, useEffect } from 'react'
import { StudentModel } from '../core/_models'
import { toAbsoluteUrl } from '../../../../_metronic/helpers'

interface StudentSelectorProps {
  students: StudentModel[]
  selectedStudent: StudentModel | null
  onSelect: (student: StudentModel) => void
  loading: boolean
  search: string
  setSearch: (val: string) => void
}

export const StudentSelector: FC<StudentSelectorProps> = ({
  students,
  selectedStudent,
  onSelect,
  loading,
  search,
  setSearch,
}) => {
  const [profileHealth, setProfileHealth] = useState<{
    score: number
    issues: { field: string; label: string; ok: boolean }[]
  }>({ score: 100, issues: [] })

  useEffect(() => {
    if (!selectedStudent) {
      setProfileHealth({ score: 100, issues: [] })
      return
    }

    const checkFields = [
      { field: 'dob', label: 'Date of Birth', ok: !!selectedStudent.profile?.dob },
      { field: 'father_name', label: "Father's Name", ok: !!selectedStudent.parent?.father_name },
      { field: 'mother_name', label: "Mother's Name", ok: !!selectedStudent.parent?.mother_name },
      { field: 'nationality', label: 'Nationality', ok: !!selectedStudent.profile?.nationality },
      { field: 'category', label: 'Caste Category', ok: !!selectedStudent.profile?.category },
      {
        field: 'admission_no',
        label: 'Admission Number',
        ok: !!selectedStudent.registration_number,
      },
      {
        field: 'enrollment',
        label: 'Class Enrollment Record',
        ok: !!selectedStudent.enrollments && selectedStudent.enrollments.length > 0,
      },
    ]

    const okCount = checkFields.filter((f) => f.ok).length
    const score = Math.round((okCount / checkFields.length) * 100)

    setProfileHealth({
      score,
      issues: checkFields,
    })
  }, [selectedStudent])

  return (
    <div className='d-flex flex-column gap-5'>
      {/* Search Card */}
      <div className='card card-flush border border-gray-200'>
        <div className='card-header pt-5 min-h-auto pb-2'>
          <h3 className='card-title fw-bold text-gray-800 fs-6'>Exiting Student Roster</h3>
        </div>
        <div className='card-body pt-2'>
          {/* Search */}
          <div className='d-flex align-items-center position-relative'>
            <i className='ki-duotone ki-magnifier fs-4 position-absolute ms-3'>
              <span className='path1'></span>
              <span className='path2'></span>
            </i>
            <input
              type='text'
              className='form-control form-control-solid ps-10 form-control-sm fs-7'
              placeholder='Search by name or adm number...'
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Student List Card */}
      <div className='card card-flush border border-gray-200 shadow-sm' style={{ maxHeight: '350px', overflowY: 'auto' }}>
        <div className='card-body py-3 px-3'>
          {loading ? (
            <div className='text-center py-8'>
              <span className='spinner-border spinner-border-sm text-primary'></span>
            </div>
          ) : students.length === 0 ? (
            <div className='text-center text-muted py-8 fs-7'>No active students found in session</div>
          ) : (
            students.map((s) => {
              const isSelected = selectedStudent?.id === s.id
              const profileImg = s.profile && (s.profile as any).profile_image
              const activeEnrollment = s.enrollments?.find((e) => e.status === 'Active' || e.status === 'Transferred')
              const classLabel = activeEnrollment?.class_section?.class?.name
                ? `${activeEnrollment.class_section.class.name}-${activeEnrollment.class_section.section?.name || ''}`
                : 'Unenrolled'

              return (
                <div
                  key={s.id}
                  onClick={() => onSelect(s)}
                  className={`d-flex align-items-center p-3 rounded-3 mb-2 border ${
                    isSelected
                      ? 'bg-primary border-primary text-white'
                      : 'bg-hover-light-primary border-transparent'
                  }`}
                  style={{ cursor: 'pointer', transition: 'all 0.15s ease' }}
                >
                  <div className='symbol symbol-35px symbol-circle me-3 flex-shrink-0'>
                    {profileImg ? (
                      <img src={profileImg} alt='profile' style={{ objectFit: 'cover' }} />
                    ) : (
                      <img src={toAbsoluteUrl('media/svg/avatars/blank.svg')} alt='avatar' />
                    )}
                  </div>
                  <div className='min-w-0 flex-grow-1'>
                    <div className={`fw-bold fs-7 text-truncate ${isSelected ? 'text-white' : 'text-gray-800'}`}>
                      {s.first_name} {s.last_name}
                    </div>
                    <div className={`fs-8 text-truncate d-flex align-items-center gap-1 ${isSelected ? 'text-white opacity-75' : 'text-muted'}`}>
                      {s.registration_number ? (
                        <span className={`fw-semibold ${isSelected ? 'text-white' : 'text-primary'}`}>
                          [{s.registration_number}]
                        </span>
                      ) : null}
                      <span>· {classLabel}</span>
                    </div>
                  </div>
                  {isSelected && (
                    <i className='ki-duotone ki-check fs-4 text-white ms-2'></i>
                  )}
                </div>
              )
            })
          )}
        </div>
      </div>

      {/* Selected Student Profile Health Dashboard */}
      {selectedStudent && (
        <div className='card card-flush border border-gray-200 bg-light-neutral shadow-sm'>
          <div className='card-header pt-4 min-h-auto pb-2'>
            <h4 className='card-title fw-bold text-gray-800 fs-6 d-flex align-items-center gap-2'>
              <i className='ki-duotone ki-shield-tick text-primary fs-4'>
                <span className='path1'></span>
                <span className='path2'></span>
              </i>
              Profile Data Quality
            </h4>
            <div className='card-toolbar'>
              <span className={`badge badge-${profileHealth.score === 100 ? 'light-success' : profileHealth.score > 60 ? 'light-warning' : 'light-danger'} fw-bold fs-8`}>
                {profileHealth.score}% Complete
              </span>
            </div>
          </div>
          <div className='card-body pt-1 pb-4'>
            <p className='fs-8 text-muted mb-3'>
              TC standard certificates fetch details directly from the database. Ensure these fields are complete.
            </p>

            <div className='d-flex flex-column gap-2'>
              {profileHealth.issues.map((issue) => (
                <div key={issue.field} className='d-flex align-items-center justify-content-between p-2 rounded bg-white border border-gray-100 shadow-sm'>
                  <span className='fs-8 text-gray-700 fw-semibold'>{issue.label}</span>
                  {issue.ok ? (
                    <span className='badge badge-circle badge-light-success badge-sm d-inline-flex align-items-center justify-content-center' style={{ width: 18, height: 18 }}>
                      <i className='ki-duotone ki-check fs-9 text-success p-0 m-0'></i>
                    </span>
                  ) : (
                    <span
                      className='badge badge-circle badge-light-danger badge-sm d-inline-flex align-items-center justify-content-center'
                      style={{ width: 18, height: 18, cursor: 'help' }}
                      title='Missing in database profile! Please complete in Admission details.'
                    >
                      <i className='ki-duotone ki-cross fs-9 text-danger p-0 m-0'>
                        <span className='path1'></span>
                        <span className='path2'></span>
                      </i>
                    </span>
                  )}
                </div>
              ))}
            </div>

            {profileHealth.score < 100 && (
              <div className='alert alert-warning d-flex align-items-center p-2 rounded mt-3 mb-0 border border-warning-clarity bg-light-warning'>
                <i className='ki-duotone ki-information-2 text-warning fs-5 me-2'>
                  <span className='path1'></span>
                  <span className='path2'></span>
                  <span className='path3'></span>
                </i>
                <span className='fs-9 text-warning-emphasis fw-bold'>
                  Missing details will print as blank. Check student profile!
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
