import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { Modal, Button, Alert } from 'react-bootstrap'
import { useAuth } from '../auth'
import { toAbsoluteUrl } from '../../../_metronic/helpers'
import {
  admitStudent, getStudents, getStudentById, updateStudentCore,
  updateStudentProfile, updateStudentParent, updateStudentAddress,
  uploadDocument, enrollStudent, updateEnrollment, getStudentDocuments, toggleStudentStatus,
} from './core/_requests'
import { getClasses, getClassSections, getAcademicSessions } from '../academic/core/_requests'
import {
  StudentModel, StudentDocumentModel, DocumentType,
  AdmitStudentPayload, StudentProfilePayload, StudentParentPayload, StudentAddressPayload,
  StudentEnrollmentModel, EnrollmentStatus
} from './core/_models'
import { BulkAdmissionModal } from './BulkAdmissionModal'
import { ClassModel, ClassSectionMappingModel, SessionModel } from '../academic/core/_models'

// ─── Constants ───────────────────────────────────────────────────────────────
const DOCUMENT_TYPES: DocumentType[] = [
  'AadharCard', 'BirthCertificate', 'TransferCertificate',
  'PassportPhoto', 'MarkSheet', 'MedicalCertificate', 'CasteCertificate', 'Other',
]
const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
const CATEGORIES = ['General', 'OBC', 'SC', 'ST', 'EWS', 'Other']
const GENDERS = ['male', 'female', 'other']

type Tab = 'enrollment' | 'profile' | 'parent' | 'address' | 'documents'

// ─── Main Page ───────────────────────────────────────────────────────────────
const AdmissionPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // ─── Students List State ───
  const [students, setStudents] = useState<StudentModel[]>([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [listError, setListError] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<'standard' | 'excel'>('standard')

  const [page, setPage] = useState(1)
  const [limit, setLimit] = useState(10)
  const [paginationMeta, setPaginationMeta] = useState({
    total: 0,
    totalPages: 0,
    hasNextPage: false,
    hasPrevPage: false
  })

  // Handle search debounce
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search)
      setPage(1) // Reset to first page on search
    }, 500)
    return () => clearTimeout(handler)
  }, [search])

  // ─── Admit Modal State ───
  const [showAdmitModal, setShowAdmitModal] = useState(false)
  const [showBulkModal, setShowBulkModal] = useState(false)
  const [admitSaving, setAdmitSaving] = useState(false)
  const [admitError, setAdmitError] = useState<string | null>(null)
  const [isEditMode, setIsEditMode] = useState(false)
  const [currentStudentId, setCurrentStudentId] = useState<number | null>(null)
  const [admitForm, setAdmitForm] = useState<AdmitStudentPayload>({
    first_name: '', last_name: '', mobile_number: '', email: '', password: '', registration_number: ''
  })

  // ─── Manage Modal State ───
  const [showManageModal, setShowManageModal] = useState(false)
  const [activeTab, setActiveTab] = useState<Tab>('enrollment')
  const [selectedStudent, setSelectedStudent] = useState<StudentModel | null>(null)
  const [manageSaving, setManageSaving] = useState(false)
  const [manageError, setManageError] = useState<string | null>(null)
  const [manageSuccess, setManageSuccess] = useState<string | null>(null)

  // Sub-forms for Manage Modal
  const [profileForm, setProfileForm] = useState<StudentProfilePayload>({ dob: '', gender: 'male', blood_group: 'B+', nationality: 'Indian', category: 'General' })
  const [profileImageFile, setProfileImageFile] = useState<File | null>(null)
  const [parentForm, setParentForm] = useState<StudentParentPayload>({ father_name: '', father_phone: '', father_occupation: '', mother_name: '', mother_phone: '', mother_occupation: '' })
  const [addrForm, setAddrForm] = useState<StudentAddressPayload>({ current_address: '', current_city: '', current_state: '', current_pincode: '', is_same_as_current: true, permanent_address: '', permanent_city: '', permanent_state: '', permanent_pincode: '' })

  // Documents
  const [docs, setDocs] = useState<StudentDocumentModel[]>([])
  const [docType, setDocType] = useState<DocumentType>('AadharCard')
  const [docFile, setDocFile] = useState<File | null>(null)
  const [docUploading, setDocUploading] = useState(false)
  const [docDragOver, setDocDragOver] = useState(false)

  // Enrollment
  const [sessions, setSessions] = useState<SessionModel[]>([])
  const [classes, setClasses] = useState<ClassModel[]>([])
  const [classSections, setClassSections] = useState<ClassSectionMappingModel[]>([])
  const [enrollForm, setEnrollForm] = useState({ academic_session_id: '', class_id: '', class_section_id: '', roll_number: '', enrollment_date: '' })
  // Existing enrollment for the selected student (if any)
  const [existingEnrollment, setExistingEnrollment] = useState<StudentEnrollmentModel | null>(null)
  const [editEnrollForm, setEditEnrollForm] = useState({ roll_number: '', class_section_id: '', status: 'Active' as EnrollmentStatus })
  const [editingEnrollmentId, setEditingEnrollmentId] = useState<number | null>(null)

  // ─── Load Data ─────────────────────────────────────────────────────────────
  const fetchStudents = useCallback(async () => {
    if (!schoolId) return
    setLoading(true); setListError(null)
    try {
      const { data } = await getStudents(schoolId, { page, limit, search: debouncedSearch })
      if (data.success) {
        setStudents(data.data.students || [])
        if (data.pagination) {
          setPaginationMeta(data.pagination)
        }
      }
    } catch (err: any) {
      setListError(err.response?.data?.error || err.response?.data?.message || 'Failed to load students')
    } finally { setLoading(false) }
  }, [schoolId, page, limit, debouncedSearch])

  useEffect(() => { fetchStudents() }, [fetchStudents])

  const loadMeta = useCallback(async () => {
    if (!schoolId) return
    try {
      const [sRes, cRes] = await Promise.all([getAcademicSessions(schoolId, 1, 100), getClasses(schoolId, 1, 100)])
      if (sRes.data.success) setSessions(sRes.data.data.sessions || [])
      if (cRes.data.success) setClasses(cRes.data.data.classes || [])
    } catch { }
  }, [schoolId])

  useEffect(() => { loadMeta() }, [loadMeta])

  // Just loads sections without touching any form state (used when editing existing enrollment)
  const loadSectionsForClass = async (classId: string) => {
    if (!classId) { setClassSections([]); return }
    try {
      const { data } = await getClassSections(schoolId, classId)
      if (data.success) setClassSections(data.data.sections || [])
    } catch { }
  }

  const handleClassChange = async (classId: string) => {
    setEnrollForm(e => ({ ...e, class_id: classId, class_section_id: '' }))
    setClassSections([])
    if (!classId) return
    try {
      const { data } = await getClassSections(schoolId, classId)
      if (data.success) setClassSections(data.data.sections || [])
    } catch { }
  }

  // ─── Handlers: Admit / Edit Core ──────────────────────────────────────────────
  const handleOpenAdmitModal = (student?: StudentModel) => {
    setAdmitError(null)
    if (student) {
      setIsEditMode(true)
      setCurrentStudentId(student.id)
      setAdmitForm({
        first_name: student.first_name,
        last_name: student.last_name,
        mobile_number: student.mobile_number || '',
        email: student.email,
        password: '',
        registration_number: student.registration_number || ''
      })
    } else {
      setIsEditMode(false)
      setCurrentStudentId(null)
      setAdmitForm({ first_name: '', last_name: '', mobile_number: '', email: '', password: '', registration_number: '' })
    }
    setShowAdmitModal(true)
  }

  const handleAdmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setAdmitSaving(true); setAdmitError(null)
    try {
      if (isEditMode && currentStudentId) {
        const payload = { ...admitForm }
        if (!payload.password) delete payload.password
        await updateStudentCore(schoolId, currentStudentId, payload)
      } else {
        await admitStudent(schoolId, admitForm)
      }
      setShowAdmitModal(false)
      setAdmitForm({ first_name: '', last_name: '', mobile_number: '', email: '', password: '', registration_number: '' })
      fetchStudents()
    } catch (err: any) {
      if (err.response?.status === 409) {
        setAdmitError(err.response?.data?.message || 'Conflict: Email or Mobile number is already taken.')
      } else {
        setAdmitError(err.response?.data?.error || err.response?.data?.message || 'Failed to process request.')
      }
    } finally { setAdmitSaving(false) }
  }

  // ─── Handlers: Manage Modal ─────────────────────────────────────────────────
  const openManageModal = async (student: StudentModel) => {
    setSelectedStudent(student)
    setActiveTab('enrollment')
    setManageError(null); setManageSuccess(null)
    setProfileImageFile(null)
    setEditingEnrollmentId(null)
    setShowManageModal(true)

    // Pre-fill forms (if backend didn't send full nested data in the list, we fetch individual)
    try {
      const { data: fullData } = await getStudentById(schoolId, student.id)
      const s = fullData.data.student

      if (s.profile) setProfileForm({ dob: s.profile.dob || '', gender: s.profile.gender, blood_group: s.profile.blood_group, nationality: s.profile.nationality, category: s.profile.category })
      if (s.parent) setParentForm({ father_name: s.parent.father_name, father_phone: s.parent.father_phone, father_occupation: s.parent.father_occupation, mother_name: s.parent.mother_name, mother_phone: s.parent.mother_phone, mother_occupation: s.parent.mother_occupation })
      if (s.address) setAddrForm({ current_address: s.address.current_address, current_city: s.address.current_city, current_state: s.address.current_state, current_pincode: s.address.current_pincode, is_same_as_current: s.address.is_same_as_current, permanent_address: s.address.permanent_address || '', permanent_city: s.address.permanent_city || '', permanent_state: s.address.permanent_state || '', permanent_pincode: s.address.permanent_pincode || '' })

      // Pre-fill enrollment if exists
      const enroll = s.enrollments?.[0] || null
      setExistingEnrollment(enroll)
      if (enroll) {
        setEditEnrollForm({
          roll_number: enroll.roll_number || '',
          class_section_id: String(enroll.class_section_id),
          status: enroll.status,
        })
        // Pre-fill new enroll form too (for reference)
        setEnrollForm({ academic_session_id: String(enroll.academic_session_id), class_id: String(enroll.class_section?.class?.id || ''), class_section_id: String(enroll.class_section_id), roll_number: enroll.roll_number || '', enrollment_date: enroll.enrollment_date?.split('T')[0] || '' })
        // Load sections without resetting form state
        const classId = String(enroll.class_section?.class?.id || '')
        if (classId) loadSectionsForClass(classId)
      } else {
        const currentSession = sessions.find(sess => sess.is_current)
        setEnrollForm({ academic_session_id: currentSession ? String(currentSession.id) : '', class_id: '', class_section_id: '', roll_number: '', enrollment_date: new Date().toISOString().split('T')[0] })
      }

      const { data: docData } = await getStudentDocuments(schoolId, student.id)
      if (docData.success) setDocs(docData.data.documents || [])
    } catch { }
  }

  const successToast = (msg: string) => {
    setManageSuccess(msg)
    setTimeout(() => setManageSuccess(null), 3000)
    fetchStudents() // Refresh list on background
  }

  // Sub-form submits
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedStudent) return
    setManageSaving(true); setManageError(null)
    try {
      await updateStudentProfile(schoolId, selectedStudent.id, profileForm, profileImageFile)
      successToast('Profile updated successfully!')
    } catch (err: any) { setManageError(err.response?.data?.error || err.response?.data?.message || 'Error saving profile') }
    finally { setManageSaving(false) }
  }

  const handleSaveParent = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedStudent) return
    setManageSaving(true); setManageError(null)
    try {
      await updateStudentParent(schoolId, selectedStudent.id, parentForm)
      successToast('Parent details saved successfully!')
    } catch (err: any) { setManageError(err.response?.data?.error || err.response?.data?.message || 'Error saving parent info') }
    finally { setManageSaving(false) }
  }

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedStudent) return
    setManageSaving(true); setManageError(null)
    try {
      const payload = addrForm.is_same_as_current
        ? { current_address: addrForm.current_address, current_city: addrForm.current_city, current_state: addrForm.current_state, current_pincode: addrForm.current_pincode, is_same_as_current: true }
        : { ...addrForm }
      await updateStudentAddress(schoolId, selectedStudent.id, payload)
      successToast('Address saved successfully!')
    } catch (err: any) { setManageError(err.response?.data?.error || err.response?.data?.message || 'Error saving address') }
    finally { setManageSaving(false) }
  }

  const handleAddDocument = async () => {
    if (!selectedStudent || !docFile) return
    setDocUploading(true); setManageError(null)
    try {
      await uploadDocument(schoolId, selectedStudent.id, docType, docFile)
      const { data } = await getStudentDocuments(schoolId, selectedStudent.id)
      if (data.success) setDocs(data.data.documents || [])
      setDocFile(null)
      // Reset the file input by changing key
      const fileInput = document.getElementById('doc-file-input') as HTMLInputElement
      if (fileInput) fileInput.value = ''
      successToast('Document uploaded successfully!')
    } catch (err: any) { setManageError(err.response?.data?.error || err.response?.data?.message || 'Error uploading document') }
    finally { setDocUploading(false) }
  }

  const handleEnroll = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedStudent) return
    setManageSaving(true); setManageError(null)
    try {
      await enrollStudent(schoolId, selectedStudent.id, {
        academic_session_id: Number(enrollForm.academic_session_id),
        class_section_id: Number(enrollForm.class_section_id),
        roll_number: enrollForm.roll_number.trim() || undefined,
        enrollment_date: enrollForm.enrollment_date,
      })
      successToast('Student enrolled successfully!')
      // Re-fetch to update existingEnrollment
      const { data: rd } = await getStudentById(schoolId, selectedStudent.id)
      const newEnroll = rd.data.student.enrollments?.[0] || null
      setExistingEnrollment(newEnroll)
      setSelectedStudent(rd.data.student)
      setEnrollForm(prev => ({
        ...prev,
        class_id: '',
        class_section_id: '',
        roll_number: ''
      }))
    } catch (err: any) { setManageError(err.response?.data?.error || err.response?.data?.message || 'Error enrolling student') }
    finally { setManageSaving(false) }
  }

  const handleUpdateEnrollment = async (e: React.FormEvent, enrollmentIdToUpdate?: number) => {
    e.preventDefault()
    const targetId = enrollmentIdToUpdate || existingEnrollment?.id
    if (!selectedStudent || !targetId) return
    setManageSaving(true); setManageError(null)
    try {
      const payload: any = {}
      if (editEnrollForm.roll_number.trim()) payload.roll_number = editEnrollForm.roll_number.trim()
      if (editEnrollForm.class_section_id) payload.class_section_id = Number(editEnrollForm.class_section_id)
      if (editEnrollForm.status) payload.status = editEnrollForm.status
      await updateEnrollment(schoolId, targetId, payload)
      successToast('Enrollment updated successfully!')
      setEditingEnrollmentId(null)
      const { data: rd } = await getStudentById(schoolId, selectedStudent.id)
      const upd = rd.data.student.enrollments?.[0] || null
      setExistingEnrollment(upd)
      setSelectedStudent(rd.data.student)
    } catch (err: any) { setManageError(err.response?.data?.error || err.response?.data?.message || 'Error updating enrollment') }
    finally { setManageSaving(false) }
  }

  const handleToggleStatus = async (student: StudentModel) => {
    try {
      await toggleStudentStatus(schoolId, student.id)
      successToast(`Student ${student.first_name} marked as ${student.is_active ? 'Inactive' : 'Active'}`)
      // Not calling fetchStudents directly here if successToast already does it
    } catch (err: any) {
      setListError(err.response?.data?.error || err.response?.data?.message || 'Failed to toggle status')
    }
  }

  // ─── Helpers ────────────────────────────────────────────────────────────────
  const filtered = students // Filtering is now handled by the backend

  const stats = {
    total: paginationMeta.total,
    active: students.filter(s => s.is_active).length,
    enrolled: students.filter(s => s.enrollments && s.enrollments.length > 0).length,
  }

  const CheckIcon = ({ exists }: { exists: boolean }) => (
    exists ? <i className="ki-duotone ki-check-circle fs-2 text-success" title="Completed"><span className="path1"></span><span className="path2"></span></i>
      : <i className="ki-duotone ki-cross-circle fs-2 text-gray-400" title="Missing"><span className="path1"></span><span className="path2"></span></i>
  )

  return (
    <>
      <Content>
        {listError && <div className='alert alert-danger mb-4'>{listError}</div>}

        {/* ── Students Table with compact stats in header ── */}
        <div className='card card-flush'>
          <div className='card-header align-items-center py-5 gap-3'>
            {/* Title + compact stat pills */}
            <div className='card-title'>
              <h3 className='fw-bold mb-0 me-4'>Students</h3>
              {!loading && (
                <div className='d-flex align-items-center gap-3'>
                  <span className='d-flex align-items-center gap-1 text-gray-600 fs-7 fw-semibold'>
                    <span className='bullet bullet-dot bg-primary h-6px w-6px'></span>
                    Total: <span className='text-primary fw-bold ms-1'>{stats.total}</span>
                  </span>
                  <span className='d-flex align-items-center gap-1 text-gray-600 fs-7 fw-semibold'>
                    <span className='bullet bullet-dot bg-primary h-6px w-6px'></span>
                    Active: <span className='text-primary fw-bold ms-1'>{stats.active}</span>
                  </span>
                  <span className='d-flex align-items-center gap-1 text-gray-600 fs-7 fw-semibold'>
                    <span className='bullet bullet-dot bg-primary h-6px w-6px'></span>
                    Enrolled: <span className='text-primary fw-bold ms-1'>{stats.enrolled}</span>
                  </span>
                </div>
              )}
            </div>
            {/* Search + Add button */}
            <div className='card-toolbar gap-3'>
              <div className='d-flex align-items-center position-relative'>
                <i className='ki-duotone ki-magnifier fs-3 position-absolute ms-4'>
                  <span className='path1'></span><span className='path2'></span>
                </i>
                <input
                  type='text'
                  className='form-control form-control-solid w-200px ps-14'
                  placeholder='Search...'
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </div>
              <div className='btn-group' role='group'>
                <button className={`btn btn-sm btn-icon ${viewMode === 'standard' ? 'btn-primary' : 'btn-light-primary'}`} onClick={() => setViewMode('standard')} title="Standard View">
                  <i className='ki-duotone ki-element-11 fs-3'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span></i>
                </button>
                <button className={`btn btn-sm btn-icon ${viewMode === 'excel' ? 'btn-primary' : 'btn-light-primary'}`} onClick={() => setViewMode('excel')} title="Excel View">
                  <i className='ki-duotone ki-row-horizontal fs-3'><span className='path1'></span><span className='path2'></span></i>
                </button>
              </div>
              <button className='btn btn-light-primary btn-sm' onClick={() => setShowBulkModal(true)}>
                <i className='ki-duotone ki-file-up fs-3'><span className='path1'></span><span className='path2'></span></i> Import Excel
              </button>
              <button className='btn btn-primary btn-sm' onClick={() => handleOpenAdmitModal()}>
                <i className='ki-duotone ki-plus fs-3'></i> Admit Student
              </button>
            </div>
          </div>

          <div className='card-body pt-0'>
            <div className='table-responsive'>
              {viewMode === 'standard' ? (
                <table className='table align-middle table-row-dashed fs-7 gy-4'>
                  <thead>
                    <tr className='text-start text-muted fw-bold fs-7 text-uppercase gs-0 border-bottom border-gray-100'>
                      <th className='w-30px'>#</th>
                      <th className='min-w-180px'>Student</th>
                      <th>Mobile</th>
                      <th className='text-center'>Profile</th>
                      <th className='text-center'>Parent</th>
                      <th className='text-center'>Address</th>
                      <th className='text-center'>Docs</th>
                      <th className='text-center'>Enrolled</th>
                      <th>Status</th>
                      <th className='text-end min-w-80px'>Actions</th>
                    </tr>
                  </thead>
                  <tbody className='text-gray-600 fw-semibold'>
                    {loading ? (
                      <tr><td colSpan={10} className='text-center py-10'>
                        <span className='spinner-border spinner-border-sm text-primary me-2'></span>
                        <span className='text-muted'>Loading students...</span>
                      </td></tr>
                    ) : filtered.length === 0 ? (
                      <tr><td colSpan={10} className='text-center py-12'>
                        <div className='d-flex flex-column align-items-center'>
                          <i className='ki-duotone ki-people fs-3x text-gray-300 mb-3'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i>
                          <div className='text-muted fs-6'>No students found.</div>
                          <button className='btn btn-sm btn-light-primary mt-3' onClick={() => handleOpenAdmitModal()}>Admit First Student</button>
                        </div>
                      </td></tr>
                    ) : filtered.map((s, idx) => {
                      const hasProfile = s.profile && (Array.isArray(s.profile) ? s.profile.length > 0 : Object.keys(s.profile).length > 0)
                      const hasParent = s.parent && (Array.isArray(s.parent) ? s.parent.length > 0 : Object.keys(s.parent).length > 0)
                      const addrObj = s.address || (s as any).addresses
                      const hasAddress = Array.isArray(addrObj) ? addrObj.length > 0 : !!addrObj && Object.keys(addrObj).length > 0
                      const docsObj = s.documents || (s as any).document
                      const docsArray = Array.isArray(docsObj) ? docsObj : (docsObj ? [docsObj] : [])
                      const docsCount = docsArray.length
                      const enrollObj = s.enrollments || (s as any).enrollment
                      const hasEnrollment = Array.isArray(enrollObj) ? enrollObj.length > 0 : !!enrollObj && Object.keys(enrollObj).length > 0

                      return (
                        <tr key={s.id}>
                          <td className='text-gray-400 fs-8'>{idx + 1}</td>
                          <td>
                            <div className='d-flex align-items-center'>
                              <div className='symbol symbol-35px me-3'>
                                {s.profile && (s.profile as any).profile_image ? (
                                  <img src={(s.profile as any).profile_image} alt='profile' style={{ objectFit: 'cover' }} />
                                ) : (
                                  <img src={toAbsoluteUrl('media/svg/avatars/blank.svg')} alt='Avatar' />
                                )}
                              </div>
                              <div>
                                <div className='text-gray-800 fw-bold fs-6'>{s.first_name} {s.last_name}</div>
                                <div className='text-muted fs-8'>
                                  {s.registration_number ? <span className='text-primary fw-semibold me-1'>[{s.registration_number}]</span> : null}
                                  {s.email}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td>
                            <span className='text-gray-700 fs-7'>{s.mobile_number || '—'}</span>
                          </td>
                          <td className='text-center'><CheckIcon exists={!!hasProfile} /></td>
                          <td className='text-center'><CheckIcon exists={!!hasParent} /></td>
                          <td className='text-center'><CheckIcon exists={!!hasAddress} /></td>
                          <td className='text-center'>
                            {docsCount > 0
                              ? <span className='badge badge-light-primary'>{docsCount}</span>
                              : <CheckIcon exists={false} />}
                          </td>
                          <td className='text-center'>
                            {hasEnrollment
                              ? <span className='badge badge-light-primary'>Yes</span>
                              : <span className='badge badge-light fs-8 text-gray-400'>No</span>}
                          </td>
                          <td>
                            <button
                              className={`btn btn-sm fw-bold ${s.is_active ? 'btn-light-success' : 'btn-light-danger'}`}
                              onClick={() => handleToggleStatus(s)}
                              title={s.is_active ? 'Click to Deactivate' : 'Click to Activate'}
                            >
                              <i className={`ki-duotone ${s.is_active ? 'ki-check-circle' : 'ki-cross-circle'} fs-5 me-1`}>
                                <span className='path1'></span><span className='path2'></span>
                              </i>
                              {s.is_active ? 'Active' : 'Inactive'}
                            </button>
                          </td>
                          <td className='text-end'>
                            <button
                              className='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1'
                              title='Edit'
                              onClick={() => handleOpenAdmitModal(s)}
                            >
                              <i className='ki-duotone ki-pencil fs-2'><span className='path1'></span><span className='path2'></span></i>
                            </button>
                            <button
                              className='btn btn-sm btn-light-primary fw-semibold'
                              onClick={() => openManageModal(s)}
                            >
                              Manage
                            </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              ) : (
                <table className='table table-bordered table-striped align-middle fs-8 gy-3 text-nowrap'>
                  <thead className='bg-light'>
                    <tr className='text-start text-muted fw-bolder fs-8 text-uppercase gs-0'>
                      <th>Reg No</th>
                      <th>Roll No</th>
                      <th>Class / Sec</th>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Gender</th>
                      <th>DOB</th>
                      <th>Blood Grp</th>
                      <th>Mobile</th>
                      <th>Email</th>
                      <th>Father Name</th>
                      <th>Father Phone</th>
                      <th>Mother Name</th>
                      <th>State / City</th>
                      <th>Status</th>
                      <th className='text-end min-w-100px'>Actions</th>
                    </tr>
                  </thead>
                  <tbody className='text-gray-600 fw-semibold'>
                    {loading ? (
                      <tr><td colSpan={16} className='text-center py-10'><span className='spinner-border spinner-border-sm text-primary me-2'></span></td></tr>
                    ) : filtered.length === 0 ? (
                      <tr><td colSpan={16} className='text-center py-5'>No data</td></tr>
                    ) : filtered.map(s => {
                      const profile = s.profile || {} as any;
                      const parent = s.parent || {} as any;
                      const addressObj = s.address || (s as any).addresses;
                      const address = (Array.isArray(addressObj) ? addressObj[0] : addressObj) || {} as any;
                      const enrollObj = s.enrollments || (s as any).enrollment;
                      const enrollArray = Array.isArray(enrollObj) ? enrollObj : (enrollObj ? [enrollObj] : []);
                      const enroll = enrollArray.length > 0 ? enrollArray[0] : null;

                      return (
                        <tr key={s.id}>
                          <td className='text-dark fw-bold'>{s.registration_number || '—'}</td>
                          <td className='text-dark fw-bold'>{enroll?.roll_number || '—'}</td>
                          <td>
                            {enroll?.class_section?.class?.name
                              ? <span className='badge badge-light-info'>{enroll.class_section.class.name} / {enroll.class_section.section?.name || '-'}</span>
                              : '—'}
                          </td>
                          <td className='text-dark fw-bold'>{s.first_name}</td>
                          <td className='text-dark fw-bold'>{s.last_name}</td>
                          <td className="text-capitalize">{profile.gender || '—'}</td>
                          <td>{profile.dob ? profile.dob.split('T')[0] : '—'}</td>
                          <td>{profile.blood_group || '—'}</td>
                          <td>{s.mobile_number || '—'}</td>
                          <td>{s.email}</td>
                          <td>{parent.father_name || '—'}</td>
                          <td>{parent.father_phone || '—'}</td>
                          <td>{parent.mother_name || '—'}</td>
                          <td>{address.current_state ? `${address.current_state} / ${address.current_city || '?'}` : '—'}</td>
                          <td>
                            <span className={`badge badge-light-${s.is_active ? 'success' : 'danger'}`}>
                              {s.is_active ? 'Active' : 'Off'}
                            </span>
                          </td>
                          <td className='text-end text-nowrap'>
                            <button
                              className='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1'
                              title='Edit'
                              onClick={() => handleOpenAdmitModal(s)}
                            >
                              <i className='ki-duotone ki-pencil fs-2'><span className='path1'></span><span className='path2'></span></i>
                            </button>
                            <button
                              className='btn btn-sm btn-light-primary fw-semibold'
                              onClick={() => openManageModal(s)}
                            >
                              Manage
                            </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              )}
            </div>

            {/* Pagination */}
            <div className='row mt-5'>
              <div className='col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'>
                <div className='dataTables_length'>
                  <label>
                    <select
                      className='form-select form-select-sm form-select-solid'
                      value={limit}
                      onChange={(e) => {
                        setLimit(Number(e.target.value))
                        setPage(1)
                      }}
                    >
                      <option value={10}>10</option>
                      <option value={25}>25</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                    </select>
                  </label>
                </div>
              </div>
              <div className='col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'>
                <div className='dataTables_paginate paging_simple_numbers'>
                  <ul className='pagination'>
                    <li className={`paginate_button page-item previous ${!paginationMeta.hasPrevPage ? 'disabled' : ''}`}>
                      <button className='page-link' onClick={() => setPage(page - 1)} disabled={!paginationMeta.hasPrevPage}>
                        <i className='previous'></i>
                      </button>
                    </li>
                    {[...Array(paginationMeta.totalPages || 0)].map((_, i) => (
                      <li key={i} className={`paginate_button page-item ${page === i + 1 ? 'active' : ''}`}>
                        <button className='page-link' onClick={() => setPage(i + 1)}>{i + 1}</button>
                      </li>
                    ))}
                    <li className={`paginate_button page-item next ${!paginationMeta.hasNextPage ? 'disabled' : ''}`}>
                      <button className='page-link' onClick={() => setPage(page + 1)} disabled={!paginationMeta.hasNextPage}>
                        <i className='next'></i>
                      </button>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Content>

      {/* ── Quick Admit / Edit Modal ── */}
      <Modal show={showAdmitModal} onHide={() => !admitSaving && setShowAdmitModal(false)} centered backdrop='static'>
        <Modal.Header closeButton className='border-0 pb-0'>
          <Modal.Title><i className={`ki-duotone ${isEditMode ? 'ki-pencil' : 'ki-user-edit'} fs-2x text-primary me-2`}><span className='path1'></span><span className='path2'></span></i> {isEditMode ? 'Edit Student Details' : 'Admit New Student'}</Modal.Title>
        </Modal.Header>
        <Modal.Body className='px-lg-10 pt-4 pb-8'>
          {!isEditMode && <p className='text-muted fs-7 mb-6'>Enter basic info to create the account. You can configure their profile & enroll them later.</p>}
          {admitError && <Alert variant='danger'>{admitError}</Alert>}
          <form onSubmit={handleAdmit}>
            <div className='row g-4'>
              <div className='col-md-6 fv-row'>
                <label className='fw-semibold fs-6 mb-1'>Reg. No (Optional)</label>
                <input className='form-control form-control-solid' placeholder='Auto-generates if blank' value={admitForm.registration_number || ''} onChange={e => setAdmitForm(s => ({ ...s, registration_number: e.target.value }))} disabled={isEditMode} />
              </div>
              <div className='col-md-6 fv-row'>
                <label className='required fw-semibold fs-6 mb-1'>First Name</label>
                <input className='form-control form-control-solid' placeholder='Rahul' value={admitForm.first_name} onChange={e => setAdmitForm(s => ({ ...s, first_name: e.target.value }))} required />
              </div>
              <div className='col-md-6 fv-row'>
                <label className='required fw-semibold fs-6 mb-1'>Last Name</label>
                <input className='form-control form-control-solid' placeholder='Sharma' value={admitForm.last_name} onChange={e => setAdmitForm(s => ({ ...s, last_name: e.target.value }))} required />
              </div>
              <div className='col-md-12 fv-row'>
                <label className='required fw-semibold fs-6 mb-1'>Email</label>
                <input type='email' className='form-control form-control-solid' placeholder='student@school.com' value={admitForm.email} onChange={e => setAdmitForm(s => ({ ...s, email: e.target.value }))} required />
              </div>
              <div className='col-md-6 fv-row'>
                <label className='required fw-semibold fs-6 mb-1'>Mobile</label>
                <input className='form-control form-control-solid' placeholder='10 digits' value={admitForm.mobile_number} onChange={e => setAdmitForm(s => ({ ...s, mobile_number: e.target.value }))} required maxLength={15} />
              </div>
              <div className='col-md-6 fv-row'>
                <label className={`${isEditMode ? '' : 'required'} fw-semibold fs-6 mb-1`}>Password {isEditMode && '(Leave blank to retain)'}</label>
                <input type='password' className='form-control form-control-solid' placeholder='Min 6 chars' value={admitForm.password || ''} onChange={e => setAdmitForm(s => ({ ...s, password: e.target.value }))} required={!isEditMode} minLength={6} />
              </div>
            </div>
            <div className='d-flex justify-content-end pt-8'>
              <Button variant='light' onClick={() => setShowAdmitModal(false)} className='me-3' disabled={admitSaving}>Cancel</Button>
              <Button variant='primary' type='submit' disabled={admitSaving}>
                {admitSaving ? <span className='spinner-border spinner-border-sm'></span> : isEditMode ? 'Update Student' : 'Admit Student'}
              </Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>

      {/* ── Manage / Profile Settings Tabbed Modal ── */}
      <Modal show={showManageModal} onHide={() => !manageSaving && setShowManageModal(false)} size='xl' centered backdrop='static'>
        <Modal.Header closeButton className='bg-light py-4'>
          <Modal.Title className='d-flex align-items-center w-100'>
            <div className='symbol symbol-40px me-4'>
              {selectedStudent?.profile && (selectedStudent.profile as any).profile_image ? (
                <img src={(selectedStudent.profile as any).profile_image} alt='profile' style={{ objectFit: 'cover' }} />
              ) : (
                <img src={toAbsoluteUrl('media/svg/avatars/blank.svg')} alt='Avatar' />
              )}
            </div>
            <div>
              <div className='fw-bolder fs-4'>{selectedStudent?.first_name} {selectedStudent?.last_name}</div>
              <div className='text-muted fs-7 fw-normal'>
                {selectedStudent?.email} · {selectedStudent?.mobile_number}
                {selectedStudent?.registration_number ? ` · Reg No: ${selectedStudent.registration_number}` : ''}
              </div>
            </div>
          </Modal.Title>
        </Modal.Header>

        <div className='d-flex flex-row flex-column-fluid'>
          {/* Sidebar Menu inside modal */}
          <div className='w-250px w-lg-300px bg-light-dark px-6 py-8 border-end border-gray-200'>
            <div className='menu menu-column menu-rounded menu-title-gray-800 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-500'>
              {[
                { id: 'enrollment' as Tab, label: 'Enrollment', icon: 'ki-book-open' },
                { id: 'profile' as Tab, label: 'Personal Profile', icon: 'ki-user-edit' },
                { id: 'parent' as Tab, label: 'Parent / Family', icon: 'ki-people' },
                { id: 'address' as Tab, label: 'Address Details', icon: 'ki-map' },
                { id: 'documents' as Tab, label: 'Documents', icon: 'ki-folder' },
              ].map(t => (
                <div key={t.id} className='menu-item mb-2'>
                  <span className={`menu-link px-4 py-3 ${activeTab === t.id ? 'active bg-white shadow-sm' : ''}`}
                    onClick={() => setActiveTab(t.id)} style={{ cursor: 'pointer', borderRadius: '8px' }}>
                    <span className='menu-icon'>
                      <i className={`ki-duotone ${t.icon} fs-2 ${activeTab === t.id ? 'text-primary' : 'text-gray-500'}`}><span className='path1'></span><span className='path2'></span></i>
                    </span>
                    <span className={`menu-title fw-bold fs-6 ${activeTab === t.id ? 'text-primary' : 'text-gray-700'}`}>{t.label}</span>
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Modal Content Area */}
          <div className='flex-grow-1 p-8 p-lg-12' style={{ minHeight: '500px', maxHeight: '70vh', overflowY: 'auto' }}>
            {manageError && <Alert variant='danger' dismissible onClose={() => setManageError(null)}>{manageError}</Alert>}
            {manageSuccess && <Alert variant='success' dismissible onClose={() => setManageSuccess(null)}>{manageSuccess}</Alert>}

            {/* TAB: Enrollment */}
            {activeTab === 'enrollment' && (
              <div>
                {currentUser?.institution_type === 'COACHING' ? (
                  // ── Coaching Mode Layout: Show list of current enrollments + Add form ──
                  <>
                    {/* List of current enrollments */}
                    {selectedStudent?.enrollments && selectedStudent.enrollments.length > 0 ? (
                      <div className='mb-8'>
                        <h5 className='fw-bold mb-4 text-gray-700'>Current Enrolled Courses / Batches</h5>
                        <div className='table-responsive border rounded bg-white'>
                          <table className='table align-middle table-row-dashed fs-7 gy-3 mb-0'>
                            <thead>
                              <tr className='text-start text-muted fw-bold fs-8 text-uppercase gs-0 bg-light'>
                                <th className='ps-4'>Course / Batch</th>
                                <th>Roll Number</th>
                                <th>Enrollment Date</th>
                                <th>Status</th>
                                <th className='text-end pe-4'>Actions</th>
                              </tr>
                            </thead>
                            <tbody className='fw-semibold text-gray-600'>
                              {selectedStudent.enrollments.map((enroll) => (
                                <tr key={enroll.id}>
                                  <td className='ps-4'>
                                    <span className='text-gray-800 fw-bold'>{enroll.class_section?.class?.name}</span>
                                    <div className='text-muted fs-8'>Section: {enroll.class_section?.section?.name}</div>
                                  </td>
                                  <td><span className='badge badge-light-dark fw-bold'>{enroll.roll_number}</span></td>
                                  <td>{enroll.enrollment_date ? new Date(enroll.enrollment_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}</td>
                                  <td>
                                    <span className={`badge badge-light-${enroll.status === 'Active' ? 'success' : enroll.status === 'Dropped' ? 'danger' : 'warning'}`}>
                                      {enroll.status}
                                    </span>
                                  </td>
                                  <td className='text-end pe-4'>
                                    {editingEnrollmentId === enroll.id ? (
                                      <span className='text-muted fs-8'>Editing below...</span>
                                    ) : (
                                      <button
                                        type='button'
                                        className='btn btn-xs btn-light-primary py-1 px-3 fw-bold'
                                        onClick={() => {
                                          setEditingEnrollmentId(enroll.id)
                                          setEditEnrollForm({
                                            roll_number: enroll.roll_number || '',
                                            class_section_id: String(enroll.class_section_id),
                                            status: enroll.status,
                                          })
                                          if (enroll.class_section?.class?.id) {
                                            loadSectionsForClass(String(enroll.class_section.class.id))
                                          }
                                        }}
                                      >
                                        Edit
                                      </button>
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    ) : (
                      <div className='alert alert-light-warning d-flex align-items-center p-5 mb-5'>
                        <i className='ki-duotone ki-information fs-2x text-warning me-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                        <div className='d-flex flex-column'>
                          <span className='fw-bold'>Not enrolled in any course/batch yet.</span>
                        </div>
                      </div>
                    )}

                    {/* Edit Form (if editing an enrollment) */}
                    {editingEnrollmentId && (
                      <form onSubmit={(e) => handleUpdateEnrollment(e, editingEnrollmentId)} className='border p-5 rounded-2 bg-light mb-8'>
                        <h5 className='fw-bold mb-4 text-gray-700'>
                          Edit Enrollment:{' '}
                          {selectedStudent?.enrollments?.find((e) => e.id === editingEnrollmentId)?.class_section?.class?.name}
                        </h5>
                        <div className='row g-5 mb-4'>
                          <div className='col-md-4 fv-row'>
                            <label className='fw-semibold fs-6 mb-2'>Roll Number</label>
                            <input
                              className='form-control form-control-solid'
                              placeholder='e.g. 15'
                              value={editEnrollForm.roll_number}
                              onChange={(e) => setEditEnrollForm((s) => ({ ...s, roll_number: e.target.value }))}
                            />
                          </div>
                          <div className='col-md-4 fv-row'>
                            <label className='fw-semibold fs-6 mb-2'>Section / Batch Group</label>
                            <select
                              className='form-select form-select-solid'
                              value={editEnrollForm.class_section_id}
                              onChange={(e) => setEditEnrollForm((s) => ({ ...s, class_section_id: e.target.value }))}
                            >
                              <option value=''>-- Keep Current --</option>
                              {classSections.map((cs) => (
                                <option key={cs.id} value={cs.id}>Section {cs.section?.name}</option>
                              ))}
                            </select>
                          </div>
                          <div className='col-md-4 fv-row'>
                            <label className='fw-semibold fs-6 mb-2'>Status</label>
                            <select
                              className='form-select form-select-solid'
                              value={editEnrollForm.status}
                              onChange={(e) =>
                                setEditEnrollForm((s) => ({ ...s, status: e.target.value as EnrollmentStatus }))
                              }
                            >
                              <option value='Active'>Active</option>
                              <option value='Promoted'>Promoted</option>
                              <option value='Dropped'>Dropped</option>
                              <option value='Transferred'>Transferred</option>
                            </select>
                          </div>
                        </div>
                        <div className='d-flex justify-content-end gap-3'>
                          <Button variant='light' size='sm' onClick={() => setEditingEnrollmentId(null)}>Cancel Edit</Button>
                          <Button variant='primary' size='sm' type='submit' disabled={manageSaving}>
                            {manageSaving ? 'Saving...' : 'Update'}
                          </Button>
                        </div>
                      </form>
                    )}

                    {/* New Enrollment Form */}
                    <form onSubmit={handleEnroll} className='border border-dashed p-6 rounded bg-light bg-opacity-50'>
                      <h5 className='fw-bold mb-4 text-primary'>
                        <i className='ki-duotone ki-plus-circle fs-4 me-2 text-primary'><span className='path1'></span><span className='path2'></span></i>
                        Enroll in a New Course / Batch
                      </h5>
                      <div className='row g-5 mb-5'>
                        <div className='col-md-6 fv-row'>
                          <label className='required fw-semibold fs-6 mb-2'>Session</label>
                          <select
                            className='form-select form-select-solid'
                            value={enrollForm.academic_session_id}
                            onChange={(e) => setEnrollForm((s) => ({ ...s, academic_session_id: e.target.value }))}
                            required
                          >
                            <option value=''>-- Select Session --</option>
                            {sessions.map((s) => (
                              <option key={s.id} value={s.id}>{s.session_year} {s.is_current ? '(Current)' : ''}</option>
                            ))}
                          </select>
                        </div>
                        <div className='col-md-6 fv-row'>
                          <label className='required fw-semibold fs-6 mb-2'>Course (Class)</label>
                          <select
                            className='form-select form-select-solid'
                            value={enrollForm.class_id}
                            onChange={(e) => handleClassChange(e.target.value)}
                            required
                          >
                            <option value=''>-- Select Course --</option>
                            {classes.map((c) => (
                              <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                          </select>
                        </div>
                        <div className='col-md-6 fv-row'>
                          <label className='required fw-semibold fs-6 mb-2'>Batch (Section)</label>
                          <select
                            className='form-select form-select-solid'
                            value={enrollForm.class_section_id}
                            onChange={(e) => setEnrollForm((s) => ({ ...s, class_section_id: e.target.value }))}
                            required
                            disabled={!enrollForm.class_id}
                          >
                            <option value=''>-- Select Batch --</option>
                            {classSections.map((cs) => (
                              <option key={cs.id} value={cs.id}>Section {cs.section?.name}</option>
                            ))}
                          </select>
                        </div>
                        <div className='col-md-6 fv-row'>
                          <label className='fw-semibold fs-6 mb-2'>Roll Number (Optional)</label>
                          <input
                            className='form-control form-control-solid'
                            placeholder='Auto-assigns if blank'
                            value={enrollForm.roll_number}
                            onChange={(e) => setEnrollForm((s) => ({ ...s, roll_number: e.target.value }))}
                          />
                        </div>
                        <div className='col-md-12 fv-row'>
                          <label className='required fw-semibold fs-6 mb-2'>Enrollment Date</label>
                          <input
                            type='date'
                            className='form-control form-control-solid'
                            value={enrollForm.enrollment_date}
                            onChange={(e) => setEnrollForm((s) => ({ ...s, enrollment_date: e.target.value }))}
                            required
                          />
                        </div>
                      </div>
                      <div className='text-end'>
                        <Button variant='success' type='submit' disabled={manageSaving}>
                          {manageSaving ? 'Enrolling...' : 'Enroll Student'}
                        </Button>
                      </div>
                    </form>
                  </>
                ) : existingEnrollment ? (
                  // ── Existing Enrollment (School/College Mode): show details + editable fields ──
                  <>
                    {/* Current info banner */}
                    <div className='d-flex align-items-center gap-4 p-5 rounded-2 bg-light-success border border-success border-opacity-25 mb-7'>
                      <i className='ki-duotone ki-check-circle fs-2x text-success'><span className='path1'></span><span className='path2'></span></i>
                      <div className='flex-grow-1'>
                        <div className='fw-bold text-gray-800 fs-5'>Already Enrolled</div>
                        <div className='text-muted fs-7'>
                          <span className='me-4'>
                            <i className='ki-duotone ki-book fs-6 me-1'><span className='path1'></span><span className='path2'></span></i>
                            {existingEnrollment.class_section?.class?.name} / {existingEnrollment.class_section?.section?.name || '—'}
                          </span>
                          <span className='me-4'>
                            <i className='ki-duotone ki-medal-star fs-6 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span></i>
                            Roll No: <strong>{existingEnrollment.roll_number || '—'}</strong>
                          </span>
                          <span className='me-4'>
                            <i className='ki-duotone ki-calendar fs-6 me-1'><span className='path1'></span><span className='path2'></span></i>
                            Session: {existingEnrollment.academic_session?.session_year || '—'}
                          </span>
                          <span className={`badge badge-light-${existingEnrollment.status === 'Active' ? 'success' : existingEnrollment.status === 'Dropped' ? 'danger' : 'warning'} ms-2`}>
                            {existingEnrollment.status}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Edit Form */}
                    <form onSubmit={handleUpdateEnrollment}>
                      <h5 className='fw-bold mb-5 text-gray-700'>Update Enrollment Details</h5>
                      <div className='row g-5 mb-6'>
                        <div className='col-md-4 fv-row'>
                          <label className='fw-semibold fs-6 mb-2'>Roll Number</label>
                          <input
                            className='form-control form-control-solid'
                            placeholder='e.g. 15'
                            value={editEnrollForm.roll_number}
                            onChange={e => setEditEnrollForm(s => ({ ...s, roll_number: e.target.value }))}
                          />
                          <div className='text-muted fs-8 mt-1'>Leave blank to keep current</div>
                        </div>
                        <div className='col-md-4 fv-row'>
                          <label className='fw-semibold fs-6 mb-2'>Section</label>
                          <select
                            className='form-select form-select-solid'
                            value={editEnrollForm.class_section_id}
                            onChange={e => setEditEnrollForm(s => ({ ...s, class_section_id: e.target.value }))}
                          >
                            <option value=''>-- Keep Current --</option>
                            {classSections.map(cs => (
                              <option key={cs.id} value={cs.id}>Section {cs.section?.name}</option>
                            ))}
                          </select>
                          <div className='text-muted fs-8 mt-1'>Only sections from same class</div>
                        </div>
                        <div className='col-md-4 fv-row'>
                          <label className='fw-semibold fs-6 mb-2'>Status</label>
                          <select
                            className='form-select form-select-solid'
                            value={editEnrollForm.status}
                            onChange={e => setEditEnrollForm(s => ({ ...s, status: e.target.value as EnrollmentStatus }))}
                          >
                            <option value='Active'>Active</option>
                            <option value='Promoted'>Promoted</option>
                            <option value='Dropped'>Dropped</option>
                            <option value='Transferred'>Transferred</option>
                          </select>
                        </div>
                      </div>
                      <div className='d-flex justify-content-between align-items-center pt-2'>
                        <div className='text-muted fs-8'>
                          <i className='ki-duotone ki-information fs-6 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                          Session cannot be changed after enrollment.
                        </div>
                        <Button variant='primary' type='submit' disabled={manageSaving}>
                          {manageSaving ? <><span className='spinner-border spinner-border-sm me-2'></span>Saving...</> : <><i className='ki-duotone ki-check fs-4 me-1'><span className='path1'></span><span className='path2'></span></i>Update Enrollment</>}
                        </Button>
                      </div>
                    </form>
                  </>
                ) : (
                  // ── New Enrollment Form ──
                  <form onSubmit={handleEnroll}>
                    <h4 className='fw-bold mb-5'>Enroll Student in Class</h4>
                    <div className='row g-5 mb-8'>
                      <div className='col-md-6 fv-row'>
                        <label className='required fw-semibold fs-6 mb-2'>Session</label>
                        <select className='form-select form-select-solid' value={enrollForm.academic_session_id} onChange={e => setEnrollForm(s => ({ ...s, academic_session_id: e.target.value }))} required>
                          <option value=''>-- Select Session --</option>
                          {sessions.map(s => <option key={s.id} value={s.id}>{s.session_year} {s.is_current ? '(Current)' : ''}</option>)}
                        </select>
                      </div>
                      <div className='col-md-6 fv-row'>
                        <label className='required fw-semibold fs-6 mb-2'>Class</label>
                        <select className='form-select form-select-solid' value={enrollForm.class_id} onChange={e => handleClassChange(e.target.value)} required>
                          <option value=''>-- Select Class --</option>
                          {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                      </div>
                      <div className='col-md-6 fv-row'>
                        <label className='required fw-semibold fs-6 mb-2'>Section</label>
                        <select className='form-select form-select-solid' value={enrollForm.class_section_id} onChange={e => setEnrollForm(s => ({ ...s, class_section_id: e.target.value }))} required disabled={!enrollForm.class_id}>
                          <option value=''>-- Select Section --</option>
                          {classSections.map(cs => <option key={cs.id} value={cs.id}>Section {cs.section?.name}</option>)}
                        </select>
                      </div>
                      <div className='col-md-6 fv-row'>
                        <label className='fw-semibold fs-6 mb-2'>Roll Number (Optional)</label>
                        <input className='form-control form-control-solid' placeholder='Auto-assigns if blank' value={enrollForm.roll_number} onChange={e => setEnrollForm(s => ({ ...s, roll_number: e.target.value }))} />
                      </div>
                      <div className='col-md-6 fv-row'>
                        <label className='required fw-semibold fs-6 mb-2'>Enrollment Date</label>
                        <input type='date' className='form-control form-control-solid' value={enrollForm.enrollment_date} onChange={e => setEnrollForm(s => ({ ...s, enrollment_date: e.target.value }))} required />
                      </div>
                    </div>
                    <div className='text-end'><Button variant='success' type='submit' disabled={manageSaving}>{manageSaving ? 'Enrolling...' : 'Save Enrollment'}</Button></div>
                  </form>
                )}
              </div>
            )}

            {/* TAB: Profile */}
            {activeTab === 'profile' && (
              <form onSubmit={handleSaveProfile}>
                <h4 className='fw-bold mb-5'>Personal Profile</h4>
                <div className='row g-5 mb-8'>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-2'>DOB</label><input type='date' className='form-control form-control-solid' value={profileForm.dob} onChange={e => setProfileForm(s => ({ ...s, dob: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='required fw-semibold fs-6 mb-2'>Gender</label><select className='form-select form-select-solid' value={profileForm.gender} onChange={e => setProfileForm(s => ({ ...s, gender: e.target.value }))}>{GENDERS.map(g => <option key={g} value={g}>{g.charAt(0).toUpperCase() + g.slice(1)}</option>)}</select></div>
                  <div className='col-md-4'><label className='required fw-semibold fs-6 mb-2'>Blood Group</label><select className='form-select form-select-solid' value={profileForm.blood_group} onChange={e => setProfileForm(s => ({ ...s, blood_group: e.target.value }))}>{BLOOD_GROUPS.map(b => <option key={b}>{b}</option>)}</select></div>
                  <div className='col-md-4'><label className='required fw-semibold fs-6 mb-2'>Nationality</label><input className='form-control form-control-solid' value={profileForm.nationality} onChange={e => setProfileForm(s => ({ ...s, nationality: e.target.value }))} required /></div>
                  <div className='col-md-4'><label className='required fw-semibold fs-6 mb-2'>Category</label><select className='form-select form-select-solid' value={profileForm.category} onChange={e => setProfileForm(s => ({ ...s, category: e.target.value }))}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></div>
                  <div className='col-md-12'><label className='fw-semibold fs-6 mb-2'>Profile Image</label><input type='file' className='form-control form-control-solid' accept='image/*' onChange={e => setProfileImageFile(e.target.files?.[0] || null)} /></div>
                </div>
                <div className='text-end'><Button variant='primary' type='submit' disabled={manageSaving}>{manageSaving ? 'Saving...' : 'Save Profile'}</Button></div>
              </form>
            )}

            {/* TAB: Parent */}
            {activeTab === 'parent' && (
              <form onSubmit={handleSaveParent}>
                <h4 className='fw-bold mb-5'>Parent Details</h4>
                <div className='row g-5 mb-8'>
                  <div className='col-md-4'><label className='required fw-semibold fs-6 mb-2'>Father Name</label><input className='form-control form-control-solid' value={parentForm.father_name} onChange={e => setParentForm(s => ({ ...s, father_name: e.target.value }))} required /></div>
                  <div className='col-md-4'><label className='required fw-semibold fs-6 mb-2'>Father Phone</label><input className='form-control form-control-solid' value={parentForm.father_phone} onChange={e => setParentForm(s => ({ ...s, father_phone: e.target.value }))} required /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-2'>Father Occupation</label><input className='form-control form-control-solid' value={parentForm.father_occupation} onChange={e => setParentForm(s => ({ ...s, father_occupation: e.target.value }))} /></div>
                  <div className='col-12'><hr className='text-muted my-2' /></div>
                  <div className='col-md-4'><label className='required fw-semibold fs-6 mb-2'>Mother Name</label><input className='form-control form-control-solid' value={parentForm.mother_name} onChange={e => setParentForm(s => ({ ...s, mother_name: e.target.value }))} required /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-2'>Mother Phone</label><input className='form-control form-control-solid' value={parentForm.mother_phone} onChange={e => setParentForm(s => ({ ...s, mother_phone: e.target.value }))} /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-2'>Mother Occupation</label><input className='form-control form-control-solid' value={parentForm.mother_occupation} onChange={e => setParentForm(s => ({ ...s, mother_occupation: e.target.value }))} /></div>
                </div>
                <div className='text-end'><Button variant='primary' type='submit' disabled={manageSaving}>{manageSaving ? 'Saving...' : 'Save Parent Details'}</Button></div>
              </form>
            )}

            {/* TAB: Address */}
            {activeTab === 'address' && (
              <form onSubmit={handleSaveAddress}>
                <h4 className='fw-bold mb-5'>Address Details</h4>
                <div className='row g-4 mb-8'>
                  <div className='col-md-8'><label className='fw-semibold fs-6 mb-2'>Current Street/Area</label><input className='form-control form-control-solid' value={addrForm.current_address} onChange={e => setAddrForm(s => ({ ...s, current_address: e.target.value }))} required /></div>
                  <div className='col-md-4'><label className='fw-semibold fs-6 mb-2'>Pincode</label><input className='form-control form-control-solid' value={addrForm.current_pincode} onChange={e => setAddrForm(s => ({ ...s, current_pincode: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-2'>City</label><input className='form-control form-control-solid' value={addrForm.current_city} onChange={e => setAddrForm(s => ({ ...s, current_city: e.target.value }))} required /></div>
                  <div className='col-md-6'><label className='fw-semibold fs-6 mb-2'>State</label><input className='form-control form-control-solid' value={addrForm.current_state} onChange={e => setAddrForm(s => ({ ...s, current_state: e.target.value }))} required /></div>
                  <div className='col-12'>
                    <div className='form-check form-switch form-check-custom mt-2'>
                      <input className='form-check-input' type='checkbox' checked={addrForm.is_same_as_current} onChange={e => setAddrForm(s => ({ ...s, is_same_as_current: e.target.checked }))} />
                      <label className='form-check-label ms-3'>Permanent address same as current address</label>
                    </div>
                  </div>
                  {!addrForm.is_same_as_current && (
                    <div className='row g-4 mt-1 p-0 m-0 w-100 border rounded bg-light'>
                      <div className='col-md-8'><label className='fw-semibold fs-6 mb-2'>Permanent Street/Area</label><input className='form-control form-control-solid' value={addrForm.permanent_address} onChange={e => setAddrForm(s => ({ ...s, permanent_address: e.target.value }))} required /></div>
                      <div className='col-md-4'><label className='fw-semibold fs-6 mb-2'>Pincode</label><input className='form-control form-control-solid' value={addrForm.permanent_pincode} onChange={e => setAddrForm(s => ({ ...s, permanent_pincode: e.target.value }))} required /></div>
                      <div className='col-md-6'><label className='fw-semibold fs-6 mb-2'>City</label><input className='form-control form-control-solid' value={addrForm.permanent_city} onChange={e => setAddrForm(s => ({ ...s, permanent_city: e.target.value }))} required /></div>
                      <div className='col-md-6 mb-4'><label className='fw-semibold fs-6 mb-2'>State</label><input className='form-control form-control-solid' value={addrForm.permanent_state} onChange={e => setAddrForm(s => ({ ...s, permanent_state: e.target.value }))} required /></div>
                    </div>
                  )}
                </div>
                <div className='text-end'><Button variant='primary' type='submit' disabled={manageSaving}>{manageSaving ? 'Saving...' : 'Save Address'}</Button></div>
              </form>
            )}

            {/* TAB: Documents */}
            {activeTab === 'documents' && (
              <div>
                <h4 className='fw-bold mb-2'>Student Documents</h4>
                <p className='text-muted fs-7 mb-6'>Upload official documents. Supported: PDF, JPG, PNG, DOC, DOCX.</p>

                {/* Upload Card */}
                <div className='card card-bordered mb-7' style={{ border: '1px solid #e4e6ef' }}>
                  <div className='card-body p-6'>
                    {/* Document Type Dropdown */}
                    <div className='mb-5'>
                      <label className='required fw-semibold fs-6 mb-2'>Document Type</label>
                      <select
                        className='form-select form-select-solid'
                        value={docType}
                        onChange={e => setDocType(e.target.value as DocumentType)}
                      >
                        <option value=''>-- Select Document Type --</option>
                        {DOCUMENT_TYPES.map(t => (
                          <option key={t} value={t}>{t.replace(/([A-Z])/g, ' $1').trim()}</option>
                        ))}
                      </select>
                    </div>

                    {/* Drag & Drop Area */}
                    <div
                      className={`rounded-2 text-center py-8 px-4 mb-5 position-relative ${docDragOver ? 'bg-light-primary border border-primary' : 'bg-light'}`}
                      style={{
                        border: `2px dashed ${docDragOver ? '#009ef7' : '#d1d3e0'}`,
                        cursor: 'pointer',
                        transition: 'all 0.2s ease'
                      }}
                      onDragOver={e => { e.preventDefault(); setDocDragOver(true) }}
                      onDragLeave={() => setDocDragOver(false)}
                      onDrop={e => {
                        e.preventDefault(); setDocDragOver(false)
                        const file = e.dataTransfer.files?.[0]
                        if (file) setDocFile(file)
                      }}
                      onClick={() => (document.getElementById('student-doc-file-input') as HTMLInputElement)?.click()}
                    >
                      <input
                        id='student-doc-file-input'
                        type='file'
                        accept='.pdf,.jpg,.jpeg,.png,.doc,.docx'
                        style={{ display: 'none' }}
                        onChange={e => setDocFile(e.target.files?.[0] || null)}
                      />
                      {docFile ? (
                        <div className='d-flex align-items-center justify-content-center gap-3'>
                          <div className='symbol symbol-45px'>
                            <div className='symbol-label bg-light-success'>
                              <i className='ki-duotone ki-file-up fs-2 text-success'><span className='path1'></span><span className='path2'></span></i>
                            </div>
                          </div>
                          <div className='text-start'>
                            <div className='fw-bold text-gray-800 fs-6'>{docFile.name}</div>
                            <div className='text-muted fs-8'>{(docFile.size / 1024).toFixed(1)} KB · Click to change file</div>
                          </div>
                          <button
                            type='button'
                            className='btn btn-icon btn-sm btn-light-danger ms-3'
                            onClick={e => { e.stopPropagation(); setDocFile(null) }}
                            title='Remove file'
                          >
                            <i className='ki-duotone ki-cross fs-3'><span className='path1'></span><span className='path2'></span></i>
                          </button>
                        </div>
                      ) : (
                        <div>
                          <i className='ki-duotone ki-file-up fs-3x text-gray-400 mb-3 d-block'><span className='path1'></span><span className='path2'></span></i>
                          <div className='fw-semibold text-gray-600 fs-6'>Drag & Drop file here, or <span className='text-primary'>click to browse</span></div>
                          <div className='text-muted fs-8 mt-1'>PDF, JPG, PNG, DOC, DOCX · Max 10MB</div>
                        </div>
                      )}
                    </div>

                    <div className='d-flex justify-content-end'>
                      <button
                        type='button'
                        className='btn btn-primary'
                        onClick={handleAddDocument}
                        disabled={docUploading || !docFile || !docType}
                      >
                        {docUploading
                          ? <><span className='spinner-border spinner-border-sm me-2'></span>Uploading...</>
                          : <><i className='ki-duotone ki-cloud-add fs-3 me-1'><span className='path1'></span><span className='path2'></span></i>Upload Document</>
                        }
                      </button>
                    </div>
                  </div>
                </div>

                {/* Documents List */}
                <div className='table-responsive'>
                  <table className='table table-row-dashed table-row-gray-200 align-middle fs-7 gy-4'>
                    <thead>
                      <tr className='text-muted fw-bold fs-8 text-uppercase border-bottom border-gray-100'>
                        <th className='ps-0 min-w-150px'>Document Type</th>
                        <th>File</th>
                        <th>Uploaded On</th>
                        <th>Verification</th>
                      </tr>
                    </thead>
                    <tbody>
                      {docs.length === 0 ? (
                        <tr>
                          <td colSpan={4} className='text-center py-10'>
                            <div className='d-flex flex-column align-items-center gap-2'>
                              <i className='ki-duotone ki-folder fs-3x text-gray-300'><span className='path1'></span><span className='path2'></span></i>
                              <div className='text-muted fs-7'>No documents uploaded yet.</div>
                            </div>
                          </td>
                        </tr>
                      ) : docs.map(d => (
                        <tr key={d.id}>
                          <td className='ps-0'>
                            <div className='d-flex align-items-center gap-2'>
                              <span className='symbol symbol-30px'>
                                <span className='symbol-label bg-light-primary'>
                                  <i className='ki-duotone ki-document fs-4 text-primary'><span className='path1'></span><span className='path2'></span></i>
                                </span>
                              </span>
                              <span className='fw-bold text-gray-800'>{d.document_type.replace(/([A-Z])/g, ' $1').trim()}</span>
                            </div>
                          </td>
                          <td>
                            <a href={d.file_path} target='_blank' rel='noreferrer' className='btn btn-sm btn-light-primary py-1 px-3'>
                              <i className='ki-duotone ki-eye fs-6 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                              View
                            </a>
                          </td>
                          <td className='text-muted'>
                            {d.createdAt ? new Date(d.createdAt).toLocaleDateString('en-IN') : '—'}
                          </td>
                          <td>
                            <span className={`badge badge-light-${d.verification_status === 'Verified' ? 'success' : d.verification_status === 'Rejected' ? 'danger' : 'warning'} fw-semibold`}>
                              {d.verification_status === 'Verified' && <i className='ki-duotone ki-check fs-7 me-1'></i>}
                              {d.verification_status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

          </div>
        </div>
      </Modal>

      {schoolId && (
        <BulkAdmissionModal 
          show={showBulkModal} 
          onHide={() => setShowBulkModal(false)}
          onSuccess={fetchStudents}
          schoolId={String(schoolId)}
          sessions={sessions}
          classes={classes}
        />
      )}
    </>
  )
}

const AdmissionWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[]}>All Students</PageTitle>
    <AdmissionPage />
  </>
)

export { AdmissionWrapper }
