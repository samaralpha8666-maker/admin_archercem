import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { StudentModel, TransferCertificateModel, NoDuesStatus } from './core/_models'
import { ClassModel, SectionModel, SessionModel } from '../academic/core/_models'
import { StudentSelector } from './components/StudentSelector'
import { NoDuesChecklist } from './components/NoDuesChecklist'
import { TcDetailsForm } from './components/TcDetailsForm'
import { TcPreview } from './components/TcPreview'
import { IssuedCertificatesTab } from './components/IssuedCertificatesTab'
import { useAuth } from '../auth'

// APIs
import {
  getEnrollments,
  getTransferCertificates,
  issueTransferCertificate,
  revokeTransferCertificate,
  downloadTransferCertificatePdf,
} from './core/_requests'
import {
  getAcademicSessions,
  getClasses,
  getClassSections,
  getClassSubjects,
} from '../academic/core/_requests'

const INITIAL_DUES = (dept: NoDuesStatus['department'], cleared = false): NoDuesStatus => ({
  department: dept,
  cleared,
})

interface TcFormData {
  serial_number: string
  issue_date: string
  total_working_days: number
  days_present: number
  conduct: string
  reason_for_leaving: string
  promotion_eligible: 'Yes' | 'No' | 'Refer to Marksheet'
  class_studied: string
  subjects_studied: string
  remarks: string
}

const DEFAULT_FORM_DATA: TcFormData = {
  serial_number: '',
  issue_date: new Date().toISOString().substring(0, 10),
  total_working_days: 220,
  days_present: 200,
  conduct: 'Very Good',
  reason_for_leaving: 'Admitted to Higher Secondary Board Institution',
  promotion_eligible: 'Yes',
  class_studied: '',
  subjects_studied: 'English, Hindi, Mathematics, General Science, Social Sciences',
  remarks: '',
}

const TransferCertificatePage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [activeTab, setActiveTab] = useState<'issue' | 'archive'>('issue')

  // Unified Filter States (Session -> Class -> Section)
  const [sessions, setSessions] = useState<SessionModel[]>([])
  const [filterSession, setFilterSession] = useState<string>('')

  const [classes, setClasses] = useState<ClassModel[]>([])
  const [filterClass, setFilterClass] = useState<string>('')

  const [sections, setSections] = useState<SectionModel[]>([])
  const [filterSection, setFilterSection] = useState<string>('')

  // Roster lists
  const [students, setStudents] = useState<StudentModel[]>([])
  const [certificates, setCertificates] = useState<TransferCertificateModel[]>([])

  // Exiting Student States
  const [selectedStudent, setSelectedStudent] = useState<StudentModel | null>(null)
  const [noDues, setNoDues] = useState<NoDuesStatus[]>([
    INITIAL_DUES('Finance'),
    INITIAL_DUES('Library'),
    INITIAL_DUES('Hostel'),
    INITIAL_DUES('SportsLab'),
  ])

  // Form Details
  const [formData, setFormData] = useState<TcFormData>(DEFAULT_FORM_DATA)
  const [isFormValid, setIsFormValid] = useState(false)
  const [verificationHash, setVerificationHash] = useState('')
  const [isLocked, setIsLocked] = useState(false)
  const [activeTcId, setActiveTcId] = useState<number | null>(null)

  // Search & Loading
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [loadingStudents, setLoadingStudents] = useState(false)
  const [apiNotice, setApiNotice] = useState<string | null>(null)

  // Search debounce
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 400)
    return () => clearTimeout(t)
  }, [search])

  // ─── 1. Load Academic Metadata (Sessions, Classes) on Mount ───────────────────
  useEffect(() => {
    if (!schoolId) return

    // Load Sessions
    getAcademicSessions(schoolId, 1, 100)
      .then((res) => {
        if (res.data.success) {
          const loaded = res.data.data.sessions || []
          setSessions(loaded)
          // Default to the current active session
          const current = loaded.find((s) => s.is_current)
          if (current) {
            setFilterSession(String(current.id))
          } else if (loaded.length > 0) {
            setFilterSession(String(loaded[0].id))
          }
        }
      })
      .catch(() => {})

    // Load Classes
    getClasses(schoolId, 1, 100)
      .then((res) => {
        if (res.data.success) {
          setClasses(res.data.data.classes || [])
        }
      })
      .catch(() => {})

    // Load TC Archives from Database
    getTransferCertificates(schoolId)
      .then((res) => {
        if (res.data.success) {
          setCertificates(res.data.data.certificates || [])
        }
      })
      .catch(() => {
        // Fallback backup storage
        const local = localStorage.getItem(`apnacampus_tc_${schoolId}`)
        if (local) {
          setCertificates(JSON.parse(local))
        }
      })
  }, [schoolId])

  // ─── 2. Handle Class selector (fetches sections and resets section/student) ──
  const handleClassFilterChange = async (classId: string) => {
    setFilterClass(classId)
    setFilterSection('')
    setSections([])
    setSelectedStudent(null)
    setIsLocked(false)

    if (!classId) return
    try {
      const res = await getClassSections(schoolId, classId)
      if (res.data.success) {
        setSections(
          res.data.data.sections?.map((s: any) => s.section).filter(Boolean) || []
        )
      }
    } catch {}
  }

  // ─── 3. Load Roster Session-wise & Class Section-wise dynamically ───────────
  const fetchSessionRoster = useCallback(async () => {
    if (!schoolId || !filterSession) return
    setLoadingStudents(true)
    setApiNotice(null)

    try {
      const params: any = {
        session_id: Number(filterSession),
        page: 1,
        limit: 100,
        status: 'Active',
      }

      if (debouncedSearch) params.search = debouncedSearch
      if (filterClass) params.class_id = Number(filterClass)
      if (filterSection) params.class_section_id = Number(filterSection)

      const res = await getEnrollments(schoolId, params)
      if (res.data.success) {
        const enrollmentsList = res.data.data.enrollments || []
        
        // Map the enrolled roster into StudentModel list
        const loadedStudents = enrollmentsList
          .map((env: any) => {
            if (!env.student) return null
            return {
              ...env.student,
              enrollments: [env], // Embed class/section context
            }
          })
          .filter(Boolean) as StudentModel[]

        // Filter locally by class in case backend class section mapping details are complex
        const classFiltered = filterClass && !filterSection
          ? loadedStudents.filter((s) => {
              const active = s.enrollments?.find((e) => e.status === 'Active')
              return active?.class_section?.class?.id === Number(filterClass)
            })
          : loadedStudents

        setStudents(classFiltered)
      }
    } catch (err) {
      setStudents([])
    } finally {
      setLoadingStudents(false)
    }
  }, [schoolId, filterSession, filterClass, filterSection, debouncedSearch])

  useEffect(() => {
    fetchSessionRoster()
  }, [fetchSessionRoster])

  // ─── 4. Auto-Generate TC Draft details when Selected Student changes ────────
  useEffect(() => {
    if (!selectedStudent) return

    // Don't auto-increment serial if reprint lock is active
    if (isLocked) return

    const year = new Date().getFullYear()
    const nextSerial = certificates.length + 1
    const padded = String(nextSerial).padStart(4, '0')

    const schoolNameWords = currentUser?.school_name
      ? currentUser.school_name.split(' ').filter(Boolean)
      : []
    let prefix = 'APNA'
    if (schoolNameWords.length > 0) {
      prefix = schoolNameWords
        .map((w: string) => w[0])
        .join('')
        .replace(/[^A-Za-z]/g, '')
        .toUpperCase()
      if (prefix.length < 2) {
        prefix = schoolNameWords[0].substring(0, 4).toUpperCase()
      }
    }

    const proposedSerial = `${year}/${prefix}/TC-${padded}`

    const activeEnrollment = selectedStudent.enrollments?.find(
      (e) => e.status === 'Active' || e.status === 'Transferred'
    )
    const classLabel = activeEnrollment?.class_section?.class?.name
      ? `Class ${activeEnrollment.class_section.class.name} - Section ${activeEnrollment.class_section.section?.name || ''}`
      : ''

    const initialFormData = {
      ...DEFAULT_FORM_DATA,
      serial_number: proposedSerial,
      class_studied: classLabel,
    }

    setFormData(initialFormData)

    // Fetch subjects dynamically based on student's active class ID
    const classId = activeEnrollment?.class_section?.class?.id
    if (classId) {
      getClassSubjects(schoolId, classId)
        .then((res) => {
          if (res.data.success && res.data.data.subjects) {
            const subjectNames = res.data.data.subjects
              .map((s: any) => s.subject?.name)
              .filter(Boolean)
              .join(', ')
            
            if (subjectNames) {
              setFormData((prev) => ({
                ...prev,
                subjects_studied: subjectNames,
              }))
            }
          }
        })
        .catch(() => {})
    }

    // Simulated Verification Hash
    const hash = Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2)
    setVerificationHash(hash)

    // Reset Checklist
    setNoDues([
      INITIAL_DUES('Finance', false),
      INITIAL_DUES('Library', false),
      INITIAL_DUES('Hostel', false),
      INITIAL_DUES('SportsLab', false),
    ])
    setIsLocked(false)
    setApiNotice(null)
  }, [selectedStudent, certificates.length, schoolId, currentUser?.school_name])

  const handleSelectStudent = (student: StudentModel) => {
    setSelectedStudent(student)
    setIsLocked(false)
    setActiveTcId(null)
  }

  // Clearances checked validation
  const areAllDuesCleared = noDues.every((d) => d.cleared)
  const canIssue = areAllDuesCleared && isFormValid

  // ─── 5. Issue Transfer Certificate API ──────────────────────────────────────
  const handleIssueTC = async () => {
    if (!selectedStudent || !canIssue) return

    try {
      const res = await issueTransferCertificate(schoolId, selectedStudent.id, {
        status: 'Issued',
        academic_session_id: Number(filterSession),
        class_studied: formData.class_studied,
        subjects_studied: formData.subjects_studied,
        promotion_eligible: formData.promotion_eligible,
        reason_for_leaving: formData.reason_for_leaving,
        conduct: formData.conduct,
        total_working_days: formData.total_working_days,
        days_present: formData.days_present,
        no_dues_clearances: noDues,
        issue_date: formData.issue_date,
        remarks: formData.remarks,
      })
      
      if (res.data.success) {
        const issuedTc = res.data.data
        
        // Sync generated serial and hash
        setFormData((prev) => ({
          ...prev,
          serial_number: issuedTc.serial_number,
        }))
        setVerificationHash(issuedTc.verification_hash)
        setActiveTcId(issuedTc.id)

        const updatedList = [issuedTc, ...certificates]
        setCertificates(updatedList)
        localStorage.setItem(`apnacampus_tc_${schoolId}`, JSON.stringify(updatedList))
      }
    } catch (err: any) {
      // Local sync fallback (for offline robustness)
      const mockPayload: TransferCertificateModel = {
        id: Date.now(),
        student_id: selectedStudent.id,
        academic_session_id: Number(filterSession),
        serial_number: formData.serial_number,
        issue_date: formData.issue_date,
        status: 'Issued',
        total_working_days: formData.total_working_days,
        days_present: formData.days_present,
        conduct: formData.conduct,
        reason_for_leaving: formData.reason_for_leaving,
        promotion_eligible: formData.promotion_eligible,
        class_studied: formData.class_studied,
        subjects_studied: formData.subjects_studied,
        remarks: formData.remarks,
        issued_by: currentUser?.first_name
          ? `${currentUser.first_name} ${currentUser.last_name || ''}`.trim()
          : 'System Admin',
        no_dues_clearances: noDues,
        verification_hash: verificationHash,
      }
      const updatedList = [mockPayload, ...certificates]
      setCertificates(updatedList)
      localStorage.setItem(`apnacampus_tc_${schoolId}`, JSON.stringify(updatedList))
      setApiNotice(
        'Clearance & TC saved in Roster (Server TC integration sync pending migration)'
      )
    }

    setIsLocked(true)

    // Transition local student state to Transferred
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === selectedStudent.id) {
          return {
            ...s,
            enrollments: s.enrollments?.map((e) =>
              e.status === 'Active' ? { ...e, status: 'Transferred' as const } : e
            ),
          }
        }
        return s
      })
    )
  }

  // ─── 6. Reprint Trigger ─────────────────────────────────────────────────────
  const handleSelectReprint = (tc: TransferCertificateModel) => {
    const student = students.find((s) => s.id === tc.student_id) || {
      id: tc.student_id,
      first_name: 'Exited',
      last_name: 'Student',
      email: 'exited@apnacampus.com',
      mobile_number: '',
      is_profile_complete: true,
      is_active: false,
    }
    
    setSelectedStudent(student)
    setFormData({
      serial_number: tc.serial_number,
      issue_date: tc.issue_date,
      total_working_days: tc.total_working_days,
      days_present: tc.days_present,
      conduct: tc.conduct,
      reason_for_leaving: tc.reason_for_leaving,
      promotion_eligible: tc.promotion_eligible,
      class_studied: tc.class_studied,
      subjects_studied: tc.subjects_studied,
      remarks: tc.remarks || '',
    })
    setVerificationHash(tc.verification_hash)
    setNoDues(tc.no_dues_clearances)
    setIsLocked(true)
    setActiveTcId(tc.id)
    setActiveTab('issue')
    setApiNotice('Reprint Lock Active: Certificate details are in read-only audit mode')
  }

  // ─── 7. Revoke Transfer Certificate API ─────────────────────────────────────
  const handleRevokeTc = async (tcId: number, reason: string, actor: string) => {
    try {
      await revokeTransferCertificate(schoolId, tcId, { reason })
      
      const updatedList = certificates.map((c) => {
        if (c.id === tcId) {
          return {
            ...c,
            status: 'Revoked' as const,
            revoke_reason: reason,
            revoked_by: actor,
            revoked_at: new Date().toISOString(),
          }
        }
        return c
      })
      setCertificates(updatedList)
      localStorage.setItem(`apnacampus_tc_${schoolId}`, JSON.stringify(updatedList))
    } catch (err) {
      // Local fallback
      const updatedList = certificates.map((c) => {
        if (c.id === tcId) {
          return {
            ...c,
            status: 'Revoked' as const,
            revoke_reason: reason,
            revoked_by: actor,
            revoked_at: new Date().toISOString(),
          }
        }
        return c
      })
      setCertificates(updatedList)
      localStorage.setItem(`apnacampus_tc_${schoolId}`, JSON.stringify(updatedList))
      setApiNotice('Certificate Revoked locally (Server DB sync pending migration)')
    }

    // Reinstate student back to active
    const target = certificates.find((c) => c.id === tcId)
    if (target) {
      setStudents((prev) =>
        prev.map((s) => {
          if (s.id === target.student_id) {
            return {
              ...s,
              enrollments: s.enrollments?.map((e) =>
                e.status === 'Transferred' ? { ...e, status: 'Active' as const } : e
              ),
            }
          }
          return s
        })
      )
    }
  }

  // Reset all filters to default
  const handleDownloadPdf = async (theme: string) => {
    if (!activeTcId || !selectedStudent) return
    const studentName = `${selectedStudent.first_name} ${selectedStudent.last_name || ''}`.trim()
    await downloadTransferCertificatePdf(schoolId, activeTcId, studentName, theme)
  }

  const handleArchiveDownloadPdf = async (tcId: number, studentName: string) => {
    await downloadTransferCertificatePdf(schoolId, tcId, studentName, 'gold')
  }

  const handleResetFilters = () => {
    const current = sessions.find((s) => s.is_current)
    setFilterSession(current ? String(current.id) : '')
    setFilterClass('')
    setFilterSection('')
    setSearch('')
    setSelectedStudent(null)
    setIsLocked(false)
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* Navigation Tabs (Hidden in Print) */}
        <div className='d-flex align-items-center justify-content-between mb-6 d-print-none'>
          <ul className='nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bold'>
            <li className='nav-item'>
              <button
                className={`nav-link text-active-primary py-2 me-6 ${
                  activeTab === 'issue' ? 'active' : ''
                }`}
                style={{ background: 'none', border: 'none' }}
                onClick={() => {
                  setActiveTab('issue')
                  setApiNotice(null)
                }}
              >
                <i className='ki-duotone ki-user-edit fs-4 me-2'>
                  <span className='path1'></span>
                  <span className='path2'></span>
                  <span className='path3'></span>
                </i>
                Issue Transfer Certificate
              </button>
            </li>
            <li className='nav-item'>
              <button
                className={`nav-link text-active-primary py-2 me-6 ${
                  activeTab === 'archive' ? 'active' : ''
                }`}
                style={{ background: 'none', border: 'none' }}
                onClick={() => {
                  setActiveTab('archive')
                  setSelectedStudent(null)
                  setApiNotice(null)
                }}
              >
                <i className='ki-duotone ki-archive fs-4 me-2'>
                  <span className='path1'></span>
                  <span className='path2'></span>
                  <span className='path3'></span>
                </i>
                Issued TC Archives
              </button>
            </li>
          </ul>
        </div>

        {/* Global Offline Sync Banner */}
        {apiNotice && (
          <div className='alert alert-info py-3 px-4 mb-5 d-flex align-items-center d-print-none border-start border-info border-3 bg-light-info'>
            <i className='ki-duotone ki-information-2 text-info fs-4 me-2'>
              <span className='path1'></span>
              <span className='path2'></span>
              <span className='path3'></span>
            </i>
            <span className='fs-8 fw-semibold text-info-emphasis'>{apiNotice}</span>
          </div>
        )}

        {activeTab === 'issue' && (
          /* ─── Unified Roster Filter Bar (Matches EnrollmentPage look-and-feel 100%) ─── */
          <div className='card card-flush border border-gray-200 mb-6 d-print-none shadow-sm'>
            <div className='card-body py-4'>
              <div className='row g-4 align-items-end'>
                {/* 1. Academic Session */}
                <div className='col-md-3'>
                  <label className='fw-semibold fs-7 mb-1 text-gray-700'>Academic Session</label>
                  <select
                    className='form-select form-select-solid form-select-sm fw-bold text-primary'
                    value={filterSession}
                    onChange={(e) => {
                      setFilterSession(e.target.value)
                      setSelectedStudent(null)
                      setIsLocked(false)
                    }}
                  >
                    <option value=''>All Sessions</option>
                    {sessions.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.session_year} {s.is_current ? '★ (Current)' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Class Selector */}
                <div className='col-md-3'>
                  <label className='fw-semibold fs-7 mb-1 text-gray-700'>Class</label>
                  <select
                    className='form-select form-select-solid form-select-sm'
                    value={filterClass}
                    onChange={(e) => handleClassFilterChange(e.target.value)}
                  >
                    <option value=''>All Classes</option>
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 3. Section Selector */}
                <div className='col-md-3'>
                  <label className='fw-semibold fs-7 mb-1 text-gray-700'>Section</label>
                  <select
                    className='form-select form-select-solid form-select-sm'
                    value={filterSection}
                    onChange={(e) => {
                      setFilterSection(e.target.value)
                      setSelectedStudent(null)
                      setIsLocked(false)
                    }}
                    disabled={!filterClass}
                  >
                    <option value=''>All Sections</option>
                    {sections.map((s) => (
                      <option key={s.id} value={s.id}>
                        Section {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 4. Reset Button */}
                <div className='col-md-3'>
                  <button className='btn btn-light-primary btn-sm w-100 fw-bold' onClick={handleResetFilters}>
                    <i className='ki-duotone ki-arrows-loop fs-4 me-1'>
                      <span className='path1'></span>
                      <span className='path2'></span>
                    </i>
                    Reset Filters
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'issue' ? (
          <div className='row g-6'>
            {/* ── Left Column: Student Selector Sidebar ── */}
            <div className='col-lg-3 col-md-4 d-print-none'>
              <StudentSelector
                students={students}
                selectedStudent={selectedStudent}
                onSelect={handleSelectStudent}
                loading={loadingStudents}
                search={search}
                setSearch={setSearch}
              />
            </div>

            {/* ── Right Column: Form, clearances, preview ── */}
            <div className='col-lg-9 col-md-8'>
              {!selectedStudent ? (
                <div className='card card-flush h-400px d-print-none border border-gray-200 shadow-sm'>
                  <div className='card-body d-flex align-items-center justify-content-center flex-column'>
                    <i className='ki-duotone ki-user-edit fs-5x text-gray-200 mb-4'>
                      <span className='path1'></span>
                      <span className='path2'></span>
                      <span className='path3'></span>
                    </i>
                    <p className='text-gray-500 fw-semibold fs-5 m-0'>
                      Select an enrolled student in the active session to begin clearance
                    </p>
                  </div>
                </div>
              ) : (
                <div className='d-flex flex-column gap-6'>
                  {/* Step 1: Clearance Checker (Hidden in print) */}
                  <div className='d-print-none'>
                    <NoDuesChecklist noDues={noDues} onChange={setNoDues} />
                  </div>

                  {/* Split Layout: Form details left, visual Preview right */}
                  <div className='row g-6'>
                    {/* Left Form Details (Hidden in print) */}
                    <div className='col-xl-5 d-print-none'>
                      <TcDetailsForm
                        student={selectedStudent}
                        formData={formData}
                        onChange={(data, isValid) => {
                          setFormData(data)
                          setIsFormValid(isValid)
                        }}
                      />
                    </div>

                    {/* Right Certificate Preview (Visible in print) */}
                    <div className='col-xl-7 col-12'>
                      <TcPreview
                        student={selectedStudent}
                        formData={formData}
                        verificationHash={verificationHash}
                        isLocked={isLocked}
                        onIssue={handleIssueTC}
                        canIssue={canIssue}
                        onDownloadPdf={handleDownloadPdf}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className='d-print-none'>
            <IssuedCertificatesTab
              certificates={certificates}
              students={students}
              sessions={sessions}
              classes={classes}
              onSelectReprint={handleSelectReprint}
              onRevokeTc={handleRevokeTc}
              onDownloadPdf={handleArchiveDownloadPdf}
            />
          </div>
        )}
      </Content>
    </>
  )
}

const TransferCertificateWrapper: FC = () => (
  <>
    <PageTitle
      breadcrumbs={[
        { title: 'Students', path: '/students/admission', isActive: false },
        { title: 'Transfer Certificate', path: '/students/transfer-certificate', isActive: true },
      ]}
    >
      Manage Student Exit & Transfer Certificate (TC)
    </PageTitle>
    <TransferCertificatePage />
  </>
)

export default TransferCertificateWrapper
