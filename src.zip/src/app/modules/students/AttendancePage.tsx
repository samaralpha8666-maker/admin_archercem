import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import { getAcademicSessions, getClasses, getClassSections } from '../academic/core/_requests'
import { SessionModel, ClassModel, ClassSectionMappingModel } from '../academic/core/_models'
import { getStudentAttendance, adminMarkStudentAttendance, adminMarkStudentPeriodAttendance } from '../attendance/core/_requests'
import { StudentAttendanceRecord } from '../attendance/core/_models'
import { getTimetableGrid } from '../timetable/core/_requests'
import { TimetableEntry } from '../timetable/core/_models'
import { toast } from 'react-toastify'

const AttendancePage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // Filter state
  const [sessions, setSessions] = useState<SessionModel[]>([])
  const [classes, setClasses] = useState<ClassModel[]>([])
  const [classSections, setClassSections] = useState<ClassSectionMappingModel[]>([])

  const [filterSession, setFilterSession] = useState('')
  const [filterClass, setFilterClass] = useState('')
  const [filterSection, setFilterSection] = useState('')
  const [filterDate, setFilterDate] = useState(new Date().toISOString().split('T')[0])
  const [filterPeriod, setFilterPeriod] = useState('')
  const [search, setSearch] = useState('')

  // Period state
  const [periods, setPeriods] = useState<TimetableEntry[]>([])
  const [loadingPeriods, setLoadingPeriods] = useState(false)

  // Data state
  const [attendances, setAttendances] = useState<StudentAttendanceRecord[]>([])
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [showSuccessModal, setShowSuccessModal] = useState(false)

  // Status tracking (local modifications before save)
  const [attendanceEdits, setAttendanceEdits] = useState<Record<number, { status: string; remark: string }>>({})

  // Load Filters Data
  const loadMeta = useCallback(async () => {
    if (!schoolId) return
    try {
      const [sRes, cRes] = await Promise.all([
        getAcademicSessions(schoolId, 1, 100),
        getClasses(schoolId, 1, 100),
      ])
      if (sRes.data.success) {
        setSessions(sRes.data.data.sessions || [])
        const current = sRes.data.data.sessions?.find(s => s.is_current)
        if (current) setFilterSession(current.id.toString())
      }
      if (cRes.data.success) setClasses(cRes.data.data.classes || [])
    } catch { }
  }, [schoolId])

  useEffect(() => { loadMeta() }, [loadMeta])

  const handleClassFilter = async (classId: string) => {
    setFilterClass(classId)
    setFilterSection('')
    setClassSections([])
    if (!classId) return
    try {
      const { data } = await getClassSections(schoolId, classId)
      if (data.success) setClassSections(data.data.sections || [])
    } catch { }
  }

  // Fetch Periods if mode is PERIOD_WISE
  useEffect(() => {
    const fetchPeriods = async () => {
      const sessionObj = sessions.find(s => s.id.toString() === filterSession)
      if (!sessionObj || sessionObj.attendance_mode !== 'PERIOD' || !filterSection || !filterDate) {
        setPeriods([])
        setFilterPeriod('')
        return
      }
      setLoadingPeriods(true)
      try {
        const { data } = await getTimetableGrid(schoolId, Number(filterSection), Number(filterSession))
        if (data.success && data.data) {
          const dateObj = new Date(filterDate)
          const dayOfWeek = dateObj.toLocaleDateString('en-US', { weekday: 'long' }).toUpperCase()
          const dayPeriods = (data.data as any)[dayOfWeek] || []
          setPeriods(dayPeriods.sort((a: any, b: any) => a.start_time.localeCompare(b.start_time)))
        }
      } catch (err) {
        setPeriods([])
      } finally {
        setLoadingPeriods(false)
      }
    }
    // Only clear selected period if Section or Date fundamentally changes
    setFilterPeriod('')
    fetchPeriods()
  }, [filterSession, filterSection, filterDate, sessions, schoolId])

  // Fetch Attendance
  const fetchAttendance = async () => {
    const sessionObj = sessions.find(s => s.id.toString() === filterSession)
    const isPeriodWise = sessionObj?.attendance_mode === 'PERIOD'

    if (!schoolId || !filterSection || !filterDate || (isPeriodWise && !filterPeriod)) {
      toast.warning(isPeriodWise ? 'Please select Class, Section, Date and Period' : 'Please select Class, Section and Date')
      return
    }
    setLoading(true)
    try {
      const { data } = await getStudentAttendance(schoolId, filterSection, filterDate, isPeriodWise ? filterPeriod : undefined)
      if (data.success) {
        setAttendances(data.data.attendances || [])
        // Reset edits
        const edits: Record<number, { status: string; remark: string }> = {}
        data.data.attendances.forEach(a => {
          edits[a.student_id] = {
            status: a.status || 'NOT_MARKED', // Match teacher behavior by defaulting to NOT_MARKED
            remark: a.remark || ''
          }
        })
        setAttendanceEdits(edits)
      }
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to fetch attendance')
    } finally {
      setLoading(false)
    }
  }

  const saveAttendance = async () => {
    const sessionObj = sessions.find(s => s.id.toString() === filterSession)
    const isPeriodWise = sessionObj?.attendance_mode === 'PERIOD'

    if (!schoolId || !filterSection || !filterDate || !filterSession || (isPeriodWise && !filterPeriod)) {
      toast.warning('Please select all required fields before saving.')
      return
    }
    setSaving(true)
    try {
      const payload = {
        class_section_id: Number(filterSection),
        academic_session_id: Number(filterSession),
        date: filterDate,
        students: Object.keys(attendanceEdits)
          .filter(studentId => attendanceEdits[Number(studentId)].status !== 'NOT_MARKED')
          .map(studentId => {
            const record = attendanceEdits[Number(studentId)];
            return {
              student_id: Number(studentId),
              status: record.status,
              ...(record.remark?.trim() ? { remark: record.remark.trim() } : {})
            };
        })
      }

      if (payload.students.length === 0) {
        toast.warning('No attendance marked to save.')
        setSaving(false)
        return
      }

      // Add a log for debugging
      console.log("Sending mark attendance payload:", payload);

      let responseData;
      if (isPeriodWise) {
        const { data } = await adminMarkStudentPeriodAttendance(schoolId, { ...payload, timetable_entry_id: Number(filterPeriod) })
        responseData = data;
      } else {
        const { data } = await adminMarkStudentAttendance(schoolId, payload)
        responseData = data;
      }

      if (responseData.success) {
        setShowSuccessModal(true)
        fetchAttendance()
      }
    } catch (error: any) {
      console.error("Attendance Mark API Error:", error.response?.data || error);
      const msg = error.response?.data?.message || error.response?.data?.error || 'Failed to save attendance';
      toast.error(Array.isArray(msg) ? msg.join(', ') : String(msg));
    } finally {
      setSaving(false)
    }
  }

  const exportToExcel = () => {
    if (filteredAttendances.length === 0) return

    const selectedClassObj = classes.find(c => c.id.toString() === filterClass)
    const selectedSectionObj = classSections.find(cs => cs.id.toString() === filterSection)
    const className = selectedClassObj?.name || 'Class'
    const sectionName = selectedSectionObj?.section?.name || 'Section'

    // CSV Headers
    const headers = ['S.No.', 'Roll Number', 'Student Name', 'Mobile Number', 'Attendance Status', 'Remark']
    
    // CSV Rows
    const rows = filteredAttendances.map((a, idx) => [
      idx + 1,
      a.roll_number || '—',
      `${a.first_name} ${a.last_name}`,
      a.mobile_number || '—',
      attendanceEdits[a.student_id]?.status || 'NOT_MARKED',
      attendanceEdits[a.student_id]?.remark || '—'
    ])

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    ].join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    const url = URL.createObjectURL(blob)
    
    link.setAttribute('href', url)
    link.setAttribute('download', `Attendance_Sheet_${className}_${sectionName}_${filterDate}.csv`)
    link.style.visibility = 'hidden'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    toast.success('Excel (CSV) sheet exported successfully!')
  }

  const exportToPdf = () => {
    if (filteredAttendances.length === 0) return

    const selectedClassObj = classes.find(c => c.id.toString() === filterClass)
    const selectedSectionObj = classSections.find(cs => cs.id.toString() === filterSection)
    const className = selectedClassObj?.name || 'Class'
    const sectionName = selectedSectionObj?.section?.name || 'Section'

    const printWindow = window.open('', '_blank')
    if (!printWindow) {
      toast.error('Popup blocker is active. Please allow popups to download PDF.')
      return
    }

    const htmlContent = `
      <html>
        <head>
          <title>Attendance Sheet - ${className} ${sectionName} - ${filterDate}</title>
          <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
          <style>
            body { font-family: 'Inter', sans-serif; padding: 40px; color: #2B2B2F; }
            .header-container { border-bottom: 2px solid #E4E6EF; padding-bottom: 25px; margin-bottom: 30px; }
            .school-title { font-size: 24px; font-weight: 800; color: #181C32; }
            .sheet-title { font-size: 16px; font-weight: 600; color: #7E8299; margin-top: 5px; }
            .meta-info { font-size: 13px; color: #4B5675; margin-top: 15px; }
            .meta-info span { font-weight: 700; color: #181C32; margin-right: 20px; }
            .table th { background-color: #F9F9F9; color: #4B5675; font-weight: 700; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #E4E6EF; padding: 12px 10px; }
            .table td { padding: 12px 10px; font-size: 13px; border-bottom: 1px solid #F1F1F4; vertical-align: middle; }
            .badge-PRESENT { background-color: #E8FFF3; color: #50CD89; border: 1px solid rgba(80, 205, 137, 0.2); }
            .badge-ABSENT { background-color: #FFF5F8; color: #F1416C; border: 1px solid rgba(241, 65, 108, 0.2); }
            .badge-LATE { background-color: #FFF8DD; color: #FFC700; border: 1px solid rgba(255, 199, 0, 0.2); }
            .badge-HALF_DAY { background-color: #E8F8FF; color: #7239EA; border: 1px solid rgba(114, 57, 234, 0.2); }
            .badge-LEAVE { background-color: #F5F8FA; color: #A1A5B7; border: 1px solid rgba(161, 165, 183, 0.2); }
            .badge-NOT_MARKED { background-color: #FFF8DD; color: #F1416C; border: 1px dashed rgba(241, 65, 108, 0.4); }
            .badge { padding: 6px 12px; font-weight: 700; border-radius: 6px; font-size: 11px; display: inline-block; }
            @media print {
              body { padding: 0; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="header-container">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div class="school-title">Attendance Report</div>
                <div class="sheet-title">Daily Student Attendance Record</div>
              </div>
              <div class="text-end">
                <button class="btn btn-primary btn-sm no-print" onclick="window.print()">Print / Download PDF</button>
              </div>
            </div>
            <div class="meta-info">
              Class: <span>${className}</span>
              Section: <span>${sectionName}</span>
              Date: <span>${new Date(filterDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
            </div>
          </div>

          <table class="table align-middle">
            <thead>
              <tr>
                <th style="width: 50px;">#</th>
                <th style="width: 120px;">Roll No</th>
                <th>Student Name</th>
                <th style="width: 150px;">Mobile</th>
                <th style="width: 150px; text-align: center;">Status</th>
                <th>Remark</th>
              </tr>
            </thead>
            <tbody>
              ${filteredAttendances.map((a, idx) => {
                const status = attendanceEdits[a.student_id]?.status || 'NOT_MARKED';
                const remark = attendanceEdits[a.student_id]?.remark || '—';
                return `
                  <tr>
                    <td>${idx + 1}</td>
                    <td class="fw-bold">${a.roll_number || '—'}</td>
                    <td class="fw-semibold">${a.first_name} ${a.last_name}</td>
                    <td>${a.mobile_number || '—'}</td>
                    <td style="text-align: center;">
                      <span class="badge badge-${status}">${status.replace('_', ' ')}</span>
                    </td>
                    <td class="text-muted italic">${remark}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>

          <script>
            setTimeout(() => {
              window.print();
            }, 500);
          </script>
        </body>
      </html>
    `

    printWindow.document.open()
    printWindow.document.write(htmlContent)
    printWindow.document.close()
  }

  const markAll = (status: string) => {
    const newEdits = { ...attendanceEdits }
    Object.keys(newEdits).forEach(id => {
      newEdits[Number(id)].status = status
    })
    setAttendanceEdits(newEdits)
  }

  const handleStatusChange = (studentId: number, status: string) => {
    setAttendanceEdits(prev => ({
      ...prev,
      [studentId]: { ...prev[studentId], status }
    }))
  }

  const handleRemarkChange = (studentId: number, remark: string) => {
    setAttendanceEdits(prev => ({
      ...prev,
      [studentId]: { ...prev[studentId], remark }
    }))
  }

  const filteredAttendances = attendances.filter(a => {
    if (!search) return true
    const name = `${a.first_name} ${a.last_name}`.toLowerCase()
    return name.includes(search.toLowerCase())
  })

  // Status options
  const STATUSES = ['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'LEAVE']

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* Filter Bar */}
        <div className='card card-flush mb-5'>
          <div className='card-body py-4'>
            <div className='row g-4 align-items-end'>
              <div className='col-md-3'>
                <label className='fw-semibold fs-7 mb-1 text-gray-600'>Academic Session</label>
                <select className='form-select form-select-solid form-select-sm' value={filterSession}
                  onChange={e => setFilterSession(e.target.value)}>
                  <option value=''>Select Session</option>
                  {sessions.map(s => (
                    <option key={s.id} value={s.id}>{s.session_year} {s.is_current ? '★' : ''}</option>
                  ))}
                </select>
              </div>
              <div className='col-md-2'>
                <label className='fw-semibold fs-7 mb-1 text-gray-600'>Class</label>
                <select className='form-select form-select-solid form-select-sm' value={filterClass}
                  onChange={e => handleClassFilter(e.target.value)}>
                  <option value=''>Select Class</option>
                  {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className='col-md-2'>
                <label className='fw-semibold fs-7 mb-1 text-gray-600'>Section</label>
                <select className='form-select form-select-solid form-select-sm' value={filterSection}
                  onChange={e => setFilterSection(e.target.value)} disabled={!filterClass}>
                  <option value=''>Select Section</option>
                  {classSections.map(cs => <option key={cs.id} value={cs.id}>{cs.section?.name}</option>)}
                </select>
              </div>
              <div className='col-md-2'>
                <label className='fw-semibold fs-7 mb-1 text-gray-600'>Date</label>
                <input type='date' className='form-control form-control-solid form-control-sm'
                  value={filterDate} onChange={e => setFilterDate(e.target.value)} />
              </div>
              {sessions.find(s => s.id.toString() === filterSession)?.attendance_mode === 'PERIOD' && (
                <div className='col-md-3'>
                  <label className='fw-semibold fs-7 mb-1 text-gray-600'>Period</label>
                  <select className='form-select form-select-solid form-select-sm' value={filterPeriod}
                    onChange={e => setFilterPeriod(e.target.value)}>
                    <option value=''>Select Period</option>
                    {periods.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.period} - {p.subject ? p.subject : 'No Subject'} ({p.start_time} to {p.end_time})
                      </option>
                    ))}
                  </select>
                </div>
              )}
              <div className='col-md-2'>
                <button className='btn btn-primary btn-sm w-100' onClick={fetchAttendance} disabled={loading || !filterSection || !filterDate}>
                  {loading ? <span className='spinner-border spinner-border-sm'></span> : 'Fetch'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Attendance Table */}
        <div className='card card-flush'>
          <div className='card-header d-flex flex-wrap align-items-center py-5 gap-2 gap-md-5'>
            <div className='card-title d-flex align-items-center gap-4'>
              <div className='d-flex align-items-center position-relative my-1'>
                <i className='ki-duotone ki-magnifier fs-3 position-absolute ms-4'>
                  <span className='path1'></span><span className='path2'></span>
                </i>
                <input type='text' className='form-control form-control-solid w-250px ps-14'
                  placeholder='Search by name...' value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              {/* Visual Indicator showing if attendance is already recorded */}
              {attendances.some(a => a.status) && (
                <span className='badge badge-light-success fs-7 fw-bold px-4 py-3 border border-success'>
                  <i className='ki-duotone ki-check-circle fs-4 text-success me-2'><span className='path1'></span><span className='path2'></span></i>
                  Attendance Already Marked
                </span>
              )}
            </div>
            <div className='card-toolbar'>
              <div className='dropdown me-2'>
                <button
                  className='btn btn-light-primary btn-sm dropdown-toggle'
                  type='button'
                  id='exportDropdown'
                  data-bs-toggle='dropdown'
                  aria-expanded='false'
                  disabled={filteredAttendances.length === 0}
                >
                  <i className='ki-duotone ki-exit-up fs-4 me-1'><span className='path1'></span><span className='path2'></span></i> Export Sheet
                </button>
                <ul className='dropdown-menu fs-7' aria-labelledby='exportDropdown'>
                  <li>
                    <button className='dropdown-item py-2 fw-semibold d-flex align-items-center gap-2' onClick={exportToExcel}>
                      <i className='ki-duotone ki-file-sheet fs-4 text-success'><span className='path1'></span><span className='path2'></span></i> Export Excel (CSV)
                    </button>
                  </li>
                  <li>
                    <button className='dropdown-item py-2 fw-semibold d-flex align-items-center gap-2' onClick={exportToPdf}>
                      <i className='ki-duotone ki-document fs-4 text-danger'><span className='path1'></span><span className='path2'></span></i> Download PDF
                    </button>
                  </li>
                </ul>
              </div>

              <button className='btn btn-light-success btn-sm me-2' onClick={() => markAll('PRESENT')} disabled={attendances.length === 0}>
                Mark All Present
              </button>
              <button className='btn btn-light-danger btn-sm' onClick={() => markAll('ABSENT')} disabled={attendances.length === 0}>
                Mark All Absent
              </button>
            </div>
          </div>

          <div className='card-body pt-0'>
            <div className='table-responsive'>
              <table className='table align-middle table-row-dashed fs-6 gy-5'>
                <thead>
                  <tr className='text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0'>
                    <th className='w-50px'>#</th>
                    <th className='min-w-150px'>Student</th>
                    <th className='min-w-300px'>Attendance Status</th>
                    <th className='min-w-200px'>Remark</th>
                  </tr>
                </thead>
                <tbody className='fw-semibold text-gray-600'>
                  {attendances.length === 0 ? (
                    <tr>
                      <td colSpan={4} className='text-center py-10 text-muted'>
                        {loading ? 'Fetching attendance records...' : 'No records found. Select class, section and date to fetch.'}
                      </td>
                    </tr>
                  ) : filteredAttendances.map((student, idx) => (
                    <tr key={student.student_id}>
                      <td>{idx + 1}</td>
                      <td>
                        <div className='d-flex align-items-center'>
                          <div className='symbol symbol-circle symbol-35px overflow-hidden me-3'>
                            <div className='symbol-label fs-3 bg-light-primary text-primary'>
                              {student.first_name.charAt(0)}
                            </div>
                          </div>
                          <div className='d-flex flex-column'>
                            <span className='text-gray-800 fw-bold mb-1'>
                              {student.first_name} {student.last_name}
                            </span>
                            <span className='text-muted fs-7'>Roll No: {student.roll_number || '—'}</span>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div className='d-flex flex-wrap gap-2'>
                          {STATUSES.map(status => {
                            const isChecked = attendanceEdits[student.student_id]?.status === status;
                            let colorClass = 'primary';
                            if (status === 'PRESENT') colorClass = 'success';
                            if (status === 'ABSENT') colorClass = 'danger';
                            if (status === 'LATE') colorClass = 'warning';
                            if (status === 'HALF_DAY') colorClass = 'info';
                            if (status === 'LEAVE') colorClass = 'secondary';

                            return (
                              <label key={status} className={`btn btn-sm btn-outline btn-outline-dashed px-3 py-2 cursor-pointer
                                              ${isChecked ? `btn-active-light-${colorClass} active border-${colorClass}` : 'btn-active-light-primary border-gray-300'}
                                          `}>
                                <input
                                  type='radio'
                                  className='btn-check'
                                  name={`status_${student.student_id}`}
                                  value={status}
                                  checked={isChecked}
                                  onChange={(e) => handleStatusChange(student.student_id, e.target.value)}
                                />
                                <span className={`fw-bold ${isChecked ? `text-${colorClass}` : 'text-gray-600'}`}>
                                  {status}
                                </span>
                              </label>
                            );
                          })}

                          {attendanceEdits[student.student_id]?.status === 'NOT_MARKED' && (
                            <span className='badge badge-light-warning fs-8 align-self-center'>⚠ Mark pending</span>
                          )}
                        </div>
                      </td>
                      <td>
                        <input
                          type='text'
                          className='form-control form-control-sm form-control-solid'
                          placeholder='Add remark...'
                          value={attendanceEdits[student.student_id]?.remark || ''}
                          onChange={(e) => handleRemarkChange(student.student_id, e.target.value)}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {attendances.length > 0 && (
              <div className='d-flex justify-content-end mt-5'>
                <button className='btn btn-primary' onClick={saveAttendance} disabled={saving}>
                  {saving ? <span className='spinner-border spinner-border-sm me-2'></span> : <i className='ki-duotone ki-check fs-2'><span className='path1'></span><span className='path2'></span></i>}
                  {attendances.some(a => a.attendance_id) ? 'Update Attendance' : 'Save Attendance'}
                </button>
              </div>
            )}
          </div>
        </div>
      </Content>

      {/* Success Modal */}
      <div className={`modal fade ${showSuccessModal ? 'show d-block' : ''}`} tabIndex={-1} style={{ backgroundColor: showSuccessModal ? 'rgba(0,0,0,0.5)' : 'transparent' }}>
        <div className='modal-dialog modal-dialog-centered'>
          <div className='modal-content'>
            <div className='modal-body text-center py-10'>
              <div className='mb-5'>
                <i className='ki-duotone ki-check-circle fs-5x text-success'>
                  <span className='path1'></span><span className='path2'></span>
                </i>
              </div>
              <h2 className='fw-bolder text-gray-900 mb-3'>Success!</h2>
              <p className='text-gray-600 fs-5 mb-8'>Your attendance has been successfully saved.</p>
              <button type='button' className='btn btn-primary px-8' onClick={() => setShowSuccessModal(false)}>
                Done
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

const AttendanceWrapper: FC = () => {
  return (
    <>
      <PageTitle breadcrumbs={[]}>Student Attendance</PageTitle>
      <AttendancePage />
    </>
  )
}

export { AttendanceWrapper }
