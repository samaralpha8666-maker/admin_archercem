import axios from 'axios'
import {
  AdmitStudentPayload,
  StudentResponse,
  StudentsListResponse,
  StudentProfilePayload,
  StudentParentPayload,
  StudentAddressPayload,
  StudentDocumentPayload,
  StudentDocumentResponse,
  StudentDocumentsResponse,
  StudentEnrollmentPayload,
  StudentEnrollmentResponse,
  EnrollmentsListResponse,
  DocumentStatus,
  EnrollmentStatus,
} from './_models'

const API_URL = import.meta.env.VITE_APP_API_URL

// ─── URL Builders ─────────────────────────────────────────────────────────────
const STUDENTS_URL = (schoolId: string | number) =>
  `${API_URL}/school/${schoolId}/students`

const STUDENT_URL = (schoolId: string | number, studentId: string | number) =>
  `${API_URL}/school/${schoolId}/students/${studentId}`

const STUDENT_PROFILE_URL = (schoolId: string | number, studentId: string | number) =>
  `${API_URL}/school/${schoolId}/students/${studentId}/profile`

const STUDENT_PARENT_URL = (schoolId: string | number, studentId: string | number) =>
  `${API_URL}/school/${schoolId}/students/${studentId}/parent`

const STUDENT_ADDRESS_URL = (schoolId: string | number, studentId: string | number) =>
  `${API_URL}/school/${schoolId}/students/${studentId}/address`

const STUDENT_DOCUMENTS_URL = (schoolId: string | number, studentId: string | number) =>
  `${API_URL}/school/${schoolId}/students/${studentId}/documents`

const STUDENT_DOCUMENT_URL = (
  schoolId: string | number,
  studentId: string | number,
  documentId: string | number
) => `${API_URL}/school/${schoolId}/students/${studentId}/documents/${documentId}`

const STUDENT_ENROLL_URL = (schoolId: string | number, studentId: string | number) =>
  `${API_URL}/school/${schoolId}/students/${studentId}/enroll`

const ENROLLMENTS_URL = (schoolId: string | number) =>
  `${API_URL}/school/${schoolId}/enrollments`

const ENROLLMENT_STATUS_URL = (schoolId: string | number, enrollmentId: string | number) =>
  `${API_URL}/school/${schoolId}/enrollments/${enrollmentId}/status`

const ENROLLMENT_URL = (schoolId: string | number, enrollmentId: string | number) =>
  `${API_URL}/school/${schoolId}/enrollments/${enrollmentId}`

// ─── Student CRUD ─────────────────────────────────────────────────────────────

/** Step 1: Admit a new student (creates core login record) */
export function admitStudent(schoolId: string | number, payload: AdmitStudentPayload) {
  return axios.post<StudentResponse>(STUDENTS_URL(schoolId), payload)
}

/** Bulk Import Students */
export function bulkImportStudents(schoolId: string | number, payload: { students: any[] }) {
  return axios.post<any>(`${STUDENTS_URL(schoolId)}/bulk-import`, payload)
}

/** Get paginated list of all students */
export function getStudents(
  schoolId: string | number,
  params: { page?: number; limit?: number; search?: string } = {}
) {
  return axios.get<StudentsListResponse>(STUDENTS_URL(schoolId), {
    params: { page: 1, limit: 50, ...params },
  })
}

/** Get single student full profile (with all relations) */
export function getStudentById(schoolId: string | number, studentId: string | number) {
  return axios.get<StudentResponse>(STUDENT_URL(schoolId, studentId))
}

/** Step 1b: Update core student data (first name, last name, mobile, email, password) */
export function updateStudentCore(schoolId: string | number, studentId: string | number, payload: Partial<AdmitStudentPayload>) {
  return axios.put<StudentResponse>(STUDENT_URL(schoolId, studentId), payload)
}

// ─── Profile / Parent / Address ──────────────────────────────────────────────

/** Step 2: Update personal profile */
export function updateStudentProfile(
  schoolId: string | number,
  studentId: string | number,
  payload: StudentProfilePayload,
  imageFile?: File | null
) {
  const formData = new FormData();
  Object.keys(payload).forEach(key => {
    const val = (payload as any)[key];
    if (val !== undefined && val !== null && val !== '') {
      formData.append(key, val);
    }
  });
  if (imageFile) {
    formData.append('profile_image', imageFile);
  }

  return axios.put<StudentResponse>(STUDENT_PROFILE_URL(schoolId, studentId), formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
}

/** Step 3: Update parent details */
export function updateStudentParent(
  schoolId: string | number,
  studentId: string | number,
  payload: StudentParentPayload
) {
  return axios.put<StudentResponse>(STUDENT_PARENT_URL(schoolId, studentId), payload)
}

/** Step 4: Update address details */
export function updateStudentAddress(
  schoolId: string | number,
  studentId: string | number,
  payload: StudentAddressPayload
) {
  return axios.put<StudentResponse>(STUDENT_ADDRESS_URL(schoolId, studentId), payload)
}

// ─── Documents ────────────────────────────────────────────────────────────────

/** Step 5: Upload / add a document with real file */
export function uploadDocument(
  schoolId: string | number,
  studentId: string | number,
  documentType: string,
  file: File
) {
  const formData = new FormData()
  formData.append('document_type', documentType)
  formData.append('document_file', file)
  return axios.post<StudentDocumentResponse>(STUDENT_DOCUMENTS_URL(schoolId, studentId), formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

/** Get all documents for a student */
export function getStudentDocuments(
  schoolId: string | number,
  studentId: string | number
) {
  return axios.get<StudentDocumentsResponse>(STUDENT_DOCUMENTS_URL(schoolId, studentId))
}

/** Admin: verify or reject a document */
export function updateDocumentStatus(
  schoolId: string | number,
  studentId: string | number,
  documentId: string | number,
  status: DocumentStatus
) {
  return axios.patch<StudentDocumentResponse>(
    STUDENT_DOCUMENT_URL(schoolId, studentId, documentId),
    { status }
  )
}

// ─── Enrollment ───────────────────────────────────────────────────────────────

/** Step 6: Enroll student into a class-section */
export function enrollStudent(
  schoolId: string | number,
  studentId: string | number,
  payload: StudentEnrollmentPayload
) {
  return axios.post<StudentEnrollmentResponse>(STUDENT_ENROLL_URL(schoolId, studentId), payload)
}

/** Get enrollment roster (filtered by session, class-section, status) */
export function getEnrollments(
  schoolId: string | number,
  params: {
    session_id?: number
    class_section_id?: number
    status?: EnrollmentStatus
    page?: number
    limit?: number
    search?: string
  } = {}
) {
  return axios.get<EnrollmentsListResponse>(ENROLLMENTS_URL(schoolId), {
    params: { page: 1, limit: 50, ...params },
  })
}

/** Admin: update enrollment status (Promote / Drop / Transfer) */
export function updateEnrollmentStatus(
  schoolId: string | number,
  enrollmentId: string | number,
  status: EnrollmentStatus
) {
  return axios.patch<StudentEnrollmentResponse>(
    ENROLLMENT_STATUS_URL(schoolId, enrollmentId),
    { status }
  )
}

/** Admin: update enrollment details – roll_number, class_section_id, status */
export function updateEnrollment(
  schoolId: string | number,
  enrollmentId: string | number,
  payload: { roll_number?: string; class_section_id?: number; status?: EnrollmentStatus }
) {
  return axios.patch<StudentEnrollmentResponse>(
    ENROLLMENT_URL(schoolId, enrollmentId),
    payload
  )
}

/** Admin: Toggle active/inactive status */
export function toggleStudentStatus(schoolId: string | number, studentId: string | number) {
  return axios.patch<any>(
    `${API_URL}/school/${schoolId}/students/${studentId}/toggle-status`,
    {}
  )
}

/** Admin: Download roster as Excel */
export async function downloadRosterExcel(schoolId: string | number, params: any) {
  const response = await axios.get(`${API_URL}/school/${schoolId}/enrollments/export/excel`, {
    params,
    responseType: 'blob'
  });
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `Enrollment_Roster_${Date.now()}.csv`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}

/** Admin: Download roster as PDF */
export async function downloadRosterPdf(schoolId: string | number, params: any) {
  const response = await axios.get(`${API_URL}/school/${schoolId}/enrollments/export/pdf`, {
    params,
    responseType: 'blob'
  });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `Enrollment_Roster_${Date.now()}.pdf`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}

/** Admin: Download individual student profile PDF */
export async function downloadStudentProfilePdf(schoolId: string | number, studentId: string | number, name: string) {
  const response = await axios.get(`${API_URL}/school/${schoolId}/students/${studentId}/download-profile`, {
    responseType: 'blob'
  });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `Student_Profile_${name.replace(/\s+/g, '_')}_${Date.now()}.pdf`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}

/** Get student exam results performance data */
export function getStudentPerformance(schoolId: string | number, studentId: string | number) {
  return axios.get<any>(`${API_URL}/school/${schoolId}/exams/students/${studentId}/performance`);
}

// ─── Transfer Certificate API Connectors ──────────────────────────────────────
export function getTransferCertificates(schoolId: string | number, params: any = {}) {
  return axios.get<any>(`${API_URL}/school/${schoolId}/transfer-certificates`, { params })
}

export function issueTransferCertificate(schoolId: string | number, studentId: string | number, payload: any) {
  return axios.post<any>(`${API_URL}/school/${schoolId}/students/${studentId}/transfer-certificate`, payload)
}

export function revokeTransferCertificate(schoolId: string | number, tcId: string | number, payload: { reason: string }) {
  return axios.post<any>(`${API_URL}/school/${schoolId}/transfer-certificates/${tcId}/revoke`, payload)
}

export async function downloadTransferCertificatePdf(schoolId: string | number, tcId: string | number, studentName: string, theme: string = 'navy') {
  const response = await axios.get(`${API_URL}/school/${schoolId}/transfer-certificates/${tcId}/download`, {
    params: { theme },
    responseType: 'blob'
  });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `Transfer_Certificate_${studentName.replace(/\s+/g, '_')}_${Date.now()}.pdf`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}

