import { FC, useState, useRef } from 'react'
import { Modal, Button, Alert } from 'react-bootstrap'
import * as XLSX from 'xlsx'
import { bulkImportStudents } from './core/_requests'
import { toast } from 'react-hot-toast'
import { SessionModel, ClassModel, ClassSectionMappingModel } from '../academic/core/_models'
import { getClassSections } from '../academic/core/_requests'

interface Props {
  show: boolean
  onHide: () => void
  onSuccess: () => void
  schoolId: string
  sessions: SessionModel[]
  classes: ClassModel[]
}

export const BulkAdmissionModal: FC<Props> = ({ show, onHide, onSuccess, schoolId, sessions, classes }) => {
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  // UI Selectors for context
  const [selectedSessionId, setSelectedSessionId] = useState('')
  const [selectedClassId, setSelectedClassId] = useState('')
  const [selectedSectionId, setSelectedSectionId] = useState('')
  const [sections, setSections] = useState<ClassSectionMappingModel[]>([])

  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleClassChange = async (classId: string) => {
    setSelectedClassId(classId)
    setSelectedSectionId('')
    setSections([])
    if (!classId) return
    try {
      const { data } = await getClassSections(schoolId, classId)
      if (data.success) setSections(data.data.sections || [])
    } catch {}
  }

  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet([{
      'First Name': 'Rahul',
      'Last Name': 'Sharma',
      'Mobile Number': '9876543210',
      'Email': 'rahul@example.com',
      'Password': 'MyPassword123', // Optional
      'Registration Number': 'ADM260001', // Optional
      'Roll Number': '101'
    }]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template');
    XLSX.writeFile(wb, 'Student_Import_Template.xlsx');
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setError(null)
    const reader = new FileReader()
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result
        if (typeof bstr !== 'string') return
        const wb = XLSX.read(bstr, { type: 'binary' })
        const wsname = wb.SheetNames[0]
        const ws = wb.Sheets[wsname]
        const jsonData = XLSX.utils.sheet_to_json(ws)
        
        const formattedData = jsonData.map((row: any, index: number) => ({
          _id: index, // temporary id for editing
          first_name: row['First Name'] || '',
          last_name: row['Last Name'] || '',
          mobile_number: row['Mobile Number'] ? String(row['Mobile Number']) : '',
          email: row['Email'] || '',
          password: row['Password'] ? String(row['Password']) : '',
          registration_number: row['Registration Number'] ? String(row['Registration Number']) : '',
          roll_number: row['Roll Number'] ? String(row['Roll Number']) : ''
        }))
        
        setData(formattedData)
      } catch (err) {
        setError('Failed to parse Excel file. Ensure it matches the template.')
      }
    }
    reader.readAsBinaryString(file)
  }

  const handleEditCell = (index: number, field: string, value: string) => {
    const updated = [...data]
    updated[index][field] = value
    setData(updated)
  }

  const handleRemoveRow = (index: number) => {
    const updated = [...data]
    updated.splice(index, 1)
    setData(updated)
  }

  const handleSubmit = async () => {
    if (data.length === 0) return
    if (!selectedSessionId || !selectedSectionId) {
      setError('Please select Session and Class Section before uploading.')
      return
    }

    setLoading(true)
    setError(null)
    
    // Validate minimally first
    const invalidRows = data.filter(r => !r.first_name || !r.mobile_number || r.mobile_number.length < 10)
    if (invalidRows.length > 0) {
      setError('Some rows have missing required fields or invalid mobile numbers. Check red highlighted inputs.')
      setLoading(false)
      return
    }

    try {
      const payload = {
        students: data.map(r => ({
          first_name: r.first_name,
          last_name: r.last_name,
          mobile_number: r.mobile_number,
          email: r.email,
          password: r.password, // Pass to backend
          class_section_id: Number(selectedSectionId),
          academic_session_id: Number(selectedSessionId),
          registration_number: r.registration_number || undefined,
          roll_number: r.roll_number
        }))
      }
      
      await bulkImportStudents(schoolId, payload)
      toast.success(`${data.length} students bulk imported successfully!`)
      setData([])
      onSuccess()
      onHide()
    } catch (err: any) {
      setError(err.response?.data?.error || err.response?.data?.message || 'Failed to bulk import students.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal show={show} onHide={() => { setData([]); onHide() }} size='xl' centered backdrop='static'>
      <Modal.Header closeButton className='bg-light py-4'>
        <Modal.Title><i className='ki-duotone ki-file-up fs-2x text-primary me-2'><span className='path1'></span><span className='path2'></span></i> Bulk Student Registration & Enrollment</Modal.Title>
      </Modal.Header>
      
      <Modal.Body className='px-lg-10 pt-4 pb-8'>
        {/* Context Selectors */}
        <div className='row g-5 mb-8 p-6 bg-light border border-gray-300 rounded'>
          <div className='col-md-4'>
            <label className='required fw-semibold fs-6 mb-2'>Academic Session</label>
            <select className='form-select form-select-solid bg-white' value={selectedSessionId} onChange={e => setSelectedSessionId(e.target.value)} disabled={data.length > 0}>
              <option value=''>-- Select Session --</option>
              {sessions.map(s => <option key={s.id} value={s.id}>{s.session_year} {s.is_current ? '(Current)' : ''}</option>)}
            </select>
          </div>
          <div className='col-md-4'>
            <label className='required fw-semibold fs-6 mb-2'>Target Class</label>
            <select className='form-select form-select-solid bg-white' value={selectedClassId} onChange={e => handleClassChange(e.target.value)} disabled={data.length > 0}>
              <option value=''>-- Select Class --</option>
              {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className='col-md-4'>
            <label className='required fw-semibold fs-6 mb-2'>Target Section</label>
            <select className='form-select form-select-solid bg-white' value={selectedSectionId} onChange={e => setSelectedSectionId(e.target.value)} disabled={!selectedClassId || data.length > 0}>
              <option value=''>-- Select Section --</option>
              {sections.map(cs => <option key={cs.id} value={cs.id}>Section {cs.section?.name}</option>)}
            </select>
          </div>
          <div className='col-12 text-muted fs-8 mt-4'>
            <i className='ki-duotone ki-information fs-6 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
            Please select the session, class, and section before importing the Excel file. All parsed students will be assigned to this selection.
          </div>
        </div>

        {error && <Alert variant='danger'>{error}</Alert>}
        
        {data.length === 0 ? (
          <div className='text-center py-10'>
            <h4 className='fw-bold mb-5 text-gray-800'>Import Students from Excel</h4>
            <div className='d-flex justify-content-center gap-4 mb-4'>
              <Button variant='light-primary' onClick={downloadTemplate}>
                <i className='ki-duotone ki-file-down fs-3 me-2'><span className='path1'></span><span className='path2'></span></i> Download Template
              </Button>
              <Button variant='primary' onClick={() => fileInputRef.current?.click()} disabled={!selectedSessionId || !selectedSectionId}>
                <i className='ki-duotone ki-add-folder fs-3 me-2'><span className='path1'></span><span className='path2'></span></i> Select File
              </Button>
              <input type='file' accept='.xlsx, .xls' ref={fileInputRef} className='d-none' onChange={handleFileUpload} />
            </div>
            {!selectedSessionId || !selectedSectionId ? (
              <p className='text-danger fs-7'>Select Session and Section above to enable upload.</p>
            ) : (
              <p className='text-muted fs-7 mx-auto w-50'>
                Make sure your Excel uses exact column names: First Name, Last Name, Mobile Number, Email, Password, Registration Number, Roll Number
              </p>
            )}
          </div>
        ) : (
          <div>
            <div className='d-flex justify-content-between align-items-center mb-5'>
              <h5 className='fw-bold m-0'>Preview & Validate {data.length} Records</h5>
              <Button variant='light-danger' size='sm' onClick={() => setData([])} disabled={loading}>Clear All</Button>
            </div>
            
            <div className='table-responsive border rounded' style={{ maxHeight: '400px', overflowY: 'auto' }}>
              <table className='table table-row-bordered table-row-gray-200 align-middle gs-0 gy-2 m-0'>
                <thead className='bg-light position-sticky top-0 z-index-1'>
                  <tr className='fw-bold text-gray-800 border-bottom border-gray-300 bg-light'>
                    <th className='px-4 min-w-100px'>First Name *</th>
                    <th className='px-4 min-w-100px'>Last Name</th>
                    <th className='px-4 min-w-120px'>Mobile *</th>
                    <th className='px-4 min-w-150px'>Email</th>
                    <th className='px-4 min-w-100px'>Password</th>
                    <th className='px-4 min-w-120px'>Reg No</th>
                    <th className='px-4 min-w-100px'>Roll No</th>
                    <th className='px-4 w-50px text-end'>Del</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((row, index) => {
                    const isMobInvalid = !row.mobile_number || row.mobile_number.length < 10
                    const isFNameInvalid = !row.first_name
                    
                    return (
                      <tr key={index}>
                        <td className='p-2'>
                          <input type='text' className={`form-control form-control-sm form-control-solid border ${isFNameInvalid ? 'border-danger' : 'border-transparent'}`} value={row.first_name} onChange={(e) => handleEditCell(index, 'first_name', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='text' className='form-control form-control-sm form-control-solid border border-transparent' value={row.last_name} onChange={(e) => handleEditCell(index, 'last_name', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='text' className={`form-control form-control-sm form-control-solid border ${isMobInvalid ? 'border-danger' : 'border-transparent'}`} value={row.mobile_number} onChange={(e) => handleEditCell(index, 'mobile_number', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='email' className='form-control form-control-sm form-control-solid border border-transparent' value={row.email} onChange={(e) => handleEditCell(index, 'email', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='text' className='form-control form-control-sm form-control-solid border border-transparent' placeholder='Default if blank' value={row.password} onChange={(e) => handleEditCell(index, 'password', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='text' className='form-control form-control-sm form-control-solid border border-transparent' placeholder='Auto-generate' value={row.registration_number} onChange={(e) => handleEditCell(index, 'registration_number', e.target.value)} />
                        </td>
                        <td className='p-2'>
                          <input type='text' className='form-control form-control-sm form-control-solid border border-transparent' value={row.roll_number} onChange={(e) => handleEditCell(index, 'roll_number', e.target.value)} />
                        </td>
                        <td className='p-2 text-end'>
                          <Button variant='icon btn-color-danger btn-active-light-danger w-30px h-30px p-0' onClick={() => handleRemoveRow(index)}>
                            <i className='ki-duotone ki-trash fs-3'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i>
                          </Button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
            
            <div className='d-flex justify-content-between align-items-center mt-6 pt-4 border-top'>
              <div className='text-muted fs-8'>
                <span className='badge badge-light-danger me-2'>Red Borders</span> indicates required items or formatting errors.
              </div>
              <div>
                <Button variant='light' onClick={() => { setData([]); onHide() }} className='me-3' disabled={loading}>Cancel</Button>
                <Button variant='success' onClick={handleSubmit} disabled={loading || data.length === 0}>
                  {loading ? <span className='spinner-border spinner-border-sm me-2'></span> : <i className='ki-duotone ki-cloud-change fs-4 me-2'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>}
                  Upload All {data.length} Records
                </Button>
              </div>
            </div>
          </div>
        )}
      </Modal.Body>
    </Modal>
  )
}
