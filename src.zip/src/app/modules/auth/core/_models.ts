export interface AuthModel {
  api_token: string
  refreshToken?: string
  user?: UserModel
}

export interface UserAddressModel {
  addressLine: string
  city: string
  state: string
  postCode: string
}

export interface UserCommunicationModel {
  email: boolean
  sms: boolean
  phone: boolean
}

export interface UserEmailSettingsModel {
  emailNotification?: boolean
  sendCopyToPersonalEmail?: boolean
  activityRelatesEmail?: {
    youHaveNewNotifications?: boolean
    youAreSentADirectMessage?: boolean
    someoneAddsYouAsAsAConnection?: boolean
    uponNewOrder?: boolean
    newMembershipApproval?: boolean
    memberRegistration?: boolean
  }
  updatesFromKeenthemes?: {
    newsAboutKeenthemesProductsAndFeatureUpdates?: boolean
    tipsOnGettingMoreOutOfKeen?: boolean
    thingsYouMissedSindeYouLastLoggedIntoKeen?: boolean
    newsAboutPartnerProductsAndOtherServices?: boolean
    tipsOnStartBusinessProducts?: boolean
  }
}

export interface UserSocialNetworksModel {
  linkedIn: string
  facebook: string
  twitter: string
  instagram: string
}

export interface UserModel {
  id: number
  name: string
  email: string
  role: 'super_admin' | 'admin' | 'manager' | 'staff' | string
  permissions?: string[]
  schoolId?: number
  school_name?: string
  school_logo?: string
  school_code?: string
  institution_type?: 'SCHOOL' | 'COLLEGE' | 'COACHING' | string
  username?: string
  password?: string
  first_name?: string
  last_name?: string
  fullname?: string
  occupation?: string
  companyName?: string
  phone?: string
  roles?: Array<number>
  pic?: string
  profile_image?: string
  language?: 'en' | 'de' | 'es' | 'fr' | 'ja' | 'zh' | 'ru'
  timeZone?: string
  website?: string
  emailSettings?: UserEmailSettingsModel
  auth?: AuthModel
  communication?: UserCommunicationModel
  address?: UserAddressModel
  socialNetworks?: UserSocialNetworksModel
}

export interface SchoolModel {
  id: number
  code: string
  name: string
  subdomain: string
  institution_type?: 'SCHOOL' | 'COLLEGE' | 'COACHING' | string
  db_host?: string
  db_port?: number
  db_username?: string
  db_password?: string
  schema?: string
  database?: string
  app_url?: string
  is_active: boolean
  setup_completed: boolean
  createdAt?: string
  principalName?: string
  phone?: string
  email?: string
  address?: string
  logoPath?: string
  bannerPath?: string
  establishedYear?: string | number
}

export interface SchoolCreationData {
  code: string
  name: string
  subdomain: string
  institution_type?: 'SCHOOL' | 'COLLEGE' | 'COACHING' | string
  db_name: string
  db_host: string
  db_port: number
  db_username: string
  db_password: string
  address: string
  phone: string
  email: string
  logoPath?: string
}

export interface SchoolResponse {
  success: boolean
  message: string
  data: {
    school: SchoolModel
  }
}

export interface LoginResponse {
  success: boolean
  message: string
  data: {
    token: string
    user?: UserModel
    admin?: UserModel
  }
}

export interface SchoolsListResponse {
  success: boolean
  message: string
  data: {
    schools: SchoolModel[]
  }
  pagination: {
    total: number
    page: number
    limit: number
    totalPages: number
    hasNextPage: boolean
    hasPrevPage: boolean
  }
}

export interface ProfessionModel {
  id: number
  name: string
  description?: string
  category: "teaching" | "administrative" | "support" | "technical" | "other" | string
  is_active: boolean
  created_by?: number | null
  createdAt?: string
  updatedAt?: string
}

export interface ProfessionCreationData {
  name: string
  description?: string
  category: string
  is_active?: boolean
}

export interface ProfessionResponse {
  success: boolean
  message: string
  data: {
    profession?: ProfessionModel
  }
}

export interface ProfessionsListResponse {
  success: boolean
  message: string
  data: {
    professions: ProfessionModel[]
  }
  pagination?: {
    total: number
    page: number
    limit: number
    totalPages: number
    hasNextPage: boolean
    hasPrevPage: boolean
  }
}

export interface StaffModel {
  id: number
  name: string
  email: string
  role: string
  is_active: boolean
  profession_id?: number | null
  createdAt?: string
  updatedAt?: string
  permissions?: string[]
}

export interface StaffCreationData {
  name: string
  email: string
  password?: string
  role: string
  profession_id?: number
  is_active?: boolean
}

export interface StaffResponse {
  success: boolean
  message: string
  data: {
    staff?: StaffModel
    admin?: StaffModel
  }
}

export interface StaffListResponse {
  success: boolean
  message: string
  data: {
    staff: StaffModel[]
  }
  pagination?: {
    total: number
    page: number
    limit: number
    totalPages: number
    hasNextPage: boolean
    hasPrevPage: boolean
  }
}
