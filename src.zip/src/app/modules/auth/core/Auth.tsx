/* eslint-disable react-refresh/only-export-components */
import { FC, useState, useEffect, createContext, useContext, Dispatch, SetStateAction } from 'react'
import { LayoutSplashScreen } from '../../../../_metronic/layout/core'
import { AuthModel, UserModel } from './_models'
import * as authHelper from './AuthHelpers'
import { getUserByToken } from './_requests'
import { WithChildren } from '../../../../_metronic/helpers'

type AuthContextProps = {
  auth: AuthModel | undefined
  saveAuth: (auth: AuthModel | undefined) => void
  currentUser: UserModel | undefined
  setCurrentUser: Dispatch<SetStateAction<UserModel | undefined>>
  logout: () => void
}

const initAuthContextPropsState = {
  auth: authHelper.getAuth(),
  saveAuth: () => { },
  currentUser: authHelper.getAuth()?.user || undefined,
  setCurrentUser: () => { },
  logout: () => { },
}

const AuthContext = createContext<AuthContextProps>(initAuthContextPropsState)

const useAuth = () => {
  return useContext(AuthContext)
}

const AuthProvider: FC<WithChildren> = ({ children }) => {
  const [auth, setAuth] = useState<AuthModel | undefined>(authHelper.getAuth())
  const [currentUser, setCurrentUser] = useState<UserModel | undefined>(authHelper.getAuth()?.user || undefined)

  // ── Dynamic tab title + favicon based on logged-in school ──
  useEffect(() => {
    const defaultTitle = 'apnacampus - School Management Portal'
    const defaultFavicon = '/media/logos/apnacampus-favicon.svg'

    if (currentUser?.school_name) {
      // School admin logged in — show school name
      document.title = `${currentUser.school_name} | apnacampus`

      // Update favicon to school logo if available, else keep apnacampus favicon
      const faviconHref = currentUser.school_logo || defaultFavicon
      updateFavicon(faviconHref)
    } else if (currentUser?.role === 'super_admin') {
      document.title = 'Super Admin | apnacampus'
      updateFavicon(defaultFavicon)
    } else {
      document.title = defaultTitle
      updateFavicon(defaultFavicon)
    }
  }, [currentUser])

  const saveAuth = (auth: AuthModel | undefined) => {
    setAuth(auth)
    if (auth) {
      if (auth.user) {
        setCurrentUser(auth.user)
      }
      authHelper.setAuth(auth)
    } else {
      authHelper.removeAuth()
      setCurrentUser(undefined)
    }
  }

  const logout = () => {
    saveAuth(undefined)
  }

  return (
    <AuthContext.Provider value={{ auth, saveAuth, currentUser, setCurrentUser, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

/** Helper: swap out the <link rel="icon"> href dynamically */
function updateFavicon(href: string) {
  // Remove all existing favicon links
  const existing = document.querySelectorAll('link[rel="icon"], link[rel="shortcut icon"]')
  existing.forEach((el) => el.parentNode?.removeChild(el))

  // Create new favicon link
  const link = document.createElement('link')
  link.rel = 'icon'
  link.type = href.endsWith('.svg') ? 'image/svg+xml' : 'image/png'
  link.href = href
  document.head.appendChild(link)
}


const AuthInit: FC<WithChildren> = ({ children }) => {
  const { auth, currentUser, logout, setCurrentUser } = useAuth()
  const [showSplashScreen, setShowSplashScreen] = useState(true)

  // We should request user by authToken (IN OUR EXAMPLE IT'S API_TOKEN) before rendering the application
  useEffect(() => {
    const requestUser = async (apiToken: string) => {
      try {
        if (!currentUser) {
          const { data: response } = await getUserByToken(apiToken)
          if (response && response.success && response.data) {
            const user = response.data.user || response.data.admin
            if (user) {
              setCurrentUser(user)
            } else {
              logout()
            }
          } else {
            logout()
          }
        }
      } catch (error) {
        console.error(error)
        logout()
      } finally {
        setShowSplashScreen(false)
      }
    }

    if (auth && auth.api_token) {
      if (currentUser) {
        setShowSplashScreen(false)
      } else {
        requestUser(auth.api_token)
      }
    } else {
      logout()
      setShowSplashScreen(false)
    }
    // eslint-disable-next-line
  }, [])

  return showSplashScreen ? <LayoutSplashScreen /> : <>{children}</>
}

export { AuthProvider, AuthInit, useAuth }
