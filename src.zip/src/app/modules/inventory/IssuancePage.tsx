import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { Modal, Button } from 'react-bootstrap'
import { useAuth } from '../auth'
import { getIssuances, getItems, issueItem, returnItem } from './core/_requests'

const emptyIssueForm = {
  item_id: '', issued_to_type: 'student' as 'student' | 'teacher' | 'staff',
  issued_to_id: '', issued_to_name: '', quantity: 1,
  issue_date: new Date().toISOString().split('T')[0],
  expected_return_date: '', notes: '',
}

const IssuancePage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [issuances, setIssuances] = useState<any[]>([])
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [filterStatus, setFilterStatus] = useState('')
  const [filterType, setFilterType] = useState('')

  const [showIssueModal, setShowIssueModal] = useState(false)
  const [form, setForm] = useState({ ...emptyIssueForm })
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)

  const [returnModal, setReturnModal] = useState<any>(null)
  const [returnNotes, setReturnNotes] = useState('')
  const [returnStatus, setReturnStatus] = useState<'returned' | 'lost'>('returned')
  const [returning, setReturning] = useState(false)

  const loadData = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    try {
      const [issRes, itemsRes] = await Promise.all([
        getIssuances(schoolId, {
          status: filterStatus || undefined,
          issued_to_type: filterType || undefined,
        }),
        getItems(schoolId),
      ])
      if (issRes.data.success) setIssuances(issRes.data.data)
      if (itemsRes.data.success) setItems(itemsRes.data.data.filter((i: any) => i.current_stock > 0))
    } catch (e: any) {
      console.error('Failed to load issuances', e)
    } finally { setLoading(false) }
  }, [schoolId, filterStatus, filterType])

  useEffect(() => { loadData() }, [loadData])

  const handleIssue = async () => {
    if (!form.item_id || !form.issued_to_id || !form.quantity) {
      setFormError('Item, Recipient ID, and Quantity are required')
      return
    }
    setSaving(true); setFormError(null)
    try {
      await issueItem(schoolId, {
        ...form,
        item_id: Number(form.item_id),
        issued_to_id: Number(form.issued_to_id),
        quantity: Number(form.quantity),
        expected_return_date: form.expected_return_date || undefined,
      })
      setShowIssueModal(false)
      setForm({ ...emptyIssueForm })
      loadData()
    } catch (e: any) {
      setFormError(e.response?.data?.message || 'Failed to issue item')
    } finally { setSaving(false) }
  }

  const handleReturn = async () => {
    if (!returnModal) return
    setReturning(true)
    try {
      await returnItem(schoolId, returnModal.id, { notes: returnNotes, status: returnStatus })
      setReturnModal(null)
      setReturnNotes('')
      loadData()
    } catch (e: any) {
      alert(e.response?.data?.message || 'Return failed')
    } finally { setReturning(false) }
  }

  const selectedItem = items.find(i => i.id === Number(form.item_id))

  const statusBadge = (s: string) => {
    if (s === 'returned') return 'success'
    if (s === 'lost') return 'danger'
    return 'warning'
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* Header */}
        <div className='d-flex align-items-center justify-content-between mb-6'>
          <div>
            <h1 className='fw-bold text-gray-800 fs-2 mb-1'>Issue & Return</h1>
            <span className='text-muted fs-6'>Track item issuance to students, teachers & staff</span>
          </div>
          <button className='btn btn-primary' onClick={() => { setForm({ ...emptyIssueForm }); setFormError(null); setShowIssueModal(true) }}>
            <i className='ki-duotone ki-send fs-4 me-2'><span className='path1' /><span className='path2' /></i>
            Issue Item
          </button>
        </div>

        {/* Quick Stats */}
        <div className='d-flex flex-wrap gap-4 mb-6'>
          {[
            { label: 'Total Issuances', value: issuances.length, color: 'primary' },
            { label: 'Currently Issued', value: issuances.filter(i => i.status === 'issued').length, color: 'warning' },
            { label: 'Returned', value: issuances.filter(i => i.status === 'returned').length, color: 'success' },
            { label: 'Lost/Damaged', value: issuances.filter(i => i.status === 'lost').length, color: 'danger' },
          ].map(({ label, value, color }) => (
            <div
              key={label}
              className='d-flex align-items-center gap-3 bg-white border border-gray-200 rounded-2 px-5 py-3'
              style={{ minWidth: 150 }}
            >
              <div className={`fw-bold text-${color} fs-2`}>{loading ? '—' : value}</div>
              <div className='text-muted fw-semibold fs-8'>{label}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className='card mb-5' style={{ borderRadius: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
          <div className='card-body py-4 d-flex flex-wrap gap-4 align-items-center'>
            <select
              className='form-select form-select-solid'
              style={{ width: 180 }}
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
            >
              <option value=''>All Status</option>
              <option value='issued'>Issued</option>
              <option value='returned'>Returned</option>
              <option value='lost'>Lost</option>
            </select>
            <select
              className='form-select form-select-solid'
              style={{ width: 180 }}
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
            >
              <option value=''>All Recipients</option>
              <option value='student'>Students</option>
              <option value='teacher'>Teachers</option>
              <option value='staff'>Staff</option>
            </select>
            <div className='ms-auto text-muted fw-semibold fs-7'>{issuances.length} records</div>
          </div>
        </div>

        {/* Table */}
        <div className='card' style={{ borderRadius: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
          <div className='card-body p-0'>
            <div className='table-responsive'>
              <table className='table table-row-dashed align-middle gs-0 gy-0 fs-7'>
                <thead>
                  <tr className='text-uppercase text-muted fw-bold fs-8 border-bottom border-gray-200'>
                    <th className='ps-7 py-5 w-40px'>#</th>
                    <th className='py-5'>Item</th>
                    <th className='py-5'>Issued To</th>
                    <th className='py-5'>Type</th>
                    <th className='py-5'>Qty</th>
                    <th className='py-5'>Issue Date</th>
                    <th className='py-5'>Expected Return</th>
                    <th className='py-5'>Status</th>
                    <th className='py-5 text-end pe-7'>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={9} className='text-center py-16'>
                        <span className='spinner-border text-primary me-2' />
                        <span className='text-muted'>Loading...</span>
                      </td>
                    </tr>
                  ) : issuances.length === 0 ? (
                    <tr>
                      <td colSpan={9} className='py-16'>
                        <div className='d-flex flex-column align-items-center'>
                          <i className='ki-duotone ki-send fs-5x text-gray-300 mb-4'>
                            <span className='path1' /><span className='path2' />
                          </i>
                          <span className='text-gray-600 fw-semibold fs-5'>No issuance records</span>
                        </div>
                      </td>
                    </tr>
                  ) : issuances.map((iss, idx) => (
                    <tr key={iss.id} className='border-bottom border-gray-100'>
                      <td className='ps-7 text-gray-400 fw-semibold'>{idx + 1}</td>
                      <td>
                        <span className='fw-semibold text-gray-800'>
                          {iss.item?.name || `Item #${iss.item_id}`}
                        </span>
                      </td>
                      <td>
                        <div className='fw-semibold text-gray-700'>{iss.issued_to_name || `ID: ${iss.issued_to_id}`}</div>
                      </td>
                      <td>
                        <span className='badge badge-light-primary fs-8 fw-semibold'>{iss.issued_to_type}</span>
                      </td>
                      <td className='fw-bold text-gray-700'>
                        {iss.quantity} {iss.item?.unit || 'pcs'}
                      </td>
                      <td className='text-muted'>
                        {new Date(iss.issue_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </td>
                      <td className='text-muted'>
                        {iss.expected_return_date
                          ? new Date(iss.expected_return_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
                          : '—'}
                      </td>
                      <td>
                        <span className={`badge badge-light-${statusBadge(iss.status)} fw-semibold fs-8`}>
                          {iss.status}
                        </span>
                      </td>
                      <td className='text-end pe-7'>
                        {iss.status === 'issued' && (
                          <button
                            className='btn btn-sm btn-light-success py-2 px-3'
                            onClick={() => { setReturnModal(iss); setReturnNotes(''); setReturnStatus('returned') }}
                          >
                            <i className='ki-duotone ki-check fs-5 me-1'><span className='path1' /><span className='path2' /></i>
                            Return
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Issue Modal */}
        <Modal show={showIssueModal} onHide={() => setShowIssueModal(false)} centered size='lg'>
          <Modal.Header closeButton className='border-0 pb-0'>
            <Modal.Title className='fw-bold text-gray-800'>Issue Inventory Item</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {formError && <div className='alert alert-danger py-3 fs-7 mb-4'>{formError}</div>}
            <div className='row g-5'>
              <div className='col-md-6'>
                <label className='required fw-semibold fs-7 text-gray-700 mb-2 d-block'>Select Item</label>
                <select
                  className='form-select form-select-solid'
                  value={form.item_id}
                  onChange={e => setForm(p => ({ ...p, item_id: e.target.value }))}
                >
                  <option value=''>Select item...</option>
                  {items.map(i => (
                    <option key={i.id} value={i.id}>
                      {i.name} ({i.current_stock} {i.unit} available)
                    </option>
                  ))}
                </select>
                {selectedItem && (
                  <div className='mt-2 text-muted fs-8'>
                    Available: <span className='fw-bold text-success'>{selectedItem.current_stock} {selectedItem.unit}</span>
                  </div>
                )}
              </div>
              <div className='col-md-3'>
                <label className='required fw-semibold fs-7 text-gray-700 mb-2 d-block'>Quantity</label>
                <input
                  type='number' min='1'
                  max={selectedItem?.current_stock || 999}
                  className='form-control form-control-solid'
                  value={form.quantity}
                  onChange={e => setForm(p => ({ ...p, quantity: Number(e.target.value) }))}
                />
              </div>
              <div className='col-md-3'>
                <label className='required fw-semibold fs-7 text-gray-700 mb-2 d-block'>Issue Date</label>
                <input
                  type='date'
                  className='form-control form-control-solid'
                  value={form.issue_date}
                  onChange={e => setForm(p => ({ ...p, issue_date: e.target.value }))}
                />
              </div>
              <div className='col-md-4'>
                <label className='required fw-semibold fs-7 text-gray-700 mb-2 d-block'>Recipient Type</label>
                <select
                  className='form-select form-select-solid'
                  value={form.issued_to_type}
                  onChange={e => setForm(p => ({ ...p, issued_to_type: e.target.value as any }))}
                >
                  <option value='student'>Student</option>
                  <option value='teacher'>Teacher</option>
                  <option value='staff'>Staff</option>
                </select>
              </div>
              <div className='col-md-4'>
                <label className='required fw-semibold fs-7 text-gray-700 mb-2 d-block'>Recipient ID</label>
                <input
                  type='number'
                  className='form-control form-control-solid'
                  placeholder='Enter ID...'
                  value={form.issued_to_id}
                  onChange={e => setForm(p => ({ ...p, issued_to_id: e.target.value }))}
                />
              </div>
              <div className='col-md-4'>
                <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Recipient Name</label>
                <input
                  type='text'
                  className='form-control form-control-solid'
                  placeholder='Name (optional)...'
                  value={form.issued_to_name}
                  onChange={e => setForm(p => ({ ...p, issued_to_name: e.target.value }))}
                />
              </div>
              <div className='col-md-6'>
                <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Expected Return Date</label>
                <input
                  type='date'
                  className='form-control form-control-solid'
                  value={form.expected_return_date}
                  onChange={e => setForm(p => ({ ...p, expected_return_date: e.target.value }))}
                />
              </div>
              <div className='col-md-6'>
                <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Notes</label>
                <input
                  type='text'
                  className='form-control form-control-solid'
                  placeholder='Optional notes...'
                  value={form.notes}
                  onChange={e => setForm(p => ({ ...p, notes: e.target.value }))}
                />
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer className='border-0'>
            <Button variant='light' onClick={() => setShowIssueModal(false)}>Cancel</Button>
            <Button variant='primary' onClick={handleIssue} disabled={saving}>
              {saving ? <><span className='spinner-border spinner-border-sm me-2' />Issuing...</> : 'Issue Item'}
            </Button>
          </Modal.Footer>
        </Modal>

        {/* Return Modal */}
        <Modal show={!!returnModal} onHide={() => setReturnModal(null)} centered>
          <Modal.Header closeButton className='border-0 pb-0'>
            <Modal.Title className='fw-bold text-gray-800'>Return / Mark Lost</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {returnModal && (
              <div>
                <div className='bg-light rounded p-4 mb-5'>
                  <div className='row g-3'>
                    <div className='col-6'>
                      <div className='text-muted fs-8'>Item</div>
                      <div className='fw-bold text-gray-800'>{returnModal.item?.name}</div>
                    </div>
                    <div className='col-6'>
                      <div className='text-muted fs-8'>Issued To</div>
                      <div className='fw-bold text-gray-800'>{returnModal.issued_to_name || `ID: ${returnModal.issued_to_id}`}</div>
                    </div>
                    <div className='col-6'>
                      <div className='text-muted fs-8'>Quantity</div>
                      <div className='fw-bold text-gray-800'>{returnModal.quantity} {returnModal.item?.unit}</div>
                    </div>
                    <div className='col-6'>
                      <div className='text-muted fs-8'>Issue Date</div>
                      <div className='fw-bold text-gray-800'>
                        {new Date(returnModal.issue_date).toLocaleDateString('en-IN')}
                      </div>
                    </div>
                  </div>
                </div>
                <div className='mb-5'>
                  <label className='fw-semibold fs-7 text-gray-700 mb-3 d-block'>Mark As</label>
                  <div className='d-flex gap-3'>
                    <button
                      className={`btn flex-grow-1 ${returnStatus === 'returned' ? 'btn-success' : 'btn-light-success'}`}
                      onClick={() => setReturnStatus('returned')}
                    >
                      <i className='ki-duotone ki-check-circle fs-4 me-2'><span className='path1' /><span className='path2' /></i>
                      Returned
                    </button>
                    <button
                      className={`btn flex-grow-1 ${returnStatus === 'lost' ? 'btn-danger' : 'btn-light-danger'}`}
                      onClick={() => setReturnStatus('lost')}
                    >
                      <i className='ki-duotone ki-cross-circle fs-4 me-2'><span className='path1' /><span className='path2' /></i>
                      Lost / Damaged
                    </button>
                  </div>
                </div>
                <div>
                  <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Notes</label>
                  <textarea
                    className='form-control form-control-solid'
                    rows={2}
                    placeholder='Optional notes...'
                    value={returnNotes}
                    onChange={e => setReturnNotes(e.target.value)}
                  />
                </div>
              </div>
            )}
          </Modal.Body>
          <Modal.Footer className='border-0'>
            <Button variant='light' onClick={() => setReturnModal(null)}>Cancel</Button>
            <Button
              variant={returnStatus === 'returned' ? 'success' : 'danger'}
              onClick={handleReturn}
              disabled={returning}
            >
              {returning
                ? <><span className='spinner-border spinner-border-sm me-2' />Processing...</>
                : returnStatus === 'returned' ? 'Confirm Return' : 'Mark as Lost'
              }
            </Button>
          </Modal.Footer>
        </Modal>

      </Content>
    </>
  )
}

const IssuanceWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[
      { title: 'Inventory', path: '/inventory/dashboard', isActive: false },
      { title: 'Issue & Return', path: '/inventory/issuance', isActive: true },
    ]}>
      Issue & Return
    </PageTitle>
    <IssuancePage />
  </>
)

export { IssuanceWrapper }
