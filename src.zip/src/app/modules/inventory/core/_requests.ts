import axios from 'axios'

const API_URL = import.meta.env.VITE_APP_API_URL

const BASE = (schoolId: string | number) =>
  `${API_URL}/school/${schoolId}/inventory`

// ==================== Dashboard ====================
export const getInventoryDashboard = (schoolId: string | number) =>
  axios.get(`${BASE(schoolId)}/dashboard`)

// ==================== Categories ====================
export const getCategories = (schoolId: string | number) =>
  axios.get(`${BASE(schoolId)}/categories`)

export const createCategory = (schoolId: string | number, data: { name: string; description?: string }) =>
  axios.post(`${BASE(schoolId)}/categories`, data)

export const updateCategory = (schoolId: string | number, id: number, data: object) =>
  axios.patch(`${BASE(schoolId)}/categories/${id}`, data)

export const deleteCategory = (schoolId: string | number, id: number) =>
  axios.delete(`${BASE(schoolId)}/categories/${id}`)

// ==================== Items ====================
export const getItems = (schoolId: string | number, params?: { category_id?: number; search?: string; low_stock?: boolean }) =>
  axios.get(`${BASE(schoolId)}/items`, { params })

export const getItemById = (schoolId: string | number, id: number) =>
  axios.get(`${BASE(schoolId)}/items/${id}`)

export const createItem = (schoolId: string | number, data: {
  name: string
  category_id?: number
  description?: string
  unit?: string
  min_stock_alert?: number
  purchase_price?: number
}) => axios.post(`${BASE(schoolId)}/items`, data)

export const updateItem = (schoolId: string | number, id: number, data: object) =>
  axios.patch(`${BASE(schoolId)}/items/${id}`, data)

export const deleteItem = (schoolId: string | number, id: number) =>
  axios.delete(`${BASE(schoolId)}/items/${id}`)

// ==================== Stock ====================
export const getStockHistory = (schoolId: string | number, itemId: number) =>
  axios.get(`${BASE(schoolId)}/stock/${itemId}/history`)

export const addStock = (schoolId: string | number, itemId: number, data: {
  quantity: number
  reference_no?: string
  notes?: string
  date?: string
}) => axios.post(`${BASE(schoolId)}/stock/${itemId}/add`, data)

export const adjustStock = (schoolId: string | number, itemId: number, data: {
  new_quantity: number
  notes?: string
}) => axios.post(`${BASE(schoolId)}/stock/${itemId}/adjust`, data)

// ==================== Alerts ====================
export const getLowStockAlerts = (schoolId: string | number) =>
  axios.get(`${BASE(schoolId)}/alerts/low-stock`)

// ==================== Issuances ====================
export const getIssuances = (schoolId: string | number, params?: {
  status?: string
  item_id?: number
  issued_to_type?: string
}) => axios.get(`${BASE(schoolId)}/issuances`, { params })

export const issueItem = (schoolId: string | number, data: {
  item_id: number
  issued_to_type: 'student' | 'teacher' | 'staff'
  issued_to_id: number
  issued_to_name?: string
  quantity: number
  issue_date?: string
  expected_return_date?: string
  notes?: string
}) => axios.post(`${BASE(schoolId)}/issuances`, data)

export const returnItem = (schoolId: string | number, issuanceId: number, data?: {
  notes?: string
  status?: 'returned' | 'lost'
}) => axios.patch(`${BASE(schoolId)}/issuances/${issuanceId}/return`, data || {})
