import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { Modal, Button } from 'react-bootstrap'
import { useAuth } from '../auth'
import {
  getItems, getCategories, createItem, updateItem, deleteItem,
  addStock, adjustStock, getStockHistory,
} from './core/_requests'

const UNITS = ['pcs', 'kg', 'ltr', 'box', 'set', 'pair', 'ream', 'meter']

const emptyForm = {
  name: '', category_id: '', description: '', unit: 'pcs',
  min_stock_alert: 5, purchase_price: '',
}

const AssetsPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [items, setItems] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterCat, setFilterCat] = useState('')
  const [filterLow, setFilterLow] = useState(false)

  // Modals
  const [showItemModal, setShowItemModal] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [form, setForm] = useState({ ...emptyForm })
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)

  const [showStockModal, setShowStockModal] = useState(false)
  const [stockItem, setStockItem] = useState<any>(null)
  const [stockHistory, setStockHistory] = useState<any[]>([])
  const [stockForm, setStockForm] = useState({ quantity: '', notes: '', reference_no: '' })
  const [stockMode, setStockMode] = useState<'add' | 'adjust'>('add')
  const [stockSaving, setStockSaving] = useState(false)

  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null)

  const loadData = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    try {
      const [itemsRes, catsRes] = await Promise.all([
        getItems(schoolId, {
          category_id: filterCat ? Number(filterCat) : undefined,
          search: search || undefined,
          low_stock: filterLow || undefined,
        }),
        getCategories(schoolId),
      ])
      if (itemsRes.data.success) setItems(itemsRes.data.data)
      if (catsRes.data.success) setCategories(catsRes.data.data)
    } catch (e: any) {
      console.error('Failed to load inventory items', e)
    } finally {
      setLoading(false)
    }
  }, [schoolId, filterCat, search, filterLow])

  useEffect(() => { loadData() }, [loadData])

  const openCreate = () => {
    setEditItem(null)
    setForm({ ...emptyForm })
    setFormError(null)
    setShowItemModal(true)
  }

  const openEdit = (item: any) => {
    setEditItem(item)
    setForm({
      name: item.name, category_id: item.category_id || '',
      description: item.description || '', unit: item.unit || 'pcs',
      min_stock_alert: item.min_stock_alert || 5,
      purchase_price: item.purchase_price || '',
    })
    setFormError(null)
    setShowItemModal(true)
  }

  const handleSave = async () => {
    if (!form.name.trim()) { setFormError('Item name is required'); return }
    setSaving(true); setFormError(null)
    try {
      const payload = {
        ...form,
        category_id: form.category_id ? Number(form.category_id) : undefined,
        min_stock_alert: Number(form.min_stock_alert),
        purchase_price: form.purchase_price ? Number(form.purchase_price) : undefined,
      }
      if (editItem) {
        await updateItem(schoolId, editItem.id, payload)
      } else {
        await createItem(schoolId, payload as any)
      }
      setShowItemModal(false)
      loadData()
    } catch (e: any) {
      setFormError(e.response?.data?.message || 'Failed to save item')
    } finally { setSaving(false) }
  }

  const handleDelete = async (id: number) => {
    try {
      await deleteItem(schoolId, id)
      setDeleteConfirm(null)
      loadData()
    } catch { }
  }

  const openStockModal = async (item: any, mode: 'add' | 'adjust') => {
    setStockItem(item)
    setStockMode(mode)
    setStockForm({ quantity: mode === 'adjust' ? String(item.current_stock) : '', notes: '', reference_no: '' })
    setShowStockModal(true)
    try {
      const { data } = await getStockHistory(schoolId, item.id)
      if (data.success) setStockHistory(data.data)
    } catch { setStockHistory([]) }
  }

  const handleStockSave = async () => {
    if (!stockForm.quantity) return
    setStockSaving(true)
    try {
      if (stockMode === 'add') {
        await addStock(schoolId, stockItem.id, {
          quantity: Number(stockForm.quantity),
          notes: stockForm.notes,
          reference_no: stockForm.reference_no,
        })
      } else {
        await adjustStock(schoolId, stockItem.id, {
          new_quantity: Number(stockForm.quantity),
          notes: stockForm.notes,
        })
      }
      setShowStockModal(false)
      loadData()
    } catch (e: any) {
      alert(e.response?.data?.message || 'Stock update failed')
    } finally { setStockSaving(false) }
  }

  const stockStatus = (item: any) => {
    if (item.current_stock === 0) return { label: 'Out of Stock', color: 'danger' }
    if (item.current_stock <= item.min_stock_alert) return { label: 'Low Stock', color: 'warning' }
    return { label: 'In Stock', color: 'success' }
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* Header */}
        <div className='d-flex align-items-center justify-content-between mb-6'>
          <div>
            <h1 className='fw-bold text-gray-800 fs-2 mb-1'>Inventory Items</h1>
            <span className='text-muted fs-6'>Manage all school inventory items</span>
          </div>
          <button className='btn btn-primary' onClick={openCreate}>
            <i className='ki-duotone ki-plus fs-4 me-2'>
              <span className='path1' /><span className='path2' />
            </i>
            Add Item
          </button>
        </div>

        {/* Filters */}
        <div className='card mb-5' style={{ borderRadius: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
          <div className='card-body py-4 d-flex flex-wrap gap-4 align-items-center'>
            {/* Search */}
            <div className='position-relative'>
              <i className='ki-duotone ki-magnifier fs-4 position-absolute ms-3 text-gray-400' style={{ top: '50%', transform: 'translateY(-50%)' }}>
                <span className='path1' /><span className='path2' />
              </i>
              <input
                type='text'
                className='form-control form-control-solid ps-12'
                style={{ width: 260 }}
                placeholder='Search items...'
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>

            {/* Category filter */}
            <select
              className='form-select form-select-solid'
              style={{ width: 200 }}
              value={filterCat}
              onChange={e => setFilterCat(e.target.value)}
            >
              <option value=''>All Categories</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>

            {/* Low stock toggle */}
            <div className='form-check form-switch ms-2'>
              <input
                className='form-check-input'
                type='checkbox'
                id='lowStockFilter'
                checked={filterLow}
                onChange={e => setFilterLow(e.target.checked)}
              />
              <label className='form-check-label fw-semibold text-gray-600 fs-7' htmlFor='lowStockFilter'>
                Low Stock Only
              </label>
            </div>

            <div className='ms-auto text-muted fw-semibold fs-7'>
              {items.length} items
            </div>
          </div>
        </div>

        {/* Table */}
        <div className='card' style={{ borderRadius: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
          <div className='card-body p-0'>
            <div className='table-responsive'>
              <table className='table table-row-dashed align-middle gs-0 gy-0 fs-7'>
                <thead>
                  <tr className='text-uppercase text-muted fw-bold fs-8 border-bottom border-gray-200'>
                    <th className='ps-7 py-5 w-50px'>#</th>
                    <th className='py-5'>Item Name</th>
                    <th className='py-5'>Category</th>
                    <th className='py-5'>Unit</th>
                    <th className='py-5'>Current Stock</th>
                    <th className='py-5'>Min Alert</th>
                    <th className='py-5'>Status</th>
                    <th className='py-5 text-end pe-7'>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={8} className='text-center py-16'>
                        <span className='spinner-border text-primary me-2' />
                        <span className='text-muted fs-6'>Loading items...</span>
                      </td>
                    </tr>
                  ) : items.length === 0 ? (
                    <tr>
                      <td colSpan={8} className='py-16'>
                        <div className='d-flex flex-column align-items-center'>
                          <i className='ki-duotone ki-package fs-5x text-gray-300 mb-4'>
                            <span className='path1' /><span className='path2' /><span className='path3' />
                          </i>
                          <span className='text-gray-600 fw-semibold fs-5'>No items found</span>
                          <span className='text-muted fs-7 mt-2'>Add your first inventory item</span>
                        </div>
                      </td>
                    </tr>
                  ) : items.map((item, idx) => {
                    const status = stockStatus(item)
                    return (
                      <tr key={item.id} className='border-bottom border-gray-100'>
                        <td className='ps-7 text-gray-400 fw-semibold'>{idx + 1}</td>
                        <td>
                          <div className='d-flex align-items-center gap-3'>
                            <div
                              className='w-38px h-38px d-flex align-items-center justify-content-center rounded'
                              style={{ background: '#e8f0fe' }}
                            >
                              <i className='ki-duotone ki-package fs-4 text-primary'>
                                <span className='path1' /><span className='path2' /><span className='path3' />
                              </i>
                            </div>
                            <div>
                              <div className='fw-semibold text-gray-800'>{item.name}</div>
                              {item.description && (
                                <div className='text-muted fs-8'>{item.description.substring(0, 50)}{item.description.length > 50 ? '...' : ''}</div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td>
                          <span className='badge badge-light-info fs-8 fw-semibold'>
                            {item.category?.name || '—'}
                          </span>
                        </td>
                        <td className='text-gray-600 fw-semibold'>{item.unit}</td>
                        <td>
                          <span className={`fw-bold fs-5 text-${status.color}`}>
                            {item.current_stock}
                          </span>
                          <span className='text-muted fs-8 ms-1'>{item.unit}</span>
                        </td>
                        <td className='text-muted'>{item.min_stock_alert}</td>
                        <td>
                          <span className={`badge badge-light-${status.color} fw-semibold fs-8`}>
                            {status.label}
                          </span>
                        </td>
                        <td className='text-end pe-7'>
                          <div className='d-flex align-items-center gap-2 justify-content-end'>
                            <button
                              className='btn btn-sm btn-light-success py-2 px-3'
                              title='Add Stock'
                              onClick={() => openStockModal(item, 'add')}
                            >
                              <i className='ki-duotone ki-plus fs-5 me-1'><span className='path1' /><span className='path2' /></i>
                              Add Stock
                            </button>
                            <button
                              className='btn btn-sm btn-icon btn-light-primary'
                              title='Edit'
                              onClick={() => openEdit(item)}
                            >
                              <i className='ki-duotone ki-pencil fs-5'><span className='path1' /><span className='path2' /></i>
                            </button>
                            <button
                              className='btn btn-sm btn-icon btn-light-danger'
                              title='Delete'
                              onClick={() => setDeleteConfirm(item.id)}
                            >
                              <i className='ki-duotone ki-trash fs-5'><span className='path1' /><span className='path2' /></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Add/Edit Item Modal */}
        <Modal show={showItemModal} onHide={() => setShowItemModal(false)} centered size='lg'>
          <Modal.Header closeButton className='border-0 pb-0'>
            <Modal.Title className='fw-bold text-gray-800'>
              {editItem ? 'Edit Item' : 'Add New Item'}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className='pt-4'>
            {formError && (
              <div className='alert alert-danger py-3 fs-7 mb-4'>{formError}</div>
            )}
            <div className='row g-5'>
              <div className='col-md-8'>
                <label className='required fw-semibold fs-7 text-gray-700 mb-2 d-block'>Item Name</label>
                <input
                  type='text'
                  className='form-control form-control-solid'
                  placeholder='e.g. A4 Paper Ream'
                  value={form.name}
                  onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                />
              </div>
              <div className='col-md-4'>
                <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Unit</label>
                <select
                  className='form-select form-select-solid'
                  value={form.unit}
                  onChange={e => setForm(p => ({ ...p, unit: e.target.value }))}
                >
                  {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
              <div className='col-md-6'>
                <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Category</label>
                <select
                  className='form-select form-select-solid'
                  value={form.category_id}
                  onChange={e => setForm(p => ({ ...p, category_id: e.target.value }))}
                >
                  <option value=''>— No Category —</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className='col-md-3'>
                <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Min Stock Alert</label>
                <input
                  type='number' min='0'
                  className='form-control form-control-solid'
                  value={form.min_stock_alert}
                  onChange={e => setForm(p => ({ ...p, min_stock_alert: Number(e.target.value) }))}
                />
              </div>
              <div className='col-md-3'>
                <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Purchase Price (₹)</label>
                <input
                  type='number' min='0' step='0.01'
                  className='form-control form-control-solid'
                  placeholder='Optional'
                  value={form.purchase_price}
                  onChange={e => setForm(p => ({ ...p, purchase_price: e.target.value }))}
                />
              </div>
              <div className='col-12'>
                <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Description</label>
                <textarea
                  className='form-control form-control-solid'
                  rows={3}
                  placeholder='Optional description...'
                  value={form.description}
                  onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                />
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer className='border-0'>
            <Button variant='light' onClick={() => setShowItemModal(false)}>Cancel</Button>
            <Button variant='primary' onClick={handleSave} disabled={saving}>
              {saving ? <><span className='spinner-border spinner-border-sm me-2' />Saving...</> : 'Save Item'}
            </Button>
          </Modal.Footer>
        </Modal>

        {/* Stock Modal */}
        <Modal show={showStockModal} onHide={() => setShowStockModal(false)} centered size='lg'>
          <Modal.Header closeButton className='border-0 pb-0'>
            <Modal.Title className='fw-bold text-gray-800'>
              {stockMode === 'add' ? 'Add Stock' : 'Adjust Stock'} — {stockItem?.name}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className='row g-5'>
              <div className='col-md-6'>
                <div className='bg-light-primary rounded p-4 mb-5'>
                  <div className='text-muted fs-8 mb-1'>Current Stock</div>
                  <div className='fw-bold text-primary fs-1'>{stockItem?.current_stock} {stockItem?.unit}</div>
                </div>
                <div className='row g-4'>
                  <div className='col-12'>
                    <label className='required fw-semibold fs-7 text-gray-700 mb-2 d-block'>
                      {stockMode === 'add' ? 'Quantity to Add' : 'New Stock Quantity'}
                    </label>
                    <input
                      type='number' min='0'
                      className='form-control form-control-solid'
                      value={stockForm.quantity}
                      onChange={e => setStockForm(p => ({ ...p, quantity: e.target.value }))}
                    />
                  </div>
                  {stockMode === 'add' && (
                    <div className='col-12'>
                      <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Reference No.</label>
                      <input
                        type='text'
                        className='form-control form-control-solid'
                        placeholder='Invoice/PO number...'
                        value={stockForm.reference_no}
                        onChange={e => setStockForm(p => ({ ...p, reference_no: e.target.value }))}
                      />
                    </div>
                  )}
                  <div className='col-12'>
                    <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Notes</label>
                    <textarea
                      className='form-control form-control-solid'
                      rows={2}
                      value={stockForm.notes}
                      onChange={e => setStockForm(p => ({ ...p, notes: e.target.value }))}
                    />
                  </div>
                </div>
              </div>
              <div className='col-md-6'>
                <div className='fw-semibold text-gray-700 fs-7 mb-3'>Recent Movements</div>
                {stockHistory.length === 0 ? (
                  <div className='text-muted fs-7 text-center py-8'>No stock history</div>
                ) : (
                  <div style={{ maxHeight: 280, overflowY: 'auto' }}>
                    {stockHistory.slice(0, 15).map((h: any) => (
                      <div key={h.id} className='d-flex align-items-center justify-content-between py-3 border-bottom border-gray-100'>
                        <div>
                          <span className={`badge badge-light-${h.type === 'IN' ? 'success' : h.type === 'OUT' ? 'danger' : 'warning'} me-2`}>
                            {h.type}
                          </span>
                          <span className='text-gray-600 fs-8'>{h.notes || '—'}</span>
                        </div>
                        <div className='text-end'>
                          <div className={`fw-bold ${h.type === 'IN' ? 'text-success' : 'text-danger'}`}>
                            {h.type === 'IN' ? '+' : '-'}{h.quantity}
                          </div>
                          <div className='text-muted fs-9'>{new Date(h.date).toLocaleDateString('en-IN')}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer className='border-0'>
            <Button variant='light' onClick={() => setShowStockModal(false)}>Cancel</Button>
            <button
              className={`btn btn-${stockMode === 'add' ? 'success' : 'warning'}`}
              onClick={handleStockSave}
              disabled={stockSaving || !stockForm.quantity}
            >
              {stockSaving
                ? <><span className='spinner-border spinner-border-sm me-2' />Saving...</>
                : stockMode === 'add' ? 'Add Stock' : 'Adjust Stock'
              }
            </button>
          </Modal.Footer>
        </Modal>

        {/* Delete Confirm Modal */}
        <Modal show={!!deleteConfirm} onHide={() => setDeleteConfirm(null)} centered>
          <Modal.Body className='text-center py-10'>
            <i className='ki-duotone ki-warning-2 fs-5x text-danger mb-4'><span className='path1' /><span className='path2' /></i>
            <h4 className='fw-bold text-gray-800 mb-3'>Deactivate Item?</h4>
            <p className='text-muted fs-6 mb-7'>This item will be marked as inactive. Stock history will be preserved.</p>
            <div className='d-flex justify-content-center gap-3'>
              <Button variant='light' onClick={() => setDeleteConfirm(null)}>Cancel</Button>
              <Button variant='danger' onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>
                Yes, Deactivate
              </Button>
            </div>
          </Modal.Body>
        </Modal>

      </Content>
    </>
  )
}

const AssetsWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[
      { title: 'Inventory', path: '/inventory/dashboard', isActive: false },
      { title: 'Items', path: '/inventory/items', isActive: true },
    ]}>
      Inventory Items
    </PageTitle>
    <AssetsPage />
  </>
)

export { AssetsWrapper }
