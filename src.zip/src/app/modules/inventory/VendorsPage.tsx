import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { Modal, Button } from 'react-bootstrap'
import { useAuth } from '../auth'
import { getCategories, createCategory, updateCategory, deleteCategory } from './core/_requests'

const VendorsPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const [showModal, setShowModal] = useState(false)
  const [editCat, setEditCat] = useState<any>(null)
  const [form, setForm] = useState({ name: '', description: '' })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [deleteId, setDeleteId] = useState<number | null>(null)

  const loadCategories = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    try {
      const { data } = await getCategories(schoolId)
      if (data.success) setCategories(data.data)
    } catch { }
    finally { setLoading(false) }
  }, [schoolId])

  useEffect(() => { loadCategories() }, [loadCategories])

  const openCreate = () => {
    setEditCat(null)
    setForm({ name: '', description: '' })
    setError(null)
    setShowModal(true)
  }

  const openEdit = (cat: any) => {
    setEditCat(cat)
    setForm({ name: cat.name, description: cat.description || '' })
    setError(null)
    setShowModal(true)
  }

  const handleSave = async () => {
    if (!form.name.trim()) { setError('Category name is required'); return }
    setSaving(true); setError(null)
    try {
      if (editCat) {
        await updateCategory(schoolId, editCat.id, form)
      } else {
        await createCategory(schoolId, form)
      }
      setShowModal(false)
      loadCategories()
    } catch (e: any) {
      setError(e.response?.data?.message || 'Failed to save')
    } finally { setSaving(false) }
  }

  const handleDelete = async (id: number) => {
    try {
      await deleteCategory(schoolId, id)
      setDeleteId(null)
      loadCategories()
    } catch { }
  }

  const colorPalette = [
    '#e8f0fe', '#e0f7fa', '#fff3e0', '#fce4ec', '#e8f5e9',
    '#f3e5f5', '#e3f2fd', '#fff8e1', '#fbe9e7', '#e0f2f1',
  ]
  const textColors = [
    '#1a73e8', '#00838f', '#ef6c00', '#c2185b', '#2e7d32',
    '#6a1b9a', '#1565c0', '#f57f17', '#bf360c', '#00695c',
  ]

  return (
    <>
      <ToolbarWrapper />
      <Content>
        <div className='d-flex align-items-center justify-content-between mb-6'>
          <div>
            <h1 className='fw-bold text-gray-800 fs-2 mb-1'>Item Categories</h1>
            <span className='text-muted fs-6'>Organize inventory items by category</span>
          </div>
          <button className='btn btn-primary' onClick={openCreate}>
            <i className='ki-duotone ki-plus fs-4 me-2'><span className='path1' /><span className='path2' /></i>
            Add Category
          </button>
        </div>

        {loading ? (
          <div className='d-flex align-items-center justify-content-center py-20'>
            <span className='spinner-border text-primary me-3' />
            <span className='text-muted fw-semibold'>Loading categories...</span>
          </div>
        ) : categories.length === 0 ? (
          <div className='text-center py-20'>
            <i className='ki-duotone ki-category fs-5x text-gray-300 mb-4'><span className='path1' /><span className='path2' /><span className='path3' /><span className='path4' /></i>
            <div className='text-gray-600 fw-semibold fs-5'>No categories yet</div>
            <div className='text-muted fs-7 mt-2'>Add your first category to organize inventory</div>
          </div>
        ) : (
          <div className='row g-5'>
            {categories.map((cat, idx) => {
              const bg = colorPalette[idx % colorPalette.length]
              const tc = textColors[idx % textColors.length]
              return (
                <div key={cat.id} className='col-sm-6 col-xl-4'>
                  <div
                    className='card border-0 h-100'
                    style={{ borderRadius: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}
                  >
                    <div className='card-body p-6'>
                      <div className='d-flex align-items-start justify-content-between mb-4'>
                        <div
                          className='w-50px h-50px rounded-circle d-flex align-items-center justify-content-center flex-shrink-0'
                          style={{ background: bg }}
                        >
                          <span className='fw-bold fs-3' style={{ color: tc }}>
                            {cat.name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div className='d-flex gap-2'>
                          <button
                            className='btn btn-sm btn-icon btn-light-primary'
                            onClick={() => openEdit(cat)}
                          >
                            <i className='ki-duotone ki-pencil fs-5'><span className='path1' /><span className='path2' /></i>
                          </button>
                          <button
                            className='btn btn-sm btn-icon btn-light-danger'
                            onClick={() => setDeleteId(cat.id)}
                          >
                            <i className='ki-duotone ki-trash fs-5'><span className='path1' /><span className='path2' /></i>
                          </button>
                        </div>
                      </div>
                      <h5 className='fw-bold text-gray-800 mb-2'>{cat.name}</h5>
                      <p className='text-muted fs-7 mb-0'>
                        {cat.description || 'No description provided'}
                      </p>
                      <div className='mt-4'>
                        <span className={`badge badge-light-${cat.is_active ? 'success' : 'danger'} fs-8`}>
                          {cat.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Add/Edit Modal */}
        <Modal show={showModal} onHide={() => setShowModal(false)} centered>
          <Modal.Header closeButton className='border-0 pb-0'>
            <Modal.Title className='fw-bold text-gray-800'>
              {editCat ? 'Edit Category' : 'New Category'}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {error && <div className='alert alert-danger py-3 fs-7 mb-4'>{error}</div>}
            <div className='mb-5'>
              <label className='required fw-semibold fs-7 text-gray-700 mb-2 d-block'>Category Name</label>
              <input
                type='text'
                className='form-control form-control-solid'
                placeholder='e.g. Stationery, Uniforms, Books...'
                value={form.name}
                onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
              />
            </div>
            <div>
              <label className='fw-semibold fs-7 text-gray-700 mb-2 d-block'>Description</label>
              <textarea
                className='form-control form-control-solid'
                rows={3}
                placeholder='Optional description...'
                value={form.description}
                onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
              />
            </div>
          </Modal.Body>
          <Modal.Footer className='border-0'>
            <Button variant='light' onClick={() => setShowModal(false)}>Cancel</Button>
            <Button variant='primary' onClick={handleSave} disabled={saving}>
              {saving ? <><span className='spinner-border spinner-border-sm me-2' />Saving...</> : 'Save Category'}
            </Button>
          </Modal.Footer>
        </Modal>

        {/* Delete Confirm */}
        <Modal show={!!deleteId} onHide={() => setDeleteId(null)} centered>
          <Modal.Body className='text-center py-10'>
            <i className='ki-duotone ki-warning-2 fs-5x text-danger mb-4'><span className='path1' /><span className='path2' /></i>
            <h4 className='fw-bold text-gray-800 mb-3'>Delete Category?</h4>
            <p className='text-muted fs-6 mb-7'>This action cannot be undone.</p>
            <div className='d-flex justify-content-center gap-3'>
              <Button variant='light' onClick={() => setDeleteId(null)}>Cancel</Button>
              <Button variant='danger' onClick={() => deleteId && handleDelete(deleteId)}>Delete</Button>
            </div>
          </Modal.Body>
        </Modal>
      </Content>
    </>
  )
}

const VendorsWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[
      { title: 'Inventory', path: '/inventory/dashboard', isActive: false },
      { title: 'Categories', path: '/inventory/categories', isActive: true },
    ]}>
      Inventory Categories
    </PageTitle>
    <VendorsPage />
  </>
)

export { VendorsWrapper }
