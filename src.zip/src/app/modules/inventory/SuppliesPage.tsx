import { FC, useState, useEffect, useCallback } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import { getInventoryDashboard } from './core/_requests'

const SuppliesPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const loadDashboard = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    try {
      const { data } = await getInventoryDashboard(schoolId)
      if (data.success) setStats(data.data)
      else setError(data.message || 'Failed to load dashboard')
    } catch (e: any) {
      setError(e.response?.data?.message || 'Failed to load inventory dashboard')
    } finally {
      setLoading(false)
    }
  }, [schoolId])

  useEffect(() => { loadDashboard() }, [loadDashboard])

  const statCards = stats ? [
    { label: 'Total Items', value: stats.totalItems, icon: 'ki-package', color: 'primary', bg: '#e8f0fe' },
    { label: 'Categories', value: stats.totalCategories, icon: 'ki-category', color: 'info', bg: '#e0f7fa' },
    { label: 'Low Stock Alerts', value: stats.lowStockCount, icon: 'ki-warning-2', color: 'danger', bg: '#fdecea' },
    { label: 'Items Issued (Active)', value: stats.totalIssued, icon: 'ki-send', color: 'warning', bg: '#fff3e0' },
    { label: 'Items Returned', value: stats.totalReturned, icon: 'ki-check-circle', color: 'success', bg: '#e8f5e9' },
    { label: 'Issued Today', value: stats.issuedToday, icon: 'ki-calendar-8', color: 'dark', bg: '#f5f5f5' },
  ] : []

  return (
    <>
      <ToolbarWrapper />
      <Content>

        {/* Header */}
        <div className='d-flex align-items-center justify-content-between mb-7'>
          <div>
            <h1 className='fw-bold text-gray-800 fs-2 mb-1'>Inventory Dashboard</h1>
            <span className='text-muted fs-6'>School inventory overview & quick stats</span>
          </div>
          <button className='btn btn-sm btn-primary' onClick={loadDashboard}>
            <i className='ki-duotone ki-arrows-circle fs-5 me-2'>
              <span className='path1' /><span className='path2' />
            </i>
            Refresh
          </button>
        </div>

        {error && (
          <div className='alert alert-danger d-flex align-items-center mb-6 py-3'>
            <i className='ki-duotone ki-cross-circle fs-3 text-danger me-3'>
              <span className='path1' /><span className='path2' />
            </i>
            <span className='fw-semibold'>{error}</span>
          </div>
        )}

        {/* Stats Cards */}
        {loading ? (
          <div className='d-flex align-items-center justify-content-center py-20'>
            <span className='spinner-border text-primary me-3' />
            <span className='text-muted fw-semibold fs-5'>Loading inventory data...</span>
          </div>
        ) : (
          <>
            <div className='row g-5 mb-7'>
              {statCards.map(({ label, value, icon, color, bg }) => (
                <div key={label} className='col-sm-6 col-xl-4'>
                  <div
                    className='card border-0 h-100'
                    style={{ boxShadow: '0 2px 12px rgba(0,0,0,0.06)', borderRadius: 16 }}
                  >
                    <div className='card-body d-flex align-items-center gap-4 p-6'>
                      <div
                        className={`w-55px h-55px d-flex align-items-center justify-content-center rounded-circle flex-shrink-0`}
                        style={{ background: bg }}
                      >
                        <i className={`ki-duotone ${icon} fs-2 text-${color}`}>
                          <span className='path1' /><span className='path2' />
                        </i>
                      </div>
                      <div>
                        <div className={`fw-bold text-${color} fs-1`}>{value ?? 0}</div>
                        <div className='text-muted fw-semibold fs-7'>{label}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className='row g-5'>
              {/* Low Stock Alerts */}
              <div className='col-xl-5'>
                <div className='card h-100' style={{ borderRadius: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
                  <div className='card-header border-0 pt-6 pb-0'>
                    <div className='card-title'>
                      <i className='ki-duotone ki-warning-2 fs-2 text-danger me-3'>
                        <span className='path1' /><span className='path2' />
                      </i>
                      <span className='fw-bold text-gray-800 fs-5'>Low Stock Alerts</span>
                    </div>
                  </div>
                  <div className='card-body pt-4'>
                    {!stats?.lowStockList?.length ? (
                      <div className='text-center py-10'>
                        <i className='ki-duotone ki-check-circle fs-3x text-success mb-3'>
                          <span className='path1' /><span className='path2' />
                        </i>
                        <div className='text-muted fw-semibold fs-6'>All items are well stocked!</div>
                      </div>
                    ) : stats.lowStockList.map((item: any) => {
                      const pct = item.min_stock_alert > 0
                        ? Math.min((item.current_stock / item.min_stock_alert) * 100, 100)
                        : 0
                      const critical = item.current_stock === 0
                      return (
                        <div key={item.id} className='d-flex align-items-center mb-5'>
                          <div className='flex-grow-1 me-4'>
                            <div className='d-flex justify-content-between mb-2'>
                              <span className='fw-semibold text-gray-700 fs-7'>{item.name}</span>
                              <span className={`badge badge-light-${critical ? 'danger' : 'warning'} fs-8`}>
                                {item.current_stock} {item.unit}
                              </span>
                            </div>
                            <div className='progress h-6px'>
                              <div
                                className={`progress-bar bg-${critical ? 'danger' : 'warning'}`}
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                            <div className='text-muted fs-8 mt-1'>Min required: {item.min_stock_alert} {item.unit}</div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* Recent Issuances */}
              <div className='col-xl-7'>
                <div className='card h-100' style={{ borderRadius: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
                  <div className='card-header border-0 pt-6 pb-0'>
                    <div className='card-title'>
                      <i className='ki-duotone ki-send fs-2 text-primary me-3'>
                        <span className='path1' /><span className='path2' />
                      </i>
                      <span className='fw-bold text-gray-800 fs-5'>Recent Issuances</span>
                    </div>
                  </div>
                  <div className='card-body pt-4 p-0'>
                    {!stats?.recentIssuances?.length ? (
                      <div className='text-center py-10'>
                        <i className='ki-duotone ki-send fs-3x text-gray-300 mb-3'>
                          <span className='path1' /><span className='path2' />
                        </i>
                        <div className='text-muted fw-semibold fs-6'>No recent issuances</div>
                      </div>
                    ) : (
                      <div className='table-responsive'>
                        <table className='table table-row-dashed table-row-gray-100 align-middle gs-0 gy-3 fs-7'>
                          <thead>
                            <tr className='text-uppercase text-muted fw-bold fs-8'>
                              <th className='ps-7 py-4'>Item</th>
                              <th className='py-4'>Issued To</th>
                              <th className='py-4'>Type</th>
                              <th className='py-4'>Qty</th>
                              <th className='py-4'>Status</th>
                              <th className='py-4'>Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            {stats.recentIssuances.map((iss: any) => (
                              <tr key={iss.id}>
                                <td className='ps-7 fw-semibold text-gray-700'>
                                  {iss.item?.name || `Item #${iss.item_id}`}
                                </td>
                                <td className='text-gray-600'>{iss.issued_to_name || `ID: ${iss.issued_to_id}`}</td>
                                <td>
                                  <span className='badge badge-light-primary fs-8 fw-semibold'>
                                    {iss.issued_to_type}
                                  </span>
                                </td>
                                <td className='fw-bold'>
                                  {iss.quantity} {iss.item?.unit || 'pcs'}
                                </td>
                                <td>
                                  <span className={`badge badge-light-${
                                    iss.status === 'returned' ? 'success'
                                      : iss.status === 'lost' ? 'danger'
                                        : 'warning'
                                  } fs-8`}>
                                    {iss.status}
                                  </span>
                                </td>
                                <td className='text-muted'>
                                  {new Date(iss.issue_date).toLocaleDateString('en-IN', {
                                    day: '2-digit', month: 'short'
                                  })}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </Content>
    </>
  )
}

const SuppliesWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[{ title: 'Inventory', path: '/inventory/dashboard', isActive: true }]}>
      Inventory Dashboard
    </PageTitle>
    <SuppliesPage />
  </>
)

export { SuppliesWrapper }
