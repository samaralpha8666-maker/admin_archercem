import { FC, useState, useEffect, useCallback, useRef } from 'react'
import { createPortal } from 'react-dom'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { createSchool, getSchools, updateSchool, toggleSchoolStatus, deleteSchool } from '../auth/core/_requests'
import { SchoolModel } from '../auth/core/_models'

// ─────────────────────────────────────────────────────────────────────────────
// Debounce Hook — prevents rapid API calls on every keystroke
// ─────────────────────────────────────────────────────────────────────────────
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value)
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay)
    return () => clearTimeout(timer)
  }, [value, delay])
  return debouncedValue
}

// ─────────────────────────────────────────────────────────────────────────────
// School Create/Edit Modal
// Uses UNCONTROLLED inputs (defaultValue, not value) so React never touches
// the DOM on every keystroke — this prevents Metronic's MutationObserver
// from firing and causing the "Page Unresponsive" freeze loop.
// ─────────────────────────────────────────────────────────────────────────────
interface SchoolModalProps {
  show: boolean
  onHide: () => void
  editSchoolData: SchoolModel | null
  onSaveSuccess: (data: any, isEdit: boolean) => void
}

const SchoolModal: FC<SchoolModalProps> = ({ show, onHide, editSchoolData, onSaveSuccess }) => {
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const formRef = useRef<HTMLFormElement>(null)

  // Reset the form whenever the modal opens or switches school
  useEffect(() => {
    if (!show) return
    setError(null)
    requestAnimationFrame(() => {
      const f = formRef.current
      if (!f) return
      if (editSchoolData) {
        ; (f.elements.namedItem('name') as HTMLInputElement).value = editSchoolData.name || ''
          ; (f.elements.namedItem('code') as HTMLInputElement).value = editSchoolData.code || ''
          ; (f.elements.namedItem('subdomain') as HTMLInputElement).value = editSchoolData.subdomain || ''
          ; (f.elements.namedItem('email') as HTMLInputElement).value = editSchoolData.email || ''
          ; (f.elements.namedItem('phone') as HTMLInputElement).value = editSchoolData.phone || ''
          ; (f.elements.namedItem('address') as HTMLTextAreaElement).value = editSchoolData.address || ''
          ; (f.elements.namedItem('institution_type') as HTMLSelectElement).value =
            editSchoolData.institution_type || 'SCHOOL'
      } else {
        f.reset()
        const dbHost = f.elements.namedItem('db_host') as HTMLInputElement | null
        const dbPort = f.elements.namedItem('db_port') as HTMLInputElement | null
        const dbUser = f.elements.namedItem('db_username') as HTMLInputElement | null
        const dbName = f.elements.namedItem('db_name') as HTMLInputElement | null
        if (dbHost) dbHost.value = 'localhost'
        if (dbPort) dbPort.value = '5432'
        if (dbUser) dbUser.value = 'postgres'
        if (dbName) dbName.value = 'samar'
      }
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show, editSchoolData?.id])

  const handleSave = async () => {
    const f = formRef.current
    if (!f) return
    setSaving(true)
    setError(null)
    try {
      if (editSchoolData) {
        const fd = new FormData(f)
        const { data } = await updateSchool(editSchoolData.id, fd as any)
        if (data.success) {
          onSaveSuccess({ ...data.data.school }, true)
          onHide()
        }
      } else {
        const g = (name: string) =>
          (f.elements.namedItem(name) as HTMLInputElement)?.value?.trim() || ''
        const payload = {
          name: g('name'),
          code: g('code'),
          subdomain: g('subdomain'),
          institution_type: g('institution_type') || 'SCHOOL',
          db_name: g('db_name'),
          db_host: g('db_host'),
          db_port: Number(g('db_port')) || 5432,
          db_username: g('db_username'),
          db_password: g('db_password'),
          address: g('address'),
          phone: g('phone'),
          email: g('email'),
        }
        const { data } = await createSchool(payload)
        if (data.success) {
          onSaveSuccess({ ...data.data.school, principalName: 'Pending...' }, false)
          onHide()
        }
      }
    } catch (err: any) {
      const resData = err.response?.data
      // Extract most meaningful error message from the API response:
      // Priority: resData.message → resData.error → Sequelize errors[0].message → generic
      let msg: string =
        resData?.message ||
        resData?.error ||
        (Array.isArray(resData?.errors) && resData.errors[0]?.message) ||
        err.message ||
        'Failed to save school'
      // Clean up Sequelize "Validation error: " prefix if present
      msg = msg.replace(/^Validation error:\s*/i, '')
      setError(msg)
    } finally {
      setSaving(false)
    }
  }

  if (!show) return null

  // ── createPortal: renders modal directly into document.body ──────────────
  // This takes the modal completely OUTSIDE Metronic's component tree.
  // Metronic's MutationObserver watches the #root subtree — by rendering into
  // body, any DOM change inside the modal never triggers Metronic reinit,
  // eliminating the infinite loop / "Page Unresponsive" freeze when typing.
  return createPortal(
    <>
      {/* Backdrop */}
      <div className='modal-backdrop fade show' style={{ zIndex: 1050 }} />

      {/* Modal */}
      <div
        className='modal fade show d-block'
        style={{ zIndex: 1055 }}
        role='dialog'
        aria-modal='true'
        onClick={(e) => {
          if (e.target === e.currentTarget && !saving) onHide()
        }}
      >
        <div className='modal-dialog modal-lg modal-dialog-centered'>
          <div className='modal-content'>
            {/* Header */}
            <div className='modal-header'>
              <h5 className='modal-title fw-bold'>
                {editSchoolData ? 'Edit School' : 'Add New School'}
              </h5>
              {!saving && (
                <button type='button' className='btn-close' onClick={onHide} aria-label='Close' />
              )}
            </div>

            {/* Body */}
            <div
              className='modal-body py-8 px-lg-17'
              style={{ maxHeight: '70vh', overflowY: 'auto' }}
            >
              {error && (
                <div className='alert alert-danger d-flex align-items-center mb-6'>
                  <i className='ki-duotone ki-information-5 me-3 fs-3'>
                    <span className='path1'></span>
                    <span className='path2'></span>
                    <span className='path3'></span>
                  </i>
                  <span>{error}</span>
                  <button
                    type='button'
                    className='btn-close ms-auto'
                    onClick={() => setError(null)}
                  />
                </div>
              )}

              <form ref={formRef} onSubmit={(e) => e.preventDefault()} autoComplete='off'>
                {/* Name + Code */}
                <div className='row g-6 mb-6'>
                  <div className='col-md-6'>
                    <label className='fs-6 fw-semibold mb-2'>
                      School Name <span className='text-danger'>*</span>
                    </label>
                    <input
                      name='name'
                      defaultValue=''
                      className='form-control form-control-solid'
                      placeholder='e.g. Green Valley School'
                    />
                  </div>
                  <div className='col-md-6'>
                    <label className='fs-6 fw-semibold mb-2'>
                      School Code
                      <span className='text-muted fw-normal fs-7 ms-1'>(auto if blank)</span>
                    </label>
                    <input
                      name='code'
                      defaultValue=''
                      className='form-control form-control-solid'
                      placeholder='e.g. GVS001'
                      disabled={!!editSchoolData}
                    />
                  </div>
                </div>

                {/* Logo – edit only */}
                {editSchoolData && (
                  <div className='mb-6'>
                    <label className='fs-6 fw-semibold mb-2'>School Logo</label>
                    <input
                      type='file'
                      name='logo'
                      accept='.png,.jpg,.jpeg'
                      className='form-control form-control-solid'
                    />
                    <div className='form-text'>Allowed: png, jpg, jpeg</div>
                  </div>
                )}

                {/* Subdomain */}
                <div className='mb-6'>
                  <label className='fs-6 fw-semibold mb-2'>
                    Subdomain {!editSchoolData && <span className='text-danger'>*</span>}
                  </label>
                  <div className='input-group'>
                    <input
                      name='subdomain'
                      defaultValue=''
                      className='form-control form-control-solid'
                      placeholder='yourschool'
                      disabled={!!editSchoolData}
                      onChange={(e) => {
                        if (!editSchoolData) {
                          const val = e.target.value.toLowerCase().replace(/\./g, '_').replace(/-/g, '_');
                          const dbNameInput = formRef.current?.elements.namedItem('db_name') as HTMLInputElement | null;
                          if (dbNameInput) {
                            dbNameInput.value = val ? `school_${val}` : 'samar';
                          }
                        }
                      }}
                    />
                    <span className='input-group-text'>.eduadmin.com</span>
                  </div>
                  {/* Hint for subdomain format */}
                  {!editSchoolData && (
                    <div className='mt-2'>
                      <span className='text-muted fs-7'>
                        <i className='ki-duotone ki-information fs-7 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                        Allowed: lowercase letters, numbers, hyphens <code>-</code> and dots <code>.</code>
                      </span>
                      <div className='d-flex flex-wrap gap-2 mt-1'>
                        <span className='badge badge-light-success fs-8'>✓ greenvalley</span>
                        <span className='badge badge-light-success fs-8'>✓ my-school</span>
                        <span className='badge badge-light-success fs-8'>✓ myschool.com</span>
                        <span className='badge badge-light-success fs-8'>✓ school.in</span>
                        <span className='badge badge-light-danger fs-8'>✗ my school</span>
                        <span className='badge badge-light-danger fs-8'>✗ .myschool</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Email + Phone */}
                <div className='row g-6 mb-6'>
                  <div className='col-md-6'>
                    <label className='fs-6 fw-semibold mb-2'>
                      Email <span className='text-danger'>*</span>
                    </label>
                    <input
                      name='email'
                      type='email'
                      defaultValue=''
                      className='form-control form-control-solid'
                      placeholder='contact@school.com'
                    />
                  </div>
                  <div className='col-md-6'>
                    <label className='fs-6 fw-semibold mb-2'>
                      Phone <span className='text-danger'>*</span>
                    </label>
                    <input
                      name='phone'
                      defaultValue=''
                      className='form-control form-control-solid'
                      placeholder='Phone Number'
                    />
                  </div>
                </div>

                {/* Institution Type */}
                <div className='row g-6 mb-6'>
                  <div className='col-md-6'>
                    <label className='fs-6 fw-semibold mb-2'>
                      Institution Type <span className='text-danger'>*</span>
                    </label>
                    <select
                      name='institution_type'
                      defaultValue='SCHOOL'
                      className='form-select form-select-solid'
                      disabled={!!editSchoolData}
                    >
                      <option value='SCHOOL'>School</option>
                      <option value='COLLEGE'>College</option>
                      <option value='COACHING'>Coaching</option>
                    </select>
                  </div>
                </div>

                {/* Address */}
                <div className='mb-6'>
                  <label className='fs-6 fw-semibold mb-2'>
                    Address <span className='text-danger'>*</span>
                  </label>
                  <textarea
                    name='address'
                    defaultValue=''
                    className='form-control form-control-solid'
                    rows={2}
                    placeholder='School Address'
                  />
                </div>

                {/* DB Config – create only */}
                {!editSchoolData && (
                  <>
                    <div className='separator separator-dashed my-6' />
                    <h5 className='fw-bold mb-5'>Database Configuration</h5>

                    <div className='row g-6 mb-6'>
                      <div className='col-md-5'>
                        <label className='fs-6 fw-semibold mb-2'>
                          DB Host <span className='text-danger'>*</span>
                        </label>
                        <input
                          name='db_host'
                          defaultValue='localhost'
                          className='form-control form-control-solid'
                          placeholder='localhost'
                        />
                      </div>
                      <div className='col-md-5'>
                        <label className='fs-6 fw-semibold mb-2'>
                          DB Name <span className='text-danger'>*</span>
                        </label>
                        <input
                          name='db_name'
                          defaultValue='samar'
                          className='form-control form-control-solid'
                          placeholder='samar'
                        />
                      </div>
                      <div className='col-md-2'>
                        <label className='fs-6 fw-semibold mb-2'>
                          DB Port <span className='text-danger'>*</span>
                        </label>
                        <input
                          name='db_port'
                          type='number'
                          defaultValue='5432'
                          className='form-control form-control-solid'
                          placeholder='5432'
                        />
                      </div>
                    </div>

                    <div className='row g-6'>
                      <div className='col-md-6'>
                        <label className='fs-6 fw-semibold mb-2'>
                          DB Username <span className='text-danger'>*</span>
                        </label>
                        <input
                          name='db_username'
                          defaultValue='postgres'
                          className='form-control form-control-solid'
                          placeholder='postgres'
                        />
                      </div>
                      <div className='col-md-6'>
                        <label className='fs-6 fw-semibold mb-2'>DB Password</label>
                        <input
                          name='db_password'
                          type='password'
                          autoComplete='new-password'
                          defaultValue=''
                          className='form-control form-control-solid'
                          placeholder='DB Password'
                        />
                      </div>
                    </div>
                  </>
                )}
              </form>
            </div>

            {/* Footer */}
            <div className='modal-footer d-flex justify-content-center'>
              <button
                type='button'
                className='btn btn-light me-3'
                onClick={onHide}
                disabled={saving}
              >
                Cancel
              </button>
              <button
                type='button'
                className='btn btn-primary'
                onClick={handleSave}
                disabled={saving}
              >
                {saving ? (
                  <>
                    <span className='spinner-border spinner-border-sm me-2' role='status' />
                    Saving...
                  </>
                ) : editSchoolData ? (
                  'Save Changes'
                ) : (
                  'Add School'
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>,
    document.body   // ← portal target: outside Metronic's observed DOM
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Main Administration Page
// ─────────────────────────────────────────────────────────────────────────────
const AdministrationPage: FC = () => {
  const [schools, setSchools] = useState<SchoolModel[]>([])

  // ── Search: raw input state + debounced value ──────────────────────────────
  // searchInput drives the <input> UI instantly (no lag while typing).
  // search (debounced) is what actually triggers the API call after 400 ms of
  // inactivity — this is what kills the Metronic MutationObserver freeze loop.
  const [searchInput, setSearchInput] = useState('')
  const search = useDebounce(searchInput, 400)
  // ──────────────────────────────────────────────────────────────────────────

  const [showModal, setShowModal] = useState(false)
  const [editSchool, setEditSchool] = useState<SchoolModel | null>(null)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [pagination, setPagination] = useState({
    total: 0,
    totalPages: 0,
    hasNextPage: false,
    hasPrevPage: false,
  })

  // Reset to page 1 whenever the debounced search value changes
  useEffect(() => {
    setPage(1)
  }, [search])

  const fetchSchools = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await getSchools(page, pageSize, search)
      if (data.success) {
        setSchools(data.data.schools)
        setPagination(
          data.pagination || {


            // Badlo is se (correct):
            total: (data.data as any).total || 0,
            totalPages: (data.data as any).totalPages || 0,
            hasNextPage: false,
            hasPrevPage: false,
          }
        )
      }
    } catch (err: any) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }, [page, pageSize, search]) // ← only debounced 'search', not 'searchInput'

  useEffect(() => {
    fetchSchools()
  }, [fetchSchools])

  const openAddModal = () => {
    setEditSchool(null)
    setShowModal(true)
  }
  const openEditModal = (s: SchoolModel) => {
    setEditSchool(s)
    setShowModal(true)
  }
  const closeModal = useCallback(() => setShowModal(false), [])

  const handleSaveSuccess = useCallback((schoolData: any, isEdit: boolean) => {
    if (isEdit) {
      setSchools((prev) => prev.map((s) => (s.id === schoolData.id ? { ...s, ...schoolData } : s)))
    } else {
      setSchools((prev) => [...prev, schoolData])
      setPagination((prev) => ({ ...prev, total: prev.total + 1 }))
    }
  }, [])

  const handleToggle = async (school: SchoolModel) => {
    if (!window.confirm(`${school.is_active ? 'Deactivate' : 'Activate'} this school?`)) return
    try {
      const { data } = await toggleSchoolStatus(school.id)
      if (data.success)
        setSchools((prev) =>
          prev.map((s) => (s.id === school.id ? { ...s, is_active: !s.is_active } : s))
        )
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed')
    }
  }

  const handleDelete = async (id: number) => {
    if (!window.confirm('Permanently delete this school?')) return
    try {
      await deleteSchool(id, true)
      setSchools((prev) => prev.filter((s) => s.id !== id))
      setPagination((prev) => ({ ...prev, total: Math.max(0, prev.total - 1) }))
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed')
    }
  }

  return (
    <>
      <PageTitle breadcrumbs={[]}>Administration Dashboard</PageTitle>
      <ToolbarWrapper />
      <Content>
        {/* Stats */}
        <div className='row g-5 g-xl-10 mb-5 mb-xl-10'>
          <div className='col-md-3'>
            <div className='card border-0' style={{ backgroundColor: '#7DA0FA', borderRadius: 15 }}>
              <div className='card-body px-8 py-7'>
                <div className='text-white fw-medium fs-6 mb-2'>Total Schools</div>
                <div className='fs-2hx fw-bold text-white'>{pagination.total}</div>
                <div className='text-white opacity-75 fs-8'>Overall registered</div>
              </div>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='card border-0 bg-primary' style={{ borderRadius: 15 }}>
              <div className='card-body px-8 py-7'>
                <div className='text-white fw-medium fs-6 mb-2'>Active (This Page)</div>
                <div className='fs-2hx fw-bold text-white'>
                  {schools.filter((s) => s.is_active).length}
                </div>
                <div className='text-white opacity-75 fs-8'>Currently running</div>
              </div>
            </div>
          </div>
        </div>

        {/* Table Card */}
        <div className='card card-flush mt-6'>
          <div className='card-header align-items-center py-5 gap-2 gap-md-5'>
            <div className='card-title'>
              <div className='d-flex align-items-center position-relative my-1'>
                <i className='ki-duotone ki-magnifier fs-3 position-absolute ms-4'>
                  <span className='path1'></span>
                  <span className='path2'></span>
                </i>
                {/* 
                  IMPORTANT: searchInput (raw) controls UI — no debounce lag while typing.
                  API call only fires when debounced 'search' updates (400ms idle).
                */}
                <input
                  type='text'
                  className='form-control form-control-solid w-250px ps-12'
                  placeholder='Search School'
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                />
              </div>
            </div>
            <div className='card-toolbar'>
              <button className='btn btn-primary' onClick={openAddModal}>
                <i className='ki-duotone ki-plus fs-2'></i> Add School
              </button>
            </div>
          </div>

          <div className='card-body pt-0'>
            <table className='table align-middle table-row-dashed fs-6 gy-5'>
              <thead>
                <tr className='text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0'>
                  <th className='min-w-100px'>Code</th>
                  <th className='min-w-200px'>School Name</th>
                  <th className='min-w-150px'>Principal</th>
                  <th className='min-w-150px'>Subdomain</th>
                  <th className='min-w-100px'>Status</th>
                  <th className='text-end min-w-70px'>Actions</th>
                </tr>
              </thead>
              <tbody className='fw-semibold text-gray-600'>
                {loading ? (
                  <tr>
                    <td colSpan={6} className='text-center py-12'>
                      <span className='spinner-border spinner-border-sm align-middle me-2'></span>
                      Loading...
                    </td>
                  </tr>
                ) : schools.length === 0 ? (
                  <tr>
                    <td colSpan={6} className='text-center py-12 text-muted'>
                      No schools found
                    </td>
                  </tr>
                ) : (
                  schools.map((school) => (
                    <tr key={school.id}>
                      <td>
                        <span className='text-gray-800 fw-bold'>{school.code}</span>
                      </td>
                      <td>
                        <span className='text-gray-800 fs-6 fw-bold d-block'>{school.name}</span>
                        <span className='text-muted fs-7'>{school.email}</span>
                      </td>
                      <td>{school.principalName || 'N/A'}</td>
                      <td>
                        <span className='badge badge-light-primary'>
                          {school.subdomain}.eduadmin.com
                        </span>
                      </td>
                      <td>
                        <span
                          className={`badge badge-light-${school.is_active ? 'success' : 'danger'}`}
                        >
                          {school.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className='text-end'>
                        <div className='d-flex justify-content-end gap-1'>
                          <button
                            onClick={() => handleToggle(school)}
                            title={school.is_active ? 'Deactivate' : 'Activate'}
                            className={`btn btn-icon btn-sm btn-bg-light btn-active-color-${school.is_active ? 'warning' : 'success'
                              }`}
                          >
                            <i
                              className={`ki-duotone ${school.is_active ? 'ki-cross-circle' : 'ki-check-circle'
                                } fs-2`}
                            >
                              <span className='path1'></span>
                              <span className='path2'></span>
                            </i>
                          </button>
                          <button
                            onClick={() => openEditModal(school)}
                            title='Edit'
                            className='btn btn-icon btn-sm btn-bg-light btn-active-color-primary'
                          >
                            <i className='ki-duotone ki-pencil fs-2'>
                              <span className='path1'></span>
                              <span className='path2'></span>
                            </i>
                          </button>
                          <button
                            onClick={() => handleDelete(school.id)}
                            title='Delete'
                            className='btn btn-icon btn-sm btn-bg-light btn-active-color-danger'
                          >
                            <i className='ki-duotone ki-trash fs-2'>
                              <span className='path1'></span>
                              <span className='path2'></span>
                              <span className='path3'></span>
                              <span className='path4'></span>
                              <span className='path5'></span>
                            </i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            {/* Pagination */}
            <div className='row mt-5'>
              <div className='col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'>
                <select
                  className='form-select form-select-sm form-select-solid w-auto'
                  value={pageSize}
                  onChange={(e) => setPageSize(Number(e.target.value))}
                >
                  {[10, 25, 50, 100].map((n) => (
                    <option key={n} value={n}>
                      {n} / page
                    </option>
                  ))}
                </select>
              </div>
              <div className='col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'>
                <ul className='pagination mb-0'>
                  <li className={`page-item ${!pagination.hasPrevPage ? 'disabled' : ''}`}>
                    <button className='page-link' onClick={() => setPage((p) => p - 1)}>
                      <i className='previous'></i>
                    </button>
                  </li>
                  {[...Array(pagination.totalPages || 0)].map((_, i) => (
                    <li key={i} className={`page-item ${page === i + 1 ? 'active' : ''}`}>
                      <button className='page-link' onClick={() => setPage(i + 1)}>
                        {i + 1}
                      </button>
                    </li>
                  ))}
                  <li className={`page-item ${!pagination.hasNextPage ? 'disabled' : ''}`}>
                    <button className='page-link' onClick={() => setPage((p) => p + 1)}>
                      <i className='next'></i>
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </Content>

      <SchoolModal
        show={showModal}
        onHide={closeModal}
        editSchoolData={editSchool}
        onSaveSuccess={handleSaveSuccess}
      />
    </>
  )
}

export default AdministrationPage