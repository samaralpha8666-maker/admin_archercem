import axios from 'axios'
import {
  CreateTeacherPayload,
  UpdateTeacherProfilePayload,
  UpdateTeacherBankPayload,
  AddTeacherExperiencePayload,
  UpdateTeacherPermissionsPayload,
  TeacherResponse,
  TeachersListResponse,
  TeacherExperienceResponse,
  TeacherDocumentResponse,
  TeacherPermissionsResponse,
} from './_models'

const API_URL = import.meta.env.VITE_APP_API_URL

const TEACHERS_URL = (schoolId: string | number) =>
  `${API_URL}/school/${schoolId}/teachers`

const TEACHER_URL = (schoolId: string | number, teacherId: string | number) =>
  `${API_URL}/school/${schoolId}/teachers/${teacherId}`

// ─── CRUD ─────────────────────────────────────────────────────────────────────

export function createTeacher(schoolId: string | number, payload: CreateTeacherPayload) {
  return axios.post<TeacherResponse>(TEACHERS_URL(schoolId), payload)
}

export function updateTeacherCore(schoolId: string | number, teacherId: string | number, payload: Partial<CreateTeacherPayload>) {
  return axios.put<TeacherResponse>(TEACHER_URL(schoolId, teacherId), payload)
}

export function getTeachers(
  schoolId: string | number,
  params: { page?: number; limit?: number; search?: string } = {}
) {
  return axios.get<TeachersListResponse>(TEACHERS_URL(schoolId), {
    params: { page: 1, limit: 50, ...params },
  })
}

export function getTeacherById(schoolId: string | number, teacherId: string | number) {
  return axios.get<TeacherResponse>(TEACHER_URL(schoolId, teacherId))
}

export function toggleTeacherStatus(schoolId: string | number, teacherId: string | number) {
  return axios.patch<any>(`${TEACHER_URL(schoolId, teacherId)}/toggle-status`, {})
}

// ─── Profile / Bank ───────────────────────────────────────────────────────────

export function updateTeacherProfile(
  schoolId: string | number,
  teacherId: string | number,
  payload: UpdateTeacherProfilePayload,
  imageFile?: File | null
) {
  const formData = new FormData();
  Object.keys(payload).forEach(key => {
    const val = (payload as any)[key];
    if (val !== undefined && val !== null && val !== '') {
      formData.append(key, val);
    }
  });
  if (imageFile) {
    formData.append('profile_image', imageFile);
  }

  return axios.put<TeacherResponse>(`${TEACHER_URL(schoolId, teacherId)}/profile`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
}

export function updateTeacherBank(
  schoolId: string | number,
  teacherId: string | number,
  payload: UpdateTeacherBankPayload
) {
  return axios.put<TeacherResponse>(`${TEACHER_URL(schoolId, teacherId)}/bank`, payload)
}

// ─── Experience ───────────────────────────────────────────────────────────────

export function addTeacherExperience(
  schoolId: string | number,
  teacherId: string | number,
  payload: AddTeacherExperiencePayload
) {
  return axios.post<TeacherExperienceResponse>(
    `${TEACHER_URL(schoolId, teacherId)}/experience`,
    payload
  )
}

export function getTeacherExperiences(schoolId: string | number, teacherId: string | number) {
  return axios.get<{ success: boolean; data: { experiences: any[] } }>(
    `${TEACHER_URL(schoolId, teacherId)}/experience`
  )
}

export function updateTeacherExperience(
  schoolId: string | number,
  teacherId: string | number,
  expId: string | number,
  payload: Partial<AddTeacherExperiencePayload>
) {
  return axios.put<TeacherExperienceResponse>(
    `${TEACHER_URL(schoolId, teacherId)}/experience/${expId}`,
    payload
  )
}

export function deleteTeacherExperience(
  schoolId: string | number,
  teacherId: string | number,
  expId: string | number
) {
  return axios.delete<{ success: boolean; message: string }>(
    `${TEACHER_URL(schoolId, teacherId)}/experience/${expId}`
  )
}

// ─── Documents ────────────────────────────────────────────────────────────────

export function addTeacherDocument(
  schoolId: string | number,
  teacherId: string | number,
  documentType: string,
  file: File
) {
  const formData = new FormData()
  formData.append('document_type', documentType)
  formData.append('document_file', file)
  return axios.post<TeacherDocumentResponse>(
    `${TEACHER_URL(schoolId, teacherId)}/documents`,
    formData,
    { headers: { 'Content-Type': 'multipart/form-data' } }
  )
}

export function getTeacherDocuments(schoolId: string | number, teacherId: string | number) {
  return axios.get<{ success: boolean; data: { documents: any[] } }>(
    `${TEACHER_URL(schoolId, teacherId)}/documents`
  )
}

export function updateTeacherDocumentStatus(
  schoolId: string | number,
  teacherId: string | number,
  docId: string | number,
  verification_status: 'Verified' | 'Rejected' | 'Pending'
) {
  return axios.patch<TeacherDocumentResponse>(
    `${TEACHER_URL(schoolId, teacherId)}/documents/${docId}/status`,
    { verification_status }
  )
}

export function deleteTeacherDocument(
  schoolId: string | number,
  teacherId: string | number,
  docId: string | number
) {
  return axios.delete<{ success: boolean; message: string }>(
    `${TEACHER_URL(schoolId, teacherId)}/documents/${docId}`
  )
}

// ─── Permissions ──────────────────────────────────────────────────────────────

export function updateTeacherPermissions(
  schoolId: string | number,
  teacherId: string | number,
  payload: UpdateTeacherPermissionsPayload
) {
  return axios.patch<TeacherPermissionsResponse>(
    `${TEACHER_URL(schoolId, teacherId)}/permissions`,
    payload
  )
}

export function bulkImportTeachers(schoolId: string | number, payload: { teachers: any[] }) {
  return axios.post<any>(`${TEACHERS_URL(schoolId)}/bulk-import`, payload)
}

export async function downloadTeachersExcel(schoolId: string | number, params: any) {
  const response = await axios.get(`${API_URL}/school/${schoolId}/teachers/export/excel`, {
    params,
    responseType: 'blob'
  });
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `Teacher_Roster_${Date.now()}.csv`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}

export async function downloadTeachersPdf(schoolId: string | number, params: any) {
  const response = await axios.get(`${API_URL}/school/${schoolId}/teachers/export/pdf`, {
    params,
    responseType: 'blob'
  });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `Teacher_Roster_${Date.now()}.pdf`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}
