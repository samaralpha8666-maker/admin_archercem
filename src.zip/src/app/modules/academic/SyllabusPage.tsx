import { FC, useState, useEffect, useCallback } from 'react'
import { toast } from 'react-toastify'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { Modal, Button, Alert, Accordion, Badge, Form, Dropdown } from 'react-bootstrap'
import { useAuth } from '../auth'
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import {
  getClasses,
  getClassSubjects,
  getSyllabusHierarchy,
  createSyllabus,
  updateSyllabus,
  addUnitsBulk,
  uploadTopicResource,
  uploadTopicResourceLink,
  deleteSyllabus,
  removeResource,
  getAcademicSessions,
  getClassSections,
  getSectionProgress,
  updateTopic,
  addTopicToUnit,
  deleteTopic,
  updateUnit,
  deleteUnit
} from './core/_requests'
import {
  ClassModel,
  SubjectModel,
  SyllabusModel,
  SessionModel,
  ClassSubjectMappingModel,
  SectionModel
} from './core/_models'
import { getAcademicLabel } from '../../../_metronic/helpers'

const SyllabusPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')

  // Data states
  const [sessions, setSessions] = useState<SessionModel[]>([])
  const [classes, setClasses] = useState<ClassModel[]>([])
  const [subjects, setSubjects] = useState<SubjectModel[]>([])

  // Selection states
  const [selectedSessionId, setSelectedSessionId] = useState<number | ''>('')
  const [selectedClassId, setSelectedClassId] = useState<number | ''>('')
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | ''>('')
  const [selectedSectionId, setSelectedSectionId] = useState<number | ''>('')
  const [sections, setSections] = useState<SectionModel[]>([])
  const [sectionProgress, setSectionProgress] = useState<any>(null)

  // Syllabus state
  const [syllabus, setSyllabus] = useState<SyllabusModel | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [createSyllabusFile, setCreateSyllabusFile] = useState<File | null>(null)
  const [showPDFUploadModal, setShowPDFUploadModal] = useState(false)
  const [syllabusPDFFile, setSyllabusPDFFile] = useState<File | null>(null)
  const [showInlinePreview, setShowInlinePreview] = useState(false)
  const [manualPDFUrl, setManualPDFUrl] = useState<string | null>(null)

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showUnitModal, setShowUnitModal] = useState(false)
  const [showResourceModal, setShowResourceModal] = useState(false)
  const [showEditTopicModal, setShowEditTopicModal] = useState(false)
  const [showAddTopicModal, setShowAddTopicModal] = useState(false)
  const [showEditUnitModal, setShowEditUnitModal] = useState(false)
  const [activeUnitId, setActiveUnitId] = useState<number | null>(null)

  const [saving, setSaving] = useState(false)

  // Smart Import States
  const [showSmartImportModal, setShowSmartImportModal] = useState(false)
  const [smartImportText, setSmartImportText] = useState('')
  const [parsedUnits, setParsedUnits] = useState<any[]>([])

  // Create Form
  const [createForm, setCreateForm] = useState({ title: '', description: '' })

  // Unit Form
  const [unitForm, setUnitForm] = useState({
    unit_name: '',
    unit_number: 1,
    description: '',
    total_lectures_estimated: 10,
    topics: [{ topic_name: '', description: '', lectures_estimated: 5, is_optional: false }]
  })

  // Edit Unit Form
  const [editUnitForm, setEditUnitForm] = useState({
    id: 0,
    unit_name: '',
    description: '',
    total_lectures_estimated: 0
  })

  // Edit Topic Form
  const [editTopicForm, setEditTopicForm] = useState({
    id: 0,
    topic_name: '',
    description: '',
    is_optional: false,
    lectures_estimated: 0
  })

  // Add Topic Form
  const [addTopicForm, setAddTopicForm] = useState({
    topic_name: '',
    lectures_estimated: 3,
    description: ''
  })

  // Resource Form
  const [activeTopicId, setActiveTopicId] = useState<number | null>(null)
  const [resourceForm, setResourceForm] = useState({
    title: '',
    resource_type: 'VIDEO',
    file_url: '',
    file: null as File | null
  })

  // Init fetch
  useEffect(() => {
    if (!schoolId) return
    getAcademicSessions(schoolId).then(res => {
      if (res.data.success) {
        setSessions(res.data.data.sessions || [])
        const current = res.data.data.sessions.find(s => s.is_current)
        if (current) setSelectedSessionId(current.id)
      }
    })
    getClasses(schoolId, 1, 100).then(res => {
      if (res.data.success) setClasses(res.data.data.classes || [])
    })
  }, [schoolId])

  // Fetch subjects when class changes
  useEffect(() => {
    setSelectedSubjectId('')
    setSubjects([])
    setSyllabus(null)
    setShowInlinePreview(false)
    setManualPDFUrl(null)
    if (!schoolId || !selectedClassId) return
    getClassSubjects(schoolId, selectedClassId).then(res => {
      if (res.data.success) {
        const maps = res.data.data.subjects || []
        const subs = maps.map((m: any) => m.subject).filter(Boolean)
        setSubjects(subs)
      }
    })
    getClassSections(schoolId, selectedClassId).then(res => {
      if (res.data.success) {
        setSections(res.data.data.sections?.map((s: any) => s.section).filter(Boolean) || [])
      }
    })
  }, [schoolId, selectedClassId])

  const fetchSyllabus = useCallback(async () => {
    if (!schoolId || !selectedClassId || !selectedSubjectId) return
    setLoading(true)
    setError(null)
    setSyllabus(null)
    setShowInlinePreview(false)
    setManualPDFUrl(null)
    try {
      const res = await getSyllabusHierarchy(schoolId, selectedClassId, selectedSubjectId)
      if (res.data.success && res.data.data.syllabus) {
        setSyllabus(res.data.data.syllabus)
      }
    } catch (err: any) {
      if (err.response?.status !== 404) {
        setError(err.response?.data?.message || 'Failed to load syllabus')
      }
    } finally {
      setLoading(false)
    }
  }, [schoolId, selectedClassId, selectedSubjectId])

  // Fetch progress when section changes
  useEffect(() => {
    setSectionProgress(null)
    if (!schoolId || !selectedSectionId || !selectedSubjectId) return
    getSectionProgress(schoolId, selectedSectionId, selectedSubjectId).then(res => {
      if (res.data.success) {
        setSectionProgress(res.data.data)
      }
    })
  }, [schoolId, selectedSectionId, selectedSubjectId])

  // Fetch syllabus when class and subject selected
  useEffect(() => {
    fetchSyllabus()
  }, [fetchSyllabus])

  const handleCreateSyllabus = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedSessionId || !selectedClassId || !selectedSubjectId) return
    setSaving(true)
    setError(null)
    try {
      if (createSyllabusFile) {
        const formData = new FormData()
        formData.append('academic_session_id', String(selectedSessionId))
        formData.append('class_id', String(selectedClassId))
        formData.append('subject_id', String(selectedSubjectId))
        formData.append('title', createForm.title)
        formData.append('description', createForm.description)
        formData.append('is_active', 'true')
        formData.append('file', createSyllabusFile)

        await createSyllabus(schoolId, formData)
      } else {
        await createSyllabus(schoolId, {
          academic_session_id: Number(selectedSessionId),
          class_id: Number(selectedClassId),
          subject_id: Number(selectedSubjectId),
          title: createForm.title,
          description: createForm.description,
          is_active: true
        })
      }
      setShowCreateModal(false)
      setCreateSyllabusFile(null)
      fetchSyllabus()
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to create syllabus')
    } finally {
      setSaving(false)
    }
  }

  const handleUpdateSyllabusPDF = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!syllabus || !syllabusPDFFile) return
    setSaving(true)
    try {
      const formData = new FormData()
      formData.append('file', syllabusPDFFile)
      await updateSyllabus(schoolId, syllabus.id, formData)
      setShowPDFUploadModal(false)
      setSyllabusPDFFile(null)
      toast.success('Syllabus PDF updated successfully')
      fetchSyllabus()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to update syllabus PDF')
    } finally {
      setSaving(false)
    }
  }

  const exportSyllabusToPDF = async (shouldDownload: boolean = true) => {
    if (!syllabus) {
      toast.warning('No syllabus data to export.')
      return
    }

    setSaving(true)
    const doc = new jsPDF('portrait')
    const className = classes.find(c => c.id === selectedClassId)?.name || 'Class'
    const subjectName = subjects.find(s => s.id === selectedSubjectId)?.name || 'Subject'
    const sessionYear = sessions.find(s => s.id === selectedSessionId)?.session_year || ''
    
    const docTitle = `${className} - ${subjectName} Syllabus`
    const fileName = `Syllabus_${className.replace(/ /g, '_')}_${subjectName.replace(/ /g, '_')}.pdf`

    // Detect if Devanagari (Hindi/Sanskrit) characters are present OR if subject name is Hindi/Sanskrit
    const subjectNameLower = subjectName.toLowerCase();
    const hasDevanagari = /[\u0900-\u097F]/.test(
      syllabus.title + 
      (syllabus.description || '') + 
      JSON.stringify(syllabus.units)
    ) || subjectNameLower.includes('hindi') || subjectNameLower.includes('sanskrit') || subjectNameLower.includes('sanskrut');

    let activeFont = 'helvetica'
    let activeBoldFont = 'helvetica'

    if (hasDevanagari) {
      toast.info("Loading Poppins Font (Devanagari & Latin support)...");
      try {
        // Fetch Regular Poppins font (supports both Latin and Devanagari/Hindi/Sanskrit)
        const regRes = await fetch(
          'https://raw.githubusercontent.com/google/fonts/main/ofl/poppins/Poppins-Regular.ttf'
        );
        if (!regRes.ok) throw new Error(`Failed to fetch regular font: ${regRes.statusText}`);
        const regBuffer = await regRes.arrayBuffer();
        const regBytes = new Uint8Array(regBuffer);
        let regBinary = '';
        for (let i = 0; i < regBytes.byteLength; i++) {
          regBinary += String.fromCharCode(regBytes[i]);
        }
        const regBase64 = window.btoa(regBinary);
        doc.addFileToVFS('Poppins-Regular.ttf', regBase64);
        doc.addFont('Poppins-Regular.ttf', 'Poppins', 'normal');
        
        // Fetch Bold Poppins font
        const boldRes = await fetch(
          'https://raw.githubusercontent.com/google/fonts/main/ofl/poppins/Poppins-Bold.ttf'
        );
        if (!boldRes.ok) throw new Error(`Failed to fetch bold font: ${boldRes.statusText}`);
        const boldBuffer = await boldRes.arrayBuffer();
        const boldBytes = new Uint8Array(boldBuffer);
        let boldBinary = '';
        for (let i = 0; i < boldBytes.byteLength; i++) {
          boldBinary += String.fromCharCode(boldBytes[i]);
        }
        const boldBase64 = window.btoa(boldBinary);
        doc.addFileToVFS('Poppins-Bold.ttf', boldBase64);
        doc.addFont('Poppins-Bold.ttf', 'Poppins', 'bold');

        activeFont = 'Poppins'
        activeBoldFont = 'Poppins'
      } catch (err) {
        console.error("Failed to load Poppins, falling back to helvetica:", err);
        toast.warning("Failed to load Devanagari font. Hindi text might not display correctly.");
      }
    }

    // Header Styling
    doc.setFont(activeBoldFont, 'bold')
    doc.setFontSize(20)
    doc.setTextColor(0, 104, 118) // Sleek brand teal
    doc.text(docTitle, 14, 20)

    doc.setFont(activeFont, 'normal')
    doc.setFontSize(10)
    doc.setTextColor(100, 100, 100)
    doc.text(`Academic Session: ${sessionYear}`, 14, 27)
    
    if (syllabus.description) {
      doc.setFontSize(11)
      doc.setTextColor(80, 80, 80)
      const splitDesc = doc.splitTextToSize(syllabus.description, 180)
      doc.text(splitDesc, 14, 35)
    }

    let currentY = syllabus.description ? 48 : 38

    if (!syllabus.units || syllabus.units.length === 0) {
      doc.setFontSize(12)
      doc.text('No units or topics added to this syllabus yet.', 14, currentY)
      setSaving(false)
      if (shouldDownload) {
        doc.save(fileName)
        toast.success('PDF Export downloaded!')
      } else {
        const blob = doc.output('blob')
        const blobUrl = URL.createObjectURL(blob)
        setManualPDFUrl(blobUrl)
        setShowInlinePreview(true)
      }
      return
    }

    syllabus.units.forEach((unit) => {
      // Check page overflow
      if (currentY > 230) {
        doc.addPage()
        currentY = 20
      }

      // Unit Title Header
      doc.setFont(activeBoldFont, 'bold')
      doc.setFontSize(13)
      doc.setTextColor(26, 47, 53) // Dark text color
      doc.text(`Unit ${unit.unit_number}: ${unit.unit_name}`, 14, currentY)

      doc.setFont(activeFont, 'normal')
      doc.setFontSize(9)
      doc.setTextColor(110, 110, 110)
      doc.text(`Estimated Lectures: ${unit.total_lectures_estimated}  ${unit.description ? `|  Description: ${unit.description}` : ''}`, 14, currentY + 5)
      
      currentY += 10

      // Table columns & rows
      const tableCols = ['#', 'Topic Name', 'Description', 'Lectures', 'Type']
      const tableData = (unit.topics || []).map((topic, tIdx) => [
        String(tIdx + 1),
        topic.topic_name || '-',
        topic.description || '-',
        `${topic.lectures_estimated} lectures`,
        topic.is_optional ? 'Optional' : 'Compulsory'
      ])

      autoTable(doc, {
        startY: currentY,
        head: [tableCols],
        body: tableData,
        theme: 'grid',
        headStyles: { 
          fillColor: [0, 104, 118], 
          textColor: 255, 
          fontStyle: 'bold', 
          fontSize: 9, 
          cellPadding: 2,
          font: activeBoldFont
        },
        styles: { 
          fontSize: 8.5, 
          cellPadding: 2, 
          textColor: [50, 50, 50],
          valign: 'middle',
          font: activeFont
        },
        columnStyles: {
          0: { cellWidth: 10, halign: 'center' },
          1: { cellWidth: 50, fontStyle: 'bold', font: activeBoldFont },
          2: { cellWidth: 85 },
          3: { cellWidth: 20, halign: 'center' },
          4: { cellWidth: 17, halign: 'center' }
        },
        alternateRowStyles: { fillColor: [248, 249, 250] },
        margin: { left: 14, right: 14 }
      })

      // Update currentY using autoTable's output
      currentY = (doc as any).lastAutoTable.finalY + 12
    })

    // Footer on all pages
    const pageCount = (doc as any).internal.getNumberOfPages()
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i)
      doc.setFont(activeFont, 'normal')
      doc.setFontSize(8)
      doc.setTextColor(150, 150, 150)
      doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 287)
      doc.text(`Page ${i} of ${pageCount}`, 180, 287)
    }

    setSaving(false)
    if (shouldDownload) {
      doc.save(fileName)
      toast.success('Syllabus PDF Export downloaded successfully!')
    } else {
      const blob = doc.output('blob')
      const blobUrl = URL.createObjectURL(blob)
      setManualPDFUrl(blobUrl)
      setShowInlinePreview(true)
    }
  }

  const handleAddUnit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!syllabus || !unitForm.unit_name.trim()) return
    setSaving(true)
    try {
      const rawText = unitForm.unit_name;
      let unitNamesList: string[] = [];

      if (rawText.includes('\n')) {
        unitNamesList = rawText.split('\n');
      } else if (rawText.includes(',')) {
        unitNamesList = rawText.split(',');
      } else {
        unitNamesList = [rawText];
      }

      // Filter and clean unit names
      const cleanedUnits = unitNamesList
        .map(u => u.trim())
        .map(u => u.replace(/^[\d\-\*•]+[\.\-\)]?\s*/, '')) // removes bullets and numbers like "1. ", "- "
        .map(u => u.replace(/^(unit|chapter|lesson)\s*\d+[\.\-\:]?\s*/i, '')) // removes "Unit 1: ", "Chapter 2 - " case-insensitive
        .filter(u => u.length > 0);

      if (cleanedUnits.length === 0) {
        toast.warning('No valid unit names found.');
        setSaving(false);
        return;
      }

      // Construct units array for bulk API call
      const startUnitNumber = Number(unitForm.unit_number);
      const unitsPayload = cleanedUnits.map((unitName, index) => {
        // If it's the first unit, include the topics entered in the form
        const isFirst = index === 0;
        return {
          unit_name: unitName,
          unit_number: startUnitNumber + index,
          description: isFirst ? unitForm.description : '',
          total_lectures_estimated: Number(unitForm.total_lectures_estimated),
          topics: isFirst 
            ? unitForm.topics.filter(t => t.topic_name.trim() !== '').map(t => ({
                ...t,
                lectures_estimated: Number(t.lectures_estimated)
              }))
            : []
        };
      });

      await addUnitsBulk(schoolId, syllabus.id, {
        units: unitsPayload
      });

      setShowUnitModal(false)
      setUnitForm({
        unit_name: '',
        unit_number: (syllabus.units?.length || 0) + cleanedUnits.length + 1,
        description: '',
        total_lectures_estimated: 10,
        topics: [{ topic_name: '', description: '', lectures_estimated: 5, is_optional: false }]
      })
      toast.success(`Successfully added ${cleanedUnits.length} units!`);
      fetchSyllabus()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to add units')
    } finally {
      setSaving(false)
    }
  }

  const handleAddResource = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!activeTopicId) return
    setSaving(true)
    try {
      if (resourceForm.resource_type === 'LINK' || resourceForm.resource_type === 'VIDEO') {
        await uploadTopicResourceLink(schoolId, activeTopicId, {
          title: resourceForm.title,
          resource_type: resourceForm.resource_type,
          file_url: resourceForm.file_url
        })
      } else {
        if (!resourceForm.file) throw new Error('Please select a file')
        const fd = new FormData()
        fd.append('title', resourceForm.title)
        fd.append('resource_type', resourceForm.resource_type)
        fd.append('resource', resourceForm.file)
        await uploadTopicResource(schoolId, activeTopicId, fd)
      }
      setShowResourceModal(false)
      setResourceForm({ title: '', resource_type: 'VIDEO', file_url: '', file: null })
      fetchSyllabus()
    } catch (err: any) {
      alert(err.response?.data?.message || err.message || 'Failed to upload resource')
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteSyllabus = async () => {
    if (!syllabus) return
    if (!window.confirm('Are you sure you want to delete this syllabus and all its contents?')) return
    try {
      await deleteSyllabus(schoolId, syllabus.id)
      setSyllabus(null)
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to delete')
    }
  }

  const handleDeleteResource = async (id: number) => {
    if (!window.confirm('Remove this resource?')) return
    try {
      await removeResource(schoolId, id)
      fetchSyllabus()
    } catch (err: any) {
      toast.error('Failed to remove resource')
    }
  }

  const handleUpdateUnit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!schoolId) return
    setSaving(true)
    try {
      await updateUnit(schoolId, editUnitForm.id, {
        unit_name: editUnitForm.unit_name,
        description: editUnitForm.description,
        total_lectures_estimated: editUnitForm.total_lectures_estimated
      })
      toast.success('Unit updated successfully')
      setShowEditUnitModal(false)
      fetchSyllabus()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to update unit')
    } finally {
      setSaving(false)
    }
  }

  const handleUpdateTopic = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      await updateTopic(schoolId, editTopicForm.id, {
        topic_name: editTopicForm.topic_name,
        description: editTopicForm.description,
        is_optional: editTopicForm.is_optional,
        lectures_estimated: Number(editTopicForm.lectures_estimated)
      })
      setShowEditTopicModal(false)
      fetchSyllabus()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to update topic')
    } finally {
      setSaving(false)
    }
  }

  const handleAddTopicToUnit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!activeUnitId || !addTopicForm.topic_name.trim()) return
    setSaving(true)
    try {
      const rawText = addTopicForm.topic_name;
      let topicsList: string[] = [];
      
      // If it contains newlines, split by newlines. Otherwise split by commas.
      if (rawText.includes('\n')) {
        topicsList = rawText.split('\n');
      } else if (rawText.includes(',')) {
        topicsList = rawText.split(',');
      } else {
        topicsList = [rawText];
      }

      // Filter and clean topics: remove empty strings, trim spaces, and clean any leading list numbers/bullets
      const cleanedTopics = topicsList
        .map(t => t.trim())
        .map(t => t.replace(/^[\d\-\*•]+[\.\-\)]?\s*/, '')) // removes "1. ", "- ", "* ", "1) "
        .filter(t => t.length > 0);

      if (cleanedTopics.length === 0) {
        toast.warning('No valid topics found.');
        setSaving(false);
        return;
      }

      // sequential API calls to add each topic to the unit
      for (const topicName of cleanedTopics) {
        await addTopicToUnit(schoolId, activeUnitId, {
          topic_name: topicName,
          lectures_estimated: Number(addTopicForm.lectures_estimated),
          description: addTopicForm.description
        });
      }

      setShowAddTopicModal(false)
      setAddTopicForm({ topic_name: '', lectures_estimated: 3, description: '' })
      toast.success(`Successfully added ${cleanedTopics.length} topics!`);
      fetchSyllabus()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to add topics')
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteTopic = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this topic?')) return
    try {
      await deleteTopic(schoolId, id)
      fetchSyllabus()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to delete topic')
    }
  }

  const handleDeleteUnit = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this unit and all its topics?')) return
    try {
      await deleteUnit(schoolId, id)
      toast.success('Unit deleted successfully')
      fetchSyllabus()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to delete unit')
    }
  }

  // Real-time Hierarchical Parser for Syllabus Text Blocks
  useEffect(() => {
    if (!smartImportText.trim()) {
      setParsedUnits([])
      return
    }

    const lines = smartImportText.split('\n').map(l => l.trim()).filter(Boolean)
    const units: any[] = []
    let currentUnit: any = null
    let unitCounter = 1

    // Regex matches "1. Numbers", "Unit 2 - Addition", "3 Subtraction", "Chapter 4: Geometry", etc.
    const unitRegex = /^(?:unit|chapter|lesson)?\s*[\*•]?\s*(\d+)[\.\-\:\)]?\s*(.*)$/i

    lines.forEach((line) => {
      const match = line.match(unitRegex)
      
      const isUnitHeader = match && 
        !line.toLowerCase().includes('digit') && 
        !line.toLowerCase().includes('lecture') &&
        !line.toLowerCase().includes('fact') &&
        !line.toLowerCase().includes('problem') &&
        (line.match(/^[\d]+[\.\)\-\:]/) || line.match(/^(unit|chapter|lesson)\s*\d+/i))

      if (isUnitHeader && match) {
        const unitNumStr = match[1]
        const unitName = match[2].trim() || line
        currentUnit = {
          unit_name: unitName.replace(/^[\.\-\:\s]+/, ''),
          unit_number: parseInt(unitNumStr) || unitCounter++,
          description: '',
          total_lectures_estimated: 10,
          topics: []
        }
        units.push(currentUnit)
      } else {
        if (!currentUnit) {
          currentUnit = {
            unit_name: 'General / Introduction',
            unit_number: unitCounter++,
            description: '',
            total_lectures_estimated: 10,
            topics: []
          }
          units.push(currentUnit)
        }

        const cleanedTopicName = line.replace(/^[\d\-\*•]+[\.\-\)]?\s*/, '').trim()
        if (cleanedTopicName) {
          currentUnit.topics.push({
            topic_name: cleanedTopicName,
            description: '',
            lectures_estimated: 3,
            is_optional: false
          })
        }
      }
    })

    setParsedUnits(units)
  }, [smartImportText])

  const handleSmartImportSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!syllabus || parsedUnits.length === 0) return
    setSaving(true)
    try {
      await addUnitsBulk(schoolId, syllabus.id, {
        units: parsedUnits
      })
      setShowSmartImportModal(false)
      setSmartImportText('')
      setParsedUnits([])
      toast.success(`Successfully imported ${parsedUnits.length} units with their topics!`)
      fetchSyllabus()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to import syllabus')
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {error && <Alert variant='danger'>{error}</Alert>}

        {/* COMPACT FILTERS */}
        <div className='card mb-7'>
          <div className='card-body py-3'>
            <div className='d-flex flex-wrap align-items-center gap-5'>
              <div className='d-flex align-items-center min-w-150px'>
                <span className='text-gray-700 fw-bold fs-7 me-3 text-nowrap'>Session:</span>
                <select className='form-select form-select-sm form-select-solid' value={selectedSessionId} onChange={e => setSelectedSessionId(Number(e.target.value))}>
                  <option value=''>Select...</option>
                  {sessions.map(s => <option key={s.id} value={s.id}>{s.session_year}</option>)}
                </select>
              </div>
              <div className='d-flex align-items-center min-w-150px'>
                <span className='text-gray-700 fw-bold fs-7 me-3 text-nowrap'>{getAcademicLabel()}:</span>
                <select className='form-select form-select-sm form-select-solid' value={selectedClassId} onChange={e => setSelectedClassId(Number(e.target.value))}>
                  <option value=''>Select...</option>
                  {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className='d-flex align-items-center min-w-150px'>
                <span className='text-gray-700 fw-bold fs-7 me-3 text-nowrap'>Subject:</span>
                <select className='form-select form-select-sm form-select-solid' value={selectedSubjectId} onChange={e => setSelectedSubjectId(Number(e.target.value))} disabled={!selectedClassId}>
                  <option value=''>Select...</option>
                  {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className='d-flex align-items-center border-start ps-5 ms-2 min-w-180px'>
                <span className='text-primary fw-bold fs-7 me-3 text-nowrap'>Track Section:</span>
                <select className='form-select form-select-sm form-select-solid border-primary border-opacity-25' value={selectedSectionId} onChange={e => setSelectedSectionId(Number(e.target.value))} disabled={!selectedClassId}>
                  <option value=''>Select Section</option>
                  {sections.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>

              <div className='ms-auto'>
                <Button variant='light' size='sm' className='btn-icon w-30px h-30px' onClick={() => {
                  setSelectedSessionId('')
                  setSelectedClassId('')
                  setSelectedSubjectId('')
                  setSelectedSectionId('')
                }}>
                  <i className='ki-duotone ki-arrows-circle fs-3'><span className='path1'></span><span className='path2'></span></i>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* SYLLABUS CONTENT */}
        {selectedClassId && selectedSubjectId ? (
          loading ? (
            <div className='text-center py-20'><span className='spinner-border text-primary'></span></div>
          ) : syllabus ? (
            <div className='card '>
              <div className='card-header pt-7 pb-5'>
                <div className='card-title flex-column'>
                  <h2 className='fw-bold text-gray-900 m-0 fs-1'>{syllabus.title}</h2>
                  <span className='text-muted fs-6 fw-semibold mt-2'>{syllabus.description || 'No description provided.'}</span>
                </div>
                <div className='card-toolbar gap-3'>
                  {sectionProgress && (
                    <div className='me-7 d-flex flex-column text-end'>
                      <div className='d-flex align-items-center mb-1'>
                        <span className='fw-bold fs-7 text-gray-700 me-2'>{sectionProgress.completion_percentage}% Complete</span>
                        <div className='h-6px w-100px bg-light-success rounded-pill'>
                          <div className='bg-success h-6px rounded-pill' style={{ width: `${sectionProgress.completion_percentage}%` }}></div>
                        </div>
                      </div>
                      <span className='text-muted fs-8 fw-semibold'>{sectionProgress.completed_topics} / {sectionProgress.total_topics} Topics Completed</span>
                    </div>
                  )}
                  <Button variant='light-danger' size='sm' className='btn-active-danger fw-bold' onClick={handleDeleteSyllabus}>
                    <i className='ki-duotone ki-trash fs-4 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i> Delete
                  </Button>
                  <Button variant='light-info' size='sm' className='btn-active-info fw-bold' onClick={() => setShowPDFUploadModal(true)}>
                    <i className='ki-duotone ki-cloud-change fs-4 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i> {syllabus.file_url ? 'Replace PDF' : 'Upload PDF'}
                  </Button>
                  {syllabus.units && syllabus.units.length > 0 && (
                    <>
                      <Button variant='light-info' size='sm' className='btn-active-info fw-bold' onClick={() => {
                        if (showInlinePreview && manualPDFUrl) {
                          setShowInlinePreview(false);
                          setManualPDFUrl(null);
                        } else {
                          exportSyllabusToPDF(false);
                        }
                      }}>
                        <i className='ki-duotone ki-eye fs-4 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i> {showInlinePreview && manualPDFUrl ? 'Hide Preview' : 'Preview PDF'}
                      </Button>
                      <Button variant='light-success' size='sm' className='btn-active-success fw-bold' onClick={() => exportSyllabusToPDF(true)}>
                        <i className='ki-duotone ki-file-down fs-4 me-1'><span className='path1'></span><span className='path2'></span></i> Download Syllabus
                      </Button>
                    </>
                  )}
                  <Button variant='light-primary' size='sm' className='fw-bold' onClick={() => setShowSmartImportModal(true)}>
                    <i className='ki-duotone ki-cloud-add fs-4 me-1'><span className='path1'></span><span className='path2'></span></i> Smart Bulk Import
                  </Button>
                  <Button variant='light-primary' size='sm' className='fw-bold' onClick={() => setShowUnitModal(true)}>
                    <i className='ki-duotone ki-plus fs-4 me-1'></i> Add Unit
                  </Button>
                </div>
              </div>

              <div className='card-body pt-0'>
                <div className='separator separator-dashed my-5'></div>

                {syllabus.file_url && (
                  <div className='card bg-light-primary border-primary border-dashed border-1 mb-8'>
                    <div className='card-body d-flex align-items-center justify-content-between p-5'>
                      <div className='d-flex align-items-center'>
                        <div className='symbol symbol-45px me-4'>
                          <span className='symbol-label bg-light-primary text-primary fs-2'>
                            <i className='ki-duotone ki-file-pdf fs-1 text-primary'><span className='path1'></span><span className='path2'></span></i>
                          </span>
                        </div>
                        <div>
                          <h4 className='text-gray-900 fw-bold m-0 fs-5'>Syllabus PDF Document</h4>
                          <span className='text-muted fs-7 fw-semibold'>Direct bulk syllabus document is active for this class.</span>
                        </div>
                      </div>
                      <div className='d-flex gap-2'>
                        <Button
                          variant='primary'
                          size='sm'
                          className='fw-bold px-4'
                          onClick={() => {
                            if (showInlinePreview && !manualPDFUrl) {
                              setShowInlinePreview(false);
                            } else {
                              setManualPDFUrl(null);
                              setShowInlinePreview(true);
                            }
                          }}
                        >
                          <i className='ki-duotone ki-eye fs-5 me-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i> {showInlinePreview && !manualPDFUrl ? 'Hide Preview' : 'Preview Inline'}
                        </Button>
                        <a
                          href={syllabus.file_url}
                          target='_blank'
                          rel='noreferrer'
                          className='btn btn-light-primary btn-sm fw-bold px-4'
                        >
                          <i className='ki-duotone ki-file-down fs-5 me-1'><span className='path1'></span><span className='path2'></span></i> Open in New Tab
                        </a>
                      </div>
                    </div>
                  </div>
                )}

                {showInlinePreview && (syllabus.file_url || manualPDFUrl) && (
                  <div className='card border border-primary border-opacity-25 mb-8 shadow-sm'>
                    <div className='card-header d-flex align-items-center justify-content-between p-4 bg-light-primary bg-opacity-25'>
                      <h5 className='m-0 fw-bold text-primary'>
                        <i className='ki-duotone ki-file-pdf fs-3 text-primary me-2'><span className='path1'></span><span className='path2'></span></i>
                        Syllabus PDF Preview
                      </h5>
                      <Button variant='light-danger' size='sm' className='fw-bold' onClick={() => { setShowInlinePreview(false); setManualPDFUrl(null); }}>
                        Close Preview
                      </Button>
                    </div>
                    <div className='card-body p-0' style={{ height: '600px' }}>
                      <iframe
                        src={manualPDFUrl || syllabus.file_url || ''}
                        width='100%'
                        height='100%'
                        style={{ border: 'none', borderRadius: '0 0 8px 8px' }}
                        title='Syllabus PDF Preview'
                      />
                    </div>
                  </div>
                )}

                {syllabus.units && syllabus.units.length > 0 ? (
                  <div className='syllabus-container'>
                    {syllabus.units.map((unit, idx) => (
                      <div key={unit.id} className='mb-10'>
                        {/* Unit Header */}
                        <div className='d-flex align-items-center justify-content-between mb-6 bg-light-dark bg-opacity-5 p-4 rounded'>
                          <div className='d-flex align-items-center'>
                            <div className='symbol symbol-40px me-4'>
                              <div className='symbol-label fs-3 fw-bold bg-dark text-white'>{unit.unit_number}</div>
                            </div>
                            <div>
                              <h3 className='text-gray-900 fw-bold m-0 fs-4'>{unit.unit_name}</h3>
                              <div className='d-flex align-items-center text-muted fs-7 fw-semibold mt-1'>
                                <i className='ki-duotone ki-time fs-8 me-1'><span className='path1'></span><span className='path2'></span></i>
                                {unit.total_lectures_estimated} Estimated Lectures
                                {unit.description && <span className='mx-2'>•</span>}
                                {unit.description && <span>{unit.description}</span>}
                              </div>
                            </div>
                          </div>
                          <div className='d-flex gap-2'>
                            <Button
                              variant='light-danger'
                              size='sm'
                              className='btn-icon w-30px h-30px'
                              onClick={() => handleDeleteUnit(unit.id)}
                              title='Delete Unit'
                            >
                              <i className='ki-duotone ki-trash fs-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i>
                            </Button>
                            <Button
                              variant='light-primary'
                              size='sm'
                              className='btn-icon w-30px h-30px'
                              onClick={() => {
                                setEditUnitForm({
                                  id: unit.id,
                                  unit_name: unit.unit_name,
                                  description: unit.description || '',
                                  total_lectures_estimated: unit.total_lectures_estimated
                                })
                                setShowEditUnitModal(true)
                              }}
                            >
                              <i className='ki-duotone ki-pencil fs-4'><span className='path1'></span><span className='path2'></span></i>
                            </Button>
                            <Button
                              variant='light-primary'
                              size='sm'
                              className='btn-active-primary fw-bold'
                              onClick={() => {
                                setActiveUnitId(unit.id);
                                setShowAddTopicModal(true);
                              }}
                            >
                              <i className='ki-duotone ki-plus fs-3'></i> Add Topic
                            </Button>
                          </div>
                        </div>

                        {/* Topics List */}
                        <div className='ps-5 border-start border-gray-300 ms-5 mt-n3 topics-list'>
                          {unit.topics && unit.topics.length > 0 ? (
                            unit.topics.map((topic, tIdx) => (
                              <div className='position-relative mb-8' key={topic.id}>
                                {/* Timeline Dot */}
                                <div className='position-absolute top-0 start-0 w-12px h-12px rounded-circle bg-gray-300 translate-middle-x ms-n6 mt-2 border border-gray-300 border border-white border-4'></div>

                                <div className='d-flex flex-column'>
                                  <div className='d-flex align-items-center justify-content-between mb-2'>
                                    <div className='d-flex align-items-center'>
                                      <h5 className='text-gray-800 fw-bold m-0 fs-5 me-3'>
                                        {topic.topic_name}
                                        {topic.is_optional && <Badge bg='light-warning' className='text-warning fs-9 px-2 py-1 ms-2 border border-warning border-opacity-25'>OPTIONAL</Badge>}
                                      </h5>
                                      {sectionProgress?.topics?.[topic.id] && (
                                        <Badge
                                          bg={`light-${sectionProgress.topics[topic.id].status === 'COMPLETED' ? 'success' : 'info'}`}
                                          className={`text-${sectionProgress.topics[topic.id].status === 'COMPLETED' ? 'success' : 'info'} fs-9 px-2 py-1 border border-${sectionProgress.topics[topic.id].status === 'COMPLETED' ? 'success' : 'info'} border-opacity-25`}
                                        >
                                          {sectionProgress.topics[topic.id].status}
                                        </Badge>
                                      )}
                                    </div>
                                    <div className='d-flex align-items-center gap-1 opacity-75 hover-opacity-100 transition-3s'>
                                      <Button variant='clean' size='sm' className='btn-icon btn-light-primary w-25px h-25px me-1' onClick={() => {
                                        setEditTopicForm({
                                          id: topic.id,
                                          topic_name: topic.topic_name,
                                          description: topic.description,
                                          is_optional: topic.is_optional,
                                          lectures_estimated: topic.lectures_estimated
                                        });
                                        setShowEditTopicModal(true);
                                      }}>
                                        <i className='ki-duotone ki-pencil fs-6'><span className='path1'></span><span className='path2'></span></i>
                                      </Button>
                                      <Button variant='clean' size='sm' className='btn-icon btn-light-danger w-25px h-25px me-1' onClick={() => handleDeleteTopic(topic.id)}>
                                        <i className='ki-duotone ki-trash fs-6'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span></i>
                                      </Button>
                                      <Button variant='clean' size='sm' className='btn-icon btn-light-info w-25px h-25px' onClick={() => { setActiveTopicId(topic.id); setShowResourceModal(true) }}>
                                        <i className='ki-duotone ki-cloud-add fs-6'><span className='path1'></span><span className='path2'></span></i>
                                      </Button>
                                    </div>
                                  </div>

                                  <p className='text-gray-600 fs-7 fw-medium mb-3 pe-10'>
                                    {topic.description} • <span className='text-dark fw-bold'>{topic.lectures_estimated} lectures</span>
                                  </p>

                                  {/* Resources */}
                                  {topic.resources && topic.resources.length > 0 && (
                                    <div className='d-flex flex-wrap gap-2 mt-1'>
                                      {topic.resources.map(res => (
                                        <div key={res.id} className='badge badge-light-dark border border-gray-300 d-flex align-items-center px-3 py-2'>
                                          <i className={`ki-duotone fs-6 text-gray-700 me-2 ${res.resource_type === 'VIDEO' ? 'ki-youtube' :
                                            res.resource_type === 'PDF' ? 'ki-file' : 'ki-link'
                                            }`}><span className='path1'></span><span className='path2'></span></i>
                                          <a href={res.file_url} target='_blank' rel='noreferrer' className='text-gray-800 text-hover-primary fw-bold fs-8 me-2'>
                                            {res.title}
                                          </a>
                                          <button className='btn btn-icon btn-xs btn-active-color-danger' onClick={() => handleDeleteResource(res.id)}>
                                            <i className='ki-duotone ki-cross fs-8'><span className='path1'></span><span className='path2'></span></i>
                                          </button>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className='text-muted fs-7 italic ps-2'>No topics added to this unit yet.</div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : !syllabus.file_url ? (
                  <div className='text-center py-20 bg-light rounded-4 border border-dashed border-gray-300'>
                    <i className='ki-duotone ki-abstract-26 fs-4x text-gray-300 mb-4'><span className='path1'></span><span className='path2'></span></i>
                    <div className='text-gray-600 fw-bold fs-5'>Your syllabus is empty.</div>
                    <p className='text-muted fs-7 mt-2'>Start by adding your first educational unit.</p>
                  </div>
                ) : null}
              </div>
            </div>
          ) : (
            <div className='card card-flush border border-gray-300'>
              <div className='card-body text-center py-20'>
                <i className='ki-duotone ki-document fs-5x text-gray-300 mb-8'><span className='path1'></span><span className='path2'></span></i>
                <h2 className='text-gray-900 fw-bolder mb-2'>No Syllabus Found</h2>
                <p className='text-gray-600 fw-semibold fs-6 mb-10 mx-auto max-w-400px'>Configure the syllabus structure for this academic track to help teachers and students stay on track.</p>
                <Button variant='primary' className='btn-lg px-8 fw-bold' onClick={() => {
                  setCreateForm({ title: `${classes.find(c => c.id === selectedClassId)?.name} - ${subjects.find(s => s.id === selectedSubjectId)?.name} Syllabus`, description: '' })
                  setShowCreateModal(true)
                }}>
                  <i className='ki-duotone ki-plus fs-2 me-1'></i> Initialize Syllabus
                </Button>
              </div>
            </div>
          )
        ) : (
          <div className='card card-flush border border-gray-300'>
            <div className='card-body text-center py-20'>
              <div className='symbol symbol-100px mb-5'>
                <div className='symbol-label bg-light-primary'>
                  <i className='ki-duotone ki-filter-search fs-3x text-primary'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                </div>
              </div>
              <h3 className='text-gray-800 fw-bold'>Select Academic Target</h3>
              <p className='text-muted fs-6 mb-0'>Please select a Session, Class, and Subject to view the detailed syllabus content.</p>
            </div>
          </div>
        )}
      </Content>

      {/* CREATE SYLLABUS MODAL */}
      <Modal show={showCreateModal} onHide={() => !saving && setShowCreateModal(false)} centered>
        <Modal.Header closeButton><Modal.Title>Create New Syllabus</Modal.Title></Modal.Header>
        <Modal.Body>
          <form onSubmit={handleCreateSyllabus}>
            <div className='mb-5'>
              <label className='required form-label'>Syllabus Title</label>
              <input type='text' className='form-control form-control-solid' value={createForm.title} onChange={e => setCreateForm({ ...createForm, title: e.target.value })} required />
            </div>
            <div className='mb-5'>
              <label className='form-label'>Description</label>
              <textarea className='form-control form-control-solid' rows={3} value={createForm.description} onChange={e => setCreateForm({ ...createForm, description: e.target.value })} />
            </div>
            <div className='mb-5'>
              <label className='form-label'>Syllabus Document (PDF - Optional)</label>
              <input type='file' className='form-control form-control-solid' accept='.pdf' onChange={e => setCreateSyllabusFile(e.target.files ? e.target.files[0] : null)} />
              <div className='form-text text-muted'>If you have a syllabus PDF, upload it here to instantly bulk upload the syllabus.</div>
            </div>
            <div className='text-end'>
              <Button variant='light' onClick={() => { setShowCreateModal(false); setCreateSyllabusFile(null); }} disabled={saving} className='me-3'>Cancel</Button>
              <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Saving...' : 'Create'}</Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>

      {/* ADD UNIT MODAL */}
      <Modal show={showUnitModal} onHide={() => !saving && setShowUnitModal(false)} size='lg' centered>
        <Modal.Header closeButton><Modal.Title>Add Unit & Topic</Modal.Title></Modal.Header>
        <Modal.Body>
          <form onSubmit={handleAddUnit}>
            <h5 className='mb-4 text-primary'>Unit Details</h5>
            <div className='row g-5 mb-8'>
              <div className='col-md-8'>
                <label className='required form-label'>Unit Name(s)</label>
                <textarea 
                  className='form-control form-control-solid' 
                  rows={4}
                  value={unitForm.unit_name} 
                  onChange={e => setUnitForm({ ...unitForm, unit_name: e.target.value })} 
                  required 
                  placeholder={`e.g. Algebra\nOr paste a list to add multiple units at once:\nUnit 1: Number Systems\nUnit 2: Algebra\nUnit 3: Geometry`} 
                />
                <div className='form-text text-muted'>You can paste a list of units (one unit per line or separated by commas) to instantly add all of them in bulk!</div>
              </div>
              <div className='col-md-4'>
                <label className='required form-label'>Unit Number</label>
                <input type='number' className='form-control form-control-solid' value={unitForm.unit_number} onChange={e => setUnitForm({ ...unitForm, unit_number: Number(e.target.value) })} required />
              </div>
              <div className='col-md-8'>
                <label className='form-label'>Description</label>
                <input type='text' className='form-control form-control-solid' value={unitForm.description} onChange={e => setUnitForm({ ...unitForm, description: e.target.value })} />
              </div>
              <div className='col-md-4'>
                <label className='required form-label'>Total Lectures</label>
                <input type='number' className='form-control form-control-solid' value={unitForm.total_lectures_estimated} onChange={e => setUnitForm({ ...unitForm, total_lectures_estimated: Number(e.target.value) })} required />
              </div>
            </div>

            <div className='d-flex align-items-center justify-content-between mb-4 border-bottom pb-2'>
              <h5 className='text-success m-0'>Topics (Array)</h5>
              <Button
                variant='light-success'
                size='sm'
                onClick={() => setUnitForm({
                  ...unitForm,
                  topics: [...unitForm.topics, { topic_name: '', description: '', lectures_estimated: 5, is_optional: false }]
                })}
              >
                <i className='ki-duotone ki-plus fs-3'></i> Add Topic
              </Button>
            </div>

            {unitForm.topics.map((topic, index) => (
              <div key={index} className='border border-gray-200 p-5 rounded mb-5 bg-light-success bg-opacity-5 position-relative'>
                <div className='d-flex justify-content-between align-items-center mb-4'>
                  <span className='badge badge-light-success fw-bold'>Topic #{index + 1}</span>
                  {unitForm.topics.length > 1 && (
                    <button
                      type='button'
                      className='btn btn-icon btn-sm btn-light-danger btn-active-danger h-25px w-25px'
                      onClick={() => {
                        const newTopics = unitForm.topics.filter((_, i) => i !== index)
                        setUnitForm({ ...unitForm, topics: newTopics })
                      }}
                    >
                      <i className='ki-duotone ki-cross fs-4'><span className='path1'></span><span className='path2'></span></i>
                    </button>
                  )}
                </div>
                <div className='row g-5'>
                  <div className='col-md-8'>
                    <label className='form-label fw-semibold fs-7'>Topic Name</label>
                    <input
                      type='text'
                      className='form-control form-control-solid'
                      value={topic.topic_name}
                      onChange={e => {
                        const newTopics = [...unitForm.topics]
                        newTopics[index] = { ...newTopics[index], topic_name: e.target.value }
                        setUnitForm({ ...unitForm, topics: newTopics })
                      }}
                      placeholder='e.g. Linear Equations'
                    />
                  </div>
                  <div className='col-md-4'>
                    <label className='form-label fw-semibold fs-7'>Lectures</label>
                    <input
                      type='number'
                      className='form-control form-control-solid'
                      value={topic.lectures_estimated}
                      onChange={e => {
                        const newTopics = [...unitForm.topics]
                        newTopics[index] = { ...newTopics[index], lectures_estimated: Number(e.target.value) }
                        setUnitForm({ ...unitForm, topics: newTopics })
                      }}
                    />
                  </div>
                  <div className='col-md-12'>
                    <label className='form-label fw-semibold fs-7'>Topic Description</label>
                    <input
                      type='text'
                      className='form-control form-control-solid'
                      value={topic.description}
                      onChange={e => {
                        const newTopics = [...unitForm.topics]
                        newTopics[index] = { ...newTopics[index], description: e.target.value }
                        setUnitForm({ ...unitForm, topics: newTopics })
                      }}
                    />
                  </div>
                  <div className='col-md-12'>
                    <div className='form-check form-check-custom form-check-solid form-check-sm'>
                      <input
                        className='form-check-input'
                        type='checkbox'
                        id={`topic_optional_${index}`}
                        checked={topic.is_optional}
                        onChange={e => {
                          const newTopics = [...unitForm.topics]
                          newTopics[index] = { ...newTopics[index], is_optional: e.target.checked }
                          setUnitForm({ ...unitForm, topics: newTopics })
                        }}
                      />
                      <label className='form-check-label fw-bold text-gray-700' htmlFor={`topic_optional_${index}`}>Mark as Optional Topic</label>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            <div className='text-end mt-5'>
              <Button variant='light' onClick={() => setShowUnitModal(false)} disabled={saving} className='me-3'>Cancel</Button>
              <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Saving...' : 'Add Unit'}</Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>

      {/* UPLOAD RESOURCE MODAL */}
      <Modal show={showResourceModal} onHide={() => !saving && setShowResourceModal(false)} centered>
        <Modal.Header closeButton><Modal.Title>Add Resource to Topic</Modal.Title></Modal.Header>
        <Modal.Body>
          <form onSubmit={handleAddResource}>
            <div className='mb-5'>
              <label className='required form-label'>Title</label>
              <input type='text' className='form-control form-control-solid' value={resourceForm.title} onChange={e => setResourceForm({ ...resourceForm, title: e.target.value })} required placeholder='e.g. Chapter 1 Notes' />
            </div>
            <div className='mb-5'>
              <label className='required form-label'>Type</label>
              <select className='form-select form-select-solid' value={resourceForm.resource_type} onChange={e => setResourceForm({ ...resourceForm, resource_type: e.target.value })}>
                <option value='VIDEO'>Video Link</option>
                <option value='LINK'>Web Link</option>
                <option value='PDF'>PDF Document</option>
                <option value='DOC'>Word Document</option>
              </select>
            </div>

            {['VIDEO', 'LINK'].includes(resourceForm.resource_type) ? (
              <div className='mb-5'>
                <label className='required form-label'>URL</label>
                <input type='url' className='form-control form-control-solid' value={resourceForm.file_url} onChange={e => setResourceForm({ ...resourceForm, file_url: e.target.value })} required placeholder='https://...' />
              </div>
            ) : (
              <div className='mb-5'>
                <label className='required form-label'>File</label>
                <input type='file' className='form-control form-control-solid' onChange={e => setResourceForm({ ...resourceForm, file: e.target.files ? e.target.files[0] : null })} required accept={resourceForm.resource_type === 'PDF' ? '.pdf' : '.doc,.docx'} />
              </div>
            )}

            <div className='text-end'>
              <Button variant='light' onClick={() => setShowResourceModal(false)} disabled={saving} className='me-3'>Cancel</Button>
              <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Uploading...' : 'Upload Resource'}</Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>
      {/* EDIT TOPIC MODAL */}
      <Modal show={showEditTopicModal} onHide={() => !saving && setShowEditTopicModal(false)} centered>
        <Modal.Header closeButton><Modal.Title>Edit Topic Details</Modal.Title></Modal.Header>
        <Modal.Body>
          <form onSubmit={handleUpdateTopic}>
            <div className='mb-5'>
              <label className='required form-label'>Topic Name</label>
              <input type='text' className='form-control form-control-solid' value={editTopicForm.topic_name} onChange={e => setEditTopicForm({ ...editTopicForm, topic_name: e.target.value })} required />
            </div>
            <div className='mb-5'>
              <label className='form-label'>Description</label>
              <textarea className='form-control form-control-solid' rows={2} value={editTopicForm.description} onChange={e => setEditTopicForm({ ...editTopicForm, description: e.target.value })} />
            </div>
            <div className='mb-5'>
              <label className='required form-label'>Lectures Estimated</label>
              <input type='number' className='form-control form-control-solid' value={editTopicForm.lectures_estimated} onChange={e => setEditTopicForm({ ...editTopicForm, lectures_estimated: Number(e.target.value) })} required />
            </div>
            <div className='mb-8'>
              <div className='form-check form-check-custom form-check-solid'>
                <input className='form-check-input' type='checkbox' id='edit_topic_optional' checked={editTopicForm.is_optional} onChange={e => setEditTopicForm({ ...editTopicForm, is_optional: e.target.checked })} />
                <label className='form-check-label fw-bold' htmlFor='edit_topic_optional'>Optional Topic</label>
              </div>
            </div>
            <div className='text-end'>
              <Button variant='light' onClick={() => setShowEditTopicModal(false)} disabled={saving} className='me-3'>Cancel</Button>
              <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Updating...' : 'Save Changes'}</Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>

      {/* EDIT UNIT MODAL */}
      <Modal show={showEditUnitModal} onHide={() => !saving && setShowEditUnitModal(false)} centered>
        <Modal.Header closeButton><Modal.Title>Edit Unit Details</Modal.Title></Modal.Header>
        <Modal.Body>
          <form onSubmit={handleUpdateUnit}>
            <div className='mb-5'>
              <label className='required form-label'>Unit Name</label>
              <input type='text' className='form-control form-control-solid' value={editUnitForm.unit_name} onChange={e => setEditUnitForm({ ...editUnitForm, unit_name: e.target.value })} required />
            </div>
            <div className='mb-5'>
              <label className='form-label'>Description</label>
              <textarea className='form-control form-control-solid' rows={2} value={editUnitForm.description} onChange={e => setEditUnitForm({ ...editUnitForm, description: e.target.value })} />
            </div>
            <div className='mb-5'>
              <label className='required form-label'>Total Lectures</label>
              <input type='number' className='form-control form-control-solid' value={editUnitForm.total_lectures_estimated} onChange={e => setEditUnitForm({ ...editUnitForm, total_lectures_estimated: Number(e.target.value) })} required />
            </div>
            <div className='text-end'>
              <Button variant='light' onClick={() => setShowEditUnitModal(false)} disabled={saving} className='me-3'>Cancel</Button>
              <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Updating...' : 'Save Unit'}</Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>

      {/* ADD TOPIC TO UNIT MODAL */}
      <Modal show={showAddTopicModal} onHide={() => !saving && setShowAddTopicModal(false)} centered>
        <Modal.Header closeButton><Modal.Title>Add New Topic to Unit</Modal.Title></Modal.Header>
        <Modal.Body>
          <form onSubmit={handleAddTopicToUnit}>
            <div className='mb-5'>
              <label className='required form-label'>Topic Name(s)</label>
              <textarea 
                className='form-control form-control-solid' 
                rows={5}
                value={addTopicForm.topic_name} 
                onChange={e => setAddTopicForm({ ...addTopicForm, topic_name: e.target.value })} 
                required 
                placeholder={`e.g. Solving Linear Equations\nOr paste a list to add multiple topics in one go:\n1. Hindi वर्णमाला\n2. स्वर (अ से अः)\n3. व्यंजन (क से ज्ञ)`} 
              />
              <div className='form-text text-muted'>You can paste a list (one topic per line or separated by commas) to instantly add all of them in bulk!</div>
            </div>
            <div className='mb-5'>
              <label className='required form-label'>Lectures Estimated</label>
              <input type='number' className='form-control form-control-solid' value={addTopicForm.lectures_estimated} onChange={e => setAddTopicForm({ ...addTopicForm, lectures_estimated: Number(e.target.value) })} required />
            </div>
            <div className='mb-5'>
              <label className='form-label'>Description</label>
              <textarea className='form-control form-control-solid' rows={2} value={addTopicForm.description} onChange={e => setAddTopicForm({ ...addTopicForm, description: e.target.value })} placeholder='Optional description...' />
            </div>
            <div className='text-end'>
              <Button variant='light' onClick={() => setShowAddTopicModal(false)} disabled={saving} className='me-3'>Cancel</Button>
              <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Adding...' : 'Add Topic'}</Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>

      {/* UPDATE SYLLABUS PDF MODAL */}
      <Modal show={showPDFUploadModal} onHide={() => !saving && setShowPDFUploadModal(false)} centered>
        <Modal.Header closeButton><Modal.Title>{syllabus?.file_url ? 'Replace Syllabus PDF' : 'Upload Syllabus PDF'}</Modal.Title></Modal.Header>
        <Modal.Body>
          <form onSubmit={handleUpdateSyllabusPDF}>
            <div className='mb-5'>
              <label className='required form-label'>Syllabus Document (PDF)</label>
              <input type='file' className='form-control form-control-solid' accept='.pdf' onChange={e => setSyllabusPDFFile(e.target.files ? e.target.files[0] : null)} required />
              <div className='form-text text-muted'>Upload the syllabus PDF. This will overwrite any existing syllabus PDF document.</div>
            </div>
            <div className='text-end'>
              <Button variant='light' onClick={() => { setShowPDFUploadModal(false); setSyllabusPDFFile(null); }} disabled={saving} className='me-3'>Cancel</Button>
              <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Uploading...' : 'Upload PDF'}</Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>

      {/* SMART BULK IMPORT MODAL */}
      <Modal show={showSmartImportModal} onHide={() => !saving && setShowSmartImportModal(false)} size='lg' centered>
        <Modal.Header closeButton>
          <Modal.Title className='d-flex align-items-center gap-2'>
            <i className='ki-duotone ki-cloud-add fs-2 text-primary'><span className='path1'></span><span className='path2'></span></i>
            Smart Hierarchical Import (Bulk Syllabus)
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleSmartImportSubmit}>
            <div className='mb-5'>
              <label className='form-label fw-bold text-gray-800'>Paste Structured Syllabus</label>
              <textarea
                className='form-control form-control-solid'
                rows={10}
                value={smartImportText}
                onChange={e => setSmartImportText(e.target.value)}
                placeholder={`Paste your entire syllabus here! e.g.\n\n1. Numbers\nCounting Numbers\nNumber Names\n\n2. Addition\n2-Digit Addition\nWord Problems`}
                required
              />
              <div className='form-text text-muted'>
                System will automatically detect <strong>Units</strong> by checking numbering (e.g. <code>1. </code>, <code>2. </code>), and all subsequent lines will be added as <strong>Topics</strong> under that Unit.
              </div>
            </div>

            {parsedUnits.length > 0 && (
              <div className='mb-8'>
                <label className='form-label fw-bold text-success mb-3'>Live Parsing Preview ({parsedUnits.length} Units Detected)</label>
                <div className='border border-success border-dashed p-5 rounded bg-light-success bg-opacity-5' style={{ maxHeight: '300px', overflowY: 'auto' }}>
                  {parsedUnits.map((unit, uIdx) => (
                    <div key={uIdx} className='mb-5 border-bottom border-dashed pb-3 last-border-none'>
                      <div className='d-flex align-items-center justify-content-between mb-2'>
                        <span className='fw-bold text-dark fs-6'>Unit {unit.unit_number}: {unit.unit_name}</span>
                        <span className='badge badge-light-success fw-bold fs-9'>{unit.topics?.length || 0} Topics</span>
                      </div>
                      {unit.topics && unit.topics.length > 0 ? (
                        <div className='ps-5 mt-1'>
                          {unit.topics.map((t: any, tIdx: number) => (
                            <div key={tIdx} className='text-gray-700 fs-7 py-1 d-flex align-items-center'>
                              <span className='bullet bullet-dot bg-success me-2'></span>
                              {t.topic_name}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className='ps-5 text-muted italic fs-8'>(No topics found under this unit)</div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className='text-end mt-5'>
              <Button
                variant='light'
                onClick={() => {
                  setShowSmartImportModal(false)
                  setSmartImportText('')
                  setParsedUnits([])
                }}
                disabled={saving}
                className='me-3'
              >
                Cancel
              </Button>
              <Button variant='primary' type='submit' disabled={saving || parsedUnits.length === 0}>
                {saving ? 'Importing...' : `Import Entire Syllabus (${parsedUnits.length} Units)`}
              </Button>
            </div>
          </form>
        </Modal.Body>
      </Modal>
    </>
  )
}

const SyllabusWrapper: FC = () => {
  return (
    <>
      <PageTitle breadcrumbs={[{ title: 'Academic', path: '/academic/classes', isActive: false }, { title: 'Syllabus Management', path: '', isActive: true }]}>Syllabus Management</PageTitle>
      <SyllabusPage />
    </>
  )
}

export { SyllabusWrapper }
