import { FC, useState, useEffect, useCallback } from 'react'
import { toast } from 'react-toastify'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { Modal, Button, Alert, Badge, Form, Tabs, Tab, Card } from 'react-bootstrap'
import { useAuth } from '../auth'
import {
  getClasses,
  getClassSubjects,
  getClassSections,
  getAcademicSessions,
  getSyllabusHierarchy,
  getLessonPlans,
  createLessonPlan,
  updateLessonPlan,
  deleteLessonPlan,
  reviewLessonPlan,
  addLessonPlanResource,
  removeLessonPlanResource
} from './core/_requests'
import {
  ClassModel,
  SubjectModel,
  SessionModel,
  SectionModel,
  SyllabusModel,
  SyllabusTopic,
  LessonPlanModel
} from './core/_models'
import { getAcademicLabel } from '../../../_metronic/helpers'

const getLocalDateString = (d: Date = new Date()) => {
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const date = String(d.getDate()).padStart(2, '0')
  return `${year}-${month}-${date}`
}

const LessonsPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')
  const userRole = currentUser?.role || 'teacher'
  const isTeacher = userRole === 'teacher'
  const isControlAdmin = userRole === 'admin' || userRole === 'manager'

  // Filter states
  const [sessions, setSessions] = useState<SessionModel[]>([])
  const [classes, setClasses] = useState<ClassModel[]>([])
  const [subjects, setSubjects] = useState<SubjectModel[]>([])
  const [sections, setSections] = useState<SectionModel[]>([])
  
  const [selectedSessionId, setSelectedSessionId] = useState<number | ''>('')
  const [selectedClassId, setSelectedClassId] = useState<number | ''>('')
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | ''>('')
  const [selectedSectionId, setSelectedSectionId] = useState<number | ''>('')

  // Data states
  const [syllabus, setSyllabus] = useState<SyllabusModel | null>(null)
  const [lessonPlans, setLessonPlans] = useState<LessonPlanModel[]>([])
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState<string>('weekly')

  // Modals state
  const [showPlanModal, setShowPlanModal] = useState(false)
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<LessonPlanModel | null>(null)

  // Plan creation / edit form
  const [planForm, setPlanForm] = useState({
    id: 0,
    topic_id: 0,
    plan_date: '',
    status: 'PLANNED' as 'PLANNED' | 'COMPLETED' | 'DELAYED',
    completed_date: '',
    objectives: '',
    methodology: 'Whiteboard',
    homework: '',
    remarks: '',
    resources: [] as Array<{ title: string; resource_type: 'PDF' | 'VIDEO' | 'LINK' | 'DOC'; file_url: string }>
  })

  // Resource Form
  const [newResource, setNewResource] = useState({
    title: '',
    resource_type: 'LINK' as 'PDF' | 'VIDEO' | 'LINK' | 'DOC',
    file_url: ''
  })

  // Review Form
  const [reviewForm, setReviewForm] = useState({
    approval_status: 'APPROVED' as 'APPROVED' | 'REJECTED',
    feedback: ''
  })

  // Initial fetches
  useEffect(() => {
    if (!schoolId) return
    getAcademicSessions(schoolId).then(res => {
      if (res.data.success) {
        setSessions(res.data.data.sessions || [])
        const current = res.data.data.sessions.find(s => s.is_current)
        if (current) setSelectedSessionId(current.id)
      }
    })
    getClasses(schoolId, 1, 100).then(res => {
      if (res.data.success) setClasses(res.data.data.classes || [])
    })
  }, [schoolId])

  // Class selection change dependencies
  useEffect(() => {
    setSelectedSubjectId('')
    setSelectedSectionId('')
    setSubjects([])
    setSections([])
    setSyllabus(null)
    if (!schoolId || !selectedClassId) return

    getClassSubjects(schoolId, selectedClassId).then(res => {
      if (res.data.success) {
        const maps = res.data.data.subjects || []
        setSubjects(maps.map((m: any) => m.subject).filter(Boolean))
      }
    })

    getClassSections(schoolId, selectedClassId).then(res => {
      if (res.data.success) {
        setSections(res.data.data.sections?.map((s: any) => s.section).filter(Boolean) || [])
      }
    })
  }, [schoolId, selectedClassId])

  // Main fetch call for syllabus and plans
  const fetchData = useCallback(async () => {
    if (!schoolId || !selectedClassId || !selectedSubjectId || !selectedSectionId) {
      setLessonPlans([])
      return
    }
    setLoading(true)
    try {
      // 1. Fetch Syllabus hierarchy
      try {
        const sylRes = await getSyllabusHierarchy(schoolId, selectedClassId, selectedSubjectId)
        if (sylRes.data.success && sylRes.data.data.syllabus) {
          setSyllabus(sylRes.data.data.syllabus)
        } else {
          setSyllabus(null)
        }
      } catch (err) {
        setSyllabus(null)
      }

      // 2. Fetch Lesson plans
      const planRes = await getLessonPlans(schoolId, {
        class_section_id: selectedSectionId,
        subject_id: selectedSubjectId
      })
      if (planRes.data.success) {
        setLessonPlans(planRes.data.data.plans || [])
      }
    } catch (err: any) {
      toast.error('Failed to load lesson plans data.')
    } finally {
      setLoading(false)
    }
  }, [schoolId, selectedClassId, selectedSubjectId, selectedSectionId])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  // Flat array of all topics in syllabus for selector mapping
  const getAllTopics = (): SyllabusTopic[] => {
    if (!syllabus || !syllabus.units) return []
    const topics: SyllabusTopic[] = []
    syllabus.units.forEach(u => {
      if (u.topics) topics.push(...u.topics)
    })
    return topics
  }

  // Handle plan submit (Create or Update)
  const handlePlanSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedSectionId || !selectedSubjectId || !planForm.topic_id || !planForm.plan_date) {
      toast.warning('Please fill in all required fields.')
      return
    }

    setSaving(true)
    try {
      const payload = {
        class_section_id: Number(selectedSectionId),
        subject_id: Number(selectedSubjectId),
        topic_id: Number(planForm.topic_id),
        plan_date: planForm.plan_date,
        status: planForm.status,
        completed_date: planForm.status === 'COMPLETED' ? planForm.completed_date || getLocalDateString() : null,
        objectives: planForm.objectives,
        methodology: planForm.methodology,
        homework: planForm.homework,
        remarks: planForm.remarks,
        resources: planForm.id === 0 ? planForm.resources : [] // Only create new resources on creation, edit resources handled separately
      }

      if (planForm.id === 0) {
        await createLessonPlan(schoolId, payload)
        toast.success('Lesson plan created successfully!')
      } else {
        await updateLessonPlan(schoolId, planForm.id, payload)
        toast.success('Lesson plan updated successfully!')
      }
      setShowPlanModal(false)
      fetchData()
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to save lesson plan.')
    } finally {
      setSaving(false)
    }
  }

  // Handle deletion
  const handleDeletePlan = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this lesson plan?')) return
    try {
      await deleteLessonPlan(schoolId, id)
      toast.success('Lesson plan deleted successfully!')
      fetchData()
    } catch (err: any) {
      toast.error('Failed to delete lesson plan.')
    }
  }

  // Handle admin approval submission
  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedPlan) return
    setSaving(true)
    try {
      await reviewLessonPlan(schoolId, selectedPlan.id, reviewForm)
      toast.success(`Lesson plan ${reviewForm.approval_status.toLowerCase()} successfully!`)
      setShowReviewModal(false)
      fetchData()
    } catch (err: any) {
      toast.error('Failed to submit review.')
    } finally {
      setSaving(false)
    }
  }

  // Handle resources modification inside plan
  const handleAddResource = async () => {
    if (!newResource.title || !newResource.file_url) {
      toast.warning('Please provide resource title and URL.')
      return
    }

    if (planForm.id === 0) {
      // In-memory add before creation
      setPlanForm({
        ...planForm,
        resources: [...planForm.resources, { ...newResource }]
      })
      setNewResource({ title: '', resource_type: 'LINK', file_url: '' })
    } else {
      // Direct API upload for edit mode
      try {
        await addLessonPlanResource(schoolId, planForm.id, newResource)
        toast.success('Resource uploaded successfully!')
        const updated = await getLessonPlans(schoolId, {
          class_section_id: selectedSectionId,
          subject_id: selectedSubjectId
        })
        setLessonPlans(updated.data.data.plans || [])
        // Update local resources array for view list update
        const updatedPlan = updated.data.data.plans.find(p => p.id === planForm.id)
        if (updatedPlan) {
          setPlanForm(prev => ({ ...prev, resources: updatedPlan.resources || [] }))
        }
        setNewResource({ title: '', resource_type: 'LINK', file_url: '' })
      } catch (err: any) {
        toast.error('Failed to add resource.')
      }
    }
  }

  const handleRemoveResource = async (idx: number, serverResId?: number) => {
    if (planForm.id === 0) {
      // In-memory remove
      setPlanForm({
        ...planForm,
        resources: planForm.resources.filter((_, i) => i !== idx)
      })
    } else if (serverResId) {
      // Direct API delete
      if (!window.confirm('Delete this resource attachment?')) return
      try {
        await removeLessonPlanResource(schoolId, serverResId)
        toast.success('Resource removed successfully!')
        setPlanForm(prev => ({
          ...prev,
          resources: prev.resources.filter(r => (r as any).id !== serverResId)
        }))
        // Refresh plans
        fetchData()
      } catch (err) {
        toast.error('Failed to remove resource.')
      }
    }
  }

  // Open modal helper
  const openPlanModal = (plan?: LessonPlanModel, targetDate?: string) => {
    if (plan) {
      setPlanForm({
        id: plan.id,
        topic_id: plan.topic_id,
        plan_date: plan.plan_date,
        status: plan.status,
        completed_date: plan.completed_date || '',
        objectives: plan.objectives || '',
        methodology: plan.methodology || 'Whiteboard',
        homework: plan.homework || '',
        remarks: plan.remarks || '',
        resources: plan.resources || []
      })
    } else {
      setPlanForm({
        id: 0,
        topic_id: 0,
        plan_date: targetDate || getLocalDateString(),
        status: 'PLANNED',
        completed_date: '',
        objectives: '',
        methodology: 'Whiteboard',
        homework: '',
        remarks: '',
        resources: []
      })
    }
    setShowPlanModal(true)
  }

  // Weekly Planner dynamic columns mapper
  const getWeeklyDays = () => {
    const today = new Date()
    const currentDayOfWeek = today.getDay() // 0 = Sunday, 1 = Monday
    const startOfWeek = new Date(today)
    startOfWeek.setDate(today.getDate() - (currentDayOfWeek === 0 ? 6 : currentDayOfWeek - 1)) // Get current week's Monday

    const days = []
    for (let i = 0; i < 7; i++) {
      const day = new Date(startOfWeek)
      day.setDate(startOfWeek.getDate() + i)
      days.push({
        dateStr: getLocalDateString(day),
        label: day.toLocaleDateString('en-US', { weekday: 'long' }),
        dateFormatted: day.toLocaleDateString('en-US', { day: 'numeric', month: 'short' }),
        isToday: day.toDateString() === today.toDateString()
      })
    }
    return days
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>
        {/* FILTERS */}
        <div className='card mb-7'>
          <div className='card-body py-3'>
            <div className='d-flex flex-wrap align-items-center gap-5'>
              <div className='d-flex align-items-center min-w-150px'>
                <span className='text-gray-700 fw-bold fs-7 me-3 text-nowrap'>Session:</span>
                <select className='form-select form-select-sm form-select-solid' value={selectedSessionId} onChange={e => setSelectedSessionId(Number(e.target.value))}>
                  <option value=''>Select...</option>
                  {sessions.map(s => <option key={s.id} value={s.id}>{s.session_year}</option>)}
                </select>
              </div>
              <div className='d-flex align-items-center min-w-150px'>
                <span className='text-gray-700 fw-bold fs-7 me-3 text-nowrap'>{getAcademicLabel()}:</span>
                <select className='form-select form-select-sm form-select-solid' value={selectedClassId} onChange={e => setSelectedClassId(Number(e.target.value))}>
                  <option value=''>Select...</option>
                  {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className='d-flex align-items-center min-w-150px'>
                <span className='text-gray-700 fw-bold fs-7 me-3 text-nowrap'>Section:</span>
                <select className='form-select form-select-sm form-select-solid' value={selectedSectionId} onChange={e => setSelectedSectionId(Number(e.target.value))} disabled={!selectedClassId}>
                  <option value=''>Select...</option>
                  {sections.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className='d-flex align-items-center min-w-150px'>
                <span className='text-gray-700 fw-bold fs-7 me-3 text-nowrap'>Subject:</span>
                <select className='form-select form-select-sm form-select-solid' value={selectedSubjectId} onChange={e => setSelectedSubjectId(Number(e.target.value))} disabled={!selectedClassId}>
                  <option value=''>Select...</option>
                  {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* WORKSPACE */}
        {selectedClassId && selectedSectionId && selectedSubjectId ? (
          loading ? (
            <div className='text-center py-20'><span className='spinner-border text-primary'></span></div>
          ) : (
            <div className='card border border-gray-300'>
              <div className='card-header pt-4 pb-0 border-bottom-0 bg-light-primary bg-opacity-10'>
                <div className='card-title flex-column'>
                  <h3 className='fw-bold text-gray-900 fs-2 m-0'>Lesson Planner Board</h3>
                  <span className='text-muted fs-7 fw-semibold mt-1'>Schedule learning targets, map resources, and view execution tracking.</span>
                </div>
                <div className='card-toolbar gap-2'>
                  <Button variant='primary' size='sm' className='fw-bold' onClick={() => openPlanModal()} disabled={!syllabus}>
                    <i className='ki-duotone ki-plus fs-4 me-1'></i> Create Daily Plan
                  </Button>
                </div>
              </div>

              <div className='card-body pt-5'>
                <Tabs activeKey={activeTab} onSelect={k => setActiveTab(k || 'weekly')} className='nav nav-tabs nav-line-tabs mb-7 fs-6'>
                  <Tab eventKey='weekly' title='Weekly Planner Grid'>
                    <div className='row row-cols-1 row-cols-md-7 g-4 mt-1'>
                      {getWeeklyDays().map((day, dIdx) => {
                        const dayPlans = lessonPlans.filter(p => p.plan_date === day.dateStr)
                        return (
                          <div key={dIdx} className='col'>
                            <div className={`card h-100 border ${day.isToday ? 'border-primary shadow-sm bg-light-primary bg-opacity-5' : 'border-gray-200'}`}>
                              <div className={`card-header p-3 d-flex flex-column align-items-center justify-content-center text-center ${day.isToday ? 'bg-primary text-white' : 'bg-light bg-opacity-50 text-gray-800'}`}>
                                <span className='fw-bold fs-7'>{day.label}</span>
                                <span className='fs-8 opacity-75 mt-1'>{day.dateFormatted}</span>
                              </div>
                              <div className='card-body p-3 d-flex flex-column gap-3 min-h-200px'>
                                {dayPlans.length > 0 ? (
                                  dayPlans.map(plan => (
                                    <div
                                      key={plan.id}
                                      className={`p-3 rounded border border-dashed transition-3s cursor-pointer position-relative hover-shadow-sm
                                        ${plan.approval_status === 'APPROVED' ? 'border-success bg-light-success bg-opacity-10' :
                                          plan.approval_status === 'REJECTED' ? 'border-danger bg-light-danger bg-opacity-10' :
                                            'border-warning bg-light-warning bg-opacity-10'
                                        }`}
                                      onClick={() => openPlanModal(plan)}
                                    >
                                      <div className='d-flex align-items-center justify-content-between mb-1'>
                                        <Badge
                                          bg={plan.status === 'COMPLETED' ? 'success' : plan.status === 'DELAYED' ? 'danger' : 'info'}
                                          className='fs-9 px-2 py-0.5'
                                        >
                                          {plan.status}
                                        </Badge>
                                        <Badge
                                          bg={plan.approval_status === 'APPROVED' ? 'light-success' : plan.approval_status === 'REJECTED' ? 'light-danger' : 'light-warning'}
                                          className={`text-${plan.approval_status === 'APPROVED' ? 'success' : plan.approval_status === 'REJECTED' ? 'danger' : 'warning'} fs-9 border-0`}
                                        >
                                          {plan.approval_status}
                                        </Badge>
                                      </div>
                                      <h6 className='fw-bold text-gray-900 fs-7 m-0 pe-4 text-truncate'>{plan.topic?.topic_name || 'Unmapped Topic'}</h6>
                                      {plan.methodology && <span className='text-muted fs-9 d-block mt-1'>{plan.methodology}</span>}
                                      
                                      {/* Quick Delete */}
                                      <button
                                        type='button'
                                        className='btn btn-icon btn-xs btn-active-color-danger position-absolute top-5px end-5px opacity-0 hover-opacity-100'
                                        onClick={(e) => {
                                          e.stopPropagation()
                                          handleDeletePlan(plan.id)
                                        }}
                                      >
                                        <i className='ki-duotone ki-cross fs-7'><span className='path1'></span><span className='path2'></span></i>
                                      </button>
                                    </div>
                                  ))
                                ) : (
                                  <div className='d-flex flex-column align-items-center justify-content-center m-auto text-center opacity-30'>
                                    <i className='ki-duotone ki-calendar-add fs-2 text-gray-400 mb-1'><span className='path1'></span><span className='path2'></span><span className='path3'></span><span className='path4'></span><span className='path5'></span><span className='path6'></span></i>
                                    <span className='fs-9 fw-semibold cursor-pointer text-primary text-hover-underline' onClick={() => openPlanModal(undefined, day.dateStr)}>Add Plan</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </Tab>
                  
                  <Tab eventKey='progress' title='Syllabus Execution Timeline'>
                    {!syllabus ? (
                      <div className='alert alert-warning border border-warning border-dashed d-flex align-items-center p-5'>
                        <i className='ki-duotone ki-information-2 fs-2qx text-warning me-4'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                        <div>
                          <h4 className='text-gray-900 fw-bold m-0 fs-5'>No Syllabus Initialized</h4>
                          <span className='text-muted fs-7 fw-semibold'>Please initialize the syllabus framework for this subject to construct the planned execution timeline.</span>
                        </div>
                      </div>
                    ) : (
                      <div className='timeline-container mt-4'>
                        {syllabus.units?.map((unit, uIdx) => (
                          <div key={unit.id} className='card border border-gray-200 bg-light bg-opacity-20 mb-6'>
                            <div className='card-header py-4 bg-light-primary bg-opacity-5'>
                              <h4 className='fw-bold text-gray-900 m-0 fs-6'>Unit {unit.unit_number}: {unit.unit_name}</h4>
                            </div>
                            <div className='card-body p-5'>
                              <div className='table-responsive'>
                                <table className='table table-row-dashed table-row-gray-300 align-middle gs-0 gy-3 m-0'>
                                  <thead>
                                    <tr className='fw-bold text-muted fs-7 border-bottom-1'>
                                      <th className='min-w-150px'>Topic</th>
                                      <th className='min-w-100px'>Planned Date</th>
                                      <th className='min-w-100px'>Actual Completed Date</th>
                                      <th className='min-w-100px text-center'>Status</th>
                                      <th className='min-w-100px text-center'>Approval</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {unit.topics?.map((topic) => {
                                      const mappedPlan = lessonPlans.find(p => p.topic_id === topic.id)
                                      return (
                                        <tr key={topic.id}>
                                          <td>
                                            <div className='d-flex flex-column'>
                                              <span className='text-gray-900 fw-bold fs-7'>{topic.topic_name}</span>
                                              <span className='text-muted fs-8'>{topic.lectures_estimated} lectures estimated</span>
                                            </div>
                                          </td>
                                          <td>
                                            {mappedPlan ? (
                                              <span className='text-gray-800 fw-semibold fs-7'>{mappedPlan.plan_date}</span>
                                            ) : (
                                              <span className='text-muted italic fs-8'>Not Scheduled</span>
                                            )}
                                          </td>
                                          <td>
                                            {mappedPlan && mappedPlan.status === 'COMPLETED' ? (
                                              <span className='text-success fw-bold fs-7'>{mappedPlan.completed_date || mappedPlan.plan_date}</span>
                                            ) : mappedPlan ? (
                                              <span className='text-warning italic fs-8'>Pending Execution</span>
                                            ) : (
                                              <span className='text-muted fs-8'>-</span>
                                            )}
                                          </td>
                                          <td className='text-center'>
                                            {mappedPlan ? (
                                              <Badge bg={mappedPlan.status === 'COMPLETED' ? 'success' : mappedPlan.status === 'DELAYED' ? 'danger' : 'info'} className='px-3 py-1.5 fs-8'>
                                                {mappedPlan.status}
                                              </Badge>
                                            ) : (
                                              <Badge bg='light' className='text-muted px-3 py-1.5 fs-8 border'>UNPLANNED</Badge>
                                            )}
                                          </td>
                                          <td className='text-center'>
                                            {mappedPlan ? (
                                              <Badge bg={mappedPlan.approval_status === 'APPROVED' ? 'light-success' : mappedPlan.approval_status === 'REJECTED' ? 'light-danger' : 'light-warning'} className={`text-${mappedPlan.approval_status === 'APPROVED' ? 'success' : mappedPlan.approval_status === 'REJECTED' ? 'danger' : 'warning'} px-3 py-1.5 fs-8 border-0`}>
                                                {mappedPlan.approval_status}
                                              </Badge>
                                            ) : (
                                              <span className='text-muted fs-8'>-</span>
                                            )}
                                          </td>
                                        </tr>
                                      )
                                    })}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </Tab>

                  {isControlAdmin && (
                    <Tab eventKey='approvals' title='Approval Board'>
                      <div className='table-responsive mt-3 border border-gray-200 rounded'>
                        <table className='table table-row-dashed table-row-gray-300 align-middle gs-0 gy-4 m-0'>
                          <thead>
                            <tr className='fw-bold text-gray-700 fs-7 border-bottom-2 bg-light p-4'>
                              <th className='ps-4'>Planned Date</th>
                              <th>Topic</th>
                              <th>Objectives</th>
                              <th>Methodology</th>
                              <th className='text-center'>Approval State</th>
                              <th className='text-end pe-4'>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {lessonPlans.length > 0 ? (
                              lessonPlans.map((plan) => (
                                <tr key={plan.id}>
                                  <td className='ps-4 fw-bold text-gray-800fs-7'>{plan.plan_date}</td>
                                  <td>
                                    <div className='d-flex flex-column'>
                                      <span className='text-gray-900 fw-bold fs-7'>{plan.topic?.topic_name || 'Unmapped Topic'}</span>
                                      <span className='text-muted fs-8'>Lectures: {plan.topic?.lectures_estimated}</span>
                                    </div>
                                  </td>
                                  <td><span className='text-gray-600 fs-7 text-truncate max-w-200px d-block'>{plan.objectives || '-'}</span></td>
                                  <td><Badge bg='light-dark' className='text-dark fs-8 border border-gray-300'>{plan.methodology}</Badge></td>
                                  <td className='text-center'>
                                    <Badge bg={plan.approval_status === 'APPROVED' ? 'light-success' : plan.approval_status === 'REJECTED' ? 'light-danger' : 'light-warning'} className={`text-${plan.approval_status === 'APPROVED' ? 'success' : plan.approval_status === 'REJECTED' ? 'danger' : 'warning'} px-3 py-1.5 fs-8 border-0`}>
                                      {plan.approval_status}
                                    </Badge>
                                  </td>
                                  <td className='text-end pe-4'>
                                    <div className='d-flex gap-2 justify-content-end'>
                                      <Button variant='light-primary' size='sm' className='fw-bold px-3 py-1' onClick={() => { setSelectedPlan(plan); setReviewForm({ approval_status: plan.approval_status === 'PENDING' ? 'APPROVED' : plan.approval_status, feedback: plan.feedback || '' }); setShowReviewModal(true); }}>
                                        Review
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))
                            ) : (
                              <tr>
                                <td colSpan={6} className='text-center py-10 text-muted fs-7 italic'>No plans registered for approval.</td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </Tab>
                  )}
                </Tabs>
              </div>
            </div>
          )
        ) : (
          <div className='card border border-gray-300'>
            <div className='card-body text-center py-20'>
              <div className='symbol symbol-100px mb-5'>
                <div className='symbol-label bg-light-primary'>
                  <i className='ki-duotone ki-filter-search fs-3x text-primary'><span className='path1'></span><span className='path2'></span><span className='path3'></span></i>
                </div>
              </div>
              <h3 className='text-gray-800 fw-bold'>Select Academic Target</h3>
              <p className='text-muted fs-6 mb-0'>Please select a Session, Class, Section, and Subject to start lesson planning.</p>
            </div>
          </div>
        )}
      </Content>

      {/* PLAN CREATION MODAL */}
      <Modal show={showPlanModal} onHide={() => !saving && setShowPlanModal(false)} size='lg' centered>
        <Modal.Header closeButton>
          <Modal.Title>{planForm.id === 0 ? 'Create Daily Lesson Plan' : 'Modify Lesson Plan'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {!syllabus ? (
            <Alert variant='danger'>No syllabusFramework found. Please define syllabus units/topics first.</Alert>
          ) : (
            <form onSubmit={handlePlanSubmit}>
              <div className='row g-5 mb-5'>
                <div className='col-md-6'>
                  <label className='required form-label fw-bold'>Select Syllabus Topic</label>
                  <select
                    className='form-select form-select-solid'
                    value={planForm.topic_id}
                    onChange={e => setPlanForm({ ...planForm, topic_id: Number(e.target.value) })}
                    required
                    disabled={planForm.id !== 0}
                  >
                    <option value=''>Select topic...</option>
                    {syllabus.units?.map(u => (
                      <optgroup key={u.id} label={`Unit ${u.unit_number}: ${u.unit_name}`}>
                        {u.topics?.map(t => (
                          <option key={t.id} value={t.id}>{t.topic_name} ({t.lectures_estimated} lectures)</option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                </div>
                <div className='col-md-6'>
                  <label className='required form-label fw-bold'>Planned Date</label>
                  <input
                    type='date'
                    className='form-control form-control-solid'
                    value={planForm.plan_date}
                    onChange={e => setPlanForm({ ...planForm, plan_date: e.target.value })}
                    required
                  />
                </div>
                <div className='col-md-6'>
                  <label className='required form-label fw-bold'>Execution Status</label>
                  <select
                    className='form-select form-select-solid'
                    value={planForm.status}
                    onChange={e => setPlanForm({ ...planForm, status: e.target.value as any })}
                    required
                  >
                    <option value='PLANNED'>Planned</option>
                    <option value='COMPLETED'>Completed</option>
                    <option value='DELAYED'>Delayed</option>
                  </select>
                </div>
                {planForm.status === 'COMPLETED' && (
                  <div className='col-md-6'>
                    <label className='required form-label fw-bold'>Actual Completion Date</label>
                    <input
                      type='date'
                      className='form-control form-control-solid'
                      value={planForm.completed_date}
                      onChange={e => setPlanForm({ ...planForm, completed_date: e.target.value })}
                      required
                    />
                  </div>
                )}
              </div>

              <div className='mb-5'>
                <label className='form-label fw-bold'>Learning Objectives (सीखने के उद्देश्य)</label>
                <textarea
                  className='form-control form-control-solid'
                  rows={3}
                  value={planForm.objectives}
                  onChange={e => setPlanForm({ ...planForm, objectives: e.target.value })}
                  placeholder='What should students learn from this lecture?'
                />
              </div>

              <div className='row g-5 mb-5'>
                <div className='col-md-6'>
                  <label className='form-label fw-bold'>Teaching Method (पद्धति)</label>
                  <select
                    className='form-select form-select-solid'
                    value={planForm.methodology}
                    onChange={e => setPlanForm({ ...planForm, methodology: e.target.value })}
                  >
                    <option value='Whiteboard'>Whiteboard & Chalk</option>
                    <option value='PowerPoint Presentation'>PowerPoint Presentation (PPT)</option>
                    <option value='Smartboard / Digital Whiteboard'>Smartboard / Digital Whiteboard</option>
                    <option value='Practical Lab Activity'>Practical Lab Activity</option>
                    <option value='Group Discussion / Quiz'>Group Discussion / Quiz</option>
                  </select>
                </div>
                <div className='col-md-6'>
                  <label className='form-label fw-bold'>Daily Homework / Tasks</label>
                  <input
                    type='text'
                    className='form-control form-control-solid'
                    value={planForm.homework}
                    onChange={e => setPlanForm({ ...planForm, homework: e.target.value })}
                    placeholder='Assigned homework or reading tasks...'
                  />
                </div>
              </div>

              <div className='mb-7'>
                <label className='form-label fw-bold'>Teacher Remarks / Execution Notes</label>
                <textarea
                  className='form-control form-control-solid'
                  rows={2}
                  value={planForm.remarks}
                  onChange={e => setPlanForm({ ...planForm, remarks: e.target.value })}
                  placeholder='Additional execution comments or notes...'
                />
              </div>

              {/* ATTACHMENTS SECTION */}
              <div className='mb-8 border-top pt-5'>
                <h5 className='text-primary mb-4 fw-bold'>Digital Attachments & Reference Materials</h5>
                
                <div className='row g-3 mb-4 align-items-end'>
                  <div className='col-md-4'>
                    <label className='form-label fs-7 fw-semibold'>Title</label>
                    <input
                      type='text'
                      className='form-control form-control-solid form-control-sm'
                      value={newResource.title}
                      onChange={e => setNewResource({ ...newResource, title: e.target.value })}
                      placeholder='e.g. Chapter 1 slides'
                    />
                  </div>
                  <div className='col-md-3'>
                    <label className='form-label fs-7 fw-semibold'>Resource Type</label>
                    <select
                      className='form-select form-select-solid form-select-sm'
                      value={newResource.resource_type}
                      onChange={e => setNewResource({ ...newResource, resource_type: e.target.value as any })}
                    >
                      <option value='LINK'>Web Link</option>
                      <option value='VIDEO'>Video URL</option>
                      <option value='PDF'>PDF Document</option>
                      <option value='DOC'>Word Document</option>
                    </select>
                  </div>
                  <div className='col-md-4'>
                    <label className='form-label fs-7 fw-semibold'>URL</label>
                    <input
                      type='url'
                      className='form-control form-control-solid form-control-sm'
                      value={newResource.file_url}
                      onChange={e => setNewResource({ ...newResource, file_url: e.target.value })}
                      placeholder='https://...'
                    />
                  </div>
                  <div className='col-md-1'>
                    <Button variant='success' size='sm' className='w-100 py-2.5 btn-icon' onClick={handleAddResource}>
                      <i className='ki-duotone ki-plus fs-4 p-0'></i>
                    </Button>
                  </div>
                </div>

                {planForm.resources.length > 0 ? (
                  <div className='d-flex flex-wrap gap-2'>
                    {planForm.resources.map((res, rIdx) => (
                      <div key={rIdx} className='badge badge-light-dark border border-gray-300 d-flex align-items-center px-3 py-2'>
                        <i className={`ki-duotone fs-6 text-gray-700 me-2 ${res.resource_type === 'VIDEO' ? 'ki-youtube' :
                          res.resource_type === 'PDF' ? 'ki-file' : 'ki-link'
                          }`}><span className='path1'></span><span className='path2'></span></i>
                        <a href={res.file_url} target='_blank' rel='noreferrer' className='text-gray-800 text-hover-primary fw-bold fs-8 me-2'>
                          {res.title}
                        </a>
                        <button type='button' className='btn btn-icon btn-xs btn-active-color-danger' onClick={() => handleRemoveResource(rIdx, (res as any).id)}>
                          <i className='ki-duotone ki-cross fs-8'><span className='path1'></span><span className='path2'></span></i>
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className='text-muted fs-8 italic'>No lecture resources mapped yet.</div>
                )}
              </div>

              <div className='text-end mt-7'>
                <Button variant='light' onClick={() => setShowPlanModal(false)} disabled={saving} className='me-3'>Cancel</Button>
                <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Saving...' : 'Save Lesson Plan'}</Button>
              </div>
            </form>
          )}
        </Modal.Body>
      </Modal>

      {/* REVIEW APPROVAL MODAL */}
      <Modal show={showReviewModal} onHide={() => !saving && setShowReviewModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Review Daily Lesson Plan</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedPlan && (
            <form onSubmit={handleReviewSubmit}>
              <div className='mb-5 bg-light-primary bg-opacity-20 p-5 rounded border border-primary border-opacity-25'>
                <h5 className='fw-bold text-gray-900 fs-6 mb-2'>Plan Date: {selectedPlan.plan_date}</h5>
                <p className='text-gray-800 fw-bold fs-7 m-0'>Topic: {selectedPlan.topic?.topic_name || 'Unmapped Topic'}</p>
                {selectedPlan.objectives && <p className='text-gray-700 fs-7 mt-2 mb-0'><strong>Objectives:</strong> {selectedPlan.objectives}</p>}
                {selectedPlan.methodology && <p className='text-gray-700 fs-7 mt-1 mb-0'><strong>Methodology:</strong> {selectedPlan.methodology}</p>}
              </div>

              <div className='mb-5'>
                <label className='required form-label fw-bold'>Approval Decision</label>
                <select
                  className='form-select form-select-solid'
                  value={reviewForm.approval_status}
                  onChange={e => setReviewForm({ ...reviewForm, approval_status: e.target.value as any })}
                  required
                >
                  <option value='APPROVED'>Approve Plan</option>
                  <option value='REJECTED'>Reject & Request Edits</option>
                </select>
              </div>

              <div className='mb-7'>
                <label className='form-label fw-bold'>Admin Review Feedback</label>
                <textarea
                  className='form-control form-control-solid'
                  rows={4}
                  value={reviewForm.feedback}
                  onChange={e => setReviewForm({ ...reviewForm, feedback: e.target.value })}
                  placeholder='Leave any revision feedback or approvals comments...'
                />
              </div>

              <div className='text-end'>
                <Button variant='light' onClick={() => setShowReviewModal(false)} disabled={saving} className='me-3'>Cancel</Button>
                <Button variant='primary' type='submit' disabled={saving}>{saving ? 'Submitting...' : 'Submit Decision'}</Button>
              </div>
            </form>
          )}
        </Modal.Body>
      </Modal>
    </>
  )
}

const LessonsWrapper: FC = () => {
  return (
    <>
      <PageTitle breadcrumbs={[{ title: 'Academic', path: '/academic/classes', isActive: false }, { title: 'Lesson Planning', path: '', isActive: true }]}>Lesson Planning Board</PageTitle>
      <LessonsPage />
    </>
  )
}

export { LessonsWrapper }
export default LessonsWrapper
