import { FC, useState, useEffect, useCallback } from 'react'
import { Modal } from 'react-bootstrap'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../auth'
import axios from 'axios'
import { toast } from 'react-toastify'
import { KTIcon } from '../../../_metronic/helpers'

const API_URL = import.meta.env.VITE_APP_API_URL
const BASE = (schoolId: string) => `${API_URL}/school/${schoolId}/programs`

// ── Types ──────────────────────────────────────────────────────────────────────
interface Program {
  id: number
  name: string
  program_type: 'SCHOOL' | 'COLLEGE'
  duration_years: number | null
  semester_based: boolean
  total_semesters: number | null
  is_active: boolean
  classes?: ProgramClass[]
}

interface ProgramClass {
  id: number
  name: string
  semester_number: number | null
  numeric_value: number | null
}

interface PromotePreview {
  count: number
  students: { id: number; name: string }[]
}

const emptyForm = (): Partial<Program> => ({
  name: '', duration_years: undefined,
  semester_based: false, total_semesters: undefined
})

// ── Program Card ───────────────────────────────────────────────────────────────
const ProgramCard: FC<{
  program: Program
  onEdit: (p: Program) => void
  onDelete: (id: number) => void
  onSelect: (p: Program) => void
  selected: boolean
}> = ({ program, onEdit, onDelete, onSelect, selected }) => (
  <div
    className={`card border mb-4 hover-elevate-up ${selected ? 'border-primary border-2 shadow-sm' : 'border-transparent'}`}
    onClick={() => onSelect(program)}
    style={{ cursor: 'pointer', transition: 'all 0.2s' }}
  >
    <div className='card-body p-5'>
      <div className='d-flex justify-content-between align-items-start mb-2'>
        <div>
          <h5 className='fw-bold mb-1'>{program.name}</h5>
          <div className='d-flex gap-2 flex-wrap'>
            <span className='badge badge-light-primary'>
              {program.program_type === 'COLLEGE' ? '🎓 College' : '🏫 School'}
            </span>
            {program.semester_based && (
              <span className='badge badge-light-primary'>Semester-based</span>
            )}
            {program.duration_years && (
              <span className='badge badge-light-primary'>{program.duration_years} yr</span>
            )}
            {program.total_semesters && (
              <span className='badge badge-light-primary'>{program.total_semesters} Semesters</span>
            )}
          </div>
        </div>
        <div className='d-flex gap-2' onClick={e => e.stopPropagation()}>
          <button className='btn btn-icon btn-sm btn-active-light-primary btn-light' title='Edit' onClick={() => onEdit(program)}>
            <KTIcon iconName='pencil' className='fs-3' />
          </button>
          <button className='btn btn-icon btn-sm btn-active-light-danger btn-light' title='Delete' onClick={() => onDelete(program.id)}>
            <KTIcon iconName='trash' className='fs-3' />
          </button>
        </div>
      </div>
      <div className='text-muted fw-semibold fs-7 mt-3'>
        {program.classes?.length || 0} {program.semester_based ? 'Semesters' : 'Classes'} linked
      </div>
    </div>
  </div>
)

// ── Promote Modal ──────────────────────────────────────────────────────────────
const PromoteModal: FC<{
  show: boolean
  program: Program | null
  schoolId: string
  onClose: () => void
  onDone: () => void
}> = ({ show, program, schoolId, onClose, onDone }) => {
  const [fromClassId, setFromClassId] = useState('')
  const [toClassId, setToClassId] = useState('')
  const [sessionId, setSessionId] = useState('')
  const [sessions, setSessions] = useState<any[]>([])
  const [preview, setPreview] = useState<PromotePreview | null>(null)
  const [selectedStudentIds, setSelectedStudentIds] = useState<number[]>([])
  const [previewing, setPreviewing] = useState(false)
  const [promoting, setPromoting] = useState(false)

  useEffect(() => {
    if (show && schoolId) {
      axios.get(`${API_URL}/school/${schoolId}/academic-sessions`, { params: { page: 1, limit: 100 } }).then(r => {
        if (r.data.success) {
          const sessionsArr = r.data.data?.sessions || r.data.data || []
          setSessions(Array.isArray(sessionsArr) ? sessionsArr : [])
        }
      }).catch(() => { })
    }
  }, [show, schoolId])

  const handlePreview = async () => {
    if (!fromClassId || !sessionId) return
    setPreviewing(true); setPreview(null)
    try {
      const { data } = await axios.post(`${BASE(schoolId)}/${program?.id}/promote/preview`, {
        from_class_id: Number(fromClassId), academic_session_id: Number(sessionId)
      })
      if (data.success) {
        setPreview(data.data)
        setSelectedStudentIds(data.data.students?.map((s: any) => s.id) || [])
      }
    } catch (e: any) { toast.error(e.response?.data?.message || 'Preview failed') }
    finally { setPreviewing(false) }
  }

  const handlePromote = async () => {
    if (!fromClassId || !toClassId || !sessionId) return
    setPromoting(true)
    try {
      const { data } = await axios.post(`${BASE(schoolId)}/${program?.id}/promote`, {
        program_id: program?.id,
        from_class_id: Number(fromClassId),
        to_class_id: Number(toClassId),
        academic_session_id: Number(sessionId),
        student_ids: selectedStudentIds
      })
      if (data.success) {
        toast.success(`✅ ${data.data.promoted} students promoted to ${data.data.to_class}!`)
        onDone(); onClose()
        setFromClassId(''); setToClassId(''); setPreview(null); setSelectedStudentIds([])
      }
    } catch (e: any) { toast.error(e.response?.data?.message || 'Promotion failed') }
    finally { setPromoting(false) }
  }

  const classes = program?.classes || []

  return (
    <Modal show={show} onHide={onClose} centered size='lg'>
      <div className='modal-header'>
        <h2 className='fw-bold'>Bulk Promote — {program?.name}</h2>
        <div className='btn btn-icon btn-sm btn-active-icon-primary' onClick={onClose}>
          <KTIcon iconName='cross' className='fs-1' />
        </div>
      </div>
      <Modal.Body>
        <div className='row g-4 mb-4'>
          <div className='col-md-4'>
            <label className='form-label fw-bold'>Academic Session <span className='text-danger'>*</span></label>
            <select className='form-select form-select-solid' value={sessionId} onChange={e => { setSessionId(e.target.value); setPreview(null) }}>
              <option value=''>Select Session</option>
              {sessions?.map((s: any) => <option key={s.id} value={s.id}>{s.session_year}</option>)}
            </select>
          </div>
          <div className='col-md-4'>
            <label className='form-label fw-bold'>From {program?.semester_based ? 'Semester' : 'Class'} <span className='text-danger'>*</span></label>
            <select className='form-select form-select-solid' value={fromClassId} onChange={e => { setFromClassId(e.target.value); setPreview(null) }}>
              <option value=''>Select Source</option>
              {classes?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className='col-md-4'>
            <label className='form-label fw-bold'>To {program?.semester_based ? 'Semester' : 'Class'} <span className='text-danger'>*</span></label>
            <select className='form-select form-select-solid' value={toClassId} onChange={e => setToClassId(e.target.value)}>
              <option value=''>Select Target</option>
              {(classes ?? []).filter((c: any) => String(c.id) !== fromClassId).map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
        </div>

        <div className='mb-4'>
          <button className='btn btn-light-primary btn-sm fw-bold' onClick={handlePreview}
            disabled={!fromClassId || !sessionId || previewing}>
            {previewing ? <span className='spinner-border spinner-border-sm me-2' /> : <KTIcon iconName='eye' className='fs-4 me-2' />}
            Preview Students
          </button>
        </div>

        {preview && (
          <div className='alert alert-light-primary border-primary border-dashed p-4 d-flex flex-column'>
            <div className='fw-bold mb-3 d-flex align-items-center'>
              <KTIcon iconName='profile-user' className='fs-2 me-2' />
              {preview.count} students will be promoted
            </div>
            <div className='row g-2 max-h-300px overflow-auto'>
              {preview?.students?.map((s: any) => (
                <div key={s.id} className='col-md-4'>
                  <label className={`d-flex align-items-center p-3 border rounded cursor-pointer ${(selectedStudentIds || []).includes(s.id) ? 'border-primary bg-light-primary' : 'border-gray-300 bg-light'}`}>
                    <input
                      type="checkbox"
                      className="form-check-input me-3"
                      checked={(selectedStudentIds || []).includes(s.id)}
                      onChange={(e) => {
                        if (e.target.checked) setSelectedStudentIds([...(selectedStudentIds || []), s.id])
                        else setSelectedStudentIds((selectedStudentIds || []).filter(id => id !== s.id))
                      }}
                    />
                    <span className={`fw-bold ${(selectedStudentIds || []).includes(s.id) ? 'text-primary' : 'text-muted text-decoration-line-through'}`}>{s.name}</span>
                  </label>
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal.Body>
      <Modal.Footer>
        <button className='btn btn-light btn-sm' onClick={onClose}>Cancel</button>
        <button className='btn btn-primary fw-bold' onClick={handlePromote}
          disabled={!fromClassId || !toClassId || !sessionId || promoting || !preview || (selectedStudentIds?.length || 0) === 0}>
          {promoting ? <span className='spinner-border spinner-border-sm me-2' /> : '⬆️ '}
          Confirm Promote ({selectedStudentIds?.length || 0} Students)
        </button>
      </Modal.Footer>
    </Modal>
  )
}

// ── Main Programs Page ─────────────────────────────────────────────────────────
const ProgramsPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')
  const isCollege = currentUser?.institution_type === 'COLLEGE'

  const [programs, setPrograms] = useState<Program[]>([])
  const [loading, setLoading] = useState(false)
  const [selectedProgram, setSelectedProgram] = useState<Program | null>(null)

  // Meta
  const [sessions, setSessions] = useState<any[]>([])
  const [currentSessionId, setCurrentSessionId] = useState<string>('')

  // Estimate
  const [estimating, setEstimating] = useState(false)
  const [showEstimate, setShowEstimate] = useState(false)
  const [estimateData, setEstimateData] = useState<any>(null)

  // Form modal
  const [showModal, setShowModal] = useState(false)
  const [editProgram, setEditProgram] = useState<Program | null>(null)
  const [form, setForm] = useState<Partial<Program>>(emptyForm())
  const [saving, setSaving] = useState(false)

  // Promote modal
  const [showPromote, setShowPromote] = useState(false)

  const loadPrograms = useCallback(async () => {
    if (!schoolId) return
    setLoading(true)
    try {
      const [pRes, sRes] = await Promise.all([
        axios.get(BASE(schoolId)),
        axios.get(`${API_URL}/school/${schoolId}/academic-sessions`, { params: { limit: 100 } })
      ])
      if (pRes.data.success) setPrograms(pRes.data.data || [])
      if (sRes.data.success) {
        const sess = sRes.data.data?.sessions || sRes.data.data || []
        setSessions(sess)
        const cur = sess.find((s: any) => s.is_current)
        if (cur) setCurrentSessionId(String(cur.id))
      }
    } catch { } finally { setLoading(false) }
  }, [schoolId])

  useEffect(() => { loadPrograms() }, [loadPrograms])

  const loadProgramDetail = async (id: number) => {
    try {
      const { data } = await axios.get(`${BASE(schoolId)}/${id}`)
      if (data.success) setSelectedProgram(data.data)
    } catch { }
  }

  const openCreate = () => {
    setEditProgram(null)
    // program_type is auto-derived from institution_type — no need to ask the user
    setForm({ ...emptyForm(), program_type: isCollege ? 'COLLEGE' : 'SCHOOL' })
    setShowModal(true)
  }

  const openEdit = (p: Program) => {
    setEditProgram(p)
    setForm({ ...p })
    setShowModal(true)
  }

  const handleSave = async () => {
    if (!form.name?.trim()) return toast.error('Program name is required')
    // Always derive program_type from institution_type — never ask admin again
    const payload = { ...form, program_type: isCollege ? 'COLLEGE' : 'SCHOOL' }
    setSaving(true)
    try {
      if (editProgram) {
        await axios.put(`${BASE(schoolId)}/${editProgram.id}`, payload)
        toast.success('Program updated!')
      } else {
        await axios.post(BASE(schoolId), payload)
        toast.success('Program created!')
      }
      setShowModal(false)
      loadPrograms()
      if (selectedProgram) loadProgramDetail(selectedProgram.id)
    } catch (e: any) { toast.error(e.response?.data?.message || 'Save failed') }
    finally { setSaving(false) }
  }

  const handleDelete = async (id: number) => {
    if (!window.confirm('Deactivate this program?')) return
    try {
      await axios.delete(`${BASE(schoolId)}/${id}`)
      toast.success('Program deactivated')
      if (selectedProgram?.id === id) setSelectedProgram(null)
      loadPrograms()
    } catch (e: any) { toast.error(e.response?.data?.message || 'Delete failed') }
  }

  const handleSelectProgram = (p: Program) => {
    setSelectedProgram(p)
    loadProgramDetail(p.id)
  }

  const handleGetEstimate = async () => {
    if (!selectedProgram) return
    if (!currentSessionId) return toast.error('No current academic session found')
    setEstimating(true)
    try {
      const { data } = await axios.get(`${API_URL}/school/${schoolId}/fees/programs/${selectedProgram.id}/estimate?session_id=${currentSessionId}`)
      if (data.success) {
        setEstimateData(data.data)
        setShowEstimate(true)
      }
    } catch (e: any) { toast.error(e.response?.data?.message || 'Failed to fetch estimate') }
    finally { setEstimating(false) }
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>
        <div className='row g-6'>
          {/* ── Left: Programs List ── */}
          <div className='col-lg-4'>
            <div className='card card-flush shadow-sm h-100'>
              <div className='card-header pt-7'>
                <h3 className='card-title align-items-start flex-column'>
                  <span className='card-label fw-bold text-gray-800'>
                    {isCollege ? '🎓 Courses / Programs' : '🏫 School Programs'}
                  </span>
                </h3>
                <div className='card-toolbar'>
                  <button className='btn btn-sm btn-light-primary fw-bold' onClick={openCreate}>
                    <KTIcon iconName='plus' className='fs-3' /> New Program
                  </button>
                </div>
              </div>
              <div className='card-body pt-5'>
                {loading ? (
                  <div className='text-center py-10'><span className='spinner-border text-primary' /></div>
                ) : programs.length === 0 ? (
                  <div className='text-center py-10'>
                    <KTIcon iconName='book' className='fs-5x text-gray-300 mb-4' />
                    <p className='text-muted fw-semibold'>No programs yet. Create one to get started.</p>
                  </div>
                ) : (
                  programs.map(p => (
                    <ProgramCard
                      key={p.id} program={p}
                      selected={selectedProgram?.id === p.id}
                      onEdit={openEdit}
                      onDelete={handleDelete}
                      onSelect={handleSelectProgram}
                    />
                  ))
                )}
              </div>
            </div>
          </div>

          {/* ── Right: Program Detail ── */}
          <div className='col-lg-8'>
            {!selectedProgram ? (
              <div className='card card-flush shadow-sm h-100'>
                <div className='card-body d-flex flex-column justify-content-center align-items-center py-20'>
                  <KTIcon iconName='element-11' className='fs-5x text-gray-300 mb-4' />
                  <p className='text-muted fw-semibold fs-5'>Select a program to see its details</p>
                </div>
              </div>
            ) : (
              <div className='card card-flush shadow-sm h-100'>
                <div className='card-header pt-7'>
                  <div className='card-title flex-column'>
                    <h3 className='fw-bold mb-2'>{selectedProgram.name}</h3>
                    <div className='d-flex gap-2 flex-wrap'>
                      <span className='badge badge-light-primary'>
                        {selectedProgram.program_type}
                      </span>
                      {selectedProgram.semester_based && <span className='badge badge-light-primary'>Semester-based</span>}
                      {selectedProgram.duration_years && <span className='badge badge-light-primary'>{selectedProgram.duration_years} Years</span>}
                      {selectedProgram.total_semesters && <span className='badge badge-light-primary'>Total: {selectedProgram.total_semesters} Semesters</span>}
                    </div>
                  </div>
                  <div className='card-toolbar d-flex gap-2'>
                    <button 
                      className='btn btn-sm btn-light-success fw-bold' 
                      disabled={!selectedProgram?.classes || estimating}
                      onClick={() => handleGetEstimate()}
                    >
                      {estimating ? <span className='spinner-border spinner-border-sm me-2'/> : <KTIcon iconName='calculator' className='fs-3 me-2'/>}
                      Fee Estimate
                    </button>
                    <button 
                      className='btn btn-sm btn-light-primary fw-bold' 
                      disabled={!selectedProgram?.classes}
                      onClick={() => setShowPromote(true)}
                    >
                      {!selectedProgram?.classes 
                        ? <span className='spinner-border spinner-border-sm me-2'/> 
                        : <KTIcon iconName='arrow-up' className='fs-3 me-2'/>}
                      Promote Students
                    </button>
                  </div>
                </div>

                <div className='card-body pt-5'>
                  <h6 className='text-uppercase text-muted fw-semibold fs-8 mb-4 letter-spacing-1'>
                    Linked {selectedProgram.semester_based ? 'Semesters' : 'Classes'}
                    &nbsp;({selectedProgram.classes?.length || 0})
                  </h6>

                  {!selectedProgram.classes?.length ? (
                    <div className='alert alert-light-primary border-primary border-dashed'>
                      No {selectedProgram.semester_based ? 'semesters' : 'classes'} linked yet.
                      Go to <strong>Academic → Classes</strong> and set <strong>program_id</strong> to link them.
                    </div>
                  ) : (
                    <div className='row g-4'>
                      {(selectedProgram.classes || [])
                        .sort((a, b) => (a.semester_number || a.numeric_value || 0) - (b.semester_number || b.numeric_value || 0))
                        .map((cls, idx) => (
                          <div key={cls.id} className='col-md-3'>
                            <div className='card bg-light-primary border-0 text-center py-5 px-3'>
                              <div className='fs-1 fw-bolder text-primary mb-1'>
                                {cls.semester_number || (idx + 1)}
                              </div>
                              <div className='fw-bold text-gray-700 fs-7'>{cls.name}</div>
                              {cls.semester_number && (
                                <div className='text-muted fs-9 mt-1'>Semester {cls.semester_number}</div>
                              )}
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ── Create/Edit Program Modal ── */}
        <Modal show={showModal} onHide={() => setShowModal(false)} centered>
          <div className='modal-header'>
            <h2 className='fw-bold'>
              {editProgram ? 'Edit Program' : 'New Program'}
            </h2>
            <div className='btn btn-icon btn-sm btn-active-icon-primary' onClick={() => setShowModal(false)}>
              <KTIcon iconName='cross' className='fs-1' />
            </div>
          </div>
          <Modal.Body>
            <div className='mb-4'>
              <label className='form-label fw-bold required'>Program Name</label>
              <input className='form-control form-control-solid'
                placeholder={isCollege ? 'e.g., B.Tech Computer Science, BCA, MBA...' : 'e.g., Primary, Secondary, Senior Secondary...'}
                value={form.name || ''}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            {/* Institution type is auto-set from school registration — no selector needed */}

            <div className='mb-4'>
              <label className='form-label fw-bold'>Duration (Years)</label>
              <input className='form-control form-control-solid' type='number' min={1} max={10}
                placeholder={isCollege ? 'e.g. 4 for B.Tech, 3 for BCA' : 'e.g. 1 (annual)'}
                value={form.duration_years || ''}
                onChange={e => setForm(f => ({ ...f, duration_years: Number(e.target.value) || undefined }))} />
            </div>

            <div className='mb-4'>
              <div className='form-check form-switch form-check-custom form-check-solid'>
                <input className='form-check-input' type='checkbox' id='semesterBased'
                  checked={Boolean(form.semester_based)}
                  onChange={e => setForm(f => ({ ...f, semester_based: e.target.checked, total_semesters: e.target.checked ? f.total_semesters : undefined }))} />
                <label className='form-check-label fw-semibold' htmlFor='semesterBased'>
                  Semester-based (College / Half-yearly)
                </label>
              </div>
              <div className='text-muted fs-8 mt-1'>
                If enabled, each "Class" under this program is treated as a Semester
              </div>
            </div>

            {form.semester_based && (
              <div className='mb-4'>
                <label className='form-label fw-bold'>Total Semesters</label>
                <input className='form-control form-control-solid' type='number' min={1} max={20}
                  placeholder='e.g. 8 for B.Tech'
                  value={form.total_semesters || ''}
                  onChange={e => setForm(f => ({ ...f, total_semesters: Number(e.target.value) || undefined }))} />
              </div>
            )}
          </Modal.Body>
          <Modal.Footer>
            <button className='btn btn-light btn-sm' onClick={() => setShowModal(false)}>Cancel</button>
            <button className='btn btn-primary fw-bold' onClick={handleSave} disabled={saving}>
              {saving ? <span className='spinner-border spinner-border-sm me-2' /> : null}
              {editProgram ? 'Update Program' : 'Create Program'}
            </button>
          </Modal.Footer>
        </Modal>

        {/* ── Promote Modal ── */}
        <PromoteModal
          show={showPromote}
          program={selectedProgram}
          schoolId={schoolId}
          onClose={() => setShowPromote(false)}
          onDone={() => { loadPrograms(); if (selectedProgram) loadProgramDetail(selectedProgram.id) }}
        />

        {/* ── Fee Estimate Modal ── */}
        <Modal show={showEstimate} onHide={() => setShowEstimate(false)} centered size='lg'>
          <div className='modal-header'>
            <h2 className='fw-bold'>Total Program Fee Estimate</h2>
            <div className='btn btn-icon btn-sm btn-active-icon-primary' onClick={() => setShowEstimate(false)}>
              <KTIcon iconName='cross' className='fs-1' />
            </div>
          </div>
          <Modal.Body className='py-5'>
            {estimateData && (
              <>
                <div className='d-flex align-items-center justify-content-between mb-8 p-5 bg-light-primary rounded border border-primary border-dashed'>
                  <div>
                    <h4 className='fw-bolder text-gray-800 mb-1'>{estimateData.program_name}</h4>
                    <div className='text-muted fs-6'>
                      {estimateData.duration_years} Years | {estimateData.total_semesters} Semesters
                    </div>
                  </div>
                  <div className='text-end'>
                    <div className='text-muted fw-semibold fs-7 mb-1'>Total Estimated Course Fee</div>
                    <div className='fs-1 fw-bolder text-primary'>₹{Number(estimateData.total_estimated_fee).toLocaleString('en-IN')}</div>
                  </div>
                </div>

                <h5 className='fw-bold text-gray-800 mb-4'>Semester-wise Breakdown</h5>
                <div className='table-responsive'>
                  <table className='table table-row-dashed table-row-gray-300 align-middle gs-0 gy-4'>
                    <thead>
                      <tr className='fw-bolder text-muted bg-light'>
                        <th className='ps-4 rounded-start min-w-150px'>Semester / Class</th>
                        <th className='min-w-200px'>Fee Categories</th>
                        <th className='text-end rounded-end pe-4 min-w-150px'>Semester Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {estimateData.breakdown_by_semester?.length === 0 ? (
                        <tr>
                          <td colSpan={3} className='text-center py-8 text-muted'>
                            No fees allocated for any semester in this program.
                          </td>
                        </tr>
                      ) : (
                        estimateData.breakdown_by_semester?.map((sem: any, i: number) => (
                          <tr key={i}>
                            <td className='ps-4'>
                              <div className='fw-bold text-gray-800 fs-6'>{sem.class_name}</div>
                              <div className='text-muted fs-8'>Semester {sem.semester_number || i + 1}</div>
                            </td>
                            <td>
                              <div className='d-flex flex-wrap gap-2'>
                                {sem.fees?.map((f: any, idx: number) => (
                                  <span key={idx} className='badge badge-light fw-bold'>
                                    {f.category} (₹{f.amount})
                                  </span>
                                ))}
                              </div>
                            </td>
                            <td className='text-end pe-4'>
                              <span className='fw-bolder text-gray-800 fs-5'>
                                ₹{Number(sem.semester_total).toLocaleString('en-IN')}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </Modal.Body>
          <Modal.Footer>
            <button className='btn btn-light fw-bold' onClick={() => setShowEstimate(false)}>Close</button>
          </Modal.Footer>
        </Modal>
      </Content>
    </>
  )
}

const ProgramsWrapper: FC = () => (
  <>
    <PageTitle breadcrumbs={[
      { title: 'Academic', path: '/academic', isActive: false },
      { title: 'Programs', path: '/academic/programs', isActive: true }
    ]}>
      Programs & Courses
    </PageTitle>
    <ProgramsPage />
  </>
)

export { ProgramsWrapper }
