export interface SessionModel {
  id: number;
  session_year: string;
  start_date: string;
  end_date: string;
  is_current: boolean;
  attendance_mode: 'DAILY' | 'PERIOD';
  createdAt?: string;
  updatedAt?: string;
}

export interface SessionCreationData {
  session_year: string;
  start_date: string;
  end_date: string;
  is_current: boolean;
  attendance_mode: 'DAILY' | 'PERIOD';
}

export interface SessionsListResponse {
  success: boolean;
  message: string;
  data: {
    sessions: SessionModel[];
  };
  pagination?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
  };
}

export interface SessionResponse {
  success: boolean;
  message: string;
  data: {
    session: SessionModel;
  };
}

// ─── Class Models ──────────────────────────────────────────────────────────
export interface ClassModel {
  id: number;
  name: string;
  numeric_value: number;
  program_id?: number | null;
  semester_number?: number | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface ClassCreationData {
  name: string;
  numeric_value: number;
  program_id?: number;
  semester_number?: number;
}

export interface ClassesListResponse {
  success: boolean;
  message: string;
  data: {
    classes: ClassModel[];
  };
  pagination?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
  };
}

export interface ClassResponse {
  success: boolean;
  message: string;
  data: {
    class: ClassModel;
  };
}

// ─── Section Models ─────────────────────────────────────────────────────────
export interface SectionModel {
  id: number;
  name: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface SectionCreationData {
  name: string;
}

export interface SectionsListResponse {
  success: boolean;
  message: string;
  data: {
    sections: SectionModel[];
  };
  pagination?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
  };
}

export interface SectionResponse {
  success: boolean;
  message: string;
  data: {
    section: SectionModel;
  };
}

// ─── Class-Section Mapping Models ───────────────────────────────────────────
export interface ClassSectionMappingModel {
  id: number;
  class_id: number;
  section_id: number;
  capacity: number;
  createdAt?: string;
  updatedAt?: string;
  section?: SectionModel;
}

export interface ClassSectionMappingCreationData {
  section_id: number;
  capacity: number;
}

export interface ClassSectionMappingsListResponse {
  success: boolean;
  message: string;
  data: {
    sections: ClassSectionMappingModel[];
  };
}

export interface ClassSectionMappingResponse {
  success: boolean;
  message: string;
  data: {
    mapping: ClassSectionMappingModel;
  };
}

// ─── Subject Models ──────────────────────────────────────────────────────────

export interface SubjectModel {
  id: number;
  name: string;
  code: string;
  type: 'theory' | 'practical' | 'both';
  category: 'compulsory' | 'elective';
  description?: string;
  is_active: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface SubjectCreationData {
  name: string;
  code: string;
  type: 'theory' | 'practical' | 'both';
  category: 'compulsory' | 'elective';
  description?: string;
}

export interface SubjectResponse {
  success: boolean;
  message: string;
  data: { subject: SubjectModel };
}

export interface SubjectsListResponse {
  success: boolean;
  message: string;
  data: { subjects: SubjectModel[] };
}

// ─── Class-Subject Mapping Models ────────────────────────────────────────────

export interface ClassSubjectMappingModel {
  id: number;
  class_id: number;
  subject_id: number;
  is_compulsory: boolean;
  createdAt?: string;
  updatedAt?: string;
  subject?: SubjectModel;
}

export interface ClassSubjectMappingCreationData {
  subject_id: number;
  is_compulsory: boolean;
}

export interface ClassSubjectMappingsListResponse {
  success: boolean;
  message: string;
  data: { subjects: ClassSubjectMappingModel[] };
}

export interface ClassSubjectMappingResponse {
  success: boolean;
  message: string;
  data: { mapping: ClassSubjectMappingModel };
}

// ─── Class Teacher Assignment ─────────────────────────────────────────────────

export interface AssignClassTeacherPayload {
  section_id: number;
  teacher_id: number;
}

export interface ClassTeacherMappingResponse {
  success: boolean;
  message: string;
  data: { mapping: any };
}

// ─── Teacher Allocation Models ───────────────────────────────────────────────

export interface TeacherAllocationModel {
  id: number;
  teacher_id: number;
  class_section_id: number;
  subject_id: number | null;
  academic_session_id: number;
  is_class_teacher: boolean;
  createdAt?: string;
  updatedAt?: string;
  teacher?: { id: number; name: string };
  subject?: { id: number; name: string; code: string };
  class_section?: {
    id: number;
    class?: { id: number; name: string };
    section?: { id: number; name: string };
  };
}

// ─── Session-aware Class Teacher Assignment ───────────────────────────────────

export interface ClassTeacherSessionPayload {
  teacher_id: number;
  class_section_id: number;
  academic_session_id: number;
}

export interface ClassTeacherSessionResponse {
  success: boolean;
  message: string;
  data: TeacherAllocationModel;
}

export interface TeacherAllocationPayload {
  teacher_id: number;
  class_section_id: number;
  subject_id: number;
  academic_session_id: number;
}

export interface TeacherAllocationsListResponse {
  success: boolean;
  count: number;
  data: TeacherAllocationModel[];
}

export interface TeacherAllocationResponse {
  success: boolean;
  message: string;
  data: TeacherAllocationModel;
}

// ─── Syllabus Models ──────────────────────────────────────────────────────────

export interface SyllabusResource {
  id: number;
  topic_id: number;
  title: string;
  resource_type: 'VIDEO' | 'PDF' | 'DOC' | 'LINK';
  file_url: string;
  uploaded_by: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface SyllabusTopic {
  id: number;
  unit_id: number;
  topic_name: string;
  description: string;
  lectures_estimated: number;
  is_optional: boolean;
  resources?: SyllabusResource[];
  createdAt?: string;
  updatedAt?: string;
}

export interface SyllabusUnit {
  id: number;
  syllabus_id: number;
  unit_name: string;
  unit_number: number;
  description: string;
  total_lectures_estimated: number;
  topics?: SyllabusTopic[];
  createdAt?: string;
  updatedAt?: string;
}

export interface SyllabusModel {
  id: number;
  academic_session_id: number;
  class_id: number;
  subject_id: number;
  section_id?: number | null;
  title: string;
  description: string;
  file_url?: string | null;
  is_active: boolean;
  units?: SyllabusUnit[];
  createdAt?: string;
  updatedAt?: string;
}

export interface SyllabusCreationData {
  academic_session_id: number;
  class_id: number;
  subject_id: number;
  section_id?: number | null;
  title: string;
  description: string;
  file_url?: string | null;
  is_active: boolean;
}

export interface SyllabusResponse {
  success: boolean;
  message: string;
  data: { syllabus: SyllabusModel };
}

export interface SyllabusUnitsBulkCreationData {
  units: Array<Omit<SyllabusUnit, 'id' | 'syllabus_id' | 'createdAt' | 'updatedAt' | 'topics'> & {
    topics?: Omit<SyllabusTopic, 'id' | 'unit_id' | 'createdAt' | 'updatedAt' | 'resources'>[];
  }>;
}

// ─── Lesson Plan Models ──────────────────────────────────────────────────────

export interface LessonPlanResource {
  id: number;
  lesson_plan_id: number;
  title: string;
  resource_type: 'PDF' | 'VIDEO' | 'LINK' | 'DOC';
  file_url: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface LessonPlanModel {
  id: number;
  class_section_id: number;
  subject_id: number;
  teacher_id: number;
  topic_id: number;
  plan_date: string;
  completed_date?: string | null;
  status: 'PLANNED' | 'COMPLETED' | 'DELAYED';
  objectives?: string | null;
  methodology?: string | null;
  homework?: string | null;
  remarks?: string | null;
  approved_by_admin_id?: number | null;
  approval_status: 'PENDING' | 'APPROVED' | 'REJECTED';
  feedback?: string | null;
  createdAt?: string;
  updatedAt?: string;
  resources?: LessonPlanResource[];
  topic?: SyllabusTopic;
  class_section?: {
    id: number;
    class?: ClassModel;
    section?: SectionModel;
  };
  subject?: SubjectModel;
  teacher?: {
    id: number;
    name: string;
  };
}

export interface LessonPlanCreationData {
  class_section_id: number;
  subject_id: number;
  topic_id: number;
  plan_date: string;
  status?: 'PLANNED' | 'COMPLETED' | 'DELAYED';
  objectives?: string;
  methodology?: string;
  homework?: string;
  remarks?: string;
  resources?: Array<{
    title: string;
    resource_type: 'PDF' | 'VIDEO' | 'LINK' | 'DOC';
    file_url: string;
  }>;
}

export interface LessonPlansListResponse {
  success: boolean;
  message: string;
  data: {
    plans: LessonPlanModel[];
  };
}

export interface LessonPlanResponse {
  success: boolean;
  message: string;
  data: {
    plan: LessonPlanModel;
  };
}
