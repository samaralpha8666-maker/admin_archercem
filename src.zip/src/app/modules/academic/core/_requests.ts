import axios from 'axios'
import {
  SessionCreationData, SessionResponse, SessionsListResponse,
  ClassCreationData, ClassResponse, ClassesListResponse,
  SectionCreationData, SectionResponse, SectionsListResponse,
  ClassSectionMappingCreationData, ClassSectionMappingResponse, ClassSectionMappingsListResponse,
  SubjectCreationData, SubjectResponse, SubjectsListResponse,
  ClassSubjectMappingCreationData, ClassSubjectMappingResponse,
  ClassSubjectMappingsListResponse, AssignClassTeacherPayload,
  ClassTeacherMappingResponse,
  TeacherAllocationPayload,
  TeacherAllocationsListResponse,
  TeacherAllocationResponse,
  ClassTeacherSessionPayload,
  ClassTeacherSessionResponse,
} from './_models'


const API_URL = import.meta.env.VITE_APP_API_URL

export const GET_SESSIONS_URL = (schoolId: string | number) => `${API_URL}/school/${schoolId}/academic-sessions`
export const SESSION_URL = (schoolId: string | number, id: string | number) => `${API_URL}/school/${schoolId}/academic-sessions/${id}`
export const SET_CURRENT_SESSION_URL = (schoolId: string | number, id: string | number) => `${API_URL}/school/${schoolId}/academic-sessions/${id}/set-current`

export function getAcademicSessions(schoolId: string | number, page: number = 1, limit: number = 10, search: string = '') {
  return axios.get<SessionsListResponse>(GET_SESSIONS_URL(schoolId), {
    params: { page, limit, search }
  })
}

export function getAcademicSessionById(schoolId: string | number, id: string | number) {
  return axios.get<SessionResponse>(SESSION_URL(schoolId, id))
}

export function createAcademicSession(schoolId: string | number, payload: SessionCreationData) {
  return axios.post<SessionResponse>(GET_SESSIONS_URL(schoolId), payload)
}

export function updateAcademicSession(schoolId: string | number, id: string | number, payload: Partial<SessionCreationData>) {
  return axios.put<SessionResponse>(SESSION_URL(schoolId, id), payload)
}

export function deleteAcademicSession(schoolId: string | number, id: string | number) {
  return axios.delete(SESSION_URL(schoolId, id))
}

export function setCurrentAcademicSession(schoolId: string | number, id: string | number) {
  return axios.patch<SessionResponse>(SET_CURRENT_SESSION_URL(schoolId, id))
}

// ─── Classes API ─────────────────────────────────────────────────────────
const CLASSES_URL = (schoolId: string | number) => `${API_URL}/school/${schoolId}/classes`
const CLASS_URL = (schoolId: string | number, id: string | number) => `${API_URL}/school/${schoolId}/classes/${id}`

export function getClasses(schoolId: string | number, page: number = 1, limit: number = 100) {
  return axios.get<ClassesListResponse>(CLASSES_URL(schoolId), { params: { page, limit } })
}

export function getClassById(schoolId: string | number, id: string | number) {
  return axios.get<ClassResponse>(CLASS_URL(schoolId, id))
}

export function createClass(schoolId: string | number, payload: ClassCreationData) {
  return axios.post<ClassResponse>(CLASSES_URL(schoolId), payload)
}

export function updateClass(schoolId: string | number, id: string | number, payload: Partial<ClassCreationData>) {
  return axios.put<ClassResponse>(CLASS_URL(schoolId, id), payload)
}

export function deleteClass(schoolId: string | number, id: string | number) {
  return axios.delete(CLASS_URL(schoolId, id))
}

// ─── Sections API ────────────────────────────────────────────────────────
const SECTIONS_URL = (schoolId: string | number) => `${API_URL}/school/${schoolId}/sections`
const SECTION_URL = (schoolId: string | number, id: string | number) => `${API_URL}/school/${schoolId}/sections/${id}`

export function getSections(schoolId: string | number, page: number = 1, limit: number = 100) {
  return axios.get<SectionsListResponse>(SECTIONS_URL(schoolId), { params: { page, limit } })
}

export function getSectionById(schoolId: string | number, id: string | number) {
  return axios.get<SectionResponse>(SECTION_URL(schoolId, id))
}

export function createSection(schoolId: string | number, payload: SectionCreationData) {
  return axios.post<SectionResponse>(SECTIONS_URL(schoolId), payload)
}

export function updateSection(schoolId: string | number, id: string | number, payload: Partial<SectionCreationData>) {
  return axios.put<SectionResponse>(SECTION_URL(schoolId, id), payload)
}

export function deleteSection(schoolId: string | number, id: string | number) {
  return axios.delete(SECTION_URL(schoolId, id))
}

// ─── Class-Section Mapping API ──────────────────────────────────────────────
const CLASS_SECTIONS_URL = (schoolId: string | number, classId: string | number) =>
  `${API_URL}/school/${schoolId}/classes/${classId}/sections`
const CLASS_SECTION_URL = (schoolId: string | number, classId: string | number, sectionId: string | number) =>
  `${API_URL}/school/${schoolId}/classes/${classId}/sections/${sectionId}`

export function getClassSections(schoolId: string | number, classId: string | number) {
  return axios.get<ClassSectionMappingsListResponse>(CLASS_SECTIONS_URL(schoolId, classId))
}

export function assignSectionToClass(
  schoolId: string | number,
  classId: string | number,
  payload: ClassSectionMappingCreationData
) {
  return axios.post<ClassSectionMappingResponse>(CLASS_SECTIONS_URL(schoolId, classId), payload)
}

export function removeSectionFromClass(
  schoolId: string | number,
  classId: string | number,
  sectionId: string | number
) {
  return axios.delete(CLASS_SECTION_URL(schoolId, classId, sectionId))
}


const SUBJECTS_URL = (schoolId: string | number) => `${API_URL}/school/${schoolId}/subjects`
const SUBJECT_URL = (schoolId: string | number, id: string | number) =>
  `${API_URL}/school/${schoolId}/subjects/${id}`

export function getSubjects(schoolId: string | number) {
  return axios.get<SubjectsListResponse>(SUBJECTS_URL(schoolId))
}

export function createSubject(schoolId: string | number, payload: SubjectCreationData) {
  return axios.post<SubjectResponse>(SUBJECTS_URL(schoolId), payload)
}

export function updateSubject(
  schoolId: string | number,
  id: string | number,
  payload: Partial<SubjectCreationData>
) {
  return axios.put<SubjectResponse>(SUBJECT_URL(schoolId, id), payload)
}

export function deleteSubject(schoolId: string | number, id: string | number) {
  return axios.delete(SUBJECT_URL(schoolId, id))
}

// ─── Class-Subject Mapping API ────────────────────────────────────────────────

const CLASS_SUBJECTS_URL = (schoolId: string | number, classId: string | number) =>
  `${API_URL}/school/${schoolId}/classes/${classId}/subjects`

const CLASS_SUBJECT_ITEM_URL = (
  schoolId: string | number,
  classId: string | number,
  subjectId: string | number
) => `${API_URL}/school/${schoolId}/classes/${classId}/subjects/${subjectId}`

export function getClassSubjects(schoolId: string | number, classId: string | number) {
  return axios.get<ClassSubjectMappingsListResponse>(CLASS_SUBJECTS_URL(schoolId, classId))
}

export function assignSubjectToClass(
  schoolId: string | number,
  classId: string | number,
  payload: ClassSubjectMappingCreationData
) {
  return axios.post<ClassSubjectMappingResponse>(CLASS_SUBJECTS_URL(schoolId, classId), payload)
}

export function removeSubjectFromClass(
  schoolId: string | number,
  classId: string | number,
  subjectId: string | number
) {
  return axios.delete(CLASS_SUBJECT_ITEM_URL(schoolId, classId, subjectId))
}

// ─── Class Teacher Assignment API ─────────────────────────────────────────────

export function assignClassTeacher(
  schoolId: string | number,
  classId: string | number,
  payload: AssignClassTeacherPayload
) {
  return axios.patch<ClassTeacherMappingResponse>(
    `${API_URL}/school/${schoolId}/classes/${classId}/class-teacher`,
    payload
  )
}

// ─── Teacher Allocation API ─────────────────────────────────────────────────

const TEACHER_ALLOCATIONS_URL = (schoolId: string | number) =>
  `${API_URL}/school/${schoolId}/teacher-allocations`

export function getTeacherAllocations(
  schoolId: string | number,
  params: { class_section_id?: number; academic_session_id?: number; subject_id?: number } = {}
) {
  return axios.get<TeacherAllocationsListResponse>(TEACHER_ALLOCATIONS_URL(schoolId), { params })
}

export function allocateTeacher(
  schoolId: string | number,
  payload: TeacherAllocationPayload
) {
  return axios.post<TeacherAllocationResponse>(TEACHER_ALLOCATIONS_URL(schoolId), payload)
}

export function updateTeacherAllocation(
  schoolId: string | number,
  allocationId: number,
  teacherId: number
) {
  return axios.put<TeacherAllocationResponse>(
    `${TEACHER_ALLOCATIONS_URL(schoolId)}/${allocationId}`,
    { teacher_id: teacherId }
  )
}

export function deleteTeacherAllocation(
  schoolId: string | number,
  allocationId: number
) {
  return axios.delete(`${TEACHER_ALLOCATIONS_URL(schoolId)}/${allocationId}`)
}

// ─── Session-aware Class Teacher API ──────────────────────────────────────────────

/** POST /school/:id/teacher-allocations/class-teacher */
export function assignClassTeacherBySession(
  schoolId: string | number,
  payload: ClassTeacherSessionPayload
) {
  return axios.post<ClassTeacherSessionResponse>(
    `${TEACHER_ALLOCATIONS_URL(schoolId)}/class-teacher`,
    payload
  )
}

/** GET /school/:id/teacher-allocations/class-teachers?session_id=X */
export function getClassTeachersForSession(
  schoolId: string | number,
  sessionId: string | number
) {
  return axios.get<{ success: boolean; count: number; data: any[] }>(
    `${TEACHER_ALLOCATIONS_URL(schoolId)}/class-teachers`,
    { params: { session_id: sessionId } }
  )
}

// ─── Syllabus API ──────────────────────────────────────────────────────────

const SYLLABUS_URL = (schoolId: string | number) => `${API_URL}/school/${schoolId}/syllabus`

export function createSyllabus(schoolId: string | number, payload: import('./_models').SyllabusCreationData | FormData) {
  return axios.post<import('./_models').SyllabusResponse>(SYLLABUS_URL(schoolId), payload, {
    headers: payload instanceof FormData ? { 'Content-Type': 'multipart/form-data' } : undefined
  })
}

export function updateSyllabus(
  schoolId: string | number,
  syllabusId: string | number,
  payload: Partial<import('./_models').SyllabusCreationData> | FormData
) {
  return axios.put<import('./_models').SyllabusResponse>(`${SYLLABUS_URL(schoolId)}/${syllabusId}`, payload, {
    headers: payload instanceof FormData ? { 'Content-Type': 'multipart/form-data' } : undefined
  })
}

export function getSyllabusHierarchy(
  schoolId: string | number,
  classId: string | number,
  subjectId: string | number,
  sectionId?: string | number
) {
  return axios.get<import('./_models').SyllabusResponse>(`${SYLLABUS_URL(schoolId)}/class/${classId}/subject/${subjectId}`, {
    params: { sectionId }
  })
}

export function addUnitsBulk(schoolId: string | number, syllabusId: string | number, payload: import('./_models').SyllabusUnitsBulkCreationData) {
  return axios.post(`${SYLLABUS_URL(schoolId)}/${syllabusId}/units`, payload)
}

export function uploadTopicResource(
  schoolId: string | number,
  topicId: string | number,
  formData: FormData
) {
  return axios.post(`${SYLLABUS_URL(schoolId)}/topics/${topicId}/resources`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export function uploadTopicResourceLink(
  schoolId: string | number,
  topicId: string | number,
  payload: { title: string; resource_type: string; file_url: string }
) {
  return axios.post(`${SYLLABUS_URL(schoolId)}/topics/${topicId}/resources`, payload)
}

export function markTopicProgress(
  schoolId: string | number,
  topicId: string | number,
  payload: { class_section_id: number; status: string; remarks?: string }
) {
  return axios.patch(`${SYLLABUS_URL(schoolId)}/topics/${topicId}/progress`, payload)
}

export function getSectionProgress(
  schoolId: string | number,
  sectionId: string | number,
  subjectId: string | number
) {
  return axios.get(`${SYLLABUS_URL(schoolId)}/progress/section/${sectionId}/subject/${subjectId}`)
}

export function updateTopic(
  schoolId: string | number,
  topicId: string | number,
  payload: { topic_name?: string; is_optional?: boolean; description?: string; lectures_estimated?: number }
) {
  return axios.put(`${SYLLABUS_URL(schoolId)}/topics/${topicId}`, payload)
}

export function addTopicToUnit(
  schoolId: string | number,
  unitId: string | number,
  payload: { topic_name: string; lectures_estimated: number; description?: string }
) {
  return axios.post(`${SYLLABUS_URL(schoolId)}/units/${unitId}/topics`, payload)
}

export function deleteTopic(schoolId: string | number, topicId: string | number) {
  return axios.delete(`${SYLLABUS_URL(schoolId)}/topics/${topicId}`)
}

export function updateUnit(
  schoolId: string | number,
  unitId: string | number,
  payload: { unit_name?: string; total_lectures_estimated?: number; description?: string }
) {
  return axios.put(`${SYLLABUS_URL(schoolId)}/units/${unitId}`, payload)
}

export function removeResource(schoolId: string | number, resourceId: string | number) {
  return axios.delete(`${SYLLABUS_URL(schoolId)}/resources/${resourceId}`)
}

export function deleteUnit(schoolId: string | number, unitId: string | number) {
  return axios.delete(`${SYLLABUS_URL(schoolId)}/units/${unitId}`)
}

export function deleteSyllabus(schoolId: string | number, syllabusId: string | number) {
  return axios.delete(`${SYLLABUS_URL(schoolId)}/${syllabusId}`)
}

// ─── Lesson Plan API Connectors ──────────────────────────────────────────────

const LESSON_PLANS_URL = (schoolId: string | number) => `${API_URL}/school/${schoolId}/lesson-plans`

export function getLessonPlans(schoolId: string | number, params: any = {}) {
  return axios.get<import('./_models').LessonPlansListResponse>(LESSON_PLANS_URL(schoolId), { params })
}

export function getLessonPlanById(schoolId: string | number, id: string | number) {
  return axios.get<import('./_models').LessonPlanResponse>(`${LESSON_PLANS_URL(schoolId)}/${id}`)
}

export function createLessonPlan(schoolId: string | number, payload: import('./_models').LessonPlanCreationData) {
  return axios.post<import('./_models').LessonPlanResponse>(LESSON_PLANS_URL(schoolId), payload)
}

export function updateLessonPlan(
  schoolId: string | number,
  id: string | number,
  payload: Partial<import('./_models').LessonPlanCreationData>
) {
  return axios.put<import('./_models').LessonPlanResponse>(`${LESSON_PLANS_URL(schoolId)}/${id}`, payload)
}

export function reviewLessonPlan(
  schoolId: string | number,
  id: string | number,
  payload: { approval_status: 'APPROVED' | 'REJECTED'; feedback?: string }
) {
  return axios.patch<import('./_models').LessonPlanResponse>(`${LESSON_PLANS_URL(schoolId)}/${id}/review`, payload)
}

export function deleteLessonPlan(schoolId: string | number, id: string | number) {
  return axios.delete(`${LESSON_PLANS_URL(schoolId)}/${id}`)
}

export function addLessonPlanResource(
  schoolId: string | number,
  lessonPlanId: string | number,
  payload: { title: string; resource_type: 'PDF' | 'VIDEO' | 'LINK' | 'DOC'; file_url: string }
) {
  return axios.post(`${LESSON_PLANS_URL(schoolId)}/${lessonPlanId}/resources`, payload)
}

export function removeLessonPlanResource(schoolId: string | number, resourceId: string | number) {
  return axios.delete(`${LESSON_PLANS_URL(schoolId)}/resources/${resourceId}`)
}
