import React, { FC, useState, useEffect } from 'react'
import { PageTitle } from '../../../_metronic/layout/core'
import { ToolbarWrapper } from '../../../_metronic/layout/components/toolbar'
import { Content } from '../../../_metronic/layout/components/content'
import { useAuth } from '../../modules/auth'
import { getInstitutionType } from '../../../_metronic/helpers'
import axios from 'axios'
import { getSubjects, getClassSubjects } from './core/_requests'

interface OnlineClass {
  id: number
  title: string
  class_section_id: number
  subject_id: number
  teacher_id: number
  platform: 'ZOOM' | 'GOOGLE_MEET' | 'TEAMS' | 'OTHER'
  meeting_link: string
  meeting_id?: string
  meeting_password?: string
  start_date_time: string
  duration_minutes: number
  status: 'SCHEDULED' | 'LIVE' | 'COMPLETED' | 'CANCELLED'
  notes?: string
  class_section?: {
    class?: { name: string }
    section?: { name: string }
  }
  subject?: { name: string }
  teacher?: { name: string }
}

const OnlineClassesPage: FC = () => {
  const { currentUser } = useAuth()
  const schoolId = String(currentUser?.schoolId || '')
  const API_URL = import.meta.env.VITE_APP_API_URL

  const [classesList, setClassesList] = useState<OnlineClass[]>([])
  const [loading, setLoading] = useState(false)
  const [showModal, setShowModal] = useState(false)

  // Form states
  const [title, setTitle] = useState('')
  const [selectedClassSection, setSelectedClassSection] = useState('')
  const [selectedSubject, setSelectedSubject] = useState('')
  const [selectedTeacher, setSelectedTeacher] = useState('')
  const [platform, setPlatform] = useState<'ZOOM' | 'GOOGLE_MEET' | 'TEAMS' | 'OTHER'>('ZOOM')
  const [meetingLink, setMeetingLink] = useState('')
  const [meetingId, setMeetingId] = useState('')
  const [meetingPassword, setMeetingPassword] = useState('')
  const [startDateTime, setStartDateTime] = useState('')
  const [duration, setDuration] = useState(40)
  const [notes, setNotes] = useState('')

  // Selector lists
  const [classSections, setClassSections] = useState<any[]>([])
  const [subjects, setSubjects] = useState<any[]>([])
  const [teachers, setTeachers] = useState<any[]>([])
  const [classSectionSubjects, setClassSectionSubjects] = useState<any[]>([])
  const [subjectsLoading, setSubjectsLoading] = useState(false)

  // Timetable and session matching states
  const [sessions, setSessions] = useState<any[]>([])
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null)
  const [timetableEntries, setTimetableEntries] = useState<any[]>([])
  const [selectedPeriod, setSelectedPeriod] = useState<string>('')
  const [timetableLoading, setTimetableLoading] = useState(false)
  const [teacherAllocations, setTeacherAllocations] = useState<any[]>([])

  const isTeacher = currentUser?.role === 'teacher'

  const fetchOnlineClasses = async () => {
    if (!schoolId) return
    setLoading(true)
    try {
      const response = await axios.get(`${API_URL}/school/${schoolId}/online-classes`)
      if (response.data?.success) {
        setClassesList(response.data.data || [])
      }
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  const fetchSelectorData = async () => {
    if (!schoolId) return
    try {
      // Fetch Academic Sessions
      let activeSessionId: number | null = null
      const sessRes = await axios.get(`${API_URL}/school/${schoolId}/academic-sessions?limit=100`)
      if (sessRes.data?.success) {
        const list = sessRes.data.data.sessions || []
        setSessions(list)
        const cur = list.find((s: any) => s.is_current) || list[0]
        if (cur) {
          activeSessionId = cur.id
          setCurrentSessionId(cur.id)
        }
      }

      // Fetch all classes and sections
      const clsResponse = await axios.get(`${API_URL}/school/${schoolId}/classes?limit=100`)
      const classesData = clsResponse.data?.data?.classes || []

      const mappings: any[] = []
      for (const cls of classesData) {
        try {
          const mappingRes = await axios.get(`${API_URL}/school/${schoolId}/classes/${cls.id}/sections`)
          const sectMappings = mappingRes.data?.data?.sections || []
          sectMappings.forEach((map: any) => {
            mappings.push({
              id: map.id,
              label: `${cls.name} - ${map.section?.name || 'Unknown'}`,
              class_id: cls.id
            })
          })
        } catch (err) {
          console.error('Section fetch error for class', cls.id, err)
        }
      }
      setClassSections(mappings)

      const subjRes = await getSubjects(schoolId)
      setSubjects(subjRes.data?.data?.subjects || [])

      const teachRes = await axios.get(`${API_URL}/school/${schoolId}/teachers?limit=200`)
      setTeachers(teachRes.data?.data?.teachers || [])

      if (currentUser?.role === 'teacher') {
        setSelectedTeacher(String(currentUser.id))
      }

    } catch (e) {
      console.error('fetchSelectorData error:', e)
    }
  }

  // Get day of week name (MONDAY, TUESDAY, etc.) - Timezone-safe local parser
  const getDayOfWeekName = (dateStr: string): string => {
    if (!dateStr) return ''
    const cleanDateStr = dateStr.split('T')[0]
    const [year, month, day] = cleanDateStr.split('-').map(Number)
    const date = new Date(year, month - 1, day)
    const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY']
    return days[date.getDay()]
  }

  // Generate Google Meet Link dynamically
  const generateGoogleMeetLink = () => {
    const chars = 'abcdefghijklmnopqrstuvwxyz'
    const part1 = Array.from({ length: 3 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    const part2 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    const part3 = Array.from({ length: 3 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    const link = `https://meet.google.com/${part1}-${part2}-${part3}`
    setMeetingLink(link)
    setPlatform('GOOGLE_MEET')
  }

  // Fetch timetable entries when Class Section or Start Date changes
  useEffect(() => {
    const fetchTimetableForSectionAndDate = async () => {
      if (!schoolId || !selectedClassSection || !startDateTime || !currentSessionId) {
        setTimetableEntries([])
        return
      }

      const datePart = startDateTime.split('T')[0]
      if (!datePart) return

      setTimetableLoading(true)
      try {
        const response = await axios.get(`${API_URL}/school/${schoolId}/timetable`, {
          params: {
            class_section_id: parseInt(selectedClassSection),
            academic_session_id: currentSessionId
          }
        })

        if (response.data?.success) {
          const grid = response.data.data || {}
          const dayName = getDayOfWeekName(datePart)
          // Filter out slots that have valid periods, excluding break slots
          const dayEntries = (grid[dayName] || []).filter((entry: any) => {
            const baseCheck = entry.period_slot && !entry.period_slot.is_break && entry.subject_id && entry.teacher_id
            if (isTeacher) {
              return baseCheck && entry.teacher_id === currentUser.id
            }
            return baseCheck
          })
          setTimetableEntries(dayEntries)
        } else {
          setTimetableEntries([])
        }
      } catch (err) {
        console.error('Error fetching timetable for matching:', err)
        setTimetableEntries([])
      } finally {
        setTimetableLoading(false)
      }
    }

    fetchTimetableForSectionAndDate()
  }, [selectedClassSection, startDateTime, currentSessionId])

  // Fetch class-specific subjects when class section changes
  useEffect(() => {
    const fetchSubjectsForClass = async () => {
      if (!selectedClassSection) {
        setClassSectionSubjects([])
        return
      }
      const selectedCSObj = classSections.find(cs => String(cs.id) === String(selectedClassSection))
      if (!selectedCSObj || !selectedCSObj.class_id) {
        setClassSectionSubjects([])
        return
      }
      setSubjectsLoading(true)
      try {
        const { data } = await getClassSubjects(schoolId, selectedCSObj.class_id)
        if (data.success) {
          const mappings = data.data?.subjects || []
          const list = mappings.map((m: any) => m.subject).filter(Boolean)
          setClassSectionSubjects(list)
        } else {
          setClassSectionSubjects([])
        }
      } catch (err) {
        console.error('Failed to load class subjects', err)
        setClassSectionSubjects([])
      } finally {
        setSubjectsLoading(false)
      }
    }
    fetchSubjectsForClass()
  }, [selectedClassSection, classSections, schoolId])

  // Handle selecting a period from the matched timetable
  const handlePeriodChange = (entryIdStr: string) => {
    setSelectedPeriod(entryIdStr)
    if (!entryIdStr) return

    const entryId = parseInt(entryIdStr)
    const selectedEntry = timetableEntries.find(e => e.period_slot_id === entryId)
    if (selectedEntry) {
      // Auto-fill subject and teacher
      setSelectedSubject(String(selectedEntry.subject_id))
      setSelectedTeacher(String(selectedEntry.teacher_id))

      // Auto-update start time
      const datePart = startDateTime ? startDateTime.split('T')[0] : new Date().toISOString().split('T')[0]
      const slot = selectedEntry.period_slot
      if (slot && slot.start_time) {
        const [h, m] = slot.start_time.split(':')
        const formattedTime = `${h.padStart(2, '0')}:${m.padStart(2, '0')}`
        setStartDateTime(`${datePart}T${formattedTime}`)

        // Calculate duration
        if (slot.end_time) {
          const [sh, sm] = slot.start_time.split(':').map(Number)
          const [eh, em] = slot.end_time.split(':').map(Number)
          const diffMinutes = (eh * 60 + em) - (sh * 60 + sm)
          if (diffMinutes > 0) {
            setDuration(diffMinutes)
          }
        }
      }

      // Auto fill title
      const subjObj = subjects.find(s => s.id === selectedEntry.subject_id)
      const subjName = subjObj?.name || 'Subject'
      const slotName = slot?.name || 'Period'
      setTitle(`Online Class: ${subjName} (${slotName})`)
    }
  }

  // Dynamic filter for subjects select options
  const getFilteredSubjects = () => {
    return classSectionSubjects.length > 0 ? classSectionSubjects : subjects
  }

  useEffect(() => {
    fetchOnlineClasses()
    fetchSelectorData()
  }, [schoolId])

  const handleScheduleClass = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title || !selectedClassSection || !selectedSubject || !selectedTeacher || !meetingLink || !startDateTime) {
      alert('Please fill in all required fields.')
      return
    }

    try {
      const payload = {
        title,
        class_section_id: parseInt(selectedClassSection),
        subject_id: parseInt(selectedSubject),
        teacher_id: parseInt(selectedTeacher),
        platform,
        meeting_link: meetingLink,
        meeting_id: meetingId || undefined,
        meeting_password: meetingPassword || undefined,
        start_date_time: startDateTime,
        duration_minutes: duration,
        notes
      }

      const res = await axios.post(`${API_URL}/school/${schoolId}/online-classes`, payload)
      if (res.data?.success) {
        setShowModal(false)
        resetForm()
        fetchOnlineClasses()
      }
    } catch (err: any) {
      alert(err.response?.data?.error || 'Failed to schedule class.')
    }
  }

  const resetForm = () => {
    setTitle('')
    setSelectedClassSection('')
    setSelectedSubject('')
    setSelectedTeacher('')
    setPlatform('ZOOM')
    setMeetingLink('')
    setMeetingId('')
    setMeetingPassword('')
    setStartDateTime('')
    setDuration(40)
    setNotes('')
    setSelectedPeriod('')
    setTimetableEntries([])
  }

  const handleDeleteClass = async (id: number) => {
    if (!window.confirm('Are you sure you want to cancel and delete this class?')) return
    try {
      await axios.delete(`${API_URL}/school/${schoolId}/online-classes/${id}`)
      fetchOnlineClasses()
    } catch (err) {
      console.error(err)
    }
  }

  const handleStatusChange = async (id: number, status: string) => {
    try {
      await axios.patch(`${API_URL}/school/${schoolId}/online-classes/${id}/status`, { status })
      fetchOnlineClasses()
    } catch (err: any) {
      alert(err.response?.data?.error || 'Failed to update status.')
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'LIVE':
        return <span className='badge badge-success animate-pulse'>🔴 LIVE</span>
      case 'SCHEDULED':
        return <span className='badge badge-primary'>🗓️ SCHEDULED</span>
      case 'COMPLETED':
        return <span className='badge badge-secondary'>✓ COMPLETED</span>
      case 'CANCELLED':
        return <span className='badge badge-danger'>✕ CANCELLED</span>
      default:
        return <span className='badge badge-info'>{status}</span>
    }
  }

  return (
    <>
      <ToolbarWrapper />
      <Content>
        <div className='card mb-5 mb-xl-8'>
          <div className='card-header border-0 pt-5'>
            <h3 className='card-title align-items-start flex-column'>
              <span className='card-label fw-bold fs-3 mb-1'>Online Virtual Classes</span>
              <span className='text-muted mt-1 fw-semibold fs-7'>Schedule and manage virtual classrooms</span>
            </h3>
            <div className='card-toolbar'>
              <button className='btn btn-sm btn-primary' onClick={() => setShowModal(true)}>
                + Schedule Live Class
              </button>
            </div>
          </div>
          <div className='card-body py-3'>
            {loading ? (
              <div className='text-center py-5'>Loading classes...</div>
            ) : classesList.length === 0 ? (
              <div className='text-center py-5 text-muted'>No online classes scheduled yet. Click the button above to schedule one.</div>
            ) : (
              <div className='table-responsive'>
                <table className='table table-striped table-row-bordered table-row-gray-100 align-middle gs-0 gy-3'>
                  <thead>
                    <tr className='fw-bold text-muted'>
                      <th className='min-w-150px'>Title / Notes</th>
                      <th className='min-w-120px'>{getInstitutionType() === 'COACHING' ? 'Batch' : 'Class & Section'}</th>
                      <th className='min-w-120px'>Subject</th>
                      <th className='min-w-120px'>Teacher</th>
                      <th className='min-w-150px'>Date & Time</th>
                      <th className='min-w-100px'>Platform</th>
                      <th className='min-w-100px'>Status</th>
                      <th className='min-w-150px text-end'>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {classesList.map((cls) => (
                      <tr key={cls.id}>
                        <td>
                          <div className='text-dark fw-bold text-hover-primary fs-6'>{cls.title}</div>
                          {cls.notes && <span className='text-muted d-block fs-7'>{cls.notes}</span>}
                        </td>
                        <td>{cls.class_section?.class?.name} - {cls.class_section?.section?.name}</td>
                        <td>{cls.subject?.name}</td>
                        <td>{cls.teacher?.name}</td>
                        <td>
                          <span className='text-dark fw-bold fs-7'>
                            {new Date(cls.start_date_time).toLocaleString()}
                          </span>
                          <span className='text-muted d-block fs-8'>{cls.duration_minutes} Minutes</span>
                        </td>
                        <td>
                          <span className='text-muted fs-7 fw-bold'>{cls.platform}</span>
                        </td>
                        <td>{getStatusBadge(cls.status)}</td>
                        <td className='text-end'>
                          <a
                            href={cls.meeting_link}
                            target='_blank'
                            rel='noreferrer'
                            className='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1'
                            title='Join Class'
                          >
                            💻
                          </a>
                          <select
                            className='form-select form-select-sm d-inline-block w-auto me-1'
                            value={cls.status}
                            onChange={(e) => handleStatusChange(cls.id, e.target.value)}
                          >
                            <option value='SCHEDULED'>SCHEDULED</option>
                            <option value='LIVE'>LIVE</option>
                            <option value='COMPLETED'>COMPLETED</option>
                            <option value='CANCELLED'>CANCELLED</option>
                          </select>
                          <button
                            onClick={() => handleDeleteClass(cls.id)}
                            className='btn btn-icon btn-bg-light btn-active-color-danger btn-sm'
                            title='Delete'
                          >
                            🗑️
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Schedule Modal */}
        {showModal && (
          <div className='modal fade show d-block' style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
            <div className='modal-dialog modal-dialog-centered modal-lg'>
              <div className='modal-content'>
                <div className='modal-header'>
                  <h5 className='modal-title'>Schedule New Online Class</h5>
                  <button type='button' className='btn-close' onClick={() => setShowModal(false)}></button>
                </div>
                <form onSubmit={handleScheduleClass}>
                  <div className='modal-body'>
                    {/* Title */}
                    <div className='row mb-4'>
                      <div className='col-md-12'>
                        <label className='form-label required'>Class Title</label>
                        <input
                          type='text'
                          className='form-control form-control-solid'
                          value={title}
                          onChange={(e) => setTitle(e.target.value)}
                          placeholder='e.g. Mathematics Chapter 2 Review'
                          required
                        />
                      </div>
                    </div>

                    {/* Class & Date */}
                    <div className='row mb-4'>
                      <div className='col-md-6'>
                        <label className='form-label required'>{getInstitutionType() === 'COACHING' ? 'Batch' : 'Class & Section'}</label>
                        <select
                          className='form-select form-select-solid'
                          value={selectedClassSection}
                          onChange={(e) => {
                            setSelectedClassSection(e.target.value)
                            setSelectedSubject('')
                            setSelectedPeriod('')
                          }}
                          required
                        >
                          <option value=''>{getInstitutionType() === 'COACHING' ? 'Select Batch' : 'Select Class Section'}</option>
                          {classSections.map((cs) => (
                            <option key={cs.id} value={cs.id}>{cs.label}</option>
                          ))}
                        </select>
                      </div>
                      <div className='col-md-6'>
                        <label className='form-label required'>Start Date & Time</label>
                        <input
                          type='datetime-local'
                          className='form-control form-control-solid'
                          value={startDateTime}
                          onChange={(e) => setStartDateTime(e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    {/* Timetable Period Selection (appears only if entries are found) */}
                    {selectedClassSection && startDateTime && (
                      <div className='row mb-4 bg-light-primary p-3 rounded mx-1 align-items-center'>
                        <div className='col-md-12'>
                          <label className='form-label fw-bold text-primary mb-1'>
                            Schedule from Timetable Period {timetableLoading && <span className='spinner-border spinner-border-sm ms-2'></span>}
                          </label>
                          {timetableEntries.length > 0 ? (
                            <div>
                              <span className='fs-8 text-muted d-block mb-2'>
                                We found scheduled timetable periods for {getDayOfWeekName(startDateTime.split('T')[0])}! Select one to auto-fill Subject, Teacher, Time, and Duration:
                              </span>
                              <select
                                className='form-select form-select-sm form-select-solid border-primary'
                                value={selectedPeriod}
                                onChange={(e) => handlePeriodChange(e.target.value)}
                              >
                                <option value=''>— Do not link timetable period —</option>
                                {timetableEntries.map((entry) => (
                                  <option key={entry.period_slot_id} value={entry.period_slot_id}>
                                    {entry.period_slot?.name} ({entry.period_slot?.start_time} - {entry.period_slot?.end_time}) &middot; {subjects.find(s => s.id === entry.subject_id)?.name} &middot; {teachers.find(t => t.id === entry.teacher_id)?.name}
                                  </option>
                                ))}
                              </select>
                            </div>
                          ) : (
                            <span className='text-muted fs-7 d-block'>
                              No scheduled periods found in the timetable for {getDayOfWeekName(startDateTime.split('T')[0])}. You can manually set Subject and Teacher below.
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Subject & Teacher */}
                    <div className='row mb-4'>
                      <div className='col-md-6'>
                        <label className='form-label required'>Subject</label>
                        <select
                          className='form-select form-select-solid'
                          value={selectedSubject}
                          onChange={(e) => setSelectedSubject(e.target.value)}
                          required
                        >
                          <option value=''>Select Subject</option>
                          {getFilteredSubjects().map((sub: any) => (
                            <option key={sub.id} value={sub.id}>{sub.name}</option>
                          ))}
                        </select>
                      </div>
                      <div className='col-md-6'>
                        <label className='form-label required'>Assigned Teacher</label>
                        <select
                          className='form-select form-select-solid'
                          value={selectedTeacher}
                          onChange={(e) => setSelectedTeacher(e.target.value)}
                          disabled={isTeacher}
                          required
                        >
                          {isTeacher ? (
                            <option value={currentUser.id}>{currentUser.name || `Teacher #${currentUser.id}`}</option>
                          ) : (
                            <>
                              <option value=''>Select Teacher</option>
                              {teachers.map((t) => (
                                <option key={t.id} value={t.id}>{t.name}</option>
                              ))}
                            </>
                          )}
                        </select>
                      </div>
                    </div>

                    {/* Platform & Meeting Link */}
                    <div className='row mb-4'>
                      <div className='col-md-4'>
                        <label className='form-label required'>Platform</label>
                        <select
                          className='form-select form-select-solid'
                          value={platform}
                          onChange={(e) => setPlatform(e.target.value as any)}
                          required
                        >
                          <option value='ZOOM'>Zoom</option>
                          <option value='GOOGLE_MEET'>Google Meet</option>
                          <option value='TEAMS'>MS Teams</option>
                          <option value='OTHER'>Other</option>
                        </select>
                      </div>
                      <div className='col-md-8'>
                        <label className='form-label required'>Meeting Link (URL)</label>
                        <div className='input-group'>
                          <input
                            type='url'
                            className='form-control form-control-solid'
                            value={meetingLink}
                            onChange={(e) => setMeetingLink(e.target.value)}
                            placeholder='https://meet.google.com/...'
                            required
                          />
                          <button
                            type='button'
                            className='btn btn-light-primary fw-bold'
                            onClick={generateGoogleMeetLink}
                          >
                            Generate Meet Link
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Meeting ID & Password */}
                    <div className='row mb-4'>
                      <div className='col-md-6'>
                        <label className='form-label'>Meeting ID (Optional)</label>
                        <input
                          type='text'
                          className='form-control form-control-solid'
                          value={meetingId}
                          onChange={(e) => setMeetingId(e.target.value)}
                        />
                      </div>
                      <div className='col-md-6'>
                        <label className='form-label'>Meeting Password (Optional)</label>
                        <input
                          type='text'
                          className='form-control form-control-solid'
                          value={meetingPassword}
                          onChange={(e) => setMeetingPassword(e.target.value)}
                        />
                      </div>
                    </div>

                    {/* Duration & Notes */}
                    <div className='row mb-4'>
                      <div className='col-md-4'>
                        <label className='form-label required'>Duration (Minutes)</label>
                        <input
                          type='number'
                          className='form-control form-control-solid'
                          value={duration}
                          onChange={(e) => setDuration(parseInt(e.target.value))}
                          required
                        />
                      </div>
                      <div className='col-md-8'>
                        <label className='form-label'>Notes / Instructions</label>
                        <textarea
                          className='form-control form-control-solid'
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          rows={2}
                        />
                      </div>
                    </div>
                  </div>
                  <div className='modal-footer'>
                    <button type='button' className='btn btn-secondary' onClick={() => setShowModal(false)}>Close</button>
                    <button type='submit' className='btn btn-primary'>Schedule Class</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </Content>
    </>
  )
}

const OnlineClassesPageWrapper: FC = () => {
  return (
    <>
      <PageTitle breadcrumbs={[]}>Online Virtual Classes</PageTitle>
      <OnlineClassesPage />
    </>
  )
}

export { OnlineClassesPageWrapper }
